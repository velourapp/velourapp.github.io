(function() {
  const EDITOR_SEL = '.b-text-editor[contenteditable="true"], .tiptap.ProseMirror[contenteditable="true"]';
  window.addEventListener("message", (e) => {
    const m = e.data;
    if (e.source !== window || !m || m.source !== "fai-of") return;
    if (m.action === "setText") {
      let ok = false, err = "";
      try {
        const el = document.querySelector(EDITOR_SEL);
        if (el && el.editor) {
          el.editor.chain().focus().clearContent().insertContent(String(m.text || "")).run();
          ok = true;
        } else {
          err = el ? "no el.editor" : "no editor element";
        }
      } catch (e2) {
        err = e2 && e2.message || "exception";
      }
      window.postMessage({ source: "fai-of-bridge", action: "setText:done", ok, err }, "*");
    }
  });
  window.postMessage({ source: "fai-of-bridge", action: "ready" }, "*");
})();
