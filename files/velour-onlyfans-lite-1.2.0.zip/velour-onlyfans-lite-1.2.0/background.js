const BEFORE_CONSENT = true;
let _consentOk = false;
importScripts("i18n.js");
importScripts("crm-core.js");
importScripts("idb.js");
importScripts("consent.js");
importScripts("ai-core.js");
importScripts("parsers.js");
importScripts("contact-store.js");
ContactStore.initBackground({ hashString: Parsers.hashString });
const PLATFORM = true ? "onlyfans" : "fansly";
const BUILD = true ? "store" : "full";
const BUILDSTAMP = true ? "215b065@20261028.0206" : "dev";
function detectBrowserLang(supported, fallback = "en") {
  const langs = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || ""];
  for (const l of langs) {
    const code = (l || "").toLowerCase().split("-")[0];
    if (supported.includes(code)) return code;
  }
  return fallback;
}
const DEFAULT_SETTINGS = {
  nativeLanguage: detectBrowserLang(["en", "ru", "uk", "es", "pt", "de", "fr", "it", "pl", "tr"]),
  // список = опции #nativeLanguage в options.html
  translateProvider: "deepl",
  translateContext: true,
  // живой перевод с контекстом диалога (todo #44); false — как до фичи (откат без релиза, интерфейса у ключа нет)
  // Прокси Velour Cloud: ИИ + DeepL через сервер по license-ключу (мастер-ключи на сервере). Свои ключи — под Advanced.
  useProxy: false,
  licenseKey: "",
  proxyBaseUrl: "https://api.velourff.com",
  bugReportEnabled: false,
  // opt-in диагностика для саппорта (только тех-метаданные, без ПДн). Дефолт OFF
  aiProvider: "mock",
  /*@cws-cut-start@*/
  ollamaEndpoint: "http://localhost:11434",
  /*@cws-cut-end@*/
  claudeApiKey: "",
  deepLApiKey: "",
  geminiApiKey: "",
  groqApiKey: "",
  // OpenRouter — explicit-фолбэк (18+-совместимые модели). Работает поверх любого основного провайдера.
  openrouterApiKey: "",
  openrouterModel: AiCore.MODELS.openrouter,
  // платная база: чистый русский, стабильный JSON (euryale сыпал мусор). :free = общий пул → 429
  creatorGender: "female",
  geminiModel: AiCore.MODELS.gemini,
  // имена моделей — в ai-core.js (MODELS), модуль подключён выше
  basePrompt: "",
  // переопределение промпта — фича убрана из UI в v0.5 (дефолт пустой → инертно)
  interfaceLanguage: detectBrowserLang(["ru", "en", "es", "de", "fr", "tr"]),
  // язык интерфейса — из браузера, иначе 'en' (см. detectBrowserLang выше)
  collectDossier: true,
  // собирать ИИ-досье+бриф (профилирование контакта; нужен ключ ИИ). full-only; в store нет — только ручные заметки
  dossierDeltaMin: 1,
  // сколько новых сообщений ФАНА копить до обновления досье. Каждое обновление = обращение из пакета,
  // а по одной короткой реплике фактов обычно нет. 1 = как было; больше — реже обращения, позже бриф. full-only
  crmEnabled: true,
  // CRM (база фанов): тумблер мастера настройки → прячет кнопку CRM в попапе. full-only
  coachEnabled: true,
  // «Советы» (коучинг в панели): тумблер мастера → прячет блок #fai-coach. full-only
  setupCompleted: false,
  // мастер настройки пройден — чтобы не открывать его повторно. full-only
  // v0.5 плашка-тумблеры (попап пишет → content реагирует через applyOwnerSettings/onChanged)
  masterEnabled: true,
  // главный рубильник («Velour на <площадке сборки>», попап) — выкл = стоп ВСЕЙ работы: панели, пульт, сканы, уведомления
  translatorEnabled: true,
  // переводчик (отображение перевода владельцу)
  aiEnabled: false,
  // авто-варианты (3 ответа): по умолчанию ВЫКЛ, тумблер скрыт из попапа (Alex 2026-07-28)
  carouselEnabled: false,
  // карусель-монитор вкл/выкл (стоп при master off)
  panelHidden: false,
  // рабочая панель скрыта (косметика; бот всё равно работает)
  // Персонаж
  creatorName: "",
  creatorAge: "",
  creatorCity: "",
  creatorAbout: "",
  creatorTimezone: "",
  // IANA TZ легенды (напр. Europe/Istanbul). Пусто = зона браузера
  // Подписки / тиры
  tiersInfo: "",
  // Кастомный контент: цена/условия удалены из продукта (2026-08-17) — осталось только табу (в «Персонаже»)
  customTaboo: "",
  // Стиль общения (few-shot примеры)
  styleExamples: "",
  styleDescription: "",
  // калибровка стиля (онбординг Фаза 2) — плоский ключ: читается buildPrompt + переживает сохранение options
  styleLearnEnabled: false,
  // показывать в панели кнопку 📚 «учиться стилю с чата» — действие разовое, дефолт OFF
  // Обработка цензуры: при блоке explicit → кокетливо-уклончивый ответ.
  // Отключить, если используешь локальную 18+-совместимую модель
  nsfwGracefulHandling: false,
  // (Alex 2026-07-29) выкл — работаем на 18+-совместимой модели, coy-фолбэк не нужен
  // Темп работы карусели (карусель = зеркало в Телеграм; авто-отправка удалена 2026-08-08).
  // Мёртвые поля автопилота (nightAutoSend / nightMaxPerSession / nightTyping / nightConfirmSend) убраны
  // 2026-08-14: их никто не читал, а тумблеры в UI врали пользователю, что что-то включают.
  frameMinVideoSec: 120,
  // кадры из видео снимаем только у роликов НЕ КОРОЧЕ этого, сек (0 = у всех).
  // Дефолт 120: у коротких роликов обложка и так почти всё показывает, а разметка
  // кадров — самая дорогая часть (≈13 с на кадр). Порог опускается вручную.
  nightPauseMin: 40,
  // мин. пауза между диалогами, сек
  nightPauseMax: 180,
  // макс. пауза, сек
  nightMsPerWord: 700,
  // задержка на слово при ручной отправке из панели, мс (cap ~25с на сообщение)
  briefStaleHours: 240,
  // через сколько часов без упоминания бриф считается устаревшим (Alex 2026-07-29: 10 дней)
  // Красные линии — на что модель НЕ соглашается (держит дистанцию художника)
  redLines: "\u041D\u0435 \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u044E\u0441\u044C \u043D\u0430 \u043B\u0438\u0447\u043D\u044B\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0438 \u0438 \u0441\u0432\u0438\u0434\u0430\u043D\u0438\u044F, \u0432\u0438\u0434\u0435\u043E\u0437\u0432\u043E\u043D\u043A\u0438 \u0438 \u0441\u043E\u0437\u0432\u043E\u043D\u044B, \u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u0432 Discord / Telegram / WhatsApp / \u0434\u0440\u0443\u0433\u0438\u0435 \u043C\u0435\u0441\u0441\u0435\u043D\u0434\u0436\u0435\u0440\u044B \u0432\u043D\u0435 Fansly, \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0444\u0438\u043B\u044C\u043C\u043E\u0432, \u043E\u0431\u043C\u0435\u043D \u043B\u0438\u0447\u043D\u044B\u043C\u0438 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430\u043C\u0438. \u0414\u0435\u0440\u0436\u0443 \u0434\u0438\u0441\u0442\u0430\u043D\u0446\u0438\u044E \u2014 \u043E\u0431\u0449\u0430\u0435\u043C\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0434\u0435\u0441\u044C.",
  // Кастомные интенты: [{ label, emoji, keywords, instruction }]
  customIntents: [],
  // Откровенный сексинг: false = бот уклоняется (артист-дистанция), true = поддерживает в характере (через Groq)
  allowExplicit: true,
  // (Alex 2026-07-29)
  // Тиры (имя/цена/цвет) авто-снимаются со страницы /posts в fansly_tiers — ручного маппинга больше нет
  // Телеграм-уведомления (Блок 10, Phase 1: подключение + срочные, один чат)
  telegramEnabled: false,
  telegramBotToken: "",
  telegramChatId: "",
  tgNotifyBrief: true,
  // 🆕 собран бриф на кастом
  tgNotifyDialogue: true,
  // 💬 весь диалог в реалтайме (Alex 2026-07-29)
  tgMuteExcluded: true,
  // не зеркалить в ТГ исключённых (скрытая пометка «исключён», Alex 2026-07-29); токсичность снята (todo п.48)
  tgCleanProcessed: true,
  // убирать отработанные сообщения (варианты/подтверждения) из ТГ — deleteMessage (Alex 2026-07-29)
  tgTopics: true,
  // топики: ветка на фана + ⚠️важное (Alex 2026-07-29); требует супергруппу-форум, бот админ
  // Нотификации: монитор лайков/фолловов на /notifications → кого стоит пригласить в диалог
  notificationsEnabled: true,
  // мониторинг активности: по умолчанию ВКЛ (Alex 2026-07-28); тумблер скрыт из попапа, панель аутрича не показываем — работает только фоновый скан (леджер/ТГ-сигналы)
  notifyLikeThreshold: 3,
  // лайков (пост+медиа) для флага на аутрич; follower флагует сразу
  notifyPaidOnly: false,
  // нотификации: только платные подписки (бесплатных-фолловеров не флагуем)
  inviteSilenceDays: 7,
  // ТГ-пинг «стоит пригласить» лайкера — только если чат молчит ≥N дней (или истории нет); живой диалог = шум
  inviteInstruction: "\u041D\u0430\u043F\u0438\u0448\u0438 \u0435\u043C\u0443 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0435 \u0442\u0451\u043F\u043B\u043E\u0435 \u043F\u0435\u0440\u0432\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u2014 \u043E\u043D \u043D\u0435\u0434\u0430\u0432\u043D\u043E \u043F\u0440\u043E\u044F\u0432\u0438\u043B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u044C (\u043B\u0430\u0439\u043A\u0438/\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430). \u041F\u043E\u0437\u043D\u0430\u043A\u043E\u043C\u044C\u0441\u044F \u0438 \u043C\u044F\u0433\u043A\u043E \u043F\u0440\u0438\u0433\u043B\u0430\u0441\u0438 \u043F\u043E\u043E\u0431\u0449\u0430\u0442\u044C\u0441\u044F. \u0411\u0435\u0437 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u0438 \u0434\u0430\u0432\u043B\u0435\u043D\u0438\u044F, \u043F\u043E-\u0447\u0435\u043B\u043E\u0432\u0435\u0447\u0435\u0441\u043A\u0438, \u0432 \u0442\u0432\u043E\u0451\u043C \u0441\u0442\u0438\u043B\u0435."
};
const RESET_SETTINGS = {
  translatorEnabled: DEFAULT_SETTINGS.translatorEnabled,
  bugReportEnabled: DEFAULT_SETTINGS.bugReportEnabled
};
const BUG_BUF_KEY = "fansly_bugbuf";
const BUG_BUF_MAX = 50;
const BUG_FLUSH_AT = 30;
const BUG_FLUSH_ALARM = "fansly_bug_flush";
const BUG_FLUSH_HOURS = 6;
const BUG_THROTTLE_MS = 6e4;
const BUG_CODES = /* @__PURE__ */ new Set([
  "exception",
  "net_fail",
  "all_providers_failed",
  "proxy_401",
  "proxy_402",
  "sync_timeout",
  "vault_notend",
  "vault_drift",
  "vault_short",
  "stale_lock",
  // vault_short — папка собрана не полностью (недобор против счётчика сайта)
  "storage_quota",
  "quota_bytes_err",
  "sel_miss",
  "trial_fail",
  // конверт /v1/trial не принят (наша ошибка сборки запроса, не состояние человека)
  "catalog_write_fail",
  // пачка правок каталога не доехала до базы (мост content→background→IndexedDB)
  // На сайте несколько папок с одним именем (#97): сверить такую нельзя, плашка каталога просит переименовать.
  // Наружу — только числа: folders (сколько имён задвоено) и got (сколько плиток их носят); имён папок нет.
  // ⚠️ Код новый, а сервер режет по СВОЕМУ списку (REPORT_CODES, другой репозиторий) и незнакомое выбрасывает
  // молча: пока код не добавлен там, событие не доезжает, а selftest прокси краснеет на сверке списков.
  "vault_dupname",
  // Живучесть пульта. Подвид едет в поле code: gap (вкладка замирала), stall (карусель не шагает),
  // nav_stuck (сторож снял залипший мьютекс), discard (вкладку выгрузили вопреки запрету). Один код на
  // все подвиды намеренно: КОДЫ режет ещё и сервер по своему списку в другом репозитории, и незнакомый
  // он выбрасывает молча (так потеряли vault_short) — а поле code уже в обоих whitelist, поэтому новый
  // подвид не потребует деплоя прокси.
  "pult_health"
]);
const CALL_KINDS = /* @__PURE__ */ new Set([
  "reply",
  // ответ фану — панель и Телеграм-пульт
  "translate",
  // перевод через ИИ
  "translate_live",
  // перевод живого сообщения с контекстом диалога — человек смотрит на панель (todo #44); на прокси не фон
  "dossier",
  // досье по кнопке
  "dossier_auto",
  // досье фоном
  "post",
  // генерация поста
  "coach",
  // совет по диалогу
  "chat",
  // чат с ИИ в панели
  "diag",
  // вопрос по «Динамике бизнеса»
  "diag_review",
  // полный разбор «Динамики» (23.10: в пакете дороже — 30 обращений против 15 у вопроса; прокси различает по виду)
  "digest",
  // черновик из дайджеста
  "onboarding",
  // ход интервью первого запуска
  "onboarding_style"
  // разбор транскрипта в профиль стиля
]);
const NO_DASH_RULE = 'NEVER use a dash as punctuation: no "\u2014", no "\u2013", and no lone "-" between words or clauses. That is a tell-tale AI habit and nobody writes that way. Use a comma, a full stop, "..." or just start a new sentence. Hyphens INSIDE words (\u043A\u0442\u043E-\u0442\u043E, \u043F\u043E-\u0440\u0443\u0441\u0441\u043A\u0438, e-mail) are fine.';
const NO_DASH_RULE_TRANSLATE = 'NEVER use a dash as punctuation in the translation: no "\u2014", no "\u2013", and no lone "-" between words or clauses. This holds even when the original text has one: drop it and rewrite that spot with a comma, a full stop or "...". Change the punctuation only, never the wording or the meaning. Hyphens INSIDE words are fine.';
const COACH_MAX_TOKENS = 2048;
AiCore.init({
  getSettings,
  saveSettings,
  bugLog,
  bugProxyFail,
  netFailKind,
  fetchWithTimeout,
  consentGiven,
  consentError,
  DEFAULT_SETTINGS,
  CALL_KINDS,
  NO_DASH_RULE_TRANSLATE,
  BUILD,
  PLATFORM
});
const BUG_FIELDS = /* @__PURE__ */ new Set([
  "ep",
  "status",
  "code",
  "provider",
  "scan",
  "folders",
  "drift",
  "folderRole",
  "ageMs",
  "pct",
  "usedKb",
  "key",
  "got",
  "exp",
  "name",
  "frame",
  "frame2",
  "n",
  "src",
  "batches",
  "moved",
  "passes"
  // недобор в хранилище: сдвиг ленты и число проходов — по ним видно, листали мы или сайт не отдал
]);
const BUG_ID_FIELDS = ["ep", "status", "code", "provider", "scan", "folderRole", "key", "name", "frame", "frame2", "src"];
let _bugEnabled = false;
const _bugCrumbs = [];
function bugCrumb(code) {
  if (code) {
    _bugCrumbs.push(code);
    if (_bugCrumbs.length > 8) _bugCrumbs.shift();
  }
}
function bugStackFrames(err) {
  const out = { name: err && err.name || "Error" };
  const stack = err && err.stack || "";
  const re = /(?:chrome-extension:\/\/[a-z]+\/)?([\w.-]+\.js):(\d+):(\d+)/g;
  const frames = [];
  let m;
  while ((m = re.exec(stack)) && frames.length < 2) frames.push(`${m[1]}:${m[2]}:${m[3]}`);
  if (frames[0]) out.frame = frames[0];
  if (frames[1]) out.frame2 = frames[1];
  return out;
}
function bugSanitize(fields) {
  const out = {};
  if (fields && typeof fields === "object") {
    for (const k of Object.keys(fields)) {
      if (!BUG_FIELDS.has(k)) continue;
      const v = fields[k];
      if (typeof v === "number" && Number.isFinite(v)) out[k] = v;
      else if (typeof v === "boolean") out[k] = v;
      else if (typeof v === "string") {
        const s = v.replace(/\s+/g, " ").trim().slice(0, 48);
        if (s) out[k] = s;
      }
    }
  }
  return out;
}
function bugSanCrumbs(bc) {
  if (!Array.isArray(bc)) return void 0;
  const out = bc.filter((x) => typeof x === "string").map((x) => x.replace(/\s+/g, "").slice(0, 24)).slice(-8);
  return out.length ? out : void 0;
}
const BUG_NOTE = /* @__PURE__ */ new Set([
  "vault_drift",
  // счётчики каталога разошлись с сайтом — обычное дело, лечится баннером и нажатием
  "proxy_402",
  // месячный пакет исчерпан — это про деньги, а не про поломку
  "storage_quota",
  // хранилище браузера заполняется — предупреждение, а не отказ
  "vault_dupname"
  // два альбома с одним именем завёл сам человек — это состояние его аккаунта, а не наша поломка
]);
let _bugQueue = Promise.resolve();
function bugBufEdit(edit) {
  const step = _bugQueue.then(async () => {
    const buf = await new Promise((r) => chrome.storage.local.get(BUG_BUF_KEY, (d) => r(d[BUG_BUF_KEY] || [])));
    const next = edit(buf);
    await new Promise((r) => chrome.storage.local.set({ [BUG_BUF_KEY]: next }, r));
    return next;
  });
  _bugQueue = step.catch(() => {
  });
  return step;
}
async function bugLog(code, fields, bc, kind) {
  if (!_bugEnabled) return;
  if (!BUG_CODES.has(code)) return;
  const ev = { t: Date.now(), c: code, k: kind || (BUG_NOTE.has(code) ? "note" : "bug"), ...bugSanitize(fields) };
  const crumbs = bugSanCrumbs(bc) || (_bugCrumbs.length ? _bugCrumbs.slice() : void 0);
  if (crumbs) ev.bc = crumbs;
  const buf = await bugBufEdit((buf2) => {
    const last = buf2[buf2.length - 1];
    if (last && last.c === code && last.k === ev.k && BUG_ID_FIELDS.every((f) => last[f] === ev[f]) && ev.t - (last.t || 0) < BUG_THROTTLE_MS && !(_bugSendingTs && _bugSendingTs.has(last.t))) {
      last.n = (last.n || 1) + 1;
      last.t = ev.t;
    } else {
      buf2.push(ev);
      while (buf2.length > BUG_BUF_MAX) buf2.shift();
    }
    return buf2;
  });
  if (buf.length >= BUG_FLUSH_AT) flushBugReports();
}
async function refreshBugEnabled() {
  try {
    const s = await getSettings();
    _bugEnabled = s.bugReportEnabled === true;
  } catch (e) {
  }
}
async function bugDeviceId() {
  const d = await new Promise((r) => chrome.storage.local.get("fansly_device_id", (x) => r(x.fansly_device_id)));
  if (d) return d;
  const id = self.crypto && self.crypto.randomUUID ? self.crypto.randomUUID().replace(/-/g, "").slice(0, 8) : Math.random().toString(16).slice(2, 10);
  await new Promise((r) => chrome.storage.local.set({ fansly_device_id: id }, r));
  return id;
}
async function bugCheckQuota() {
  if (!_bugEnabled || !chrome.storage.local.getBytesInUse) return;
  try {
    const used = await new Promise((r) => chrome.storage.local.getBytesInUse(null, (b) => r(b || 0)));
    const quota = chrome.storage.local.QUOTA_BYTES || 10485760;
    const pct = Math.round(used / quota * 100);
    if (pct >= 80) bugLog("storage_quota", { pct, usedKb: Math.round(used / 1024) });
  } catch (e) {
  }
}
function netFailKind(e) {
  if (e && e.faiConsent) return null;
  if (e && e.name === "AbortError") return { code: "timeout", k: "note" };
  return { code: "fetch", k: "bug" };
}
function bugProxyFail(ep, status, code) {
  if (code === "upstream_saturated") return;
  if (status === 401) bugLog("proxy_401", { ep });
  else if (status === 402) bugLog("proxy_402", { ep });
  else if (code === "all_providers_failed") bugLog("all_providers_failed", { ep });
  else bugLog("net_fail", { ep, status: status || 0, code: code || void 0 });
}
let _bugFlushing = false;
let _bugSendingTs = null;
async function flushBugReports() {
  if (_bugFlushing) return;
  _bugFlushing = true;
  try {
    const s = await getSettings();
    if (s.bugReportEnabled !== true) return;
    if (!s.licenseKey) return;
    const sending = await bugBufEdit((buf) => {
      _bugSendingTs = new Set(buf.map((e) => e.t));
      return buf;
    });
    if (!sending.length) return;
    const sentTs = _bugSendingTs;
    const resp = await AiCore.proxyCall("/v1/report", {
      method: "POST",
      headers: { "Authorization": `Bearer ${s.licenseKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        meta: { version: chrome.runtime.getManifest().version, build: BUILD, platform: PLATFORM, stamp: BUILDSTAMP, device: await bugDeviceId(), ts: Date.now() },
        events: sending
      })
    }, 2e4);
    if (resp && resp.ok) {
      await bugBufEdit((cur) => cur.filter((e) => !sentTs.has(e.t)));
    }
  } catch (e) {
  } finally {
    _bugFlushing = false;
    _bugSendingTs = null;
  }
}
function armBugFlush() {
  if (!chrome.alarms) return;
  chrome.alarms.create(BUG_FLUSH_ALARM, { periodInMinutes: BUG_FLUSH_HOURS * 60, delayInMinutes: 3 });
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === BUG_FLUSH_ALARM) {
    bugCheckQuota();
    flushBugReports();
    AiCore.trCacheSweep().catch(() => {
    });
  }
});
const ENDPOINTS_ALARM = "fansly_endpoints_refresh";
function armEndpointsRefresh() {
  if (!chrome.alarms) return;
  chrome.alarms.create(ENDPOINTS_ALARM, { periodInMinutes: 24 * 60, delayInMinutes: 1 });
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ENDPOINTS_ALARM) AiCore.endpointsMaintain().catch(() => {
  });
});
if (typeof self !== "undefined" && self.addEventListener) {
  self.addEventListener("error", (e) => {
    try {
      bugLog("exception", { src: "bg", ...bugStackFrames(e.error) });
    } catch (_) {
    }
  });
  self.addEventListener("unhandledrejection", (e) => {
    try {
      bugLog("exception", { src: "bg", ...bugStackFrames(e.reason) });
    } catch (_) {
    }
  });
}
chrome.runtime.onInstalled.addListener((details) => {
  console.log("[FanslyAI] onInstalled v0.3");
  armBugFlush();
  armEndpointsRefresh();
  refreshBugEnabled();
  purgeTransCacheOnce();
  AiCore.trCacheMigrateOnce();
  mergeCrmNotesOnce();
  seedLikesOnce();
  chrome.storage.local.remove("fansly_ai_log");
  FaiDB.ensureMigrated().catch((e) => console.warn("[FanslyAI] \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u043E\u0442\u043B\u043E\u0436\u0435\u043D\u0430:", e && e.message));
});
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(() => {
  armBugFlush();
  armEndpointsRefresh();
  refreshBugEnabled();
  refreshSelectors();
  AiCore.trCacheMigrateOnce();
  FaiDB.ensureMigrated().catch(() => {
  });
});
function purgeTransCacheOnce() {
  chrome.storage.local.get("fansly_trcache_purged", (d) => {
    if (d.fansly_trcache_purged) return;
    chrome.storage.local.get(null, (all) => {
      const keys = Object.keys(all).filter((k) => k.startsWith("tr_"));
      const done = () => chrome.storage.local.set({ fansly_trcache_purged: 1 });
      if (keys.length) chrome.storage.local.remove(keys, done);
      else done();
    });
  });
}
function seedLikesOnce() {
  chrome.storage.local.get(["fansly_likes_seeded", "fansly_outreach", "fansly_likes"], (d) => {
    if (d.fansly_likes_seeded) return;
    const store = d.fansly_likes || {};
    const writes = CRM.likesSeed(store, d.fansly_outreach || {}) ? { fansly_likes: store } : {};
    writes.fansly_likes_seeded = 1;
    chrome.storage.local.set(writes);
  });
}
function likesFromOutreach(outreach) {
  const s = {};
  return CRM.likesSeed(s, outreach) ? s : null;
}
const PINNED_MAX_BG = 15;
function mergeCrmNotesOnce() {
  chrome.storage.local.get(["fansly_crm_notes_merged", "fansly_crm_notes"], (d) => {
    if (d.fansly_crm_notes_merged) return;
    const notes = d.fansly_crm_notes || {};
    const handles = Object.keys(notes).filter((h) => String(notes[h] || "").trim());
    if (!handles.length) {
      chrome.storage.local.set({ fansly_crm_notes_merged: 1 });
      return;
    }
    chrome.storage.local.get(null, (all) => {
      const byHandle = {};
      for (const k in all) {
        if (!k.startsWith("fai_contact_") || !all[k] || !all[k].handle) continue;
        byHandle[String(all[k].handle).toLowerCase()] = k;
      }
      const writes = { fansly_crm_notes_premerge: notes };
      const leftover = {};
      let moved = 0, orphan = 0;
      for (const h of handles) {
        const key = byHandle[h];
        if (!key) {
          leftover[h] = notes[h];
          orphan++;
          continue;
        }
        const rec = all[key];
        const dz = rec.dossier || (rec.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null });
        if (!dz.facts) dz.facts = [];
        if (!dz.factDates) dz.factDates = {};
        if (!dz.manualFacts) dz.manualFacts = [];
        const lines = String(notes[h]).split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
        for (const line of lines) {
          if (!dz.manualFacts.includes(line)) dz.manualFacts.push(line);
          if (!dz.facts.includes(line)) dz.facts.push(line);
          if (!dz.factDates[line]) dz.factDates[line] = Date.now();
        }
        writes[key] = rec;
        moved++;
      }
      writes.fansly_crm_notes = leftover;
      writes.fansly_crm_notes_merged = 1;
      chrome.storage.local.set(writes, () => {
        console.log(`[FanslyAI] \u0437\u0430\u043C\u0435\u0442\u043A\u0438 \xAB\u0424\u0430\u043D\u043E\u0432\xBB \u0441\u0432\u0435\u0434\u0435\u043D\u044B \u0441 \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u0451\u043D\u043D\u044B\u043C\u0438 \u0444\u0430\u043A\u0442\u0430\u043C\u0438: \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u043E ${moved}, \u0431\u0435\u0437 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430 ${orphan} (\u043A\u043E\u043F\u0438\u044F \u2014 fansly_crm_notes_premerge)`);
      });
    });
  });
}
async function setPinnedFacts(handle, lines) {
  const h = String(handle || "").toLowerCase();
  if (!h) return { success: false, error: "no handle" };
  const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
  const hits = [];
  for (const k in all) {
    if (k.startsWith("fai_contact_") && all[k] && all[k].handle && String(all[k].handle).toLowerCase() === h) hits.push(k);
  }
  if (!hits.length) return { success: false, error: "no contact" };
  if (hits.length > 1) return { success: false, error: "ambiguous handle", keys: hits.length };
  const key = hits[0];
  const wanted = (Array.isArray(lines) ? lines : []).map((s) => String(s).trim()).filter(Boolean);
  const next = wanted.slice(0, PINNED_MAX_BG);
  const ok = await ContactStore.patchRecord(key, (rec) => {
    const dz = rec.dossier || { facts: [], closeness: "new", topics: [], lastMessageAt: null };
    if (!dz.facts) dz.facts = [];
    if (!dz.factDates) dz.factDates = {};
    dz.manualFacts = next;
    for (const f of next) {
      if (!dz.facts.includes(f)) dz.facts.push(f);
      if (!dz.factDates[f]) dz.factDates[f] = Date.now();
    }
    return { dossier: dz };
  });
  if (!ok) return { success: false, error: "no contact" };
  return { success: true, pinned: next.length, dropped: wanted.length - next.length };
}
refreshBugEnabled();
const CONFIG_ORIGIN = "https://velourapp.github.io";
const CONFIG_MAX_BYTES = 65536;
const UPDATE_URL_HOSTS = /* @__PURE__ */ new Set(["velourapp.github.io", "github.com", "objects.githubusercontent.com"]);
async function fetchPinnedJson(url) {
  const r = await fetchWithTimeout(url + "?t=" + Date.now(), { method: "GET", cache: "no-store", credentials: "omit" }, 1e4, BEFORE_CONSENT);
  if (!r.ok) return null;
  try {
    if (new URL(r.url).origin !== CONFIG_ORIGIN) return null;
  } catch (e) {
    return null;
  }
  const text = await r.text();
  if (text.length > CONFIG_MAX_BYTES) return null;
  try {
    return JSON.parse(text);
  } catch (e) {
    return null;
  }
}
const SELECTORS_URL = "https://velourapp.github.io/selectors.json";
const SEL_MAX_KEYS = 200;
const SEL_MAX_CAND = 8;
const SEL_MAX_LEN = 200;
const SEL_KEY_RE = /^[A-Za-z0-9_]{1,40}$/;
function validSelOverrides(d) {
  if (!d || typeof d !== "object" || Array.isArray(d)) return null;
  const out = {};
  for (const plat of [
    "fansly",
    "onlyfans"
    /*@of-end@*/
  ]) {
    const src = d[plat];
    if (!src || typeof src !== "object" || Array.isArray(src)) continue;
    const dst = {};
    let n = 0;
    for (const key of Object.keys(src)) {
      if (n >= SEL_MAX_KEYS) break;
      if (!SEL_KEY_RE.test(key)) continue;
      const v = src[key];
      const list = (Array.isArray(v) ? v : [v]).filter((s) => typeof s === "string" && s.trim() && s.length <= SEL_MAX_LEN).slice(0, SEL_MAX_CAND);
      if (!list.length) continue;
      dst[key] = list;
      n++;
    }
    if (n) out[plat] = dst;
  }
  return Object.keys(out).length ? out : null;
}
async function fetchSelOverrides() {
  try {
    const raw = await fetchPinnedJson(SELECTORS_URL);
    const clean = validSelOverrides(raw);
    if (clean) chrome.storage.local.set({ fansly_sel_overrides: clean });
    else chrome.storage.local.remove("fansly_sel_overrides");
  } catch (e) {
  }
}
let _selFetch = null, _selFetchAt = 0;
function refreshSelectors(maxAgeMs = 6e4) {
  if (_selFetch && Date.now() - _selFetchAt < maxAgeMs) return _selFetch;
  _selFetchAt = Date.now();
  return _selFetch = fetchSelOverrides();
}
refreshSelectors();
setTimeout(() => {
  try {
    AiCore.requestTrial();
  } catch (e) {
  }
}, 5e3);
chrome.tabs.onRemoved.addListener((id) => {
});
const PRICING_URL = "https://velourff.com/buy";
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case "TRANSLATE":
      AiCore.translate(
        request.text,
        request.targetLang,
        request.genderHint,
        request.toGender,
        request.kind,
        false,
        Array.isArray(request.ctx) && request.ctx.length ? request.ctx : null,
        typeof request.fanLang === "string" && request.fanLang ? request.fanLang : null
      ).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TRANSLATE_BATCH":
      AiCore.translateBatch(
        request.texts,
        request.targetLang,
        request.genderHint,
        request.toGender,
        request.cheapOnly === true,
        Array.isArray(request.ctx) && request.ctx.length ? request.ctx : null,
        typeof request.fanLang === "string" && request.fanLang ? request.fanLang : null
      ).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "GET_SETTINGS":
      getSettings().then((s) => sendResponse({ success: true, result: s }));
      return true;
    // Открыть настройки из КОНТЕНТ-СКРИПТА. Сам он этого не может: chrome.tabs ему недоступен, а
    // options.html не лежит в web_accessible_resources — из-за этого в панели были подсказки словами
    // вместо кнопок (см. humanError в CHANGELOG). Теперь кнопка настоящая.
    // ⚠️ BUILD-NEUTRAL: плашку «ещё не настроено» показывает и переводчик (там она про перевод), значит
    // обработчик нужен обеим сборкам — внутри full-региона кнопка в store молча не делала бы ничего.
    // ⚠️ Вкладку открываем сами, как попап, мастер и онбординг. chrome.runtime.openOptionsPage() здесь не годится:
    // страницы настроек в манифесте нет, и он ВСЕГДА отказывал — промисом, а try/catch вокруг ловил только синхронную
    // ошибку, так что запасной путь не срабатывал и кнопка молчала («Could not create an options page», живая проверка
    // #163 08.10; «Настроить» на плашке «нет ключа» молчала так же с 25.08).
    case "OPEN_OPTIONS":
      chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
      sendResponse({ success: true });
      return true;
    case "ABOUT_INFO":
      bugDeviceId().then((id) => sendResponse({ success: true, deviceId: id, stamp: BUILDSTAMP, build: BUILD }));
      return true;
    case "REDEEM_TRIAL_CODE":
      AiCore.requestTrial(String(request.code || "").slice(0, 32)).then((res) => sendResponse(res || { ok: false }));
      return true;
    case "OPEN_TRIAL_PATH":
      AiCore.readTrialState().then((st) => {
        chrome.tabs.create({ url: st && st.closed === "tg" ? "https://t.me/velourmebot" : PRICING_URL });
      });
      sendResponse({ success: true });
      return true;
    case "OPEN_PRICING":
      chrome.tabs.create({ url: PRICING_URL });
      sendResponse({ success: true });
      return true;
    case "SAVE_SETTINGS":
      if (request.settings && Object.prototype.hasOwnProperty.call(request.settings, "licenseKey")) AiCore.subPauseClear();
      saveSettings(request.settings, () => {
        refreshBugEnabled();
        armBugFlush();
        sendResponse({ success: true });
        if (request.settings && request.settings.privacyConsentAt) AiCore.requestTrial();
      });
      return true;
    case "RESET_SETTINGS":
      saveSettings(JSON.parse(JSON.stringify(RESET_SETTINGS)), () => {
        refreshBugEnabled();
        armBugFlush();
        sendResponse({ success: true, result: Object.keys(RESET_SETTINGS) });
      });
      return true;
    case "REPORT_BUG":
      bugLog(request.code, request.fields, request.bc, request.k);
      return false;
    case "GET_QUOTA":
      AiCore.getQuota(request.force === true).then((q) => sendResponse({ success: true, result: q })).catch(() => sendResponse({ success: true, result: null }));
      return true;
    case "SET_PINNED_FACTS":
      setPinnedFacts(request.handle, request.facts).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "GET_ALL_CONTACTS":
      getAllContacts().then((contacts) => sendResponse({ success: true, result: contacts }));
      return true;
    case "IMPORT_DATA":
      importData(request.data, (err) => sendResponse(err ? { success: false, error: err } : { success: true }));
      return true;
    case "OPEN_WORK_TAB":
      openWorkTab(sender.tab?.id ?? null).then((r) => sendResponse(r));
      return true;
    // ── Приватность: стирание данных (build-neutral — есть кеш переписки и в store) ──
    case "WIPE_FAN_DATA":
      (async () => {
        const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
        const KILL = ["fansly_ai_log", "fansly_earnings", "fansly_subs", "fansly_ledger", "fansly_purchases", "fansly_outreach", "fansly_outreach_done", "fansly_likes", "fansly_msg_ts", "fansly_mirror_since", "fansly_crm_notes", "fansly_todo_drafts", "fansly_todo_ack", "fansly_row_mirrored", "fansly_row_last", "fansly_tg_fan_ctx"];
        const keys = Object.keys(all).filter((k) => KILL.includes(k) || k.startsWith("fai_contact_") || k.startsWith("tr_"));
        if (keys.length) await new Promise((r) => chrome.storage.local.remove(keys, r));
        if (all.fansly_tg_topics && all.fansly_tg_topics.fans) {
          const tp = all.fansly_tg_topics;
          tp.fans = {};
          await new Promise((r) => chrome.storage.local.set({ fansly_tg_topics: tp }, r));
        }
        sendResponse({ success: true, removed: keys.length });
      })();
      return true;
    case "WIPE_ALL":
      (async () => {
        try {
          await FaiDB.deleteDatabase();
        } catch (e) {
          sendResponse({ success: false, error: e.message || "idb_blocked" });
          return;
        }
        const KEEP = ["fansly_ai_settings", "fansly_device_id"];
        const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
        const keys = Object.keys(all).filter((k) => !KEEP.includes(k));
        if (keys.length) await new Promise((r) => chrome.storage.local.remove(keys, r));
        sendResponse({ success: true, removed: keys.length });
      })();
      return true;
    case "DELETE_FAN":
      (async () => {
        const h = (request.handle || "").toLowerCase();
        const name = request.name || "";
        const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
        const removeKeys = [], setObj = {};
        for (const k in all) {
          if (!k.startsWith("fai_contact_") || !all[k]) continue;
          const rec = all[k];
          if (request.contactId != null && k === "fai_contact_" + request.contactId || h && rec.handle && rec.handle.toLowerCase() === h) removeKeys.push(k);
        }
        const rowMap = all.fansly_row_mirrored;
        if (rowMap && request.contactId != null && rowMap[String(request.contactId)]) {
          delete rowMap[String(request.contactId)];
          setObj.fansly_row_mirrored = rowMap;
        }
        const rowLast = all.fansly_row_last;
        if (rowLast && request.contactId != null && rowLast[String(request.contactId)]) {
          delete rowLast[String(request.contactId)];
          setObj.fansly_row_last = rowLast;
        }
        for (const store of ["fansly_subs", "fansly_purchases", "fansly_outreach", "fansly_outreach_done", "fansly_likes", "fansly_crm_notes", "fansly_ledger"]) {
          const o = all[store];
          if (!o || typeof o !== "object") continue;
          let ch = false;
          for (const key in o) if (h && key.toLowerCase() === h) {
            delete o[key];
            ch = true;
          }
          if (ch) setObj[store] = o;
        }
        if (all.fansly_earnings && typeof all.fansly_earnings === "object" && h) {
          const e = all.fansly_earnings;
          let ch = false;
          for (const oid in e) {
            const b = (e[oid] && e[oid].buyer || "").toLowerCase();
            if (b && b === h) {
              delete e[oid];
              ch = true;
            }
          }
          if (ch) setObj.fansly_earnings = e;
        }
        for (const store of ["fansly_todo_drafts", "fansly_todo_ack"]) {
          const o = all[store];
          if (!o || typeof o !== "object") continue;
          let ch = false;
          for (const key in o) if (h && key.toLowerCase().startsWith(h + "|")) {
            delete o[key];
            ch = true;
          }
          if (ch) setObj[store] = o;
        }
        const fanTid = all.fansly_tg_topics && all.fansly_tg_topics.fans && name ? all.fansly_tg_topics.fans[name] : null;
        if (fanTid != null && all.fansly_tg_fan_ctx && all.fansly_tg_fan_ctx.threads && all.fansly_tg_fan_ctx.threads[fanTid]) {
          const fc = all.fansly_tg_fan_ctx;
          delete fc.threads[fanTid];
          setObj.fansly_tg_fan_ctx = fc;
        }
        if (all.fansly_tg_topics && all.fansly_tg_topics.fans && name && all.fansly_tg_topics.fans[name] != null) {
          const tp = all.fansly_tg_topics;
          delete tp.fans[name];
          setObj.fansly_tg_topics = tp;
        }
        if (removeKeys.length) await new Promise((r) => chrome.storage.local.remove(removeKeys, r));
        if (Object.keys(setObj).length) await new Promise((r) => chrome.storage.local.set(setObj, r));
        sendResponse({ success: true, removed: removeKeys.length });
      })();
      return true;
  }
});
async function catalogThumbPut(items) {
  await FaiDB.ensureMigrated();
  return FaiDB.thumbPut(items || []);
}
const WORK_TAB_URL = (
  /*@of-start@*/
  PLATFORM === "onlyfans" ? "https://onlyfans.com/my/chats/" : (
    /*@of-end@*/
    "https://fansly.com/messages"
  )
);
const WORK_TAB_MATCH = (
  /*@of-start@*/
  PLATFORM === "onlyfans" ? "*://onlyfans.com/my/chats*" : (
    /*@of-end@*/
    "*://fansly.com/messages*"
  )
);
async function openWorkTab(excludeTabId) {
  const tabs = await new Promise((r) => {
    try {
      chrome.tabs.query({ url: WORK_TAB_MATCH }, (t) => {
        void chrome.runtime.lastError;
        r(t || []);
      });
    } catch (e) {
      r([]);
    }
  });
  for (const tb of tabs) {
    if (tb.id === excludeTabId) continue;
    const st = await new Promise((res) => {
      try {
        chrome.tabs.sendMessage(tb.id, { type: "PULT_STATE" }, (x) => {
          void chrome.runtime.lastError;
          res(x);
        });
      } catch (e) {
        res(null);
      }
    });
    if (st && st.pult === false) {
      await new Promise((res) => chrome.tabs.update(tb.id, { active: true }, () => {
        void chrome.runtime.lastError;
        res();
      }));
      if (tb.windowId != null) {
        try {
          chrome.windows.update(tb.windowId, { focused: true });
        } catch (e) {
        }
      }
      return { success: true, focused: tb.id };
    }
  }
  const nt = await new Promise((r) => chrome.tabs.create({ url: WORK_TAB_URL, active: true }, r));
  return { success: true, created: nt?.id };
}
function migrateOffSync() {
  try {
    chrome.storage.sync.get(["fansly_ai_settings"], (syncData) => {
      if (chrome.runtime.lastError) return;
      const fromSync = syncData && syncData.fansly_ai_settings;
      const wipe = () => {
        try {
          chrome.storage.sync.remove("fansly_ai_settings", () => {
            void chrome.runtime.lastError;
            try {
              chrome.storage.sync.clear(() => {
                void chrome.runtime.lastError;
              });
            } catch (e) {
            }
          });
        } catch (e) {
        }
      };
      if (!fromSync) {
        wipe();
        return;
      }
      chrome.storage.local.get("fansly_ai_settings", (localData) => {
        if (localData && localData.fansly_ai_settings) {
          wipe();
          return;
        }
        chrome.storage.local.get("fansly_ai_settings", (now) => {
          const merged = Object.assign({}, fromSync, now && now.fansly_ai_settings || {});
          chrome.storage.local.set({ fansly_ai_settings: merged }, () => {
            console.log("[FanslyAI] \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u044B \u0438\u0437 sync \u0432 local");
            wipe();
          });
        });
      });
    });
  } catch (e) {
  }
}
migrateOffSync();
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["fansly_ai_settings", "fansly_tiers"], (localData) => {
      const done = (base) => {
        const s = Object.assign({}, DEFAULT_SETTINGS, base || {});
        s.tiers = localData.fansly_tiers?.list || [];
        const scanned = s.tiers.length ? s.tiers.map((t) => `${t.name} \u2014 $${t.price}/mo${t.perks && t.perks.length ? "\n  includes: " + t.perks.join("; ") : ""}`).join("\n") : "";
        const manual = (base && base.tiersInfo || "").trim();
        s.tiersInfo = [scanned, manual].filter(Boolean).join("\n");
        resolve(s);
      };
      done(localData.fansly_ai_settings);
    });
  });
}
function saveSettings(settings, cb) {
  chrome.storage.local.get("fansly_ai_settings", (d) => {
    const merged = Object.assign({}, d.fansly_ai_settings || {}, settings);
    chrome.storage.local.set({ fansly_ai_settings: merged }, () => cb());
  });
}
async function getAllContacts() {
  return new Promise((resolve) => {
    chrome.storage.local.get(null, (allData) => {
      const contacts = {};
      for (const [key, val] of Object.entries(allData)) {
        if (key.startsWith("fai_contact_")) contacts[key] = val;
      }
      resolve(contacts);
    });
  });
}
const IMPORT_SKIP_SETTINGS = ["masterEnabled", "panelHidden", "carouselEnabled", "setupCompleted", "showAdvanced", "proxyBaseUrl"];
const SECRET_KEYS = ["licenseKey", "claudeApiKey", "deepLApiKey", "geminiApiKey", "groqApiKey", "openrouterApiKey", "telegramBotToken"];
function pickBackupContacts(contacts, existing) {
  const liveHandles = /* @__PURE__ */ new Set();
  for (const [k, v] of Object.entries(existing || {})) {
    if (k.startsWith("fai_contact_") && v && v.handle) liveHandles.add(String(v.handle).toLowerCase());
  }
  const out = {};
  const stats = { restored: 0, keptByKey: 0, keptByHandle: 0, rejected: 0 };
  for (const [k, rec] of Object.entries(contacts || {})) {
    if (!k.startsWith("fai_contact_") || !rec || typeof rec !== "object" || Array.isArray(rec)) {
      stats.rejected++;
      continue;
    }
    if (existing && existing[k] != null) {
      stats.keptByKey++;
      continue;
    }
    if (rec.handle && liveHandles.has(String(rec.handle).toLowerCase())) {
      stats.keptByHandle++;
      continue;
    }
    out[k] = rec;
    stats.restored++;
  }
  return { out, stats };
}
const IMPORT_TG_GUARD = ["tgBotId", "tgOwnerId", "tgOwnerChat", "tgMemberCount", "tgMemberCountChat", "tgAdminIds", "tgAdminChat"];
const IMPORT_TG_LINK = ["telegramBotToken", "telegramChatId", "tgTopics", "tgChatPrev"];
function pickBackupTg(copySettings, curSettings, copyTopics, curTopics) {
  const cs = copySettings || {}, cur = curSettings || {};
  const drop = [...IMPORT_TG_GUARD], set = {};
  const curChat = String(cur.telegramChatId || "");
  if (!curChat) return { drop, set, topics: copyTopics || null, why: "\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E \u0431\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B: \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0438 \u043A\u0430\u0440\u0442\u0430 \u0432\u0435\u0442\u043E\u043A \u2014 \u0438\u0437 \u043A\u043E\u043F\u0438\u0438" };
  drop.push(...IMPORT_TG_LINK);
  const ids = (chat, prev2) => [String(chat || ""), ...Array.isArray(prev2) ? prev2.map(String) : []].filter(Boolean);
  const mine = ids(curChat, cur.tgChatPrev);
  const theirs = ids(copyTopics && copyTopics.chat || cs.telegramChatId, cs.tgChatPrev);
  if (!theirs.some((id) => mine.includes(id))) return { drop, set, topics: null, why: "\u043A\u043E\u043F\u0438\u044F \u0434\u0440\u0443\u0433\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u044B: \u0435\u0451 \u043A\u0430\u0440\u0442\u0430 \u043D\u0435 \u0432\u0437\u044F\u0442\u0430, \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E \u043D\u0430 \u0441\u0432\u043E\u0435\u0439 \u0433\u0440\u0443\u043F\u043F\u0435" };
  const prev = [.../* @__PURE__ */ new Set([...mine, ...theirs])].filter((id) => id !== curChat).slice(-5);
  if (prev.length) set.tgChatPrev = prev;
  if (!copyTopics || typeof copyTopics !== "object") return { drop, set, topics: null, why: "\u0442\u0430 \u0436\u0435 \u0433\u0440\u0443\u043F\u043F\u0430, \u0432 \u043A\u043E\u043F\u0438\u0438 \u043A\u0430\u0440\u0442\u044B \u0432\u0435\u0442\u043E\u043A \u043D\u0435\u0442" };
  const live = curTopics && typeof curTopics === "object" && (!curTopics.chat || mine.includes(String(curTopics.chat))) ? curTopics : {};
  const keep = (a, b) => a != null ? a : b != null ? b : null;
  const added = Object.keys(copyTopics.fans || {}).filter((f) => !(live.fans && f in live.fans)).length;
  return { drop, set, why: "\u0442\u0430 \u0436\u0435 \u0433\u0440\u0443\u043F\u043F\u0430: \u0432\u0435\u0442\u043E\u043A \u0438\u0437 \u043A\u043E\u043F\u0438\u0438 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E " + added, topics: Object.assign({}, live, {
    important: keep(live.important, copyTopics.important),
    posts: keep(live.posts, copyTopics.posts),
    fans: Object.assign({}, copyTopics.fans || {}, live.fans || {}),
    // живые привязки поверх копии
    chat: curChat
  }) };
}
function importData(data, cb) {
  const inv = data.inventory || {};
  const invMap = {
    fansly_subs: inv.subs,
    fansly_ledger: inv.ledger,
    fansly_posts: inv.posts,
    fansly_purchases: inv.purchases,
    fansly_crm_notes: inv.crmNotes,
    fansly_outreach: inv.outreach,
    // Лайки и фоллоу (todo #53). Старая копия без них — засев из её аутрича тем же правилом, что разовый перенос при обновлении.
    fansly_likes: inv.likes || inv.outreach && likesFromOutreach(inv.outreach),
    // Добавлено 2026-08-17 (аудит полноты бэкапа)
    fansly_earnings: inv.earnings,
    fansly_stats_daily: inv.statsDaily,
    fansly_broadcast_stats: inv.broadcastStats,
    fansly_todo_ack: inv.todoAck,
    fansly_outreach_done: inv.outreachDone,
    fansly_tiers: inv.tiers
  };
  const invKeys = Object.keys(invMap).filter((k) => invMap[k]);
  const stampMap = { fansly_earnings_lastsync: inv.earningsLastsync, fansly_broadcast_lastsync: inv.broadcastLastsync };
  const stampKeys = Object.keys(stampMap).filter((k) => stampMap[k] != null);
  chrome.storage.local.get(null, (existing) => {
    const writes = {};
    const tg = pickBackupTg(data.settings, existing.fansly_ai_settings, data.tgTopics, existing.fansly_tg_topics);
    console.log("[FanslyAI] \u0438\u043C\u043F\u043E\u0440\u0442: \u0422\u0435\u043B\u0435\u0433\u0440\u0430\u043C \u2014", tg.why);
    if (data.settings) {
      const incoming = Object.assign({}, data.settings);
      for (const k of IMPORT_SKIP_SETTINGS) delete incoming[k];
      const cur = existing.fansly_ai_settings || {};
      for (const k of SECRET_KEYS) if (incoming[k] === "" && cur[k]) delete incoming[k];
      for (const k of tg.drop) delete incoming[k];
      Object.assign(incoming, tg.set);
      writes.fansly_ai_settings = Object.assign({}, cur, incoming);
    }
    if (data.contacts) {
      const { out, stats } = pickBackupContacts(data.contacts, existing);
      Object.assign(writes, out);
      console.log(
        "[FanslyAI] \u0438\u043C\u043F\u043E\u0440\u0442: \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0444\u0430\u043D\u043E\u0432 \u0438\u0437 \u043A\u043E\u043F\u0438\u0438 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u043E",
        stats.restored,
        "\xB7 \u0436\u0438\u0432\u044B\u0445 \u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E",
        stats.keptByKey + stats.keptByHandle,
        "(\u0438\u0437 \u043D\u0438\u0445 \u043F\u043E \u043D\u0438\u043A\u0443 " + stats.keptByHandle + ")" + (stats.rejected ? " \xB7 \u043E\u0442\u0431\u0440\u043E\u0448\u0435\u043D\u043E \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u043D\u0435 \u043F\u0440\u043E \u0444\u0430\u043D\u043E\u0432: " + stats.rejected : "")
      );
    }
    if (tg.topics) writes.fansly_tg_topics = tg.topics;
    for (const k of invKeys) writes[k] = Object.assign({}, invMap[k], existing[k] || {});
    for (const k of stampKeys) writes[k] = Math.max(+stampMap[k] || 0, +existing[k] || 0);
    const finish = (err) => {
      FaiDB.restoreCatalog(inv).then(() => cb(err)).catch((e) => cb(err || "catalog: " + (e && e.message || e)));
    };
    if (Object.keys(writes).length === 0) {
      finish(null);
      return;
    }
    chrome.storage.local.set(writes, () => {
      finish(chrome.runtime.lastError ? chrome.runtime.lastError.message : null);
    });
  });
}
async function consentGiven() {
  if (_consentOk) return true;
  try {
    _consentOk = await self.FaiConsent.given();
  } catch (e) {
    _consentOk = false;
  }
  return _consentOk;
}
function consentError() {
  const e = new Error("consent_required");
  e.faiConsent = true;
  return e;
}
async function fetchWithTimeout(url, opts, ms = 3e4, beforeConsent = false) {
  if (!beforeConsent && !await consentGiven()) throw consentError();
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(id);
  }
}
