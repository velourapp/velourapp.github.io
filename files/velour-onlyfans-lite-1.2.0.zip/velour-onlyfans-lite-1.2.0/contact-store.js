(function() {
  "use strict";
  let state, hashString, sendSafe, renderDossier, renderBrief;
  const DEPS = ["state", "hashString", "send", "renderDossier"];
  function init(deps) {
    const d = deps || {};
    const missing = DEPS.filter((k) => d[k] == null);
    if (missing.length) console.warn("[FanslyAI] ContactStore.init: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439:", missing.join(", "));
    state = d.state;
    hashString = d.hashString;
    sendSafe = d.send;
    renderDossier = d.renderDossier;
  }
  function initBackground(deps) {
    const d = deps || {};
    if (d.hashString == null) console.warn("[FanslyAI] ContactStore.initBackground: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439: hashString");
    hashString = d.hashString;
  }
  function keyOfId(id) {
    return "fai_contact_" + id;
  }
  function keyOfName(name) {
    return "fai_contact_" + hashString(name || "unknown");
  }
  function keyOfCurrent() {
    return state.currentContactId ? keyOfId(state.currentContactId) : keyOfName(state.currentContact);
  }
  function contactDataIsCurrent() {
    return !!state.contactData && state._dataFor === keyOfCurrent();
  }
  function emptyDossier() {
    return { facts: [], closeness: "new", topics: [], lastMessageAt: null };
  }
  function defaultContact(name) {
    return {
      name,
      handle: null,
      nameHistory: [],
      gender: "male",
      totalMsgs: 0,
      lang: "en",
      note: "",
      isSubscribed: false,
      dossier: emptyDossier(),
      brief: null,
      excludeFromAuto: false,
      // личный контакт — карусель его пропускает
      allowExplicit: null
      // пер-контакт оверрайд секстинга: null=по глобалке, true=разрешён, false=запрещён
      // closed_toxic (токсичность, todo 48) и confirmOverride (подтверждение ночного автоответа, todo 50) сняты 2026-10-08
      // вместе с фичами: в старых записях поля остаются как есть, читать их некому.
    };
  }
  const QUEUE_GUARD_MS = 5e3;
  const tails = /* @__PURE__ */ new Map();
  const qstat = { ops: 0, waited: 0, maxWaitMs: 0, timeouts: 0, refused: 0 };
  function withKey(key, op) {
    qstat.ops++;
    const prev = tails.get(key);
    const start = () => {
      try {
        return Promise.resolve(op());
      } catch (e) {
        return Promise.reject(e);
      }
    };
    const result = prev ? waitTurn(prev, key).then(start) : start();
    const tail = result.then(() => {
    }, () => {
    });
    tails.set(key, tail);
    tail.then(() => {
      if (tails.get(key) === tail) tails.delete(key);
    });
    return result;
  }
  function waitTurn(prev, key) {
    qstat.waited++;
    const t0 = Date.now();
    return new Promise((go) => {
      let over = false, timer = null;
      const pass = (timedOut) => {
        if (over) return;
        over = true;
        if (timedOut) {
          qstat.timeouts++;
          console.warn("[FanslyAI] ContactStore: \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 " + key + " \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0430\u0441\u044C \u0437\u0430 " + QUEUE_GUARD_MS + " \u043C\u0441 \u2014 \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u043E\u0442\u043F\u0443\u0441\u043A\u0430\u0435\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443");
        } else if (timer != null) {
          try {
            clearTimeout(timer);
          } catch (e) {
          }
        }
        qstat.maxWaitMs = Math.max(qstat.maxWaitMs, Date.now() - t0);
        go();
      };
      try {
        timer = setTimeout(() => {
          if (Date.now() - t0 >= QUEUE_GUARD_MS) pass(true);
        }, QUEUE_GUARD_MS);
      } catch (e) {
      }
      prev.then(() => pass(false));
    });
  }
  function queueStats() {
    return { ops: qstat.ops, waited: qstat.waited, maxWaitMs: qstat.maxWaitMs, timeouts: qstat.timeouts, refused: qstat.refused, pending: tails.size };
  }
  async function loadContact(name, handle = null) {
    const primaryKey = keyOfCurrent();
    return new Promise((resolve) => withKey(primaryKey, () => new Promise((done) => {
      chrome.storage.local.get(null, (all) => {
        let data = all[primaryKey] || null;
        let dirty = false;
        for (const [k, v] of Object.entries(all)) {
          if (k === primaryKey || !k.startsWith("fai_contact_") || !v) continue;
          const suffix = k.slice("fai_contact_".length);
          const isNumericId = /^\d{12,}$/.test(suffix);
          if (isNumericId) continue;
          const sameHandle = handle && v.handle && v.handle === handle;
          const sameName = v.name && v.name === name;
          if (!(sameHandle || sameName)) continue;
          if (!data) {
            data = v;
            console.log(`[FanslyAI] \u043A\u043E\u043D\u0442\u0430\u043A\u0442 "${name}": ${k} \u2192 ${primaryKey} (\u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F)`);
          } else console.log(`[FanslyAI] \u043A\u043E\u043D\u0442\u0430\u043A\u0442 "${name}": \u0443\u0434\u0430\u043B\u044F\u044E \u0434\u0443\u0431\u043B\u044C ${k} (\u043A\u0430\u043D\u043E\u043D ${primaryKey})`);
          chrome.storage.local.remove(k);
          dirty = true;
        }
        if (data) {
          if (dirty) chrome.storage.local.set({ [primaryKey]: data }, done);
          else done();
          resolve(data);
          return;
        }
        done();
        resolve(defaultContact(name));
      });
    })));
  }
  function saveContact(name, updates) {
    const key = keyOfCurrent();
    if (state.contactData && state._dataFor === key) {
      Object.assign(state.contactData, updates);
      const rec = state.contactData;
      withKey(key, () => new Promise((done) => chrome.storage.local.get([key], (st) => {
        try {
          const fresh = st && st[key];
          chrome.storage.local.set({ [key]: fresh ? Object.assign(fresh, updates) : rec }, done);
        } catch (e) {
          done();
          throw e;
        }
      })));
      return;
    }
    if (state.contactData) {
      qstat.refused++;
      console.warn("[FanslyAI] ContactStore: \u043E\u0442\u043A\u0430\u0437 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 " + key + " \u2014 \u0432 \u043F\u0430\u043C\u044F\u0442\u0438 " + (state._dataFor ? "\u0437\u0430\u043F\u0438\u0441\u044C \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0447\u0430\u0442\u0430 (" + state._dataFor + ")" : "\u0437\u0430\u0433\u043B\u0443\u0448\u043A\u0430 \u0431\u0435\u0437 \u043F\u0440\u043E\u0438\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u044F") + "; \u043F\u043E\u043B\u044F: " + Object.keys(updates || {}).join(", "));
      return;
    }
    withKey(key, () => new Promise((done) => chrome.storage.local.get(key, (data) => {
      try {
        const existing = data[key] || defaultContact(name);
        chrome.storage.local.set({ [key]: Object.assign({}, existing, updates) }, done);
      } catch (e) {
        done();
        throw e;
      }
    })));
  }
  function patchRecord(key, patch) {
    return withKey(key, () => new Promise((res) => {
      try {
        chrome.storage.local.get([key], (d) => {
          try {
            const rec = d && d[key];
            if (!rec) {
              res(false);
              return;
            }
            const p = typeof patch === "function" ? patch(rec) : patch;
            Object.assign(rec, p || {});
            chrome.storage.local.set({ [key]: rec }, () => res(true));
          } catch (e) {
            res(false);
          }
        });
      } catch (e) {
        res(false);
      }
    }));
  }
  function pinnedOf(d) {
    return d && d.manualFacts || [];
  }
  function isPinned(d, fact) {
    return pinnedOf(d).includes(fact);
  }
  function applyScanMarks(d, update) {
    if (update.analyzedUpTo) d.analyzedUpTo = Math.max(d.analyzedUpTo || 0, update.analyzedUpTo);
    if (update.partial) d.partialScan = true;
    else if (update.facts) delete d.partialScan;
  }
  function keepPinnedOnly(d) {
    const pin = pinnedOf(d);
    const kept = {};
    pin.forEach((f) => {
      if (d.factDates && d.factDates[f]) kept[f] = d.factDates[f];
    });
    d.facts = pin.slice();
    d.factDates = kept;
    d.topics = [];
  }
  const ContactStore = { init, keyOfId, keyOfName, keyOfCurrent, contactDataIsCurrent, defaultContact, loadContact, saveContact, pinnedOf, isPinned, applyScanMarks, keepPinnedOnly, queueStats, initBackground, patchRecord };
  self.ContactStore = ContactStore;
})();
