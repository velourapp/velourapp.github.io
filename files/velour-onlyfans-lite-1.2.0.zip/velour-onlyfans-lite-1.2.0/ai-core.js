(function() {
  "use strict";
  let getSettings, saveSettings, bugLog, bugProxyFail, netFailKind, fetchWithTimeout, consentGiven, consentError, DEFAULT_SETTINGS, CALL_KINDS, NO_DASH_RULE_TRANSLATE, BUILD, PLATFORM;
  let buildPrompt, parseDialogueResponse, ctxTimeout, buildDossierPrompt;
  function init(deps) {
    ({ getSettings, saveSettings, bugLog, bugProxyFail, netFailKind, fetchWithTimeout, consentGiven, consentError, DEFAULT_SETTINGS, CALL_KINDS, NO_DASH_RULE_TRANSLATE, BUILD, PLATFORM } = deps);
  }
  function initFull(deps) {
    ({ buildPrompt, parseDialogueResponse, ctxTimeout, buildDossierPrompt } = deps);
  }
  const MODELS = {
    gemini: "gemini-3.5-flash",
    groq: "llama-3.1-8b-instant",
    // генерация ответов и запасной путь досье
    groqChat: "llama-3.3-70b-versatile",
    // чат провайдера и Groq-резерв каскада
    openrouter: "meta-llama/llama-3.3-70b-instruct",
    claude: "claude-haiku-4-5-20251001",
    ollama: "llama3"
    // адаптер Ollama живёт в @cws-cut, имя — просто строка
  };
  Object.freeze(MODELS);
  const TR_CACHE_MAX_ENTRIES = 5e3;
  const TR_CACHE_MAX_BYTES = 2 * 1024 * 1024;
  const TR_CACHE_KEEP = 0.8;
  const TR_CACHE_SWEEP_EVERY = 200;
  const TR_CACHE_MARK = "fansly_trcache_v2";
  let _trPuts = 0;
  function trCacheUnpack(raw) {
    if (typeof raw === "string") return raw || null;
    if (raw && typeof raw === "object" && typeof raw.v === "string" && raw.v) return raw.v;
    return null;
  }
  function trEntryBytes(key, raw) {
    return String(key).length + (typeof raw === "string" ? raw.length + 2 : JSON.stringify(raw ?? "").length);
  }
  function trCacheEvictionPlan(entries, limits = {}) {
    const maxEntries = limits.maxEntries ?? TR_CACHE_MAX_ENTRIES;
    const maxBytes = limits.maxBytes ?? TR_CACHE_MAX_BYTES;
    const keep = limits.keep ?? TR_CACHE_KEEP;
    let count = entries.length;
    let bytes = entries.reduce((n, e) => n + (e.bytes || 0), 0);
    if (count <= maxEntries && bytes <= maxBytes) return [];
    const targetEntries = Math.floor(maxEntries * keep), targetBytes = Math.floor(maxBytes * keep);
    const sorted = [...entries].sort((a, b) => (a.t || 0) - (b.t || 0) || String(a.key).localeCompare(String(b.key)));
    const out = [];
    for (const e of sorted) {
      if (count <= targetEntries && bytes <= targetBytes) break;
      out.push(e.key);
      count -= 1;
      bytes -= e.bytes || 0;
    }
    return out;
  }
  async function trCacheGet(key) {
    const raw = await new Promise((r) => chrome.storage.local.get([key], (d) => r(d[key])));
    return trCacheUnpack(raw);
  }
  function trCachePut(key, value) {
    chrome.storage.local.set({ [key]: { v: value, t: Date.now() } });
    _trPuts += 1;
    if (_trPuts % TR_CACHE_SWEEP_EVERY === 0) trCacheSweep().catch(() => {
    });
  }
  let _trSweeping = null;
  function trCacheSweep() {
    if (_trSweeping) return _trSweeping;
    _trSweeping = new Promise((resolve) => {
      chrome.storage.local.get(null, (all) => {
        const entries = [];
        for (const k of Object.keys(all || {})) {
          if (!k.startsWith("tr_")) continue;
          const raw = all[k];
          entries.push({ key: k, t: raw && typeof raw === "object" && Number(raw.t) || 0, bytes: trEntryBytes(k, raw) });
        }
        const victims = trCacheEvictionPlan(entries);
        const bytes = entries.reduce((n, e) => n + e.bytes, 0);
        const done = () => resolve({ entries: entries.length, bytes, removed: victims.length });
        if (!victims.length) {
          done();
          return;
        }
        chrome.storage.local.remove(victims, () => {
          console.log(`[FanslyAI] \u{1F310} \u043A\u0435\u0448 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432: \u0437\u0430\u043F\u0438\u0441\u0435\u0439 ${entries.length}, ~${Math.round(bytes / 1024)} \u041A\u0411 \u2192 \u0443\u0431\u0440\u0430\u043D\u043E \u0441\u0442\u0430\u0440\u044B\u0445 ${victims.length}`);
          done();
        });
      });
    }).finally(() => {
      _trSweeping = null;
    });
    return _trSweeping;
  }
  function trCacheMigrateOnce() {
    chrome.storage.local.get(TR_CACHE_MARK, (d) => {
      if (d && d[TR_CACHE_MARK]) return;
      trCacheSweep().then(() => chrome.storage.local.set({ [TR_CACHE_MARK]: 1 })).catch(() => {
      });
    });
  }
  self.__faiTrCache = async function() {
    const used = chrome.storage.local.getBytesInUse ? await new Promise((r) => chrome.storage.local.getBytesInUse(null, (b) => r(b || 0))) : null;
    const all = await new Promise((r) => chrome.storage.local.get(null, r));
    let entries = 0, legacy = 0, bytes = 0, oldest = Infinity, newest = 0;
    for (const k of Object.keys(all)) {
      if (!k.startsWith("tr_")) continue;
      const raw = all[k];
      entries += 1;
      bytes += trEntryBytes(k, raw);
      const t = raw && typeof raw === "object" && Number(raw.t) || 0;
      if (!t) legacy += 1;
      else {
        oldest = Math.min(oldest, t);
        newest = Math.max(newest, t);
      }
    }
    const out = {
      entries,
      legacy,
      kb: Math.round(bytes / 1024),
      storageUsedKb: used == null ? null : Math.round(used / 1024),
      maxEntries: TR_CACHE_MAX_ENTRIES,
      maxKb: Math.round(TR_CACHE_MAX_BYTES / 1024),
      oldest: oldest === Infinity ? null : new Date(oldest).toISOString(),
      newest: newest ? new Date(newest).toISOString() : null
    };
    console.log("[FanslyAI] \u043A\u0435\u0448 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432:", JSON.stringify(out));
    return out;
  };
  self.__faiTrCacheSweep = () => trCacheSweep().then((r) => {
    console.log("[FanslyAI] \u0447\u0438\u0441\u0442\u043A\u0430 \u043A\u0435\u0448\u0430 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432:", JSON.stringify(r));
    return r;
  });
  const lang2 = (l) => String(l || "").toLowerCase().split(/[-_]/)[0];
  function isOutgoingTarget(targetLang, settings) {
    const native = lang2(settings && settings.nativeLanguage), target = lang2(targetLang);
    return !!native && !!target && target !== native;
  }
  function fanLangDiffers(fanLang, targetLang) {
    const fan = lang2(fanLang), target = lang2(targetLang);
    return !!fan && !!target && fan !== target;
  }
  function alreadyInTargetLang(text, targetLang) {
    const cyr = (text.match(/[а-яёіїєґ]/gi) || []).length;
    const lat = (text.match(/[a-z]/gi) || []).length;
    const tl = (targetLang || "").toLowerCase();
    if (["ru", "uk"].includes(tl)) return cyr > 0 && cyr >= lat;
    if (tl === "en") return lat > 0 && cyr === 0;
    return false;
  }
  function trOutputProblem(out, src, targetLang) {
    const o = String(out || "").trim(), s = String(src || "").trim();
    if (!o) return "";
    const REFUSAL = /\b(?:can(?:no|['’])t|unable to|not able to)\s+(?:help|assist)(?:\s+you)?\s+with\s+(?:that|this)\b|\b(?:can(?:no|['’])t|unable to|not able to)\s+(?:fulfil|comply|assist)|\bas an ai\b|no puedo ayudar|ne (?:peux|puis) pas (?:vous |t['’])?aider|non posso aiutar|não posso ajudar|не могу (?:вам |тебе )?(?:с этим )?помочь/i;
    const HELP_SRC = /(помо[чгщ]|с этим|help|assist|with (?:that|this)|ayud|aider|aiut|ajud|pom[oó]c)/i;
    if (o.length <= 300 && REFUSAL.test(o) && !HELP_SRC.test(s)) return "refusal";
    const META_SRC = /(translat|translit|traduc|traduz|tradu[ií]r|tradurr|перев[оеё]д|перевест|переклад|übersetz|tłumacz|přelož)/i;
    const META_OUT = /(translat|translit|traduc|traduz|tradu[ií]r|tradurr|переклад|übersetz|tłumacz|přelož)|(перев[оеё]д|перевест)[\s\S]{0,40}(текст|сообщени)|(текст|сообщени)[\s\S]{0,40}(перев[оеё]д|перевест)/i;
    if (META_OUT.test(o) && !META_SRC.test(s)) return "comment";
    if (/\n\s*\n/.test(o) && !/\n/.test(s)) return "comment";
    const LATIN = ["en", "es", "de", "fr", "it", "pt", "pl", "cs", "tr", "nl", "sv", "da", "no", "nb", "fi", "ro", "hu", "sk", "sl", "hr", "lt", "lv", "et", "id", "ms"];
    const norm = (x) => x.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
    if (LATIN.includes(String(targetLang || "").toLowerCase().split(/[-_]/)[0]) && /[\u0400-\u04FF]/.test(s) && norm(o) === norm(s)) return "untranslated";
    return "";
  }
  function trGuard(r, src, targetLang, engine) {
    if (!r || !r.success) return r;
    const bad = trOutputProblem(r.result, src, targetLang);
    if (!bad) return r;
    console.warn(`[FanslyAI] \u{1F310} \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u043E\u0442\u043A\u043B\u043E\u043D\u0451\u043D (${bad}, ${engine}) \u2192 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A`);
    return { success: false, error: "\u043E\u0442\u043A\u043B\u043E\u043D\u0451\u043D: " + bad, rejected: bad };
  }
  function trCacheDrop(key) {
    try {
      chrome.storage.local.remove(key);
    } catch (e) {
    }
  }
  const trCacheKey = (targetLang, hash, g, tg) => `tr_${targetLang}_${g || ""}${tg ? "_to" + tg : ""}_${hash}`;
  function hashText(str) {
    let h1 = 3735928559, h2 = 1103547991;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  const GENDERED_TARGETS = /* @__PURE__ */ new Set(["ru", "uk", "pl", "cs", "es", "fr", "it", "pt"]);
  function targetNeedsGender(lang) {
    return GENDERED_TARGETS.has(String(lang || "").toLowerCase().split(/[-_]/)[0]);
  }
  const TR_FALLBACK_PARALLEL = 3;
  const TR_CTX_NOCACHE_CHARS = 20;
  async function handleTranslateBatch(texts, targetLang, genderHint = null, toGender = null, cheapOnly = false, ctx = null, fanLang = null) {
    const list = Array.isArray(texts) ? texts : [];
    if (!list.length) return { success: true, results: [] };
    if ((await getSettings()).translatorEnabled === false) return { success: true, results: list.map(() => null), translatorOff: true };
    const results = new Array(list.length).fill(null);
    const needGender = BUILD === "full" && !!(genderHint || toGender) && targetNeedsGender(targetLang);
    const keyOf = (text, withGender) => trCacheKey(targetLang, hashText(text.trim()), withGender ? genderHint : "", withGender ? toGender : "");
    let ctxOn = needGender && Array.isArray(ctx) && ctx.length > 0;
    if (ctxOn && (await getSettings()).translateContext === false) ctxOn = false;
    const ctxShort = (text) => ctxOn && text.trim().length < TR_CTX_NOCACHE_CHARS;
    const byLetters = !fanLangDiffers(fanLang, targetLang);
    const pending = [];
    for (let i = 0; i < list.length; i++) {
      const text = list[i];
      if (!text?.trim()) {
        results[i] = { result: "", genderSafe: true, retryAfterMs: 0 };
        continue;
      }
      if (!/[\p{L}\p{N}]/u.test(text) || byLetters && alreadyInTargetLang(text.trim(), targetLang)) {
        results[i] = { result: text, genderSafe: true, retryAfterMs: 0 };
        continue;
      }
      if (ctxShort(text)) {
        pending.push(i);
        continue;
      }
      const key = keyOf(text, needGender);
      const cached = await trCacheGet(key);
      const cachedBad = cached ? trOutputProblem(cached, text, targetLang) : "";
      if (cached && !cachedBad) {
        results[i] = { result: cached, genderSafe: true, retryAfterMs: 0 };
        continue;
      }
      if (cachedBad) {
        console.warn(`[FanslyAI] \u{1F310} \u0432 \u043A\u0435\u0448\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u043B\u0435\u0436\u0430\u043B \u043D\u0435\u0433\u043E\u0434\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 (${cachedBad}) \u2192 \u0432\u044B\u0431\u0440\u043E\u0448\u0435\u043D, \u043F\u0435\u0440\u0435\u0432\u043E\u0436\u0443 \u0437\u0430\u043D\u043E\u0432\u043E`);
        trCacheDrop(key);
      }
      pending.push(i);
    }
    if (cheapOnly || !pending.length) return { success: true, results };
    let skipLlm = false;
    if (needGender) {
    }
    const rest = pending.filter((i) => !results[i]);
    for (let k = 0; k < rest.length; k += TR_FALLBACK_PARALLEL) {
      await Promise.all(rest.slice(k, k + TR_FALLBACK_PARALLEL).map(async (i) => {
        const one = await handleTranslate(list[i], targetLang, genderHint, toGender, "translate", skipLlm, null, fanLang);
        results[i] = one?.success ? { result: one.result, genderSafe: one.genderSafe !== false, retryAfterMs: one.retryAfterMs || 0 } : null;
      }));
    }
    return { success: true, results };
  }
  const trKind = (kind) => kind === "translate" ? "translate" : "translate_live";
  async function handleTranslate(text, targetLang, genderHint = null, toGender = null, kind = "translate_live", skipLlm = false, ctx = null, fanLang = null) {
    if (!text?.trim()) return { success: true, result: "" };
    kind = trKind(kind);
    if (!/[\p{L}\p{N}]/u.test(text)) return { success: true, result: text };
    const s0 = await getSettings();
    if (s0.translatorEnabled === false) return { success: true, result: text, translatorOff: true };
    const looksDone = alreadyInTargetLang(text.trim(), targetLang);
    if (looksDone && !isOutgoingTarget(targetLang, s0) && !fanLangDiffers(fanLang, targetLang)) {
      return { success: true, result: text };
    }
    const hash = hashText(text.trim());
    const keyFor = (g, tg) => trCacheKey(targetLang, hash, g, tg);
    const needGender = BUILD === "full" && !!(genderHint || toGender) && targetNeedsGender(targetLang);
    const cacheKey = needGender ? keyFor(genderHint, toGender) : keyFor(null, null);
    let s = s0, ctxOn = false;
    if (!ctxOn) {
      const cached = await trCacheGet(cacheKey);
      const cachedBad = cached ? trOutputProblem(cached, text, targetLang) : "";
      if (cached && !cachedBad) {
        return { success: true, result: cached };
      }
      if (cachedBad) {
        console.warn(`[FanslyAI] \u{1F310} \u0432 \u043A\u0435\u0448\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u043B\u0435\u0436\u0430\u043B \u043D\u0435\u0433\u043E\u0434\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 (${cachedBad}) \u2192 \u0432\u044B\u0431\u0440\u043E\u0448\u0435\u043D, \u043F\u0435\u0440\u0435\u0432\u043E\u0436\u0443 \u0437\u0430\u043D\u043E\u0432\u043E`);
        trCacheDrop(cacheKey);
      }
    }
    let result;
    let gendered = false;
    let lookLlm = false;
    if ((needGender || ctxOn || lookLlm) && !skipLlm) {
    }
    if (!result || !result.success) {
      if (proxyOn(s)) {
        result = trGuard(await translateViaProxy(text, targetLang, s), text, targetLang, "DeepL \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u043E\u043A\u0441\u0438");
        if (!result.success && s.deepLApiKey) {
          console.warn(`[FanslyAI] \u{1F310} DeepL-\u043F\u0440\u043E\u043A\u0441\u0438 \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u0441\u0432\u043E\u0439 \u043A\u043B\u044E\u0447 DeepL`);
          result = trGuard(await translateDeepL(text, targetLang, s.deepLApiKey), text, targetLang, "DeepL");
        }
        if (!result.success) {
          console.warn(`[FanslyAI] \u{1F310} \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u043E\u043A\u0441\u0438/DeepL \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u0444\u043E\u043B\u0431\u044D\u043A \u043D\u0430 Google`);
          result = trGuard(await translateGoogle(text, targetLang), text, targetLang, "Google");
        }
      } else if (s.deepLApiKey) {
        result = trGuard(await translateDeepL(text, targetLang, s.deepLApiKey), text, targetLang, "DeepL");
        if (!result.success) {
          console.warn(`[FanslyAI] \u{1F310} DeepL \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u0444\u043E\u043B\u0431\u044D\u043A \u043D\u0430 Google`);
          result = trGuard(await translateGoogle(text, targetLang), text, targetLang, "Google");
        }
      } else {
        result = trGuard(await translateGoogle(text, targetLang), text, targetLang, "Google");
      }
    }
    if (result.success && result.result && !ctxOn) {
      const key = needGender && !gendered ? keyFor(null, null) : cacheKey;
      trCachePut(key, result.result);
    }
    const retryAfterMs = gendered ? 0 : breakerOpen() ? Math.max(1e3, PROXY_BREAKER.until - Date.now()) : bgHoldOn() ? Math.max(1e3, PROXY_BG_HOLD.until - Date.now()) : 3e5;
    return { ...result, genderSafe: !(needGender && !gendered), retryAfterMs };
  }
  async function translateDeepL(text, targetLang, apiKey) {
    try {
      const host = /:fx$/i.test(String(apiKey || "").trim()) ? "api-free.deepl.com" : "api.deepl.com";
      const r = await fetchWithTimeout(`https://${host}/v2/translate`, {
        method: "POST",
        headers: {
          "Authorization": `DeepL-Auth-Key ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ text: [text], target_lang: targetLang.toUpperCase() })
      }, 15e3);
      const data = await r.json();
      if (data.translations) return { success: true, result: data.translations[0].text };
      return { success: false, error: JSON.stringify(data) };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function translateGoogle(text, targetLang) {
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
      const r = await fetchWithTimeout(url, {}, 1e4);
      const data = await r.json();
      const translated = data[0].map((chunk) => chunk[0]).filter(Boolean).join("");
      return { success: true, result: translated };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  function proxyOn(s) {
    return !!(s && s.useProxy === true && s.licenseKey);
  }
  const _psleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const PROXY_GATE = { active: 0, max: 3, minGapMs: 250, lastStart: 0, cooldownUntil: 0, waiters: [] };
  async function proxyGateWait() {
    for (; ; ) {
      const now = Date.now();
      if (now < PROXY_GATE.cooldownUntil) {
        await _psleep(PROXY_GATE.cooldownUntil - now + 50);
        continue;
      }
      const gap = PROXY_GATE.lastStart + PROXY_GATE.minGapMs - now;
      if (PROXY_GATE.active < PROXY_GATE.max && gap <= 0) {
        PROXY_GATE.active++;
        PROXY_GATE.lastStart = Date.now();
        return;
      }
      if (PROXY_GATE.active < PROXY_GATE.max) {
        await _psleep(gap);
        continue;
      }
      await new Promise((r) => PROXY_GATE.waiters.push(r));
    }
  }
  function proxyGateRelease() {
    PROXY_GATE.active = Math.max(0, PROXY_GATE.active - 1);
    const w = PROXY_GATE.waiters.shift();
    if (w) w();
  }
  const _breakers = /* @__PURE__ */ new Map();
  const PROXY_BREAKER = {
    get until() {
      let m = 0;
      for (const b of _breakers.values()) m = m ? Math.min(m, b.until) : b.until;
      return m;
    },
    get fails() {
      let m = 0;
      for (const b of _breakers.values()) m = Math.max(m, b.fails);
      return m;
    }
  };
  const brk = (host) => {
    let b = _breakers.get(host);
    if (!b) {
      b = { until: 0, fails: 0 };
      _breakers.set(host, b);
    }
    return b;
  };
  const BREAKER_STEPS = [3e4, 12e4, 3e5];
  function breakerOpen(host) {
    if (host) return Date.now() < brk(host).until;
    for (const b of _breakers.values()) if (Date.now() >= b.until) return false;
    return _breakers.size > 0;
  }
  function breakerTrip(host) {
    const b = brk(host || "");
    const step = BREAKER_STEPS[Math.min(b.fails, BREAKER_STEPS.length - 1)];
    b.fails++;
    b.until = Date.now() + Math.round(step * (0.75 + Math.random() * 0.5));
    console.warn("[FanslyAI] \u043D\u0435 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442", host || "\u043F\u0440\u043E\u043A\u0441\u0438", "\u2192 \u043F\u0430\u0443\u0437\u0430", Math.round((b.until - Date.now()) / 1e3), "\u0441 (\u043D\u0435\u0443\u0434\u0430\u0447 \u043F\u043E\u0434\u0440\u044F\u0434:", b.fails + ")");
  }
  function breakerReset(host) {
    const b = brk(host || "");
    if (b.fails) console.log("[FanslyAI]", host || "\u043F\u0440\u043E\u043A\u0441\u0438", "\u0441\u043D\u043E\u0432\u0430 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442");
    b.fails = 0;
    b.until = 0;
  }
  const BG_HOLD_DEFAULT_S = 3;
  const BG_HOLD_MAX_S = 15;
  const BG_BUSY_HOLD_S = 10;
  const PROXY_BG_HOLD = { until: 0 };
  function bgHoldOn() {
    return Date.now() < PROXY_BG_HOLD.until;
  }
  function bgHoldMs() {
    return Math.max(0, PROXY_BG_HOLD.until - Date.now());
  }
  function bgHoldTrip(sec) {
    const ms = Math.min(Math.max(Number(sec) || BG_HOLD_DEFAULT_S, 1), BG_HOLD_MAX_S) * 1e3;
    PROXY_BG_HOLD.until = Math.max(PROXY_BG_HOLD.until, Date.now() + ms);
    return ms;
  }
  function retryAfterFrom(body, headers) {
    const num = (v) => {
      const n = Number(v);
      return Number.isFinite(n) && n > 0 ? n : null;
    };
    const fromBody = num(body?.retry_after_seconds) ?? num(body?.error?.retry_after_seconds);
    if (fromBody != null) return fromBody;
    const h = headers && typeof headers.get === "function" ? headers.get("retry-after") : null;
    return h == null ? null : num(parseInt(String(h), 10));
  }
  let aiQuotaUntil = 0;
  let dlQuotaUntil = 0;
  const QUOTA_COOLDOWN_MS = 30 * 60 * 1e3;
  const QUOTA_MSG_AI = "\u041C\u0435\u0441\u044F\u0447\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442 \u0418\u0418 \u0438\u0441\u0447\u0435\u0440\u043F\u0430\u043D";
  const SUB_PAUSE_KEY = "fansly_sub_expired";
  const SUB_PAUSE_MS = 3 * 60 * 60 * 1e3;
  const SUB_MSG = "\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0437\u0430\u043A\u043E\u043D\u0447\u0438\u043B\u0430\u0441\u044C";
  let _subPause = void 0;
  function keyFp(k) {
    let h = 5381;
    const s = String(k || "");
    for (let i = 0; i < s.length; i++) h = (h << 5) + h + s.charCodeAt(i) | 0;
    return (h >>> 0).toString(16);
  }
  async function subPauseLoad() {
    if (_subPause === void 0) _subPause = await new Promise((r) => chrome.storage.local.get(SUB_PAUSE_KEY, (d) => r(d && d[SUB_PAUSE_KEY] || null)));
    return _subPause;
  }
  function subPausedSync(key) {
    return !!(key && _subPause && _subPause.fp === keyFp(key) && Date.now() < _subPause.until);
  }
  async function subPausedFor(key) {
    await subPauseLoad();
    return subPausedSync(key);
  }
  function subPauseSet(key) {
    _subPause = { fp: keyFp(key), until: Date.now() + SUB_PAUSE_MS };
    chrome.storage.local.set({ [SUB_PAUSE_KEY]: _subPause });
    console.warn("[FanslyAI] \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0437\u0430\u043A\u043E\u043D\u0447\u0438\u043B\u0430\u0441\u044C (402 subscription_expired) \u2192 \u043A \u043F\u0440\u043E\u043A\u0441\u0438 \u043D\u0435 \u0445\u043E\u0434\u0438\u043C \u0434\u043E " + new Date(_subPause.until).toLocaleTimeString() + " \u0438\u043B\u0438 \u0434\u043E \xAB\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C\xBB \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445");
  }
  function subPauseClear() {
    _subPause = null;
    chrome.storage.local.remove(SUB_PAUSE_KEY);
  }
  const bearerOf = (init2) => {
    const h = init2 && init2.headers || {};
    const m = /^Bearer\s+(.+)$/.exec(String(h.Authorization || h.authorization || ""));
    return m ? m[1] : "";
  };
  function subExpiredResponse() {
    const body = { error: { code: "subscription_expired", message: "Payment Required", local: true } };
    const r = { status: 402, ok: false, headers: { get: (k) => /^content-type$/i.test(k) ? "application/json" : null }, json: async () => body };
    r.clone = () => r;
    return r;
  }
  async function proxyFetch(url, init2, timeoutMs) {
    if (!await consentGiven()) throw consentError();
    const host = (() => {
      try {
        return new URL(url).hostname;
      } catch (e) {
        return "";
      }
    })();
    if (breakerOpen(host)) throw new Error("proxy_down");
    let last;
    for (let attempt = 0; attempt < 2; attempt++) {
      await proxyGateWait();
      try {
        last = await fetchWithTimeout(url, init2, timeoutMs);
      } catch (e) {
        if (!(e && (e.name === "AbortError" || e.faiConsent))) breakerTrip(host);
        throw e;
      } finally {
        proxyGateRelease();
      }
      if (last.status < 500) breakerReset(host);
      if (last.status === 429 || last.status >= 500) {
        const d = await last.clone().json().catch(() => ({}));
        if (d?.error?.code === "upstream_saturated") {
          bgHoldTrip(retryAfterFrom(d, last.headers));
          return last;
        }
        if (last.status === 429 || d?.error?.type === "rate_limit_error") {
          const ra = retryAfterFrom(d, last.headers) || 5;
          PROXY_GATE.cooldownUntil = Math.max(PROXY_GATE.cooldownUntil, Date.now() + Math.min(Math.max(ra, 1), 60) * 1e3);
          if (attempt === 0) continue;
        } else if (last.status >= 500) breakerTrip(host);
      }
      return last;
    }
    return last;
  }
  const QUOTA_CACHE_KEY = "fansly_ai_quota";
  const QUOTA_TTL_MS = 6 * 60 * 60 * 1e3;
  function saveQuota(q) {
    if (!q || typeof q !== "object") return null;
    const limit = Number(q.limit) || 0, used = Number(q.used) || 0;
    const v = {
      tier: String(q.tier || ""),
      used,
      limit,
      periodEnd: String(q.periodEnd || ""),
      at: Date.now()
    };
    const p = q.prepaid, n = p && typeof p === "object" ? Math.floor(Number(p.count)) : 0;
    if (Number.isFinite(n) && n > 0) v.prepaid = { count: n, tier: String(p.tier || ""), limit: Number(p.limit) || 0, days: Number(p.days) || 0 };
    chrome.storage.local.set({ [QUOTA_CACHE_KEY]: v });
    return v;
  }
  function readQuotaCache() {
    return new Promise((r) => chrome.storage.local.get(QUOTA_CACHE_KEY, (d) => r(d[QUOTA_CACHE_KEY] || null)));
  }
  async function fetchQuota(s) {
    try {
      const r = await proxyCall("/v1/quota", {
        method: "POST",
        headers: { "Authorization": `Bearer ${s.licenseKey}`, "Content-Type": "application/json" },
        body: "{}"
      }, 15e3);
      const data = await r.json().catch(() => ({}));
      if (!r.ok || !data || typeof data.used !== "number") return null;
      return saveQuota(data);
    } catch (e) {
      return null;
    }
  }
  async function getQuota(force) {
    const s = await getSettings();
    if (!proxyOn(s)) return null;
    const c = await readQuotaCache();
    const rolled = c && c.periodEnd && Date.parse(c.periodEnd) <= Date.now();
    const fresh = c && !rolled && Date.now() - (c.at || 0) < QUOTA_TTL_MS;
    if (fresh && !force) return c;
    return await fetchQuota(s) || (rolled ? null : c);
  }
  const ENDPOINTS_PUBKEY = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEpZ+s+DJQ4ZDOuRhyoYX0YLiOQNSNyBQrq+zkSfjrbm+YfaAMae1ZCytYm63aC9raXM0klE0oVDQ5RDtHcWjt7A==";
  const ENDPOINTS_BUILTIN = { rev: 1, endpoints: [{ url: "https://api.velourff.com", weight: 1 }] };
  const ENDPOINTS_KEY = "fansly_endpoints";
  const ENDPOINTS_TTL_MIN = 5 * 60 * 1e3;
  const ENDPOINTS_TTL_MAX = 7 * 24 * 3600 * 1e3;
  function endpointsPayload(list) {
    return ["velour-endpoints-v1", String(Math.trunc(list.rev))].concat((list.endpoints || []).map((e) => e.url + "	" + Math.trunc(Number(e.weight) || 1))).join("\n");
  }
  const sanePoint = (u) => {
    try {
      const x = new URL(u);
      return x.protocol === "https:" && x.pathname === "/" && !x.search && !x.hash && !/^\d+\.\d+\.\d+\.\d+$/.test(x.hostname) && !/^\[|localhost$/i.test(x.hostname) && x.hostname.includes(".");
    } catch (e) {
      return false;
    }
  };
  let _epKey = null;
  async function endpointsVerify(list) {
    if (!list || !Array.isArray(list.endpoints) || !list.endpoints.length || !list.sig) return false;
    if (!Number.isFinite(list.rev)) return false;
    if (!list.endpoints.every((e) => e && typeof e.url === "string" && sanePoint(e.url))) return false;
    try {
      if (!_epKey) {
        const raw = Uint8Array.from(atob(ENDPOINTS_PUBKEY), (c) => c.charCodeAt(0));
        _epKey = await crypto.subtle.importKey("spki", raw, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      }
      const b64 = list.sig.replace(/-/g, "+").replace(/_/g, "/");
      const sig = Uint8Array.from(atob(b64 + "=".repeat((4 - b64.length % 4) % 4)), (c) => c.charCodeAt(0));
      return await crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        _epKey,
        sig,
        new TextEncoder().encode(endpointsPayload(list))
      );
    } catch (e) {
      return false;
    }
  }
  async function endpointsAccept(list) {
    if (!await endpointsVerify(list)) return false;
    const cur = await new Promise((r) => chrome.storage.local.get(ENDPOINTS_KEY, (d) => r(d[ENDPOINTS_KEY] || null)));
    const rev = Math.trunc(list.rev);
    if (rev <= ((cur && cur.rev) | 0)) return false;
    if (rev < (ENDPOINTS_BUILTIN.rev | 0)) return false;
    const ttl = Math.min(ENDPOINTS_TTL_MAX, Math.max(ENDPOINTS_TTL_MIN, (Number(list.ttl) || 0) * 1e3));
    await new Promise((r) => chrome.storage.local.set({ [ENDPOINTS_KEY]: {
      rev: Math.trunc(list.rev),
      endpoints: list.endpoints.map((e) => ({ url: e.url, weight: Math.trunc(Number(e.weight) || 1) })),
      ttl,
      at: Date.now()
    } }, r));
    return true;
  }
  async function endpointsList() {
    const cur = await new Promise((r) => chrome.storage.local.get(ENDPOINTS_KEY, (d) => r(d[ENDPOINTS_KEY] || null)));
    return cur && cur.endpoints && cur.endpoints.length ? cur : ENDPOINTS_BUILTIN;
  }
  async function endpointsRefresh(base) {
    try {
      const r = await fetchWithTimeout(base + "/v1/endpoints", { method: "GET" }, 1e4, BEFORE_CONSENT);
      if (!r.ok) return null;
      const list = await r.json();
      return { accepted: await endpointsAccept(list), ttl: Number(list && list.ttl) || 0 };
    } catch (e) {
      return null;
    }
  }
  const BEFORE_CONSENT = true;
  const ENDPOINTS_CHECK_KEY = "fansly_endpoints_checked";
  async function endpointsMaintain(force) {
    const mark = await new Promise((r) => chrome.storage.local.get(ENDPOINTS_CHECK_KEY, (d) => r(d[ENDPOINTS_CHECK_KEY] || null)));
    if (!force && mark && mark.at && Date.now() - mark.at < (mark.ttl || 0)) return "fresh";
    const setMark = (ttlMs) => new Promise((r) => chrome.storage.local.set({ [ENDPOINTS_CHECK_KEY]: { at: Date.now(), ttl: ttlMs } }, r));
    const ring = await proxyRing();
    for (const base of ring) {
      const res = await endpointsRefresh(base);
      if (!res) continue;
      await setMark(Math.min(ENDPOINTS_TTL_MAX, Math.max(ENDPOINTS_TTL_MIN, res.ttl * 1e3)));
      console.log("[FanslyAI] \u0441\u043F\u0438\u0441\u043E\u043A \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043F\u0440\u043E\u043A\u0441\u0438:", res.accepted ? "\u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D" : "\u0431\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", "\u2190", base);
      return res.accepted ? "updated" : "same";
    }
    await setMark(ENDPOINTS_TTL_MIN);
    return "unreachable";
  }
  const STICKY_KEY = "fansly_proxy_sticky";
  const STICKY_MS = 24 * 3600 * 1e3;
  function hrwScore(seed, url, weight) {
    let h = 2166136261;
    const s = seed + "|" + url;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    const u = ((h >>> 0) + 1) / 4294967297;
    return -Math.max(1, weight | 0) / Math.log(u);
  }
  async function proxySeed(s) {
    return s.licenseKey || await new Promise((r) => chrome.storage.local.get(TRIAL_CODE_KEY, (d) => r(d[TRIAL_CODE_KEY] || "anon")));
  }
  async function proxyRing() {
    const s = await getSettings();
    const manual = String(s.proxyBaseUrl || "").replace(/\/+$/, "");
    if (manual && manual !== DEFAULT_SETTINGS.proxyBaseUrl.replace(/\/+$/, "")) return [manual];
    const list = await endpointsList();
    const seed = await proxySeed(s);
    const ranked = list.endpoints.map((e) => ({ url: e.url, sc: hrwScore(seed, e.url, e.weight) })).sort((a, b) => b.sc - a.sc);
    const home = ranked[0] && ranked[0].url;
    const st = await new Promise((r) => chrome.storage.local.get(STICKY_KEY, (d) => r(d[STICKY_KEY] || null)));
    const stick = st && st.url && Date.now() - (st.at || 0) < STICKY_MS && ranked.some((x) => x.url === st.url) ? st.url : null;
    const order = ranked.map((x) => x.url);
    if (!stick || stick === home) return order;
    return [stick, ...order.filter((u) => u !== stick)];
  }
  const proxyStick = (url) => new Promise((r) => chrome.storage.local.set({ [STICKY_KEY]: { url, at: Date.now() } }, r));
  async function proxyCall(path, init2, timeoutMs) {
    const key = bearerOf(init2);
    if (key && await subPausedFor(key)) return subExpiredResponse();
    const ring = await proxyRing();
    let lastErr = null;
    for (let i = 0; i < ring.length; i++) {
      const base = ring[i];
      try {
        const r = await proxyFetch(base + path, init2, timeoutMs);
        const ct = r.headers.get("content-type") || "";
        if (/json/i.test(ct) || r.status === 429) {
          if (i > 0) await proxyStick(base);
          if (r.status === 402 && key) {
            const d = await r.clone().json().catch(() => null);
            if (d && d.error && d.error.code === "subscription_expired") subPauseSet(key);
          }
          return r;
        }
        lastErr = new Error("proxy_no_app_" + r.status);
      } catch (e) {
        if (e && (e.name === "AbortError" || e.faiConsent)) throw e;
        lastErr = e;
      }
    }
    throw lastErr || new Error("proxy_unreachable");
  }
  const TRIAL_CODE_KEY = "fansly_install_code";
  const TRIAL_STATE_KEY = "fansly_trial_state";
  let _trialRunning = false;
  async function installCode() {
    const cur = await new Promise((r) => chrome.storage.local.get(TRIAL_CODE_KEY, (d) => r(d[TRIAL_CODE_KEY])));
    if (cur) return cur;
    const code = crypto.randomUUID();
    await new Promise((r) => chrome.storage.local.set({ [TRIAL_CODE_KEY]: code }, r));
    return code;
  }
  async function sha256Hex(str) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  async function readTrialState() {
    return new Promise((r) => chrome.storage.local.get(TRIAL_STATE_KEY, (d) => r(d[TRIAL_STATE_KEY] || null)));
  }
  async function requestTrial(code) {
    if (_trialRunning) return null;
    const s = await getSettings();
    if (s.licenseKey) return null;
    if (!s.privacyConsentAt) return null;
    const st = await readTrialState();
    if (!code && st && st.waitUntil && Date.now() < st.waitUntil) return st;
    if (!code && st && st.closed) return st;
    _trialRunning = true;
    try {
      const body = {
        installHash: await sha256Hex(await installCode()),
        ...code ? { code } : {},
        // код приглашения — необязательное поле; конверт строгий, лишнего слать нельзя
        platform: PLATFORM,
        extVersion: chrome.runtime.getManifest().version,
        lang: s.interfaceLanguage || "ru"
      };
      const r = await proxyCall("/v1/trial", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }, 15e3);
      const data = await r.json().catch(() => ({}));
      const errCode = data && data.error && data.error.code;
      let state;
      if (r.ok && data.licenseKey) {
        await new Promise((res) => saveSettings({ licenseKey: data.licenseKey, useProxy: true }, res));
        if (data.velour_quota) saveQuota(data.velour_quota);
        state = { at: Date.now(), ok: true };
        console.log("[FanslyAI] \u043F\u0440\u043E\u0431\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F \u0432\u044B\u0434\u0430\u043D");
      } else if (r.status === 403 && errCode === "trial_closed") {
        state = { at: Date.now(), closed: data.error.where === "tg" ? "tg" : "site" };
      } else if (r.status === 429) {
        const ra = parseInt(r.headers.get("Retry-After") || "", 10);
        state = { at: Date.now(), waitUntil: Date.now() + (Number.isFinite(ra) ? ra : 3600) * 1e3 };
      } else {
        if (r.status === 400) bugLog("trial_fail", { status: r.status, code: String(errCode || "") });
        state = { at: Date.now(), waitUntil: Date.now() + 36e5 };
      }
      if (code && !state.ok) return { ok: false, code: String(errCode || "") };
      await new Promise((r2) => chrome.storage.local.set({ [TRIAL_STATE_KEY]: state }, r2));
      return state.ok ? { ok: true } : state;
    } catch (e) {
      const state = { at: Date.now(), waitUntil: Date.now() + 36e5 };
      await new Promise((r2) => chrome.storage.local.set({ [TRIAL_STATE_KEY]: state }, r2));
      return state;
    } finally {
      _trialRunning = false;
    }
  }
  async function translateViaProxy(text, targetLang, s) {
    if (Date.now() < dlQuotaUntil) return { success: false, status: 402, dlQuota: true, error: "dl quota" };
    if (await subPausedFor(s && s.licenseKey)) return { success: false, status: 402, dlQuota: true, subscriptionExpired: true, error: SUB_MSG };
    try {
      const r = await proxyCall("/v1/translate", {
        method: "POST",
        headers: { "Authorization": `Bearer ${s.licenseKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ text, targetLang })
      }, 2e4);
      const data = await r.json().catch(() => ({}));
      if (data?.velour_quota) saveQuota(data.velour_quota);
      if (r.ok && data.text) return { success: true, result: data.text };
      if (r.status === 402 && data?.error?.code === "dl_quota_exhausted") {
        dlQuotaUntil = Date.now() + QUOTA_COOLDOWN_MS;
        bugProxyFail("translate", 402, "dl_quota_exhausted");
        return { success: false, status: 402, dlQuota: true, error: "dl quota" };
      }
      if (r.status === 402 && data?.error?.code === "subscription_expired") {
        if (!data.error.local) bugProxyFail("translate", 402, "subscription_expired");
        return { success: false, status: 402, dlQuota: true, subscriptionExpired: true, error: SUB_MSG };
      }
      bugProxyFail("translate", r.status, data?.error?.code);
      return { success: false, error: data?.error?.message || `proxy HTTP ${r.status}` };
    } catch (e) {
      const nf = netFailKind(e);
      if (nf) bugLog("net_fail", { ep: "translate", code: nf.code, ageMs: 2e4 }, void 0, nf.k);
      return { success: false, error: e.message };
    }
  }
  const AiCore = { init, initFull, MODELS, translate: handleTranslate, translateBatch: handleTranslateBatch, proxyOn, proxyCall, endpointsMaintain, getQuota, requestTrial, readTrialState, trCacheSweep, trCacheMigrateOnce, subPauseClear };
  self.AiCore = AiCore;
})();
