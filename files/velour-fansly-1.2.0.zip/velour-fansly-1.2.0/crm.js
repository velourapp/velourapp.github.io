let uiLang = "ru";
let nativeLang = "ru";
let creatorGender = "female";
let fans = [];
let crmNotes = {};
let catalog = {};
let activeSeg = "all";
let activeStage = null;
let sortBy = "score";
let query = "";
let activeTier = "";
let focusHandle = null;
let briefStaleHours = 48;
let crmStore = null;
const STAGES = ["lead", "acquaint", "interest", "brief", "paid", "repeat"];
const STAGE_ICON = { lead: "\u{1F331}", acquaint: "\u{1F44B}", interest: "\u{1F4AC}", brief: "\u{1F4CB}", paid: "\u{1F4B0}", repeat: "\u{1F501}", lost: "\u{1F6AA}", cold: "\u{1F4A4}" };
const CLOSENESS = {
  new: { icon: "\u{1F331}", key: "common.closeness.new" },
  interested: { icon: "\u{1F4AC}", key: "common.closeness.interested" },
  regular: { icon: "\u{1F525}", key: "common.closeness.regular" },
  supporter: { icon: "\u{1F48E}", key: "common.closeness.supporter" }
};
document.addEventListener("DOMContentLoaded", init);
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && ch.fansly_ai_settings) init();
});
chrome.storage.onChanged.addListener(onContactsChanged);
function init() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (r) => {
    uiLang = r?.result?.interfaceLanguage || "ru";
    nativeLang = r?.result?.nativeLanguage || "ru";
    creatorGender = r?.result?.creatorGender || "female";
    briefStaleHours = r?.result?.briefStaleHours ?? 48;
    applyI18n(document, uiLang);
    try {
      focusHandle = (new URLSearchParams(location.search).get("handle") || "").toLowerCase() || null;
    } catch (e) {
      focusHandle = null;
    }
    bindControls();
    if (typeof FaiLock !== "undefined") {
      FaiLock.init({ lang: uiLang });
      FaiLock.wire("lock-btn");
    }
    if (!window._tourInit && typeof initPageTour === "function") {
      window._tourInit = true;
      initPageTour({ flag: "tourCrm", btn: "page-tour", lang: uiLang, steps: [
        { sel: "#funnel", key: "tour.crm.s1" },
        { sel: ".chips", key: "tour.crm.s2" },
        { sel: "#search", key: "tour.crm.s3" },
        { sel: "#openDigest", key: "tour.crm.s4" },
        { sel: "#list .row", key: "tour.crm.s5" }
      ] });
    }
    loadData();
  });
}
function bindControls() {
  const search = document.getElementById("search");
  search.addEventListener("input", () => {
    query = search.value.trim().toLowerCase();
    render();
  });
  document.getElementById("sort").addEventListener("change", (e) => {
    sortBy = e.target.value;
    render();
  });
  document.getElementById("tierFilter").addEventListener("change", (e) => {
    activeTier = e.target.value;
    render();
  });
  document.getElementById("collect-all").addEventListener("click", () => {
    if (!confirm(t("collect.confirm", uiLang))) return;
    chrome.runtime.sendMessage({ type: "RUN_FULL_COLLECT" });
    const b = document.getElementById("collect-all");
    b.disabled = true;
    b.textContent = t("collect.running", uiLang);
    const once = () => {
      window.removeEventListener("focus", once);
      b.disabled = false;
      b.textContent = t("collect.btn", uiLang);
      loadData();
    };
    window.addEventListener("focus", once);
  });
  document.getElementById("refresh").addEventListener("click", loadData);
  document.getElementById("openDigest").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") }));
  document.querySelectorAll(".chip[data-seg]").forEach((c) => c.addEventListener("click", () => {
    document.querySelectorAll(".chip[data-seg]").forEach((x) => x.classList.remove("active"));
    c.classList.add("active");
    activeSeg = c.dataset.seg;
    if (activeSeg === "all") {
      activeStage = null;
      activeTier = "";
      document.getElementById("tierFilter").value = "";
    }
    render();
  }));
}
async function loadData() {
  const store = await new Promise((r) => chrome.storage.local.get([...CRM.STORE_KEYS, "fansly_crm_notes"], (d) => r(d)));
  const contacts = await new Promise((r) => chrome.runtime.sendMessage({ type: "GET_ALL_CONTACTS" }, (resp) => r(resp?.result || {})));
  crmStore = store;
  crmNotes = store.fansly_crm_notes || {};
  for (const [key, c] of Object.entries(contacts)) if (c && c.handle) contactMeta(key, c);
  fans = CRM.allFans(store, contacts, { briefStaleHours }).map((f) => {
    f.msgId = f.contact && f.contact._msgId || null;
    return f;
  });
  renderTierOptions();
  render();
}
function contactMeta(key, c) {
  const id = key.replace("fai_contact_", "");
  c._msgId = /^\d{10,}$/.test(id) ? id : null;
  c._key = key;
  return c;
}
function fmtMoney(n) {
  return (+(+n).toFixed(2)).toString();
}
function filtered() {
  let list = fans.slice();
  if (activeSeg === "hasDigest") list = list.filter(hasDigest);
  else if (activeSeg !== "all") list = list.filter((f) => f.segments.has(activeSeg));
  if (activeStage === "lost" || activeStage === "cold") list = list.filter((f) => f.stage === activeStage);
  else if (activeStage) {
    const i = STAGES.indexOf(activeStage);
    list = list.filter((f) => STAGES.indexOf(f.stage) >= i);
  }
  if (activeTier) list = list.filter((f) => (f.tiers || []).includes(activeTier));
  if (query) list = list.filter(
    (f) => (f.name || "").toLowerCase().includes(query) || (f.handle || "").toLowerCase().includes(query) || (f.sub && f.sub.tierName || "").toLowerCase().includes(query) || (f.contact ? (f.contact.dossier && f.contact.dossier.manualFacts || []).join(" ") : crmNotes[f.handle.toLowerCase()] || "").toLowerCase().includes(query)
  );
  list.sort((a, b) => {
    if (sortBy === "spend") return b.spent - a.spent;
    if (sortBy === "months") return (b.months || 0) - (a.months || 0);
    if (sortBy === "renew") {
      const dv = (f) => {
        const d = f.activeSub ? f.daysLeft : null;
        return d != null ? d : 1e9;
      };
      return dv(a) - dv(b);
    }
    return b.score - a.score;
  });
  return list;
}
function renderFunnel() {
  const el = document.getElementById("funnel");
  if (!el) return;
  const counts = {};
  STAGES.forEach((s) => counts[s] = 0);
  for (const f of fans) if (counts[f.stage] != null) counts[f.stage]++;
  const reach = {};
  let acc = 0;
  for (let i = STAGES.length - 1; i >= 0; i--) {
    acc += counts[STAGES[i]];
    reach[STAGES[i]] = acc;
  }
  el.innerHTML = "";
  STAGES.forEach((s, i) => {
    const cell = document.createElement("div");
    cell.className = "fstage" + (activeStage === s ? " active" : "");
    const c = document.createElement("div");
    c.className = "fc";
    c.textContent = reach[s];
    const l = document.createElement("div");
    l.className = "fl";
    l.textContent = STAGE_ICON[s] + " " + t("crm.stage." + s, uiLang);
    cell.append(c, l);
    cell.title = t("crm.funnel.reach", uiLang, { n: reach[s] }) + "\n" + t("crm.funnel.here", uiLang, { n: counts[s] });
    cell.addEventListener("click", () => {
      activeStage = activeStage === s ? null : s;
      render();
    });
    el.appendChild(cell);
    if (i < STAGES.length - 1) {
      const conv = document.createElement("div");
      conv.className = "fconv";
      conv.textContent = "\u2192 " + (reach[s] ? Math.round(reach[STAGES[i + 1]] / reach[s] * 100) : 0) + "%";
      conv.title = t("crm.funnel.conv", uiLang);
      el.appendChild(conv);
    }
  });
  el.appendChild(Object.assign(document.createElement("div"), { className: "fsep" }));
  const churn = document.createElement("div");
  churn.className = "fchurn";
  const churnH = document.createElement("div");
  churnH.className = "fchurn-h";
  churnH.textContent = t("crm.funnel.churnHead", uiLang);
  const churnRow = document.createElement("div");
  churnRow.className = "fchurn-row";
  for (const key of ["lost", "cold"]) {
    const cell = document.createElement("div");
    cell.className = "fstage lost" + (activeStage === key ? " active" : "");
    const c = document.createElement("div");
    c.className = "fc";
    c.textContent = fans.filter((f) => f.stage === key).length;
    const l = document.createElement("div");
    l.className = "fl";
    l.textContent = STAGE_ICON[key] + " " + t("crm.stage." + key, uiLang);
    cell.append(c, l);
    cell.title = t("crm.tip." + key, uiLang);
    cell.addEventListener("click", () => {
      activeStage = activeStage === key ? null : key;
      render();
    });
    churnRow.appendChild(cell);
  }
  churn.append(churnH, churnRow);
  el.appendChild(churn);
}
function subtitleText(total, subsCount, mrr) {
  if (uiLang !== "ru") return t("crm.subtitle", uiLang, { n: total, subs: subsCount, mrr: fmtMoney(mrr) });
  return CRM.plural(total, ["\u0444\u0430\u043D", "\u0444\u0430\u043D\u0430", "\u0444\u0430\u043D\u043E\u0432"]) + " \xB7 " + CRM.plural(subsCount, ["\u0430\u043A\u0442\u0438\u0432\u043D\u0430\u044F \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430", "\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438", "\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u043F\u043E\u0434\u043F\u0438\u0441\u043E\u043A"]) + " \xB7 MRR $" + fmtMoney(mrr);
}
function renderEmptyActions() {
  const box = document.getElementById("empty-acts");
  if (!box || box.dataset.built) return;
  box.dataset.built = "1";
  const b = document.createElement("button");
  b.className = "btn";
  b.textContent = t("crm.empty.scan", uiLang);
  b.addEventListener("click", () => window.open("https://fansly.com/creator/subscribers", "_blank", "noopener"));
  box.appendChild(b);
}
function renderSummary() {
  renderFunnel();
  const total = fans.length;
  const subsCount = fans.filter((f) => f.activeSub).length;
  const mrr = fans.reduce((a, f) => a + (f.activeSub && f.sub && f.sub.renewOn !== false ? f.sub.price || 0 : 0), 0);
  document.getElementById("subtitle").textContent = subtitleText(total, subsCount, mrr);
}
function renderTierOptions() {
  const sel = document.getElementById("tierFilter");
  const cnt = {};
  for (const f of fans) for (const tr of f.tiers || []) cnt[tr] = (cnt[tr] || 0) + 1;
  const tiers = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a] || a.localeCompare(b));
  while (sel.options.length > 1) sel.remove(1);
  for (const tr of tiers) {
    const o = document.createElement("option");
    o.value = tr;
    o.textContent = tr + " (" + cnt[tr] + ")";
    sel.appendChild(o);
  }
  if (!cnt[activeTier]) activeTier = "";
  sel.value = activeTier;
}
function renderSelSummary(list) {
  const el = document.getElementById("selSummary");
  if (!list.length) {
    el.textContent = "";
    return;
  }
  const active = list.filter((f) => f.activeSub).length, gone = list.filter((f) => f.expired).length;
  const spent = list.reduce((a, f) => a + (f.spent || 0), 0), buys = list.reduce((a, f) => a + (f.buyCount || 0), 0);
  const churn = active + gone ? Math.round(gone / (active + gone) * 100) : "\u2014";
  el.textContent = t("crm.sel.summary", uiLang, { active, gone, churn, spent: fmtMoney(spent), buys });
}
function render() {
  renderSummary();
  const total = fans.length;
  const empty = document.getElementById("empty");
  const listEl = document.getElementById("list");
  listEl.innerHTML = "";
  if (!total) {
    empty.style.display = "block";
    renderEmptyActions();
    document.getElementById("showing").textContent = "";
    document.getElementById("selSummary").textContent = "";
    return;
  }
  empty.style.display = "none";
  const list = filtered();
  document.getElementById("showing").textContent = t("crm.showing", uiLang, { n: list.length, total });
  renderSelSummary(list);
  const frag = document.createDocumentFragment();
  for (const f of list) frag.appendChild(row(f));
  listEl.appendChild(frag);
  if (focusHandle) {
    const el = listEl.querySelector('.row[data-handle="' + (window.CSS && CSS.escape ? CSS.escape(focusHandle) : focusHandle) + '"]');
    if (el) {
      el.scrollIntoView({ block: "center", behavior: "smooth" });
      el.style.outline = "2px solid #e91e8c";
      el.style.outlineOffset = "2px";
      setTimeout(() => {
        el.style.outline = "";
      }, 3500);
      focusHandle = null;
    }
  }
}
function badge(cls, text, tip) {
  const b = document.createElement("span");
  b.className = "bg " + cls;
  b.textContent = text;
  if (tip) b.title = tip;
  return b;
}
function spentTip(f) {
  const lines = [t("crm.tip.spent", uiLang)];
  if (f.subSpent > 0) lines.push(t("crm.tip.spent.subs", uiLang, { n: fmtMoney(f.subSpent) }));
  if (f.buySpent > 0) lines.push(t("crm.tip.spent.buys", uiLang, { n: fmtMoney(f.buySpent) }));
  if (f.tipSpent > 0) lines.push(t("crm.tip.spent.tips", uiLang, { n: fmtMoney(f.tipSpent) }));
  if (f.buysNoAmount > 0) lines.push(t("crm.tip.spent.unknown", uiLang, { n: f.buysNoAmount }));
  return lines.join("\n");
}
function fanGenders(contact) {
  return { genderHint: contact?.gender || "male", toGender: creatorGender };
}
function translate(text, g = null) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "TRANSLATE", text, targetLang: nativeLang, genderHint: g?.genderHint || null, toGender: g?.toGender || null }, (r) => resolve(r?.success ? r.result : text));
  });
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
}
function briefHas(b) {
  return !!(b && (b.wants || b.mood || b.details && b.details.length || b.refs && b.refs.length));
}
function hasDigest(f) {
  const c = f.contact;
  if (!c) return false;
  const d = c.dossier || {};
  return !!(briefHas(c.brief) || d.facts && d.facts.length || d.topics && d.topics.length);
}
function buildDigestBody(el, f) {
  const c = f.contact || {}, d = c.dossier || {};
  const body = document.createElement("div");
  body.className = "rowbody";
  if (briefHas(c.brief)) {
    const b = c.brief;
    const sec = document.createElement("div");
    sec.className = "dg-sec";
    sec.innerHTML = `<div class="dg-h">${t("dashboard.brief.header", uiLang)} <button class="brief-lang-btn" title="${t("dashboard.brief.lang.title", uiLang)}">\u{1F310}</button></div><div class="dg-brief-box"></div>`;
    const box = sec.querySelector(".dg-brief-box"), langBtn = sec.querySelector(".brief-lang-btn");
    const rows = [
      [t("common.brief.wants", uiLang), b.wants],
      [t("common.brief.mood", uiLang), b.mood],
      [t("common.brief.details", uiLang), b.details && b.details.length ? b.details.join(", ") : ""],
      [t("common.brief.refs", uiLang), b.refs && b.refs.length ? b.refs.join(", ") : ""]
    ].filter(([, v]) => v);
    let showOriginal = false;
    const renderRows = () => {
      box.innerHTML = "";
      rows.forEach(([label, value]) => {
        const r = document.createElement("div");
        r.className = "dg-brief-row";
        r.innerHTML = `<b>${escapeHtml(label)}:</b> <span data-tr>${showOriginal ? escapeHtml(value) : "\u23F3"}</span>`;
        box.appendChild(r);
        if (!showOriginal) translate(value, fanGenders(c)).then((tr) => {
          const s = r.querySelector("[data-tr]");
          if (s) s.textContent = tr;
        });
      });
    };
    langBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      showOriginal = !showOriginal;
      langBtn.classList.toggle("active", showOriginal);
      renderRows();
    });
    renderRows();
    body.appendChild(sec);
  }
  if (hasDigest(f)) {
    const facts = d.facts || [];
    const fsec = document.createElement("div");
    fsec.className = "dg-sec";
    fsec.innerHTML = `<div class="dg-h">${t("dashboard.dossier.header", uiLang)} (${facts.length})</div>`;
    if (facts.length) {
      facts.forEach((fact) => {
        const r = document.createElement("div");
        r.className = "dg-fact";
        r.textContent = "\u23F3";
        fsec.appendChild(r);
        translate(fact, fanGenders(c)).then((tr) => {
          r.textContent = tr;
        });
      });
    } else {
      const e = document.createElement("div");
      e.className = "dg-fact";
      e.textContent = t("dashboard.dossier.empty", uiLang);
      fsec.appendChild(e);
    }
    body.appendChild(fsec);
    if (d.topics && d.topics.length) {
      const tsec = document.createElement("div");
      tsec.className = "dg-sec";
      tsec.innerHTML = `<div class="dg-h">${t("dashboard.topics.header", uiLang)}</div><div class="dg-brief-row" data-topics>\u23F3</div>`;
      body.appendChild(tsec);
      translate(d.topics.join(", "), fanGenders(c)).then((tr) => {
        const e2 = tsec.querySelector("[data-topics]");
        if (e2) e2.textContent = tr;
      });
    }
  }
  if (f.purchasedMedia && f.purchasedMedia.length) body.appendChild(buildPurchasesStrip(f));
  el.appendChild(body);
}
function loadThumbsFor(ids) {
  return FaiDB.thumbGet(ids).catch(() => ({}));
}
async function loadMetaFor(ids) {
  try {
    await FaiDB.ensureMigrated();
    Object.assign(catalog, await FaiDB.metaGet(ids));
  } catch (e) {
  }
}
function buildPurchasesStrip(f) {
  const items = f.purchasedMedia;
  const sec = document.createElement("div");
  sec.className = "dg-sec buys-sec";
  const head = document.createElement("div");
  head.className = "dg-h buys-head";
  head.innerHTML = `<span class="buys-caret">\u25B8</span> ${t("crm.buys.title", uiLang, { n: items.length })}`;
  const grid = document.createElement("div");
  grid.className = "buys-grid";
  grid.style.display = "none";
  let built = false;
  head.style.cursor = "pointer";
  head.addEventListener("click", async () => {
    const open = grid.style.display !== "none";
    grid.style.display = open ? "none" : "grid";
    head.querySelector(".buys-caret").textContent = open ? "\u25B8" : "\u25BE";
    if (!built) {
      built = true;
      const ids = items.map((i) => i.mediaId).filter(Boolean);
      await loadMetaFor(ids);
      const thumbs = await loadThumbsFor(ids);
      const money = (n) => (+(+n).toFixed(2)).toString();
      for (const it of items) {
        const cat = catalog[it.mediaId] || {};
        const card = document.createElement("div");
        card.className = "buy-card";
        const url = thumbs[it.mediaId];
        if (url) {
          const img = document.createElement("img");
          img.className = "buy-thumb";
          img.src = url;
          img.alt = "";
          card.appendChild(img);
        } else {
          const ph = document.createElement("div");
          ph.className = "buy-thumb none";
          ph.textContent = cat.type === "video" ? "\u{1F3A5}" : "\u{1F5BC}";
          card.appendChild(ph);
        }
        const meta = document.createElement("div");
        meta.className = "buy-meta";
        const dt = cat.date ? (() => {
          const short = cat.date.replace(/([A-Za-z]{3})[a-z]+/, "$1");
          if (/\b\d{4}\b/.test(cat.date)) return short.replace(/\b(\d{2})(\d{2})\b/, "'$2");
          const y = (CRM.dateWithYear(cat.date, it.mediaId).match(/\b(\d{4})\b/) || [])[1];
          return y && +y !== (/* @__PURE__ */ new Date()).getFullYear() ? short + " '" + y.slice(2) : short;
        })() : "";
        meta.textContent = (it.amount ? "$" + money(it.amount) : "") + (dt ? " \xB7 " + dt : "");
        card.appendChild(meta);
        card.style.cursor = "pointer";
        card.title = (cat.filename || it.mediaId) + "\n" + t("crm.buys.open", uiLang);
        card.addEventListener("click", () => {
          const url2 = chrome.runtime.getURL("catalog.html?media=" + encodeURIComponent(it.mediaId));
          if (chrome.tabs && chrome.tabs.create) chrome.tabs.create({ url: url2 });
          else window.open(url2, "_blank");
        });
        grid.appendChild(card);
      }
    }
  });
  sec.append(head, grid);
  return sec;
}
function row(f) {
  const el = document.createElement("div");
  el.className = "row";
  el.dataset.handle = (f.handle || "").toLowerCase();
  const head = document.createElement("div");
  head.className = "rowhead";
  const score = document.createElement("div");
  score.className = "score";
  score.textContent = f.score;
  score.title = t("crm.tip.score", uiLang);
  score.style.borderColor = f.score >= 66 ? "#4caf50" : f.score >= 33 ? "#e6a23c" : "#556";
  head.appendChild(score);
  const main = document.createElement("div");
  main.className = "main";
  const nm = document.createElement("div");
  nm.className = "nm";
  nm.textContent = f.name;
  const hn = document.createElement("div");
  hn.className = "hn";
  hn.textContent = "@" + f.handle;
  main.append(nm, hn);
  const badges = document.createElement("div");
  badges.className = "badges";
  const badgesSec = document.createElement("div");
  badgesSec.className = "badges-sec";
  badges.appendChild(badge("", STAGE_ICON[f.stage] + " " + t("crm.stage." + f.stage, uiLang), t("crm.tip.stage", uiLang)));
  if (f.contact && f.contact.notCustomer) badges.appendChild(badge("dead", t("crm.card.notCustomer.badge", uiLang), t("crm.card.notCustomer.badgeTip", uiLang)));
  if (f.stuck) badges.appendChild(badge("stuck", t("crm.stuck." + f.stuck.key, uiLang, { n: f.stuck.n }), t("crm.tip.stuck", uiLang)));
  if (f.sub && f.sub.tierName) badges.appendChild(badge("tier", "\u2B50 " + f.sub.tierName, t("crm.tip.tier", uiLang)));
  if (f.spent > 0) badges.appendChild(badge("spent", t("crm.card.spent", uiLang, { n: fmtMoney(f.spent) }), spentTip(f)));
  if (f.buyCount > 0) badges.appendChild(badge("", t("crm.card.buys", uiLang, { n: f.buyCount }), t("crm.tip.buys", uiLang)));
  if (f.activeSub && f.sub && f.sub.price) badges.appendChild(badge("", t("crm.card.perMonth", uiLang, { n: fmtMoney(f.sub.price) }), t("crm.tip.perMonth", uiLang)));
  if (f.activeSub && f.sub && f.sub.billingCycle) badges.appendChild(badge("", t("crm.card.cycle", uiLang, { v: f.sub.billingCycle }), t("crm.tip.cycle", uiLang)));
  if (f.activeSub && f.sub && f.sub.renewOn === true) badges.appendChild(badge("ok", t("crm.card.renewOn", uiLang), t("crm.tip.renewOn", uiLang)));
  if (f.activeSub && f.sub && f.sub.renewOn === false) badges.appendChild(badge("churn", t("crm.card.renewOff", uiLang), t("crm.tip.renewOff", uiLang)));
  if (f.activeSub && f.daysLeft != null) badges.appendChild(badge("exp", t("crm.card.renews", uiLang, { n: f.daysLeft }), t("crm.tip.renews", uiLang)));
  if (f.expired) {
    const dt = (f.sub && f.sub.endDate || "").replace(/^[A-Za-z]+,\s*/, "");
    badges.appendChild(badge("dead", t("crm.card.expired", uiLang) + (dt ? " " + dt : ""), t("crm.tip.expired", uiLang)));
  }
  if (f.deleted) badges.appendChild(badge("dead", t("crm.card.deleted", uiLang), t("crm.tip.deleted", uiLang)));
  if (f.months) badgesSec.appendChild(badge("", t("crm.card.months", uiLang, { n: f.months }), t("crm.tip.months", uiLang)));
  if (f.firstSubAt) badgesSec.appendChild(badge("", t("crm.card.since", uiLang, { d: new Date(f.firstSubAt).toLocaleDateString(uiLang, { month: "short", year: "numeric" }) }), t("crm.tip.since", uiLang)));
  if (f.subCount > 1) badgesSec.appendChild(badge("", t("crm.card.subcount", uiLang, { n: f.subCount }), t("crm.tip.subcount", uiLang)));
  if (f.hasCard) badgesSec.appendChild(badge("", "\u{1F4B3}", t("crm.tip.card", uiLang)));
  const lastMsgAt = f.contact && f.contact.dossier && f.contact.dossier.lastMessageAt;
  if (lastMsgAt) {
    const dd = Math.floor((Date.now() - lastMsgAt) / 864e5);
    badgesSec.appendChild(badge("", t(dd <= 0 ? "crm.card.lastMsgToday" : "crm.card.lastMsg", uiLang, { n: dd }), t("crm.tip.lastMsg", uiLang)));
  }
  const cl = f.contact && f.contact.dossier && CLOSENESS[f.contact.dossier.closeness];
  if (cl) badgesSec.appendChild(badge("", cl.icon + " " + t("crm.card.closeness", uiLang, { v: t(cl.key, uiLang) }), t("crm.tip.closeness", uiLang)));
  if (f.lastLikeAt) {
    const days = Math.floor((Date.now() - f.lastLikeAt) / 864e5);
    const txt = days <= 0 ? t("crm.card.lastLikeToday", uiLang) : t("crm.card.lastLike", uiLang, { n: days });
    const hot = days <= 30 && f.expired;
    (hot ? badges : badgesSec).appendChild(badge(hot ? "exp" : "", txt, t("crm.tip.lastLike", uiLang)));
  }
  if (badgesSec.children.length) {
    const more = document.createElement("button");
    more.className = "bg-more";
    more.textContent = "\xB7\xB7\xB7 " + badgesSec.children.length;
    more.title = t("crm.card.moreChips", uiLang);
    more.addEventListener("click", (ev) => {
      ev.stopPropagation();
      badgesSec.classList.toggle("open");
    });
    badges.appendChild(more);
  }
  main.appendChild(badges);
  if (badgesSec.children.length) main.appendChild(badgesSec);
  head.appendChild(main);
  const side = document.createElement("div");
  side.className = "side";
  const note = document.createElement("textarea");
  note.className = "note";
  note.placeholder = t("crm.card.noteph", uiLang);
  const key = f.handle.toLowerCase();
  const pinnedOfFan = () => f.contact && f.contact.dossier && f.contact.dossier.manualFacts || [];
  note.value = f.contact && pinnedOfFan().length ? pinnedOfFan().join("\n") : crmNotes[key] || "";
  const noteBtn = document.createElement("button");
  noteBtn.className = "note-btn";
  const paintNote = () => {
    const v = (note.value || "").trim();
    noteBtn.textContent = v ? t("crm.card.noteBtn", uiLang, { note: v.slice(0, 26) }) : t("crm.card.noteBtnEmpty", uiLang);
    noteBtn.classList.toggle("filled", !!v);
    noteBtn.title = v || t("crm.card.noteAdd", uiLang);
  };
  paintNote();
  noteBtn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (note.classList.toggle("open")) note.focus();
  });
  note.addEventListener("click", (ev) => ev.stopPropagation());
  let dirty = false;
  const commitNote = () => {
    if (!dirty) return;
    dirty = false;
    if (!f.contact) {
      crmNotes[key] = note.value;
      saveNotes();
      return;
    }
    const lines = note.value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    chrome.runtime.sendMessage({ type: "SET_PINNED_FACTS", handle: f.handle, facts: lines }, (resp) => {
      if (!resp || !resp.success) {
        console.warn("[FanslyAI] \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u0451\u043D\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u044B \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0441\u044C:", resp && resp.error);
        return;
      }
      if (f.contact) {
        if (!f.contact.dossier) f.contact.dossier = {};
        f.contact.dossier.manualFacts = lines.slice(0, resp.pinned);
      }
      if (resp.dropped) {
        note.value = lines.slice(0, resp.pinned).join("\n");
        noteBtn.textContent = t("crm.card.noteLimit", uiLang, { n: resp.pinned });
        noteBtn.classList.add("filled");
      }
    });
  };
  note.addEventListener("input", () => {
    dirty = true;
    paintNote();
  });
  note.addEventListener("change", commitNote);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) commitNote();
  });
  const dm = document.createElement("a");
  dm.className = "dm";
  dm.textContent = t("crm.card.openDm", uiLang);
  dm.href = f.msgId ? "https://fansly.com/messages/" + f.msgId : "https://fansly.com/" + encodeURIComponent(f.handle);
  dm.title = t(f.msgId ? "crm.card.openDm.title.chat" : "crm.card.openDm.title.profile", uiLang);
  dm.target = "_blank";
  dm.rel = "noopener";
  const del = document.createElement("button");
  del.className = "fan-del";
  del.textContent = "\u{1F5D1}";
  del.title = t("crm.card.delete", uiLang);
  del.style.cssText = "background:none;border:none;cursor:pointer;font-size:13px;opacity:.55;padding:2px 4px";
  del.addEventListener("click", (e) => {
    e.stopPropagation();
    if (!window.confirm(t("crm.delete.confirm", uiLang, { name: f.name || f.handle }))) return;
    chrome.runtime.sendMessage({ type: "DELETE_FAN", handle: f.handle, name: f.name }, (r) => {
      if (r && r.success) el.remove();
    });
  });
  const own = document.createElement("button");
  own.className = "fan-own";
  const paintOwn = () => {
    const on = !!(f.contact && f.contact.notCustomer);
    own.textContent = on ? "\u{1F465}" : "\u{1F464}";
    own.title = on ? t("crm.card.notCustomer.onTip", uiLang) : t("crm.card.notCustomer.offTip", uiLang);
    own.style.cssText = "background:none;border:none;cursor:pointer;font-size:13px;padding:2px 4px;opacity:" + (on ? "1" : ".45") + ";filter:" + (on ? "none" : "grayscale(1)");
  };
  paintOwn();
  own.addEventListener("click", async (e) => {
    e.stopPropagation();
    const key2 = f.contact && f.contact._key;
    if (!key2) {
      own.title = t("crm.card.notCustomer.noKey", uiLang);
      own.textContent = "\u26A0\uFE0F";
      return;
    }
    let next;
    const ok = await ContactStore.patchRecord(key2, (rec) => ({ notCustomer: next = !rec.notCustomer }));
    if (ok) {
      f.contact.notCustomer = next;
      paintOwn();
    }
  });
  side.append(dm, noteBtn, note, own, del);
  head.appendChild(side);
  el.appendChild(head);
  const hasBuys = !!(f.purchasedMedia && f.purchasedMedia.length);
  if (hasDigest(f) || hasBuys) {
    const caret = document.createElement("span");
    caret.className = "dgcaret";
    caret.textContent = (hasDigest(f) ? "\u{1F4AC}" : "") + (hasBuys ? "\u{1F6D2}" : "");
    nm.appendChild(caret);
    main.style.cursor = "pointer";
    main.title = t("crm.digest.toggle", uiLang);
    let built = false;
    const build = () => {
      if (!built) {
        buildDigestBody(el, f);
        built = true;
      }
    };
    main.addEventListener("click", () => {
      build();
      el.classList.toggle("open");
    });
    el.faiReopen = () => {
      build();
      el.classList.add("open");
    };
  }
  return el;
}
const LIVE_DELAY = 500;
let livePending = /* @__PURE__ */ new Map(), liveTimer = null;
function onContactsChanged(ch, area) {
  if (area !== "local") return;
  for (const k of Object.keys(ch)) if (k.startsWith("fai_contact_") && ch[k].newValue) livePending.set(k, ch[k].newValue);
  if (livePending.size && !liveTimer) liveTimer = setTimeout(liveFlush, LIVE_DELAY);
}
function liveFlush() {
  liveTimer = null;
  if (!crmStore) return;
  const batch = livePending;
  livePending = /* @__PURE__ */ new Map();
  let changed = false;
  for (const [key, rec] of batch) {
    const l = (rec.handle || "").toLowerCase();
    const i = fans.findIndex((f2) => f2.contact ? f2.contact._key === key : !!l && (f2.handle || "").toLowerCase() === l);
    if (i < 0) continue;
    const el = [...document.querySelectorAll("#list .row")].find((r) => r.dataset.handle === (fans[i].handle || "").toLowerCase());
    const a = document.activeElement;
    if (el && el.contains(a) && (a.tagName === "TEXTAREA" || a.tagName === "INPUT")) {
      livePending.set(key, rec);
      el.addEventListener("focusout", () => setTimeout(() => {
        if (!liveTimer) liveTimer = setTimeout(liveFlush, LIVE_DELAY);
      }, 0), { once: true });
      continue;
    }
    const f = CRM.computeFan(fans[i].handle, fans[i].name, crmStore, contactMeta(key, rec), { briefStaleHours });
    f.msgId = rec._msgId || null;
    fans[i] = f;
    changed = true;
    if (!el) continue;
    const nel = row(f);
    if (el.classList.contains("open") && nel.faiReopen) nel.faiReopen();
    if (el.querySelector(".badges-sec.open")) {
      const s = nel.querySelector(".badges-sec");
      if (s) s.classList.add("open");
    }
    const grid = el.querySelector(".buys-grid");
    if (grid && grid.style.display !== "none") {
      const h = nel.querySelector(".buys-head");
      if (h) h.click();
    }
    el.replaceWith(nel);
  }
  if (changed) renderSummary();
}
function saveNotes() {
  chrome.storage.local.get("fansly_crm_notes", (d) => {
    const n = d.fansly_crm_notes || {};
    Object.assign(n, crmNotes);
    chrome.storage.local.set({ fansly_crm_notes: n });
  });
}
