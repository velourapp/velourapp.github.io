self.FaiDB = /* @__PURE__ */ (() => {
  const DB_NAME = "fai-catalog";
  const DB_VERSION = 3;
  const S_THUMBS = "thumbs", S_MEDIA = "media", S_HASHES = "hashes", S_FRAMES = "frames";
  const REV_KEY = "fansly_catalog_rev";
  const OLD_META = "fansly_catalog", OLD_HASH = "fansly_thumb_hashes", MIG_KEY = "fansly_catalog_migrated";
  const CLR_KEY = "fansly_catalog_cleared";
  const CHUNK = 300;
  const getLocal = (keys) => new Promise((r) => chrome.storage.local.get(keys, (d) => r(d || {})));
  const setLocal = (obj) => new Promise((r) => chrome.storage.local.set(obj, () => r()));
  const removeLocal = (keys) => new Promise((r) => chrome.storage.local.remove(keys, () => r()));
  const bumpRev = () => setLocal({ [REV_KEY]: Date.now() });
  let _db = null, _opening = null;
  function openDB() {
    if (_db) return Promise.resolve(_db);
    if (_opening) return _opening;
    _opening = new Promise((resolve, reject) => {
      let req;
      try {
        req = indexedDB.open(DB_NAME, DB_VERSION);
      } catch (e) {
        _opening = null;
        return reject(e);
      }
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(S_THUMBS)) db.createObjectStore(S_THUMBS);
        if (!db.objectStoreNames.contains(S_MEDIA)) db.createObjectStore(S_MEDIA);
        if (!db.objectStoreNames.contains(S_HASHES)) db.createObjectStore(S_HASHES);
        if (!db.objectStoreNames.contains(S_FRAMES)) db.createObjectStore(S_FRAMES);
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => {
          try {
            db.close();
          } catch (e) {
          }
          if (_db === db) _db = null;
        };
        db.onclose = () => {
          if (_db === db) _db = null;
        };
        _db = db;
        _opening = null;
        resolve(db);
      };
      req.onerror = () => {
        _opening = null;
        reject(req.error || new Error("idb_open_failed"));
      };
      req.onblocked = () => {
        console.warn("[FanslyAI] \u0431\u0430\u0437\u0430 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u0437\u0430\u043D\u044F\u0442\u0430 \u0434\u0440\u0443\u0433\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u043E\u0439 \u2014 \u0436\u0434\u0443, \u043F\u043E\u043A\u0430 \u043E\u043D\u0430 \u0435\u0451 \u043E\u0442\u043F\u0443\u0441\u0442\u0438\u0442 (\u043E\u0431\u043D\u043E\u0432\u0438 \u0432\u043A\u043B\u0430\u0434\u043A\u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F)");
        setTimeout(() => {
          if (_opening) {
            _opening = null;
            reject(new Error("idb_blocked: \u0431\u0430\u0437\u0443 \u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u2014 \u043E\u0431\u043D\u043E\u0432\u0438 \u0435\u0451 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438"));
          }
        }, 15e3);
      };
    });
    return _opening;
  }
  function closeDB() {
    try {
      if (_db) _db.close();
    } catch (e) {
    }
    _db = null;
  }
  async function run(names, mode, body) {
    const list = Array.isArray(names) ? names : [names];
    for (let attempt = 0; ; attempt++) {
      const db = await openDB();
      try {
        return await new Promise((resolve, reject) => {
          const t = db.transaction(list, mode);
          let result;
          t.oncomplete = () => resolve(result);
          t.onerror = () => reject(t.error || new Error("idb_tx_error"));
          t.onabort = () => reject(t.error || new Error("idb_tx_abort"));
          body(list.map((n) => t.objectStore(n)), (v) => {
            result = v;
          });
        });
      } catch (e) {
        if (attempt === 0 && /InvalidState|closing|closed|not allowed/i.test(String((e && e.name) + " " + (e && e.message)))) {
          closeDB();
          continue;
        }
        throw e;
      }
    }
  }
  const chunks = (arr) => {
    const out = [];
    for (let i = 0; i < arr.length; i += CHUNK) out.push(arr.slice(i, i + CHUNK));
    return out;
  };
  async function metaGetAll() {
    return run(S_MEDIA, "readonly", ([st], ok) => {
      const vals = st.getAll(), keys = st.getAllKeys();
      keys.onsuccess = () => {
        const k = keys.result;
        ok(Object.fromEntries(k.map((id, i) => [id, vals.result[i]])));
      };
    });
  }
  async function metaGet(ids) {
    if (!ids || !ids.length) return {};
    return run(S_MEDIA, "readonly", ([st], ok) => {
      const out = {};
      for (const id of ids) {
        const g = st.get(id);
        g.onsuccess = () => {
          if (g.result) out[id] = g.result;
        };
      }
      ok(out);
    });
  }
  const metaIds = () => run(S_MEDIA, "readonly", ([st], ok) => {
    const r = st.getAllKeys();
    r.onsuccess = () => ok(r.result);
  });
  const metaCount = () => run(S_MEDIA, "readonly", ([st], ok) => {
    const r = st.count();
    r.onsuccess = () => ok(r.result);
  });
  async function metaPut(map, onProgress) {
    const ids = Object.keys(map || {});
    if (!ids.length) return 0;
    let done = 0;
    for (const part of chunks(ids)) {
      await run(S_MEDIA, "readwrite", ([st]) => {
        for (const id of part) st.put(map[id], id);
      });
      done += part.length;
      if (onProgress) onProgress(done, ids.length);
    }
    await bumpRev();
    return ids.length;
  }
  async function metaPatch(patches) {
    const list = (patches || []).filter((p) => p && p.id);
    if (!list.length) return 0;
    let written = 0;
    for (const part of chunks(list)) {
      const box = await run(S_MEDIA, "readwrite", ([st], ok) => {
        const b = { n: 0 };
        ok(b);
        for (const p of part) {
          const g = st.get(p.id);
          g.onsuccess = () => {
            if (!g.result && !p.base) return;
            const rec = g.result || Object.assign({}, p.base);
            if (p.set) Object.assign(rec, p.set);
            for (const f of p.unset || []) delete rec[f];
            st.put(rec, p.id);
            b.n++;
          };
        }
      });
      written += box && box.n || 0;
    }
    await bumpRev();
    return written;
  }
  async function metaDelete(ids) {
    if (!ids || !ids.length) return 0;
    for (const part of chunks(ids)) await run(S_MEDIA, "readwrite", ([st]) => {
      for (const id of part) st.delete(id);
    });
    await bumpRev();
    return ids.length;
  }
  function metaFolderCounts(lastFull) {
    return run(S_MEDIA, "readonly", ([st], ok) => {
      const per = {};
      let total = 0;
      const cur = st.openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok({ total, per });
        const e = c.value || {};
        if (!(lastFull && e.lastSeen != null && e.lastSeen < lastFull)) {
          total++;
          for (const f of e.folders || []) per[f] = (per[f] || 0) + 1;
        }
        c.continue();
      };
    });
  }
  const THUMB_TRIES = 3;
  function metaThumbGapFolders() {
    return run(S_MEDIA, "readonly", ([st], ok) => {
      const s = /* @__PURE__ */ new Set();
      const cur = st.openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok([...s]);
        const e = c.value || {};
        if (!e.thumb && e.type !== "audio" && (e.thumbTry | 0) < THUMB_TRIES) {
          for (const f of e.folders || []) if (!/^all$/i.test(f)) s.add(f);
        }
        c.continue();
      };
    });
  }
  async function promoteFrameThumbs() {
    const withFrames = await frameIds();
    if (!withFrames.size) return { promoted: 0 };
    const ids = await run(S_MEDIA, "readonly", ([st], ok) => {
      const out = [];
      const cur = st.openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok(out);
        const e = c.value || {};
        if (!e.thumb && e.type === "video" && withFrames.has(String(c.key))) out.push(String(c.key));
        c.continue();
      };
    });
    let promoted = 0;
    for (const id of ids) {
      const frames = await frameGet(id);
      if (!frames || !frames.length) continue;
      await thumbPut([{ id, dataUrl: frames[0] }]);
      await metaPatch([{ id, set: { thumb: true, thumbFromFrame: true } }]);
      promoted++;
    }
    return { promoted };
  }
  async function metaUntagFolder(folder, keepIds) {
    const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();
    const keep = new Set(keepIds || []);
    const target = norm(folder);
    const changed = await run(S_MEDIA, "readwrite", ([st], ok) => {
      let n = 0;
      const cur = st.openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok(n);
        const e = c.value || {};
        if (!keep.has(String(c.key)) && (e.folders || []).some((f) => norm(f) === target)) {
          e.folders = e.folders.filter((f) => norm(f) !== target);
          c.update(e);
          n++;
        }
        c.continue();
      };
    });
    if (changed) await bumpRev();
    return changed;
  }
  async function metaUntagMissingFolders(keepNames) {
    const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();
    const keep = new Set((keepNames || []).map(norm));
    if (!keep.size) return { touched: 0, dropped: [] };
    const dropped = /* @__PURE__ */ new Set();
    const touched = await run(S_MEDIA, "readwrite", ([st], ok) => {
      let n = 0;
      const cur = st.openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok(n);
        const e = c.value || {};
        const cur_f = e.folders || [];
        if (cur_f.length) {
          const left = cur_f.filter((f) => keep.has(norm(f)));
          if (left.length !== cur_f.length) {
            for (const f of cur_f) if (!keep.has(norm(f))) dropped.add(f);
            e.folders = left;
            c.update(e);
            n++;
          }
        }
        c.continue();
      };
    });
    if (touched) await bumpRev();
    return { touched, dropped: [...dropped] };
  }
  const hashGetAll = () => run(S_HASHES, "readonly", ([st], ok) => {
    const vals = st.getAll(), keys = st.getAllKeys();
    keys.onsuccess = () => {
      const k = keys.result;
      ok(Object.fromEntries(k.map((id, i) => [id, vals.result[i]])));
    };
  });
  async function hashPut(map) {
    const ids = Object.keys(map || {});
    if (!ids.length) return 0;
    for (const part of chunks(ids)) await run(S_HASHES, "readwrite", ([st]) => {
      for (const id of part) st.put(map[id], id);
    });
    return ids.length;
  }
  async function hashDelete(ids) {
    if (!ids || !ids.length) return 0;
    for (const part of chunks(ids)) await run(S_HASHES, "readwrite", ([st]) => {
      for (const id of part) st.delete(id);
    });
    return ids.length;
  }
  async function thumbPut(items, onProgress) {
    const list = (items || []).filter((it) => it && it.id && it.dataUrl);
    if (!list.length) return 0;
    let done = 0;
    for (const part of chunks(list)) {
      await run(S_THUMBS, "readwrite", ([st]) => {
        for (const it of part) st.put(it.dataUrl, it.id);
      });
      done += part.length;
      if (onProgress) onProgress(done, list.length);
    }
    return list.length;
  }
  const thumbCount = () => run(S_THUMBS, "readonly", ([st], ok) => {
    const r = st.count();
    r.onsuccess = () => ok(r.result);
  });
  const thumbGetAll = () => run(S_THUMBS, "readonly", ([st], ok) => {
    const out = {};
    const cur = st.openCursor();
    cur.onsuccess = () => {
      const c = cur.result;
      if (!c) return ok(out);
      out[c.key] = c.value;
      c.continue();
    };
  });
  function thumbGet(ids) {
    if (!ids || !ids.length) return Promise.resolve({});
    return run(S_THUMBS, "readonly", ([st], ok) => {
      const out = {};
      for (const id of ids) {
        const g = st.get(id);
        g.onsuccess = () => {
          if (g.result) out[id] = g.result;
        };
      }
      ok(out);
    });
  }
  const thumbDelete = (ids) => run(S_THUMBS, "readwrite", ([st]) => {
    for (const id of Array.isArray(ids) ? ids : [ids]) st.delete(id);
  });
  const frameKey = (id, idx) => id + "|" + String(idx).padStart(2, "0");
  const frameRange = (id) => IDBKeyRange.bound(id + "|", id + "|\uFFFF");
  async function framePut(items) {
    const list = (items || []).filter((it) => it && it.id && it.dataUrl && it.idx != null);
    if (!list.length) return 0;
    for (const part of chunks(list))
      await run(S_FRAMES, "readwrite", ([st]) => {
        for (const it of part) st.put(it.dataUrl, frameKey(it.id, it.idx));
      });
    return list.length;
  }
  const frameGet = (id) => run(S_FRAMES, "readonly", ([st], ok) => {
    const out = [];
    const cur = st.openCursor(frameRange(id));
    cur.onsuccess = () => {
      const c = cur.result;
      if (!c) return ok(out);
      out.push(c.value);
      c.continue();
    };
  });
  const frameIds = () => run(S_FRAMES, "readonly", ([st], ok) => {
    const out = /* @__PURE__ */ new Set();
    const cur = st.openKeyCursor();
    cur.onsuccess = () => {
      const c = cur.result;
      if (!c) return ok(out);
      out.add(String(c.key).split("|")[0]);
      c.continue();
    };
  });
  const frameDelete = (id) => run(S_FRAMES, "readwrite", ([st]) => {
    st.delete(frameRange(id));
  });
  const frameGetAll = () => run(S_FRAMES, "readonly", ([st], ok) => {
    const out = {};
    const cur = st.openCursor();
    cur.onsuccess = () => {
      const c = cur.result;
      if (!c) return ok(out);
      out[c.key] = c.value;
      c.continue();
    };
  });
  async function framePutRaw(map) {
    const keys = Object.keys(map || {});
    if (!keys.length) return 0;
    let done = 0;
    for (const part of chunks(keys)) {
      await run(S_FRAMES, "readwrite", ([st]) => {
        for (const k of part) st.put(map[k], k);
      });
      done += part.length;
    }
    return done;
  }
  const frameCount = () => run(S_FRAMES, "readonly", ([st], ok) => {
    const r = st.count();
    r.onsuccess = () => ok(r.result);
  });
  const SAMPLE = 25;
  const sampleAvgLen = (store) => run(store, "readonly", ([st], ok) => {
    let sum = 0, cnt = 0;
    const cur = st.openCursor();
    cur.onsuccess = () => {
      const c = cur.result;
      if (!c || cnt >= SAMPLE) return ok(cnt ? Math.round(sum / cnt) : 0);
      if (typeof c.value === "string") {
        sum += c.value.length;
        cnt++;
      }
      c.continue();
    };
  });
  async function backupWeight() {
    const [tn, fn, ta, fa, media] = await Promise.all([
      thumbCount().catch(() => 0),
      frameCount().catch(() => 0),
      sampleAvgLen(S_THUMBS).catch(() => 0),
      sampleAvgLen(S_FRAMES).catch(() => 0),
      metaCount().catch(() => 0)
    ]);
    return { thumbs: tn, frames: fn, thumbAvg: ta, frameAvg: fa, media };
  }
  const videoList = async () => {
    const have = await frameIds().catch(() => /* @__PURE__ */ new Set());
    return run(S_MEDIA, "readonly", ([st], ok) => {
      const out = [];
      const cur = st.openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok(out);
        const e = c.value;
        if (e && e.type === "video" && !e.deleted)
          out.push({
            id: String(c.key),
            dur: e.dur || "",
            folders: e.folders || [],
            framesAt: e.framesAt || 0,
            frames: e.frames | 0,
            framesTry: e.framesTry | 0,
            hasFrames: have.has(String(c.key))
          });
        c.continue();
      };
    });
  };
  async function clearCatalog() {
    await setLocal({ [CLR_KEY]: Date.now() });
    await run([S_MEDIA, S_HASHES, S_THUMBS, S_FRAMES], "readwrite", ([m, h, t, f]) => {
      m.clear();
      h.clear();
      t.clear();
      f.clear();
    });
    await removeLocal([OLD_META, OLD_HASH]);
    await setLocal({ [MIG_KEY]: DB_VERSION });
    await bumpRev();
  }
  function deleteDatabase(timeoutMs = 8e3) {
    closeDB();
    return new Promise((resolve, reject) => {
      let done = false, blocked = false;
      const fin = (fn) => {
        if (!done) {
          done = true;
          fn();
        }
      };
      let rq;
      try {
        rq = indexedDB.deleteDatabase(DB_NAME);
      } catch (e) {
        return reject(e);
      }
      rq.onsuccess = () => fin(resolve);
      rq.onerror = () => fin(() => reject(rq.error || new Error("idb_delete_failed")));
      rq.onblocked = () => {
        blocked = true;
      };
      setTimeout(() => fin(() => reject(new Error(blocked ? "idb_blocked" : "idb_delete_timeout"))), timeoutMs);
    });
  }
  async function requestPersist() {
    try {
      if (typeof navigator === "undefined" || !navigator.storage || !navigator.storage.persist) return null;
      if (await navigator.storage.persisted()) return true;
      const ok = await navigator.storage.persist();
      console.log("[FanslyAI] \u043F\u043E\u0441\u0442\u043E\u044F\u043D\u043D\u043E\u0435 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430:", ok ? "\u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043E" : "\u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u043E\u0442\u043A\u0430\u0437\u0430\u043B");
      return ok;
    } catch (e) {
      return null;
    }
  }
  const CAT_MANUAL = ["tags", "desc", "folders", "personal", "blurManual", "notCustomer", "deleted", "deletedAt"];
  const CAT_MACHINE = ["autoTags", "tagScores", "rating", "tagger"];
  const isEmptyVal = (v) => v == null || v === "" || Array.isArray(v) && v.length === 0 || typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 0;
  function mergeCatalog(fromBackup, existing) {
    const out = Object.assign({}, fromBackup, existing);
    for (const id in fromBackup) {
      const b = fromBackup[id], e = existing[id];
      if (!b || typeof b !== "object" || !e || typeof e !== "object") continue;
      const rec = Object.assign({}, out[id]);
      for (const f of CAT_MANUAL) if (isEmptyVal(rec[f]) && !isEmptyVal(b[f])) rec[f] = b[f];
      if (!rec.tagger && b.tagger) {
        for (const f of CAT_MACHINE) if (b[f] !== void 0) rec[f] = b[f];
      }
      if (b.blurManual === true && e.blurManual !== true && b.blur !== void 0) rec.blur = b.blur;
      out[id] = rec;
    }
    return out;
  }
  async function restoreCatalog(inv, onProgress) {
    const say = (stage, done, total) => {
      if (onProgress) onProgress({ stage, done, total });
    };
    say("start");
    await ensureMigrated();
    if (inv.catalog && typeof inv.catalog === "object") {
      const existing = await metaGetAll();
      const merged = mergeCatalog(inv.catalog, existing);
      say("catalog", 0, Object.keys(merged).length);
      await metaPut(merged, (d, t) => say("catalog", d, t));
    }
    if (inv.thumbHashes && typeof inv.thumbHashes === "object") {
      const existing = await hashGetAll();
      const map = Object.assign({}, inv.thumbHashes, existing);
      say("hashes", 0, Object.keys(map).length);
      await hashPut(map);
      say("hashes", Object.keys(map).length, Object.keys(map).length);
    }
    if (inv.frames && typeof inv.frames === "object") {
      const keys = Object.keys(inv.frames);
      say("frames", 0, keys.length);
      await framePutRaw(inv.frames);
      say("frames", keys.length, keys.length);
    }
    if (inv.thumbs && typeof inv.thumbs === "object") {
      const items = Object.entries(inv.thumbs).map(([id, dataUrl]) => ({ id, dataUrl }));
      say("thumbs", 0, items.length);
      await thumbPut(items, (d, t) => say("thumbs", d, t));
    }
    say("done");
  }
  let _mig = null;
  function ensureMigrated() {
    if (_mig) return _mig;
    _mig = (async () => {
      const st = await getLocal([MIG_KEY, OLD_META, OLD_HASH, CLR_KEY]);
      const oldMeta = st[OLD_META] && typeof st[OLD_META] === "object" ? st[OLD_META] : null;
      const oldHash = st[OLD_HASH] && typeof st[OLD_HASH] === "object" ? st[OLD_HASH] : null;
      if (st[MIG_KEY] === DB_VERSION && !oldMeta && !oldHash) return { moved: 0, hashes: 0 };
      if (!oldMeta && !oldHash) {
        await setLocal({ [MIG_KEY]: DB_VERSION });
        return { moved: 0, hashes: 0 };
      }
      const gen0 = st[CLR_KEY] || 0;
      const cleared = async () => ((await getLocal(CLR_KEY))[CLR_KEY] || 0) !== gen0;
      let moved = 0, hashes = 0, junk = 0;
      if (oldMeta) {
        const valid = Object.keys(oldMeta).filter((id) => oldMeta[id] && typeof oldMeta[id] === "object");
        junk = Object.keys(oldMeta).length - valid.length;
        const have = new Set((await metaIds()).map(String));
        const todo = valid.filter((id) => !have.has(String(id)));
        for (const part of chunks(todo)) {
          if (await cleared()) {
            _mig = null;
            return { moved, hashes, junk, aborted: true };
          }
          await run(S_MEDIA, "readwrite", ([s]) => {
            for (const id of part) s.put(oldMeta[id], id);
          });
          moved += part.length;
        }
        const after = new Set((await metaIds()).map(String));
        const missing = valid.filter((id) => !after.has(String(id)));
        if (missing.length) throw new Error("migration_verify_failed: " + missing.length);
      }
      if (oldHash) {
        const todo = {};
        for (const id in oldHash) if (oldHash[id]) todo[id] = oldHash[id];
        hashes = await hashPut(todo);
      }
      if (await cleared()) {
        _mig = null;
        return { moved, hashes, junk, aborted: true };
      }
      const drop = [];
      if (oldMeta) drop.push(OLD_META);
      if (oldHash) drop.push(OLD_HASH);
      if (drop.length) await removeLocal(drop);
      await setLocal({ [MIG_KEY]: DB_VERSION });
      await bumpRev();
      console.log("[FanslyAI] \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u043B \u0432 IndexedDB:", moved, "\u043C\u0435\u0434\u0438\u0430 \xB7", hashes, "\u0445\u0435\u0448\u0435\u0439 \u043F\u0440\u0435\u0432\u044C\u044E" + (junk ? " \xB7 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E \u0431\u0438\u0442\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439: " + junk : ""));
      return { moved, hashes, junk };
    })().catch((e) => {
      _mig = null;
      throw e;
    });
    return _mig;
  }
  return {
    DB_NAME,
    DB_VERSION,
    REV_KEY,
    S_MEDIA,
    S_HASHES,
    S_THUMBS,
    S_FRAMES,
    open: openDB,
    close: closeDB,
    bumpRev,
    ensureMigrated,
    requestPersist,
    mergeCatalog,
    restoreCatalog,
    metaGetAll,
    metaGet,
    metaIds,
    metaCount,
    metaPut,
    metaPatch,
    metaDelete,
    metaFolderCounts,
    metaThumbGapFolders,
    metaUntagFolder,
    metaUntagMissingFolders,
    promoteFrameThumbs,
    hashGetAll,
    hashPut,
    hashDelete,
    thumbPut,
    thumbGet,
    thumbGetAll,
    thumbDelete,
    thumbCount,
    framePut,
    frameGet,
    frameGetAll,
    framePutRaw,
    frameIds,
    frameDelete,
    frameCount,
    videoList,
    backupWeight,
    clearCatalog,
    deleteDatabase
  };
})();
