(function() {
  "use strict";
  const clean = (s) => (s || "").replace(/\s+/g, " ").trim();
  const key = (s) => clean(s).toLowerCase();
  function read(root, reg) {
    const counts = {}, first = /* @__PURE__ */ new Map();
    for (const a of reg.qa("vaultAlbum", root)) {
      const name = clean(reg.q("vaultAlbumName", a)?.textContent);
      if (!name) continue;
      const hit = first.get(key(name));
      if (hit) {
        hit.tiles++;
        continue;
      }
      first.set(key(name), { name, tiles: 1 });
      const num = (reg.q("vaultAlbumCount", a)?.textContent || "").replace(/[^\d]/g, "");
      if (num) counts[name] = parseInt(num, 10);
    }
    const dups = [];
    let dupTiles = 0;
    for (const { name, tiles: tiles2 } of first.values()) if (tiles2 > 1) {
      dups.push(name);
      dupTiles += tiles2;
      delete counts[name];
    }
    return { counts, dups, dupTiles };
  }
  const names = (site) => [...Object.keys(site && site.counts || {}), ...site && site.dups || []];
  const isDup = (site, name) => {
    const k = key(name);
    return (site && site.dups || []).some((d) => key(d) === k);
  };
  function tiles(root, reg) {
    const all = [...reg.qa("vaultAlbum", root)];
    let last = -1;
    all.forEach((a, i) => {
      if (a.childElementCount) last = i;
    });
    let real = 0, labeled = 0, holes = 0;
    const names2 = [], seen = /* @__PURE__ */ new Set();
    all.forEach((a, i) => {
      if (!a.childElementCount) {
        if (i < last) holes++;
        return;
      }
      real++;
      const name = clean(reg.q("vaultAlbumName", a)?.textContent);
      if (!name) return;
      labeled++;
      if (!seen.has(key(name))) {
        seen.add(key(name));
        names2.push(name);
      }
    });
    return { real, labeled, holes, fillers: all.length - real - holes, names: names2, complete: real > 0 && labeled === real && holes === 0 };
  }
  function firstByName(list) {
    const out = [], seen = /* @__PURE__ */ new Map();
    for (const it of list) {
      const hit = seen.get(key(it.name));
      if (hit) {
        hit.dup = true;
        continue;
      }
      const copy = { ...it };
      seen.set(key(it.name), copy);
      out.push(copy);
    }
    return out;
  }
  function missed(siteCounts, walked, onlyFolders) {
    const done = new Set((walked || []).map(key)), seen = /* @__PURE__ */ new Set();
    const expected = onlyFolders && onlyFolders.length ? onlyFolders : Object.keys(siteCounts || {});
    return expected.filter((n) => {
      const k = key(n);
      if (!k || k === "all" || done.has(k) || seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }
  function drift(site, ours, noise) {
    const counts = site && site.counts || {};
    const dupKeys = new Set((site && site.dups || []).map(key));
    const lim = noise > 0 ? noise : 0;
    const byFolder = {};
    const all = {};
    let max = 0;
    for (const name in counts) {
      if (dupKeys.has(key(name))) continue;
      const siteN = counts[name];
      const isAll = /^all$/i.test(name);
      const our = isAll ? ours.total : ours.per[name] || 0;
      const diff = siteN - our;
      all[name] = { site: siteN, our, diff };
      if (isAll || Math.abs(diff) <= lim) continue;
      byFolder[name] = { site: siteN, our, diff };
      max = Math.max(max, Math.abs(diff));
    }
    return { drift: max, byFolder, all };
  }
  self.VaultCounts = { clean, key, read, names, isDup, tiles, firstByName, missed, drift };
})();
