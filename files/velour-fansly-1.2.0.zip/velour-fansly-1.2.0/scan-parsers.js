(function() {
  "use strict";
  let q, qa, qm, PLAT, cleanContactName;
  function init(deps) {
    const d = deps || {};
    const missing = ["sel", "plat", "cleanContactName"].filter((k) => d[k] == null);
    if (missing.length) console.warn("[FanslyAI] ScanParsers.init: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439:", missing.join(", "));
    ({ q, qa, qm } = d.sel || {});
    PLAT = d.plat;
    cleanContactName = d.cleanContactName;
  }
  const collapseKey = (k) => (k || "").normalize("NFKC").replace(/[\u200d\ufe0f]/g, "").replace(/\s+/g, " ").trim();
  function getUnreadCount(el) {
    const badge = el.querySelector(PLAT.SEL.listUnread);
    if (!badge) return 0;
    const t = badge.innerText?.trim();
    if (t && /^\d+$/.test(t)) return parseInt(t) || 1;
    return 1;
  }
  function hour24(h, ap) {
    return ap ? h % 12 + (/p/i.test(ap) ? 12 : 0) : h;
  }
  function parseMsgTimeFull(txt) {
    const s = (txt || "").trim().toLowerCase();
    if (!s) return null;
    if (/^(now|just now|сейчас|jetzt|ahora|maintenant)$/.test(s)) return { ts: Date.now(), step: 1e3 };
    let m;
    if (m = s.match(/^(\d+)\s*(s|sec|secs|с|сек|s\.)$/)) return { ts: Date.now() - +m[1] * 1e3, step: 1e3 };
    if (m = s.match(/^(\d+)\s*(m|min|mins|м|мин|m\.)$/)) return { ts: Date.now() - +m[1] * 6e4, step: 6e4 };
    if (m = s.match(/^(\d+)\s*(h|hr|hrs|ч|час|std|h\.)$/)) return { ts: Date.now() - +m[1] * 36e5, step: 36e5 };
    if (m = s.match(/^(\d+)\s*(d|day|days|д|дн|t|j)$/)) return { ts: Date.now() - +m[1] * 864e5, step: 864e5 };
    if (m = s.match(/^(\d+)\s*(w|wk|wks|week|weeks|н|нед)$/)) return { ts: Date.now() - +m[1] * 7 * 864e5, step: 7 * 864e5 };
    if (m = s.match(/^(\d+)\s*(mo|mon|month|months|мес)$/)) return { ts: Date.now() - +m[1] * 30 * 864e5, step: 30 * 864e5 };
    const md = (txt || "").match(/([A-Z][a-z]{2})\s+(\d{1,2})(?:,?\s*(\d{4}))?(?:[, ]+(\d{1,2}):(\d{2})(?:\s*([AaPp])\.?[Mm]\.?(?![A-Za-z]))?)?/);
    if (md && monthOf(md[1]) != null) {
      const y = md[3] ? +md[3] : (/* @__PURE__ */ new Date()).getFullYear(), hh = md[4] ? hour24(+md[4], md[6]) : 0;
      let ts = new Date(y, monthOf(md[1]), +md[2], hh, md[5] ? +md[5] : 0).getTime();
      if (!md[3] && ts > Date.now() + 864e5) ts = new Date(y - 1, monthOf(md[1]), +md[2], hh, md[5] ? +md[5] : 0).getTime();
      return { ts, step: md[4] ? 6e4 : 864e5 };
    }
    return null;
  }
  function parseMsgTime(txt) {
    const r = parseMsgTimeFull(txt);
    return r ? r.ts : null;
  }
  function rowActivityTs(el) {
    return parseMsgTime(el.querySelector(PLAT.SEL.messageTime)?.textContent || "");
  }
  function rowActivityFull(el) {
    return parseMsgTimeFull(el.querySelector(PLAT.SEL.messageTime)?.textContent || "");
  }
  function rowSnapshot(el) {
    const id = PLAT.contactIdFromHref(el.getAttribute("href"));
    if (!id) return null;
    const nameEl = el.querySelector(PLAT.SEL.displayName);
    const previewRaw = (el.querySelector(PLAT.SEL.rowPreview)?.innerText || "").trim();
    return {
      id,
      name: nameEl ? cleanContactName(nameEl.innerText) : "",
      preview: collapseKey(previewRaw),
      // ключ: та же нормализация, что у ключей ленты (NFKC, без ZWJ/VS16, пробелы)
      previewRaw,
      // в ТГ уходит оригинал: нормализованный ключ ломает составные эмодзи (ревью 2026-09-07)
      badge: getUnreadCount(el),
      paid: !!el.querySelector(PLAT.SEL.rowPaid),
      media: !!el.querySelector(PLAT.SEL.rowMedia),
      ts: rowActivityTs(el),
      tsLabel: (el.querySelector(PLAT.SEL.messageTime)?.textContent || "").trim(),
      // сырая метка: сравнение меток надёжнее пересчёта (метки статичны до перерисовки)
      seenAt: Date.now()
      // когда снимок снят: для обычного «+1» это и есть приход (с точностью до дебаунса)
    };
  }
  function readEnvelopeUnread() {
    let max = 0;
    document.querySelectorAll(PLAT.SEL.navEnvelope).forEach((el) => {
      const n = parseInt((el.textContent || "").replace(/\D/g, ""), 10) || 0;
      if (n > max) max = n;
    });
    return max;
  }
  function subText(el) {
    return (el && el.textContent || "").replace(/\s+/g, " ").trim();
  }
  function subDays(txt) {
    const m = txt.match(/(\d+)\s*(?:day|days|день|дня|дней|Tag|Tage|jour|día)/i);
    return m ? parseInt(m[1], 10) : null;
  }
  function subDate(txt) {
    const m = txt.match(/:\s*([A-Za-z]{3,}[^()]*?\d{4})/);
    return m ? m[1].trim() : "";
  }
  function subCardParse(card) {
    const a = q("subUserLink", card);
    const handle = (a && a.getAttribute("href") || "").replace(/^\//, "").trim();
    if (!handle || handle === "#") return null;
    const name = subText(q("subUserName", card)) || handle;
    if (/^unknown\b/i.test(name)) return null;
    const starIcon = [...qa("subStarIcon", card)].find((u) => q("subStar", u));
    const tierColor = starIcon ? (((starIcon.getAttribute("style") || "").match(/color:\s*([^;]+)/) || [])[1] || "").trim() : "";
    const overlay = starIcon && q("subStarOverlay", starIcon);
    const overlayCls = overlay ? overlay.className : "";
    let tierName = "", renewOn = null, billingCycle = "", totalMonths = 0, price = 0, endLabel = "", endDate = "", endInDays = null;
    for (const row of card.querySelectorAll(".subscription-details .flex-row")) {
      const icon = row.querySelector("i");
      const cls = icon ? icon.className : "";
      const txt = subText(row);
      if (/fa-star\b/.test(cls)) tierName = txt.replace(/^.*?:\s*/, "").trim();
      else if (/fa-toggle-(on|off)/.test(cls)) {
        const m = txt.match(/:\s*(on|off)\b/i);
        renewOn = m ? m[1].toLowerCase() === "on" : /fa-toggle-on/.test(cls);
      } else if (/fa-calendar-star/.test(cls)) billingCycle = txt.replace(/^.*?:\s*/, "").trim();
      else if (/fa-droplet/.test(cls)) {
        if (/\d{4}/.test(txt)) {
          endLabel = "ended";
          endDate = subDate(txt);
        } else totalMonths = parseInt((txt.match(/(\d+)/) || [])[1] || "0", 10);
      } else if (/fa-rotate\b/.test(cls)) {
        endLabel = "renews";
        endDate = subDate(txt);
        endInDays = subDays(txt);
      } else if (/fa-circle-pause/.test(cls)) {
        endLabel = "ends";
        endDate = subDate(txt);
        endInDays = subDays(txt);
      } else if (/fa-circle-xmark|fa-xmark|fa-ban/.test(cls) || /expired/i.test(txt)) {
        endLabel = "ended";
        endDate = subDate(txt);
      }
    }
    const dl = q("subDetails", card);
    if (dl) {
      if (!tierName) tierName = subText(q("subTier", card));
      const dds = [...qa("subDetailValue", dl)];
      const ri = dds.findIndex((dd) => /^(on|off)$/i.test(subText(dd)));
      if (ri >= 0) {
        renewOn = subText(dds[ri]).toLowerCase() === "on";
        const prev = dds[ri - 1], next = dds[ri + 1];
        if (prev && !qm("subPriceRow", prev) && !billingCycle) billingCycle = subText(prev);
        const m = next && subText(next).match(/^(\d+)/);
        if (m) totalMonths = parseInt(m[1], 10);
      }
      const dateBox = q("subDateBox", card);
      const dateVal = subText(dateBox && q("subDateValue", dateBox));
      if (dateVal) endDate = dateVal;
      const pill = q("subStatus", card);
      if (pill) endLabel = qm("subStatusOk", pill) ? renewOn === false ? "ends" : "renews" : "ended";
      const dm = endLabel !== "ended" && dateVal.match(/([A-Z][a-z]{2})[a-z]*\s+(\d{1,2}),\s*(\d{4})/);
      const mo = dm ? monthOf(dm[1]) : null;
      if (mo != null) endInDays = Math.max(0, Math.ceil((new Date(+dm[3], mo, +dm[2]).getTime() - Date.now()) / 864e5));
    }
    const bal = q("subPrice", card);
    price = parseMoney(subText(bal)) || 0;
    let status;
    if (endLabel === "renews" || /fa-arrow-rotate-right/.test(overlayCls)) status = "active";
    else if (endLabel === "ends" || /fa-pause/.test(overlayCls)) status = "ending";
    else status = "expired";
    return { handle, name, tierName, tierColor, renewOn, billingCycle, totalMonths, price, status, endLabel, endDate, endInDays, syncedAt: Date.now() };
  }
  function earnMediaEls(descTd) {
    return [...qa("earnMedia", descTd)].filter((el) => !qm("mediaPreview", el));
  }
  function earnHiddenCount(descTd) {
    const s = q("moreOverlay", descTd);
    return s ? parseInt((s.textContent || "").trim(), 10) || 0 : 0;
  }
  function earnType(descTd) {
    const mediaCount = earnMediaEls(descTd).length;
    if (mediaCount) return mediaCount + earnHiddenCount(descTd) > 1 ? "media_bundle" : "media";
    if (/subscription|подписк|suscrip|abonn/i.test(descTd.textContent || "")) return "subscription";
    return "tip";
  }
  function parseMoney(s) {
    s = (s || "").replace(/[^\d.,]/g, "").replace(/[.,]+$/, "");
    if (!s) return NaN;
    const dec = Math.max(s.lastIndexOf("."), s.lastIndexOf(","));
    if (dec === -1) return parseFloat(s);
    return parseFloat(s.slice(0, dec).replace(/[.,]/g, "") + "." + s.slice(dec + 1).replace(/[.,]/g, ""));
  }
  function parseWalletTx(row) {
    const pick = (key) => subText(q(key, row));
    if (!q("earnTxBuyer", row)) return null;
    if (q("earnTxOut", row) || /^[−–-]/.test(pick("earnTxSign"))) return null;
    const oid = (pick("earnTxId").match(/\d{15,}/) || [])[0];
    if (!oid) return null;
    const type = earnType(row);
    if (!type) return null;
    const amtEl = q("earnTxAmount", row);
    const net = amtEl ? parseMoney(subText(amtEl)) : NaN;
    if (!(net >= 0)) return null;
    const refunded = /refund|возврат|declined|chargeback/i.test(pick("earnTxStatus"));
    const buyerA = q("earnTxBuyerLink", row);
    const buyer = buyerA ? (buyerA.getAttribute("href") || "").replace(/^\//, "") : "";
    const dateStr = pick("earnTxDate");
    const mediaIds = earnMediaEls(row).map((el) => el.getAttribute("data-media-id")).filter(Boolean);
    const bundleSize = mediaIds.length + earnHiddenCount(row);
    return { orderId: oid, date: dateStr, at: parseMsgTime(dateStr), type, buyer, net, refunded, mediaIds, bundleSize };
  }
  function parseEarningsRow(tr) {
    if (qm("earnTxRow", tr)) return parseWalletTx(tr);
    const tds = [...qa("earnCell", tr)];
    if (tds.length < 4) return null;
    let descTd = tds.find((td) => q("earnCellBuyer", td));
    if (!descTd) descTd = tds.find((td) => /Sale to|Subscription|\bTip\b/i.test(td.textContent || ""));
    if (!descTd) return null;
    const type = earnType(descTd);
    if (!type) return null;
    const orderId = (subText(tds[2] || tds.find((td) => /^\s*\d{15,}\s*$/.test(td.textContent || "")) || {}) || "").match(/\d{15,}/);
    const oid = orderId ? orderId[0] : (("" + (tr.textContent || "")).match(/\b\d{16,}\b/) || [])[0];
    if (!oid) return null;
    const amtEl = q("earnAmount", tr);
    const net = amtEl ? parseMoney(subText(amtEl)) : NaN;
    if (!(net >= 0)) return null;
    const refunded = /refund|возврат|declined|chargeback/i.test(subText(tds[1] || document.createElement("td")));
    const buyerA = q("earnCellBuyerLink", descTd);
    const buyer = buyerA ? (buyerA.getAttribute("href") || "").replace(/^\//, "") : "";
    const dateStr = subText(tds[0]);
    const mediaIds = earnMediaEls(descTd).map((el) => el.getAttribute("data-media-id")).filter(Boolean);
    const bundleSize = mediaIds.length + earnHiddenCount(descTd);
    return { orderId: oid, date: dateStr, at: parseMsgTime(dateStr), type, buyer, net, refunded, mediaIds, bundleSize };
  }
  const BROADCAST_ICONS = { reach: "broadcastReach", open: "broadcastOpen", sale: "broadcastSale" };
  function broadcastStatNumber(statEl) {
    if (!statEl) return null;
    const clone = statEl.cloneNode(true);
    qa("broadcastTooltip", clone).forEach((x) => x.remove());
    const m = (clone.textContent || "").replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : null;
  }
  function broadcastMetric(card, iconKey) {
    const item = [...qa("broadcastStat", card)].find((s) => q(iconKey, s));
    return item ? broadcastStatNumber(item) : null;
  }
  function broadcastDate(s) {
    const m = (s || "").match(/([A-Za-z]{3,})\s+(\d{1,2}),\s*(\d{4})(?:\s+at\s+(\d{1,2}):(\d{2})(?:\s*([AaPp])\.?[Mm]\.?(?![A-Za-z]))?)?/);
    const mo = m && monthOf(m[1].slice(0, 3));
    if (!m || mo == null) return null;
    return new Date(+m[3], mo, +m[2], m[4] ? hour24(+m[4], m[6]) : 0, m[5] ? +m[5] : 0).getTime();
  }
  function broadcastParseCard(card) {
    const reach = broadcastMetric(card, BROADCAST_ICONS.reach);
    const open = broadcastMetric(card, BROADCAST_ICONS.open);
    const sale = broadcastMetric(card, BROADCAST_ICONS.sale);
    if (reach == null && open == null && sale == null) return null;
    let dollarEl = q("broadcastAmount", card);
    const dollarBox = dollarEl ? null : q("broadcastAmountBox", card);
    if (dollarBox) {
      dollarEl = dollarBox.cloneNode(true);
      qa("broadcastTooltip", dollarEl).forEach((x) => x.remove());
    }
    const revenue = dollarEl ? parseMoney(subText(dollarEl)) || 0 : null;
    const label = subText(q("broadcastTime", card) || document.createElement("span"));
    const preview = subText(q("broadcastText", card) || document.createElement("span")).slice(0, 120);
    return { reach, open, sale, revenue, label, preview, at: broadcastDate(label), syncedAt: Date.now() };
  }
  const monthOf = (k) => self.CRM.MONTHS[k];
  function notifTier(txt) {
    const m = (txt || "").match(/\(([^)]+)\)\s*$/);
    return m ? m[1].trim() : "";
  }
  function notifParse(node) {
    const a = q("notifUser", node);
    const handle = (a && a.getAttribute("href") || "").replace(/^\//, "").trim();
    if (!handle || handle === "#") return null;
    const name = subText(q("displayName", node)) || handle;
    const txt = (node.innerText || "").replace(/\s+/g, " ").trim();
    const bal = q("notifAmount", node);
    const _amt = bal ? parseMoney(subText(bal)) : NaN;
    const amount = Number.isFinite(_amt) ? _amt : null;
    const stamp = subText(q("notifTime", node));
    const at = parseMsgTime(stamp);
    const tierTxt = stamp && txt.endsWith(stamp) ? txt.slice(0, -stamp.length).trim() : txt;
    let type = null, mediaId = null, tier = "";
    if (qm("notifMediaOrder", node) || /Purchased your Media/i.test(txt)) {
      type = "media";
      const mEl = q("notifMedia", node);
      mediaId = mEl ? mEl.getAttribute("data-media-id") : null;
    } else if (qm("notifSubExpire", node) || /Subscription\s+expired/i.test(txt)) {
      type = "sub_expire";
      tier = notifTier(tierTxt);
    } else if (qm("notifSubPay", node) || /Subscription\s+(Purchase|Renewal)/i.test(txt)) {
      type = /Purchase/i.test(txt) ? "sub_new" : "sub_renew";
      tier = notifTier(tierTxt);
    } else if (qm("notifTipRow", node) || /has tipped you/i.test(txt)) {
      type = "tip";
    } else return null;
    return { handle, name, type, amount, mediaId, tier, at };
  }
  function scrapeCreatorStats() {
    const out = {};
    for (const st of qa("creatorStat")) {
      const title = (q("creatorStatTitle", st)?.textContent || "").trim().toLowerCase();
      const val = parseInt((q("creatorStatValue", st)?.textContent || "").replace(/[^\d]/g, ""), 10);
      if (!(val >= 0)) continue;
      if (/бесплатн/i.test(title)) out.followers = val;
      else if (/subscriber|платн|abonnent|suscriptor|abonné/i.test(title)) out.subscribers = val;
      else if (/follower|фолловер|фоловер|seguidor/i.test(title)) out.followers = val;
      else if (/like|лайк|gefällt|me gusta|j.?aime/i.test(title)) out.likes = val;
    }
    return out;
  }
  function scrapeTiers() {
    const out = [];
    for (const box of qa("tierBox")) {
      const name = subText(q("tierName", box));
      if (!name) continue;
      const plan = q("tierPlan", box);
      const color = plan ? (((plan.getAttribute("style") || "").match(/background:\s*([^;]+)/) || [])[1] || "").trim() : "";
      const price = parseMoney(subText(q("tierPrice", box)));
      if (!(price >= 0)) continue;
      if (out.some((x) => x.name === name)) continue;
      out.push({ name, price, color });
    }
    out.sort((a, b) => a.price - b.price);
    return out;
  }
  self.ScanParsers = { init, collapseKey, getUnreadCount, parseMsgTime, rowActivityTs, rowActivityFull, rowSnapshot, readEnvelopeUnread, subText, subCardParse, parseEarningsRow, broadcastParseCard, notifParse, parseMoney, scrapeCreatorStats, scrapeTiers, broadcastDate };
})();
