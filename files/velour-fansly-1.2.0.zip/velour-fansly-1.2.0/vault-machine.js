(function() {
  "use strict";
  const FULL_MAX = 300;
  const STALE_MS = 24 * 3600 * 1e3;
  const NOTICE_MS = 24 * 3600 * 1e3;
  const BEAT_MS = 10 * 1e3;
  const DEAD_MS = 60 * 1e3;
  const ACTIVE = /* @__PURE__ */ new Set(["check", "quick", "full", "verify"]);
  const MANUAL_QUICK = /* @__PURE__ */ new Set(["panelQuick", "catalogQuick", "offer"]);
  const MANUAL_FULL = /* @__PURE__ */ new Set(["panelFull", "collectAll"]);
  const EMPTY = Object.freeze({ v: 1, state: "idle", since: 0, trigger: null, snapshot: null, plan: null, offer: null, note: null, mismatchSig: null, added: 0, error: null, stopRequested: false, beat: 0 });
  const WHOLE = Object.freeze({ incr: [], full: [], whole: true });
  const key = (s) => VaultCounts.key(s);
  const isAll = (n) => key(n) === "all";
  const sameName = (a, b) => key(a) === key(b);
  const fresh = (st, patch) => Object.freeze(Object.assign({}, st, patch));
  const none = (st) => ({ state: st, effects: [] });
  const alive = (st, now) => now - (st.beat || 0) <= DEAD_MS;
  function sig(site) {
    const names = Object.keys(site || {}).filter((n) => !isAll(n)).sort();
    return JSON.stringify(names.map((n) => [n, site[n]]));
  }
  function plan(snap) {
    const site = snap && snap.site || {};
    const ours = snap && snap.ours || { total: 0, per: {} };
    const dups = snap && snap.dups || [];
    const { drift, byFolder } = VaultCounts.drift({ counts: site, dups }, ours, 0);
    const dupKeys = new Set(dups.map(key));
    const gaps = (snap && snap.gaps || []).filter((g) => !isAll(g) && !dupKeys.has(key(g)));
    const full = [], incr = [];
    const push = (arr, n) => {
      if (!arr.some((x) => sameName(x, n))) arr.push(n);
    };
    for (const n of Object.keys(byFolder)) {
      const v = byFolder[n];
      if (gaps.some((g) => sameName(g, n)) || v.diff < 0 || v.diff > 0 && v.site <= FULL_MAX) push(full, n);
      else if (v.diff > 0) push(incr, n);
    }
    for (const g of gaps) if (!full.some((x) => sameName(x, g))) push(full, g);
    return { incr, full, whole: false, drift, byFolder };
  }
  const isEmpty = (p) => !p.whole && !p.incr.length && !p.full.length;
  const offerFor = (p) => p.full.length ? "folders" : "update";
  const snapshotOf = (snap, p, now) => ({ at: snap.at || now, site: snap.site || {}, ours: snap.ours || { total: 0, per: {} }, dups: snap.dups || [], gaps: snap.gaps || [], drift: p.drift, byFolder: p.byFolder });
  const finish = (st, patch) => ({ state: fresh(st, Object.assign({ stopRequested: false }, patch)), effects: [{ do: "finish" }] });
  const scan = (st, patch, p) => ({ state: fresh(st, patch), effects: [{ do: "scan", plan: p }] });
  function fromCheck(st, ev, now) {
    const snap = ev.snap;
    if (!snap) {
      if (st.stopRequested) return finish(st, { state: "stopped", note: "stopped", offer: "update", plan: null });
      if (st.trigger === "periodic") return finish(st, { state: "done", note: "noOverview" });
      return scan(st, { state: "full", plan: WHOLE, offer: null, note: null }, WHOLE);
    }
    const p = plan(snap);
    const snapshot = snapshotOf(snap, p, now);
    const sameSig = !!st.mismatchSig && st.mismatchSig === sig(snap.site);
    if (st.stopRequested) return finish(st, { snapshot, state: "stopped", note: "stopped", offer: "update", plan: null });
    if (MANUAL_FULL.has(st.trigger)) return scan(st, { snapshot, state: "full", plan: WHOLE, offer: null, note: null }, WHOLE);
    if (isEmpty(p)) {
      if (st.trigger === "periodic") return finish(st, { snapshot, state: "done", note: "upToDate", offer: null, plan: null, mismatchSig: null });
      return { state: fresh(st, { snapshot, state: "done", note: "upToDate", offer: null, plan: null, mismatchSig: null }), effects: [{ do: "sweep" }, { do: "finish" }] };
    }
    if (sameSig) return finish(st, { snapshot, state: "done", note: "siteMismatch", offer: null, plan: p });
    if (st.trigger === "periodic") return finish(st, { snapshot, state: "done", note: null, offer: offerFor(p), plan: p, mismatchSig: null });
    return scan(st, { snapshot, state: p.full.length ? "full" : "quick", plan: p, offer: null, note: null, mismatchSig: null }, p);
  }
  function fromVerify(st, ev, now) {
    const executed = st.plan || WHOLE;
    const snap = ev.snap;
    if (!snap) {
      if (st.stopRequested) return finish(st, { state: "stopped", note: "stopped", offer: "update", plan: null });
      return finish(st, { state: "done", note: "noOverview", plan: null });
    }
    const p = plan(snap);
    const snapshot = snapshotOf(snap, p, now);
    if (st.stopRequested) return finish(st, { snapshot, state: "stopped", note: "stopped", offer: "update", plan: null });
    if (isEmpty(p)) return finish(st, { snapshot, state: "done", note: "upToDate", offer: null, plan: null, mismatchSig: null });
    const wasFull = executed.whole || executed.full.length > 0;
    if (!wasFull) {
      const p2 = { incr: [], full: [...p.incr, ...p.full], whole: false, drift: p.drift, byFolder: p.byFolder, stuck: true };
      return finish(st, { snapshot, state: "done", note: null, offer: "folders", plan: p2, mismatchSig: null });
    }
    const planned = executed.whole ? null : [...executed.incr, ...executed.full];
    const remaining = [...p.incr, ...p.full];
    const covered = executed.whole || remaining.every((n) => planned.some((x) => sameName(x, n)));
    if (covered) return finish(st, { snapshot, state: "done", note: "siteMismatch", offer: null, plan: p, mismatchSig: sig(snap.site) });
    return finish(st, { snapshot, state: "done", note: null, offer: offerFor(p), plan: p, mismatchSig: null });
  }
  function step(st, ev) {
    st = st || EMPTY;
    const t = ev && ev.type;
    const now = ev && ev.now || 0;
    if (t === "reset") return { state: EMPTY, effects: [] };
    const active = ACTIVE.has(st.state) && alive(st, now);
    let r;
    switch (t) {
      case "start":
        r = active ? none(st) : { state: fresh(st, { state: "check", since: now, trigger: ev.trigger || null, note: null, error: null, stopRequested: false }), effects: [{ do: "check" }] };
        break;
      case "counts":
        r = st.state === "check" ? fromCheck(st, ev, now) : st.state === "verify" ? fromVerify(st, ev, now) : none(st);
        break;
      case "scanEnd":
        r = st.state === "quick" || st.state === "full" ? { state: fresh(st, { state: "verify", added: ev.added | 0, stopRequested: st.stopRequested || !!ev.stopped }), effects: [] } : none(st);
        break;
      // пересверку делает сам модуль в конце прогона; stopped от модуля — та же остановка (кнопка могла уйти к нему напрямую)
      case "stop":
        r = active ? { state: fresh(st, { stopRequested: true }), effects: [{ do: "cancel" }] } : none(st);
        break;
      // модуль дорабатывает границу прохода, дальше — verify → stopped
      case "error":
        r = active ? finish(st, { state: "error", note: "error", offer: "update", plan: null, error: { name: ev.name || "Error", mode: ev.mode || null } }) : none(st);
        break;
      case "beat":
        r = active ? { state: fresh(st, {}), effects: [] } : none(st);
        break;
      // сигнал жизни: только время (ниже)
      case "abort":
        r = active ? { state: fresh(st, { state: "stopped", note: "aborted", offer: "update", plan: null, stopRequested: false }), effects: [] } : none(st);
        break;
      // вкладка закрывается: исполнять эффекты некому
      default:
        r = none(st);
    }
    return r.state === st ? r : { state: fresh(r.state, { beat: now }), effects: r.effects };
  }
  function describe(st, ctx) {
    st = st || EMPTY;
    ctx = ctx || {};
    const now = ctx.now || 0;
    const dead = ACTIVE.has(st.state) && !alive(st, now);
    const busy = ACTIVE.has(st.state) && !dead;
    const snap = st.snapshot;
    const by = snap && snap.byFolder || {};
    const short = Object.keys(by).filter((n) => by[n].diff > 0).map((n) => [n, by[n].diff]);
    const over = Object.keys(by).filter((n) => by[n].diff < 0).map((n) => [n, -by[n].diff]);
    let offer = busy ? null : dead ? "update" : st.offer, note = dead ? "aborted" : st.note, stale = false;
    const last = Math.max(snap && snap.at || 0, ctx.lastSyncAt || 0);
    if (!busy && !offer && ctx.periodicOn === false && last > 0 && now - last > STALE_MS) {
      offer = "update";
      note = "stale";
      stale = true;
    }
    const showNote = st.note === "siteMismatch" ? now - (st.since || 0) < NOTICE_MS : !!note;
    return {
      state: st.state,
      busy,
      dead,
      offer,
      note,
      stale,
      showNote,
      drift: snap ? snap.drift : 0,
      short,
      over,
      dups: snap && snap.dups || [],
      plan: st.plan,
      added: st.added,
      stuck: !!(st.plan && st.plan.stuck),
      sinceLast: last > 0 ? now - last : null
    };
  }
  function migrate(old) {
    old = old || {};
    const sf = old.scan_failed;
    if (sf && sf.at) return fresh(EMPTY, { state: "error", since: sf.at, note: "error", offer: "update", error: { name: "scan_failed", mode: sf.mode || null } });
    const c = old.counts;
    if (!c || !c.site) return EMPTY;
    const per = {};
    let total = 0;
    for (const n of Object.keys(c.byFolder || {})) {
      const v = c.byFolder[n];
      if (v && typeof v.our === "number") {
        per[n] = v.our;
        if (!isAll(n)) total += v.our;
      }
    }
    const snapIn = { site: c.site, ours: { total, per }, dups: c.dups || [], gaps: [], at: c.at || 0 };
    const p = plan(snapIn);
    const snapshot = snapshotOf(snapIn, p, c.at || 0);
    if (isEmpty(p)) return fresh(EMPTY, { state: "done", since: c.at || 0, snapshot, note: "upToDate" });
    const nf = old.needfull;
    const stuck = !!(nf && (nf.tries | 0) >= 1);
    const p2 = stuck ? { incr: [], full: [...p.incr, ...p.full], whole: false, drift: p.drift, byFolder: p.byFolder, stuck: true } : p;
    return fresh(EMPTY, { state: "done", since: c.at || 0, snapshot, plan: p2, offer: offerFor(p2) });
  }
  self.VaultMachine = { EMPTY, FULL_MAX, STALE_MS, NOTICE_MS, BEAT_MS, DEAD_MS, sig, plan, step, describe, migrate };
})();
