let uiLang = "ru";
let nativeLang = "ru";
let items = [];
let drafts = {};
document.addEventListener("DOMContentLoaded", () => {
  load();
  document.getElementById("refreshBtn").addEventListener("click", load);
  document.getElementById("tgDigestBtn").addEventListener("click", sendToTelegram);
});
function load() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (sResp) => {
    if (sResp?.result?.nativeLanguage) nativeLang = sResp.result.nativeLanguage;
    uiLang = sResp?.result?.interfaceLanguage || "ru";
    applyI18n(document, uiLang);
    if (typeof FaiLock !== "undefined") {
      FaiLock.init({ lang: uiLang });
      FaiLock.wire("lock-btn");
    }
    chrome.runtime.sendMessage({ type: "TODAY_LIST", limit: 30 }, (resp) => {
      items = resp && resp.success && Array.isArray(resp.items) ? resp.items : [];
      chrome.storage.local.get("fansly_todo_drafts", (d) => {
        drafts = d.fansly_todo_drafts || {};
        render();
      });
    });
  });
}
function reasonText(it) {
  return t("todo.reason." + it.kind, uiLang, it.data || {});
}
const STAGE_ICON = { lead: "\u{1F331}", acquaint: "\u{1F44B}", interest: "\u{1F4AC}", brief: "\u{1F4CB}", paid: "\u{1F4B0}", repeat: "\u{1F501}", lost: "\u{1F6AA}" };
const CLOSENESS = { new: { icon: "\u{1F331}", key: "common.closeness.new" }, interested: { icon: "\u{1F4AC}", key: "common.closeness.interested" }, regular: { icon: "\u{1F525}", key: "common.closeness.regular" }, supporter: { icon: "\u{1F48E}", key: "common.closeness.supporter" } };
function fmtMoney(n) {
  return (+(+n).toFixed(2)).toString();
}
function crmChips(c) {
  const wrap = document.createElement("div");
  wrap.className = "crm-chips";
  const add = (cls, txt) => {
    const b = document.createElement("span");
    b.className = "crm-chip " + (cls || "");
    b.textContent = txt;
    wrap.appendChild(b);
  };
  add("", STAGE_ICON[c.stage] + " " + t("crm.stage." + c.stage, uiLang));
  if (c.stuck) add("warn", t("crm.stuck." + c.stuck.key, uiLang, { n: c.stuck.n }));
  if (c.tierName) add("tier", "\u2B50 " + c.tierName);
  if (c.spent > 0) add("money", t("crm.card.spent", uiLang, { n: fmtMoney(c.spent) }));
  if (c.buyCount > 0) add("", t("crm.card.buys", uiLang, { n: c.buyCount }));
  if (c.activeSub && c.price) add("", t("crm.card.perMonth", uiLang, { n: fmtMoney(c.price) }));
  if (c.activeSub && c.billingCycle) add("", t("crm.card.cycle", uiLang, { v: c.billingCycle }));
  if (c.activeSub && c.renewOn === true) add("ok", t("crm.card.renewOn", uiLang));
  if (c.activeSub && c.renewOn === false) add("churn", t("crm.card.renewOff", uiLang));
  if (c.activeSub && c.daysLeft != null) add("exp", t("crm.card.renews", uiLang, { n: c.daysLeft }));
  if (c.expired) {
    const dt = (c.endDate || "").replace(/^[A-Za-z]+,\s*/, "");
    add("dead", t("crm.card.expired", uiLang) + (dt ? " " + dt : ""));
  }
  if (c.months) add("", t("crm.card.months", uiLang, { n: c.months }));
  if (c.firstSubAt) add("", t("crm.card.since", uiLang, { d: new Date(c.firstSubAt).toLocaleDateString(uiLang, { month: "short", year: "numeric" }) }));
  if (c.subCount > 1) add("", t("crm.card.subcount", uiLang, { n: c.subCount }));
  if (c.hasCard) add("", "\u{1F4B3}");
  if (c.lastMessageAt) {
    const dd = Math.floor((Date.now() - c.lastMessageAt) / 864e5);
    add("", t(dd <= 0 ? "crm.card.lastMsgToday" : "crm.card.lastMsg", uiLang, { n: dd }));
  }
  if (CLOSENESS[c.closeness]) add("", CLOSENESS[c.closeness].icon + " " + t("crm.card.closeness", uiLang, { v: t(CLOSENESS[c.closeness].key, uiLang) }));
  if (c.lastLikeAt) {
    const days = Math.floor((Date.now() - c.lastLikeAt) / 864e5);
    add(days <= 30 && c.expired ? "exp" : "", days <= 0 ? t("crm.card.lastLikeToday", uiLang) : t("crm.card.lastLike", uiLang, { n: days }));
  }
  return wrap;
}
const GROUPS = [
  { titleKey: "todo.group.fire.title", hintKey: "todo.group.fire.hint", kinds: ["churn", "expiring"] },
  { titleKey: "todo.group.orders.title", hintKey: "todo.group.orders.hint", kinds: ["briefStale"] },
  { titleKey: "todo.group.thank.title", hintKey: "todo.group.thank.hint", kinds: ["thank"] },
  { titleKey: "todo.group.winback.title", hintKey: "todo.group.winback.hint", kinds: ["winback", "silent"] },
  // ⚠️ «не подписан» было неточно: подписки нет и у бесплатных фолловеров, поэтому сюда попадали давние
  // собеседники. Условие сигнала теперь — «лайкает, а переписки мы не видели» (Alex, 2026-08-16).
  { titleKey: "todo.group.greet.title", hintKey: "todo.group.greet.hint", kinds: ["greet"] }
];
function groupBox(title, hint, list) {
  const box = document.createElement("div");
  box.className = "grp";
  const h = document.createElement("div");
  h.className = "grp-h";
  const gt = document.createElement("span");
  gt.className = "gt";
  gt.textContent = title;
  const gc = document.createElement("span");
  gc.className = "gc";
  gc.textContent = list.length;
  const gh = document.createElement("span");
  gh.className = "gh";
  gh.textContent = hint;
  h.append(gt, gc, gh);
  const box2 = document.createElement("div");
  box2.className = "grp-list";
  for (const it of list) box2.appendChild(renderItem(it));
  box.append(h, box2);
  return box;
}
function render() {
  const listEl = document.getElementById("list");
  const summaryEl = document.getElementById("summary");
  const legendEl = document.getElementById("acts-legend");
  listEl.innerHTML = "";
  summaryEl.textContent = items.length ? t("todo.summary", uiLang, { n: items.length }) : "";
  if (!items.length) {
    legendEl.style.display = "none";
    listEl.innerHTML = `<div class="no-contacts">${t("todo.empty", uiLang)}</div>`;
    return;
  }
  legendEl.style.display = "flex";
  const shown = /* @__PURE__ */ new Set();
  for (const g of GROUPS) {
    const list = items.filter((it) => g.kinds.includes(it.kind));
    if (!list.length) continue;
    list.forEach((it) => shown.add(it.key));
    listEl.appendChild(groupBox(t(g.titleKey, uiLang), t(g.hintKey, uiLang), list));
  }
  const rest = items.filter((it) => !shown.has(it.key));
  if (rest.length) listEl.appendChild(groupBox(t("todo.group.other.title", uiLang), "", rest));
}
function renderItem(it) {
  const card = document.createElement("div");
  card.className = "todo-card";
  const head = document.createElement("div");
  head.className = "todo-head";
  const main = document.createElement("div");
  main.className = "todo-main";
  const nm = document.createElement("div");
  nm.className = "todo-name";
  nm.textContent = (it.crm ? "\u25B8 " : "") + it.name;
  const rs = document.createElement("div");
  rs.className = "todo-reason";
  rs.textContent = reasonText(it);
  main.append(nm, rs);
  let chipsBox = null;
  if (it.crm) {
    main.style.cursor = "pointer";
    main.title = t("todo.expand", uiLang);
    main.addEventListener("click", () => {
      if (!chipsBox) {
        chipsBox = crmChips(it.crm);
        card.insertBefore(chipsBox, card.querySelector(".todo-draft") || null);
      }
      const open = chipsBox.style.display !== "none";
      chipsBox.style.display = open ? "none" : "flex";
      nm.textContent = (open ? "\u25B8 " : "\u25BE ") + it.name;
    });
  }
  const acts = document.createElement("div");
  acts.className = "todo-acts";
  const advise = mkBtn("todo-advise", "\u{1F4A1} " + t("todo.advise", uiLang), t("todo.advise.title", uiLang));
  advise.addEventListener("click", () => requestAdvice(it, advise, card));
  const write = mkBtn("todo-write", "\u2709\uFE0F " + t("todo.write", uiLang), t("todo.write.title", uiLang));
  write.addEventListener("click", () => openChat(it));
  const done = mkBtn("todo-done", "\u2714", t("todo.ackToday", uiLang));
  done.addEventListener("click", () => ack(it, "today"));
  const snooze = mkBtn("todo-done", "\u23F0", t("todo.snoozeWeek", uiLang));
  snooze.addEventListener("click", () => ack(it, "week"));
  acts.append(advise, write, done, snooze);
  if (it.kind === "briefStale") {
    const delBrief = mkBtn("todo-never", "\u{1F5D1}", t("todo.delBrief", uiLang));
    delBrief.addEventListener("click", () => {
      if (confirm(t("todo.delBrief.confirm", uiLang))) deleteBrief(it);
    });
    acts.append(delBrief);
  }
  const never = mkBtn("todo-never", "\u2715", t("todo.ackForever", uiLang));
  never.addEventListener("click", () => ack(it, "forever"));
  acts.append(never);
  head.append(main, acts);
  card.appendChild(head);
  const d = drafts[it.key];
  if (d && d.text) card.appendChild(draftBox(it, d.text, d.advice || ""));
  return card;
}
function draftBox(it, text, advice) {
  const box = document.createElement("div");
  box.className = "todo-draft";
  const ad = document.createElement("div");
  ad.className = "todo-draft-advice";
  ad.textContent = advice || "";
  const tx = document.createElement("div");
  tx.className = "todo-draft-text";
  tx.textContent = text;
  box.append(ad, tx);
  return box;
}
function mkBtn(cls, txt, title) {
  const b = document.createElement("button");
  b.className = cls;
  b.textContent = txt;
  if (title) {
    b.title = title;
    b.setAttribute("aria-label", title);
  }
  return b;
}
function requestAdvice(it, btn, card) {
  btn.disabled = true;
  btn.textContent = "\u23F3";
  chrome.runtime.sendMessage({ type: "TODO_ADVICE", context: { handle: it.handle, kind: it.kind, name: it.name, data: it.data, uiLang } }, (r) => {
    btn.disabled = false;
    btn.textContent = "\u{1F4A1} " + t("todo.advise", uiLang);
    let box = card.querySelector(".todo-draft");
    if (!box) {
      box = draftBox(it, "", "");
      card.appendChild(box);
    }
    if (r && r.success && r.text) {
      drafts[it.key] = { text: r.text, advice: r.advice };
      box.querySelector(".todo-draft-text").textContent = r.text;
      box.querySelector(".todo-draft-advice").textContent = r.advice || "";
    } else {
      box.querySelector(".todo-draft-text").textContent = t("todo.advise.fail", uiLang) + (r && r.error ? " (" + r.error + ")" : "");
      box.querySelector(".todo-draft-advice").textContent = "";
    }
  });
}
function openChat(it) {
  const d = drafts[it.key];
  const go = () => {
    const url = it.msgId ? "https://fansly.com/messages/" + encodeURIComponent(it.msgId) : "https://fansly.com/" + encodeURIComponent(it.handle);
    window.open(url, "_blank", "noopener");
  };
  if (d && d.text && it.msgId) chrome.storage.local.set({ fansly_pending_draft: { msgId: it.msgId, handle: it.handle, text: d.text, at: Date.now() } }, go);
  else go();
}
function ack(it, mode) {
  chrome.storage.local.get("fansly_todo_ack", (d) => {
    const a = d.fansly_todo_ack || {};
    a[it.key] = mode === "forever" ? "forever" : mode === "week" ? { until: Date.now() + 7 * 864e5 } : Date.now();
    chrome.storage.local.set({ fansly_todo_ack: a }, () => {
      items = items.filter((x) => x.key !== it.key);
      render();
    });
  });
}
function deleteBrief(it) {
  chrome.runtime.sendMessage({ type: "DELETE_BRIEF", handle: it.handle }, () => {
    items = items.filter((x) => x.key !== it.key);
    render();
  });
}
function sendToTelegram() {
  const btn = document.getElementById("tgDigestBtn");
  if (!items.length) {
    chrome.runtime.sendMessage({ type: "NOTIFY_TELEGRAM", notifyType: "digest", text: t("todo.tg.empty", uiLang) });
    return;
  }
  const lines = [t("todo.tg.header", uiLang)];
  for (const it of items.slice(0, 12)) lines.push("\u2022 " + it.name + " \u2014 " + reasonText(it));
  if (btn) btn.textContent = "\u23F3...";
  chrome.runtime.sendMessage({ type: "NOTIFY_TELEGRAM", notifyType: "digest", text: lines.join("\n") }, (r) => {
    if (btn) {
      btn.textContent = r?.success ? t("dashboard.btn.sent", uiLang) : "\u274C " + (r?.error || t("panel.err.genericLower", uiLang));
      setTimeout(() => {
        btn.textContent = t("dashboard.btn.tgDigest", uiLang);
      }, 2500);
    }
  });
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}
