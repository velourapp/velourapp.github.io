(function() {
  "use strict";
  const MODEL_REPO = "SmilingWolf/wd-vit-tagger-v3";
  const MODEL_REV = "v1.0";
  const BATCH = 1;
  const GENERAL_THRESHOLD = 0.25;
  const MODEL_SOURCES = [
    { model: "https://api.velourff.com/v1/model/wd14/model.onnx", tags: "https://api.velourff.com/v1/model/wd14/selected_tags.csv", auth: true },
    { model: `https://huggingface.co/${MODEL_REPO}/resolve/main/model.onnx`, tags: `https://huggingface.co/${MODEL_REPO}/resolve/main/selected_tags.csv` }
  ];
  async function licenseHeaders(src) {
    if (!src.auth) return {};
    try {
      const key = await new Promise((r) => chrome.storage.local.get("fansly_ai_settings", (d) => r(d?.fansly_ai_settings?.licenseKey || "")));
      return key ? { "Authorization": "Bearer " + key } : {};
    } catch (e) {
      return {};
    }
  }
  const DB_NAME = "fai-models", DB_STORE = "blobs", KEY_MODEL = "wd14-model", KEY_TAGS = "wd14-tags";
  function idb() {
    return new Promise((resolve, reject) => {
      const rq = indexedDB.open(DB_NAME, 1);
      rq.onupgradeneeded = () => {
        const db = rq.result;
        if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE);
      };
      rq.onsuccess = () => resolve(rq.result);
      rq.onerror = () => reject(rq.error);
    });
  }
  async function idbGet(key) {
    const db = await idb();
    return new Promise((resolve) => {
      let g;
      try {
        g = db.transaction(DB_STORE).objectStore(DB_STORE).get(key);
      } catch (e) {
        db.close();
        return resolve(null);
      }
      g.onsuccess = () => {
        db.close();
        resolve(g.result || null);
      };
      g.onerror = () => {
        db.close();
        resolve(null);
      };
    });
  }
  async function idbPut(key, val) {
    const db = await idb();
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(DB_STORE, "readwrite");
        tx.objectStore(DB_STORE).put(val, key);
        tx.oncomplete = () => {
          db.close();
          resolve(true);
        };
        tx.onerror = () => {
          db.close();
          resolve(false);
        };
      } catch (e) {
        db.close();
        resolve(false);
      }
    });
  }
  async function isReady() {
    const m = await idbGet(KEY_MODEL);
    return !!(m && m.buf && m.rev === MODEL_REV);
  }
  const DL_STALL_MS = 3e4;
  const DL_ATTEMPTS = 5;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function fetchWithProgress(url, onProgress, headers) {
    const chunks = [];
    let got = 0, total = 0;
    for (let attempt = 1; ; attempt++) {
      const ac = new AbortController();
      let stall = null;
      const arm = () => {
        clearTimeout(stall);
        stall = setTimeout(() => ac.abort(), DL_STALL_MS);
      };
      try {
        const h = Object.assign({}, headers || {});
        if (got) h.Range = "bytes=" + got + "-";
        arm();
        const r = await fetch(url, { cache: "no-store", headers: h, signal: ac.signal });
        if (!r.ok) throw new Error("HTTP " + r.status);
        if (got && r.status !== 206) {
          chunks.length = 0;
          got = 0;
        }
        const cl = +(r.headers.get("content-length") || 0);
        const cr = r.headers.get("content-range");
        total = cr ? +(cr.split("/")[1] || 0) || 0 : got + cl;
        if (!r.body) {
          clearTimeout(stall);
          const b = new Uint8Array(await r.arrayBuffer());
          chunks.push(b);
          got += b.length;
          break;
        }
        const reader = r.body.getReader();
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          arm();
          chunks.push(value);
          got += value.length;
          if (onProgress) onProgress(got, total);
        }
        clearTimeout(stall);
        if (total && got < total) throw new Error("\u043E\u0431\u043E\u0440\u0432\u0430\u043D\u043E \u043D\u0430 " + got + "/" + total);
        break;
      } catch (e) {
        clearTimeout(stall);
        const m = String(e && e.message || "");
        if (m.startsWith("HTTP 4") && m !== "HTTP 408" && m !== "HTTP 429") throw e;
        if (attempt >= DL_ATTEMPTS) throw new Error(e && e.message || "\u043E\u0431\u0440\u044B\u0432 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438");
        console.warn("[FanslyAI] \u{1F3F7} \u043E\u0431\u0440\u044B\u0432 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u043D\u0430", (got / 1048576).toFixed(1), "\u041C\u0411 \u2014 \u043F\u043E\u043F\u044B\u0442\u043A\u0430", attempt + 1, "\u0438\u0437", DL_ATTEMPTS, ":", e && e.message || e);
        if (onProgress) onProgress(got, total, { retry: attempt });
        await sleep(2e3 * attempt);
      }
    }
    const out = new Uint8Array(got);
    let off = 0;
    for (const c of chunks) {
      out.set(c, off);
      off += c.length;
    }
    return out;
  }
  async function download(onProgress) {
    let lastErr = null;
    for (const src of MODEL_SOURCES) {
      try {
        const hdrs = await licenseHeaders(src);
        if (src.auth && !hdrs.Authorization) {
          console.log("[FanslyAI] \u{1F3F7} \u043A\u043B\u044E\u0447\u0430 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0438 \u043D\u0435\u0442 \u2014 \u0441\u0440\u0430\u0437\u0443 \u0437\u0435\u0440\u043A\u0430\u043B\u043E");
          continue;
        }
        const tagsBuf = await fetchWithProgress(src.tags, (got, total, info) => onProgress && onProgress({ phase: "tags", got, total, retry: info && info.retry }), hdrs);
        const csv = new TextDecoder("utf-8").decode(tagsBuf);
        const buf = await fetchWithProgress(src.model, (got, total, info) => onProgress && onProgress({ phase: "model", got, total, retry: info && info.retry }), hdrs);
        await idbPut(KEY_TAGS, { csv, rev: MODEL_REV, at: Date.now() });
        await idbPut(KEY_MODEL, { buf, rev: MODEL_REV, at: Date.now(), src: src.model });
        console.log("[FanslyAI] \u{1F3F7} \u043C\u043E\u0434\u0443\u043B\u044C \u0430\u0432\u0442\u043E\u0442\u0435\u0433\u043E\u0432 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D:", (buf.length / 1048576).toFixed(1), "\u041C\u0411, \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A", src.model);
        return true;
      } catch (e) {
        lastErr = e;
        const denied = src.auth && /HTTP 40[13]/.test(e.message || "");
        console.warn(
          "[FanslyAI] \u{1F3F7} \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u043D\u0435 \u043E\u0442\u0434\u0430\u043B \u043C\u043E\u0434\u0443\u043B\u044C:",
          src.model,
          denied ? "(\u043B\u0438\u0446\u0435\u043D\u0437\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u0430 \u2192 \u0437\u0435\u0440\u043A\u0430\u043B\u043E)" : e.message
        );
      }
    }
    throw lastErr || new Error("\u043D\u0435\u0442 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0430 \u043C\u043E\u0434\u0443\u043B\u044F");
  }
  let _worker = null, _rpcId = 0, _backend = null;
  const _pending = /* @__PURE__ */ new Map();
  function ensureWorker() {
    if (_worker) return _worker;
    _worker = new Worker(chrome.runtime.getURL("autotag-worker.js"));
    _worker.onmessage = (ev) => {
      const { id, ok, result, error } = ev.data || {};
      const p = _pending.get(id);
      if (!p) return;
      _pending.delete(id);
      ok ? p.resolve(result) : p.reject(new Error(error || "\u043E\u0448\u0438\u0431\u043A\u0430 \u0432\u043E\u0440\u043A\u0435\u0440\u0430"));
    };
    _worker.onerror = (e) => {
      for (const [, p] of _pending) p.reject(new Error("\u0432\u043E\u0440\u043A\u0435\u0440 \u0430\u0432\u0442\u043E\u0442\u0435\u0433\u043E\u0432 \u0443\u043F\u0430\u043B: " + (e.message || "")));
      _pending.clear();
    };
    return _worker;
  }
  function rpc(cmd, payload, transfer) {
    const w = ensureWorker();
    const id = ++_rpcId;
    return new Promise((resolve, reject) => {
      _pending.set(id, { resolve, reject });
      w.postMessage({ id, cmd, payload }, transfer || []);
    });
  }
  async function init() {
    if (_backend) return true;
    const [mrec, trec] = await Promise.all([idbGet(KEY_MODEL), idbGet(KEY_TAGS)]);
    if (!mrec || !mrec.buf) throw new Error("\u043C\u043E\u0434\u0443\u043B\u044C \u0430\u0432\u0442\u043E\u0442\u0435\u0433\u043E\u0432 \u043D\u0435 \u0441\u043A\u0430\u0447\u0430\u043D");
    const cores = navigator.hardwareConcurrency || 4;
    const threads = self.crossOriginIsolated ? Math.max(1, Math.min(cores - 1, 8)) : 1;
    const bytes = mrec.buf instanceof Uint8Array ? mrec.buf : new Uint8Array(mrec.buf);
    const copy = bytes.slice().buffer;
    const cached = await new Promise((r) => chrome.storage.local.get("fai_autotag_ep", (d) => r(d.fai_autotag_ep)));
    const prefer = cached && cached.rev === MODEL_REV ? cached.ep : null;
    const t0 = performance.now();
    const info = await rpc("init", {
      ortUrl: chrome.runtime.getURL("vendor/ort/ort.webgpu.min.js"),
      wasmPath: chrome.runtime.getURL("vendor/ort/"),
      modelBuf: copy,
      csv: trec.csv,
      threads,
      prefer
    }, [copy]);
    if (info.ep) chrome.storage.local.set({ fai_autotag_ep: { ep: info.ep, rev: MODEL_REV, backend: info.backend, at: Date.now() } });
    _backend = info.backend;
    console.log(
      "[FanslyAI] \u{1F3F7} \u0443\u0441\u043A\u043E\u0440\u0438\u0442\u0435\u043B\u044C:",
      _backend,
      "| \u044F\u0434\u0435\u0440:",
      cores,
      "| \u043F\u043E\u0442\u043E\u043A\u043E\u0432:",
      threads,
      "| \u0437\u0430\u043C\u0435\u0440 GPU:",
      info.gpuMs != null ? info.gpuMs + " \u043C\u0441" : "\u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D",
      "| \u0437\u0430\u043C\u0435\u0440 CPU:",
      info.cpuMs != null ? info.cpuMs + " \u043C\u0441" : "\u043D\u0435 \u043C\u0435\u0440\u0438\u043B\u0438",
      "| crossOriginIsolated:",
      !!self.crossOriginIsolated,
      "| \u0441\u0435\u0441\u0441\u0438\u044F \u0437\u0430",
      Math.round(performance.now() - t0),
      "\u043C\u0441"
    );
    return true;
  }
  function backend() {
    return _backend;
  }
  function release() {
    if (_worker) {
      try {
        _worker.terminate();
      } catch (e) {
      }
      _worker = null;
    }
    _pending.clear();
    _backend = null;
  }
  async function tagDataUrl(dataUrl, threshold) {
    if (!_backend) await init();
    return rpc("tag", { dataUrl, threshold: threshold != null ? threshold : GENERAL_THRESHOLD });
  }
  async function tagAll(items, { onItem, onProgress, shouldStop, threshold, batch } = {}) {
    if (!_backend) await init();
    const B = Math.max(1, batch || BATCH);
    let done = 0, failed = 0;
    for (let i = 0; i < items.length; i += B) {
      if (shouldStop && shouldStop()) break;
      const chunk = items.slice(i, i + B);
      try {
        const res = await rpc("tagBatch", { dataUrls: chunk.map((c) => c.dataUrl), threshold: threshold != null ? threshold : GENERAL_THRESHOLD });
        for (let k = 0; k < chunk.length; k++) {
          done++;
          if (onItem) onItem(chunk[k].id, res[k], i + k);
        }
      } catch (e) {
        failed += chunk.length;
        console.warn("[FanslyAI] \u{1F3F7} \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0440\u0430\u0437\u043C\u0435\u0442\u0438\u0442\u044C \u043F\u0430\u0447\u043A\u0443 \u0438\u0437", chunk.length, "\u2014", e.message);
      }
      if (onProgress) onProgress(Math.min(i + B, items.length), items.length, done, failed);
    }
    return { done, failed, total: items.length };
  }
  window.AutoTag = {
    MODEL: MODEL_REPO,
    REV: MODEL_REV,
    THRESHOLD: GENERAL_THRESHOLD,
    isReady,
    download,
    init,
    release,
    tagDataUrl,
    tagAll,
    backend
  };
})();
