(function() {
  function targetOf(s) {
    let el = document.querySelector(s.sel);
    for (let n = s.up || 0; n > 0 && el && el.parentElement; n--) el = el.parentElement;
    return el;
  }
  function runPageTour(o) {
    if (document.getElementById("fai-page-tour")) return;
    const steps = o.steps.filter((s) => {
      const el = targetOf(s);
      return el && el.offsetParent !== null;
    });
    if (!steps.length) return;
    let i = 0;
    const dim = document.createElement("div");
    dim.id = "fai-page-tour";
    dim.style.cssText = "position:fixed;inset:0;z-index:99999";
    const hole = document.createElement("div");
    hole.style.cssText = "position:absolute;border:2px solid #e91e8c;border-radius:10px;box-shadow:0 0 0 99999px rgba(8,8,16,.6);transition:all .25s";
    const bubble = document.createElement("div");
    bubble.style.cssText = 'position:absolute;width:min(300px,86vw);background:#12121f;border:1px solid #e91e8c;border-radius:12px;padding:12px 14px;color:#f0f0f0;font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.5);box-sizing:border-box';
    const txt = document.createElement("div");
    txt.style.marginBottom = "10px";
    const rowB = document.createElement("div");
    rowB.style.cssText = "display:flex;align-items:center;gap:8px";
    const cnt = document.createElement("span");
    cnt.style.cssText = "font-size:11px;color:#8a8aa5;flex:1";
    const mkBtn = (css, label) => {
      const b = document.createElement("button");
      b.style.cssText = css;
      b.textContent = label;
      return b;
    };
    const bSkip = mkBtn("background:#1a1a2e;color:#9a9ab0;border:1px solid #2e2e50;border-radius:8px;padding:5px 10px;font-size:11px;cursor:pointer", t("panel.tour.skip", o.lang));
    const bNext = mkBtn("background:#e91e8c;color:#fff;border:none;border-radius:8px;padding:5px 14px;font-size:12px;font-weight:600;cursor:pointer", "");
    rowB.append(cnt, bSkip, bNext);
    bubble.append(txt, rowB);
    dim.append(hole, bubble);
    document.body.appendChild(dim);
    const finish = () => {
      dim.remove();
      chrome.storage.local.get("fai_panel_ui", (d) => {
        const ui = d.fai_panel_ui || {};
        ui[o.flag] = true;
        chrome.storage.local.set({ fai_panel_ui: ui });
      });
    };
    bSkip.addEventListener("click", finish);
    bNext.addEventListener("click", () => {
      i++;
      if (i >= steps.length) finish();
      else show();
    });
    const show = () => {
      const s = steps[i];
      cnt.textContent = i + 1 + "/" + steps.length;
      txt.textContent = t(s.key, o.lang);
      bNext.textContent = t(i === steps.length - 1 ? "panel.tour.done" : "panel.tour.next", o.lang);
      const el = targetOf(s);
      if (!el) {
        i++;
        i >= steps.length ? finish() : show();
        return;
      }
      try {
        el.scrollIntoView({ block: "nearest" });
      } catch (e) {
      }
      const r = el.getBoundingClientRect();
      hole.style.left = r.left - 4 + "px";
      hole.style.top = r.top - 4 + "px";
      hole.style.width = r.width + 8 + "px";
      hole.style.height = r.height + 8 + "px";
      const bw = Math.min(300, innerWidth * 0.86);
      bubble.style.left = Math.min(Math.max(8, r.left), Math.max(8, innerWidth - bw - 8)) + "px";
      bubble.style.top = r.bottom + 10 + "px";
      requestAnimationFrame(() => {
        const bh = bubble.offsetHeight;
        if (r.bottom + 10 + bh > innerHeight - 8) bubble.style.top = Math.max(8, r.top - bh - 10) + "px";
      });
    };
    show();
  }
  const consentGiven = () => typeof FaiConsent !== "undefined" && FaiConsent.given ? FaiConsent.given() : Promise.resolve(false);
  window.initPageTour = function(o) {
    chrome.storage.local.get("fai_panel_ui", (d) => {
      const ui = d.fai_panel_ui || {};
      if (ui[o.flag]) return;
      const go = () => setTimeout(() => {
        if (!document.getElementById("fai-consent")) runPageTour(o);
      }, o.delay || 1300);
      consentGiven().then((ok) => {
        if (ok) return go();
        const onChange = (ch, area) => {
          if (area !== "local" || !ch.fansly_ai_settings) return;
          consentGiven().then((ok2) => {
            if (ok2) {
              chrome.storage.onChanged.removeListener(onChange);
              go();
            }
          }, () => {
          });
        };
        chrome.storage.onChanged.addListener(onChange);
      }, () => {
      });
    });
    if (o.btn) document.getElementById(o.btn)?.addEventListener("click", () => runPageTour(o));
  };
})();
