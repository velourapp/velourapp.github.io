(function() {
  "use strict";
  const KEY = "fai_screen_lock";
  const Z = 2147483647;
  const BUILD = true ? "full" : "full";
  const PIN_ALLOWED = BUILD !== "store";
  let lang = "ru", pin = "", overlay = null, inited = false, skipWhen = null, scale = 1;
  function applyScale() {
    const card = overlay && overlay.firstElementChild;
    if (card) card.style.transform = scale !== 1 ? `scale(${scale})` : "";
  }
  function setScale(k) {
    scale = k > 0 ? k : 1;
    applyScale();
  }
  const T = (k, fallback) => {
    try {
      return (typeof t === "function" ? t(k, lang) : null) || fallback;
    } catch (e) {
      return fallback;
    }
  };
  const mk = (tag, css, txt) => {
    const el = document.createElement(tag);
    el.style.cssText = css;
    if (txt != null) el.textContent = txt;
    return el;
  };
  const alive = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  };
  function pinInput() {
    const i = document.createElement("input");
    i.type = "text";
    i.inputMode = "numeric";
    i.autocomplete = "off";
    i.style.cssText = "width:100%;box-sizing:border-box;background:#0f0f1a;border:1px solid #3a3a5c;border-radius:10px;color:#f0f0f0;padding:11px;font-size:18px;text-align:center;letter-spacing:6px;-webkit-text-security:disc;margin-bottom:10px";
    i.addEventListener("input", () => {
      i.value = i.value.replace(/\D/g, "").slice(0, 12);
    });
    return i;
  }
  function paintOverlay() {
    if (overlay) return;
    if (skipWhen && skipWhen()) return;
    overlay = mk("div", `position:fixed;inset:0;z-index:${Z};background:rgba(6,6,12,.985);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif`);
    overlay.id = "fai-screen-lock";
    const card = mk("div", "width:min(320px,88vw);background:#12121f;border:2px solid #e91e8c;border-radius:16px;padding:20px 22px;text-align:center;color:#f0f0f0;box-shadow:0 12px 48px rgba(0,0,0,.6)");
    card.append(mk("div", "font-size:36px;margin-bottom:10px", "\u{1F512}"));
    if (pin) {
      card.append(mk("div", "font-size:14px;color:#e6e6f0;margin-bottom:12px", T("panel.pult.pin.prompt", "\u0412\u0432\u0435\u0434\u0438 PIN, \u0447\u0442\u043E\u0431\u044B \u0440\u0430\u0437\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u0442\u044C")));
      const inp = pinInput();
      const err = mk("div", "font-size:12px;color:#ef9a9a;min-height:16px;margin-bottom:6px", "");
      const submit = () => {
        if (inp.value === pin) unlock();
        else {
          err.textContent = T("panel.pult.pin.wrong", "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 PIN");
          inp.value = "";
          inp.focus();
        }
      };
      inp.addEventListener("keydown", (e) => {
        if (e.key === "Enter") submit();
      });
      const ok2 = mk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer", T("panel.pult.unlock", "\u0420\u0430\u0437\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u0442\u044C"));
      ok2.addEventListener("click", submit);
      card.append(inp, err, ok2);
      overlay.appendChild(card);
      document.body.appendChild(overlay);
      applyScale();
      setTimeout(() => inp.focus(), 50);
      return;
    }
    card.append(mk("div", "font-size:14px;color:#e6e6f0;margin-bottom:12px", T("lock.noPinHint", "\u042D\u043A\u0440\u0430\u043D \u0437\u0430\u043F\u0435\u0440\u0442. PIN \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u2014 \u043C\u043E\u0436\u043D\u043E \u0440\u0430\u0437\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0440\u0430\u0437\u0443.")));
    const ok = mk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer", T("panel.pult.unlock", "\u0420\u0430\u0437\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u0442\u044C"));
    ok.addEventListener("click", unlock);
    card.append(ok);
    overlay.appendChild(card);
    document.body.appendChild(overlay);
    applyScale();
  }
  function removeOverlay() {
    overlay?.remove();
    overlay = null;
  }
  function askPinThenLock(rechecked) {
    if (document.getElementById("fai-lock-setpin")) return;
    if (!pin && !rechecked && alive()) {
      chrome.storage.local.get("fansly_ai_settings", (d) => {
        const p = d.fansly_ai_settings && d.fansly_ai_settings.pultLockPin || "";
        if (p) {
          pin = p;
          lock();
        } else askPinThenLock(true);
      });
      return;
    }
    const dim = mk("div", `position:fixed;inset:0;z-index:${Z};background:rgba(8,8,16,.75);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif`);
    dim.id = "fai-lock-setpin";
    const card = mk("div", "width:min(340px,88vw);background:#12121f;border:2px solid #e91e8c;border-radius:16px;padding:20px 22px;text-align:center;color:#f0f0f0");
    card.append(
      mk("div", "font-size:34px;margin-bottom:8px", "\u{1F512}"),
      mk("div", "font-size:14px;color:#e6e6f0;margin-bottom:6px", T("panel.pult.setpin.prompt", "\u0417\u0430\u0434\u0430\u0442\u044C PIN \u0434\u043B\u044F \u0440\u0430\u0437\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0438?")),
      mk("div", "font-size:11px;color:#8a8aa5;line-height:1.5;margin-bottom:10px", T("panel.pult.setpin.hint", "\u0411\u0435\u0437 PIN \u044D\u043A\u0440\u0430\u043D \u0440\u0430\u0437\u0431\u043B\u043E\u043A\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u043E\u0434\u043D\u0438\u043C \u043A\u043B\u0438\u043A\u043E\u043C."))
    );
    const inp = pinInput();
    const withPin = mk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;margin-bottom:8px;opacity:.5", T("panel.pult.setpin.withPin", "\u0417\u0430\u043F\u0435\u0440\u0435\u0442\u044C \u0441 PIN"));
    withPin.disabled = true;
    inp.addEventListener("input", () => {
      const ok = inp.value.length >= 4;
      withPin.disabled = !ok;
      withPin.style.opacity = ok ? "1" : ".5";
    });
    const setAndLock = () => {
      const v = inp.value.replace(/\D/g, "").slice(0, 12);
      if (v.length < 4) return;
      pin = v;
      chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: { pultLockPin: v } }, () => void chrome.runtime.lastError);
      dim.remove();
      lock();
    };
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") setAndLock();
    });
    withPin.addEventListener("click", setAndLock);
    const noPin = mk("button", "width:100%;background:#241a34;color:#e6c8ff;border:1px solid #5a3a7a;border-radius:10px;padding:10px;font-size:13px;cursor:pointer;margin-bottom:8px", T("panel.pult.setpin.noPin", "\u0417\u0430\u043F\u0435\u0440\u0435\u0442\u044C \u0431\u0435\u0437 PIN"));
    noPin.addEventListener("click", () => {
      dim.remove();
      lock();
    });
    const cancel = mk("button", "width:100%;background:#1a1a2e;color:#cfcfe0;border:1px solid #3a3a5c;border-radius:10px;padding:10px;font-size:13px;cursor:pointer", T("panel.pult.warn.bg.cancel", "\u041E\u0442\u043C\u0435\u043D\u0430"));
    cancel.addEventListener("click", () => dim.remove());
    card.append(inp, withPin, noPin, cancel);
    if (scale !== 1) card.style.transform = `scale(${scale})`;
    dim.appendChild(card);
    document.body.appendChild(dim);
    inp.focus();
  }
  function lock() {
    if (alive()) chrome.storage.local.set({ [KEY]: { at: Date.now() } });
    paintOverlay();
  }
  function unlock() {
    if (alive()) chrome.storage.local.remove(KEY);
    removeOverlay();
  }
  function button(css) {
    const b = mk("button", css || "", "\u{1F512}");
    b.id = "fai-lock-btn";
    b.title = T("lock.btn.title", "\u0417\u0430\u043F\u0435\u0440\u0435\u0442\u044C \u044D\u043A\u0440\u0430\u043D");
    b.addEventListener("click", () => {
      pin || !PIN_ALLOWED ? lock() : askPinThenLock();
    });
    return b;
  }
  function refresh() {
    if (!alive()) return;
    chrome.storage.local.get(KEY, (d) => {
      d[KEY] ? paintOverlay() : removeOverlay();
    });
  }
  function init(opts) {
    if (opts && opts.skipWhen) skipWhen = opts.skipWhen;
    if (inited) return;
    inited = true;
    lang = opts && opts.lang || "ru";
    if (!alive()) return;
    chrome.storage.local.get([KEY, "fansly_ai_settings"], (d) => {
      pin = d.fansly_ai_settings && d.fansly_ai_settings.pultLockPin || "";
      if (d[KEY]) paintOverlay();
    });
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== "local") return;
      if (ch.fansly_ai_settings) pin = ch.fansly_ai_settings.newValue?.pultLockPin || "";
      if (!ch[KEY]) return;
      ch[KEY].newValue ? paintOverlay() : removeOverlay();
    });
  }
  function wire(id) {
    const b = typeof id === "string" ? document.getElementById(id) : id;
    if (!b || b.dataset.faiLockWired) return;
    b.dataset.faiLockWired = "1";
    if (!b.title) b.title = T("lock.btn.title", "\u0417\u0430\u043F\u0435\u0440\u0435\u0442\u044C \u044D\u043A\u0440\u0430\u043D");
    b.addEventListener("click", () => {
      pin || !PIN_ALLOWED ? lock() : askPinThenLock();
    });
  }
  window.FaiLock = { init, lock, unlock, button, wire, refresh, setScale, isLocked: () => !!overlay, setLang: (l) => {
    lang = l || lang;
  } };
})();
