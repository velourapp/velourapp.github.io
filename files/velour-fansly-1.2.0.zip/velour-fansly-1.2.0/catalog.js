let uiLang = "ru";
let catalog = {};
let revenue = {};
let mediaGrossTotal = 0;
let thumbs = {};
let postedMap = {};
let postsByMedia = {};
let fFrom = null, fTo = null;
let focusMedia = null;
let postedNames = /* @__PURE__ */ new Set();
let fType = null;
let fSold = false;
let fPosted = null;
let fStatus = null;
let fFolder = "";
let fBlur = "sharp";
let fPersonal = "no";
let dateBasis = "vault";
const VIEW_KEY = "fansly_catalog_view";
let _viewSaveT = null;
function saveView() {
  clearTimeout(_viewSaveT);
  _viewSaveT = setTimeout(() => {
    try {
      chrome.storage.local.set({ [VIEW_KEY]: { fType, fSold, fPosted, fStatus, fFolder, fBlur, fPersonal, dedup, sortBy, dateBasis } });
    } catch (e) {
    }
  }, 400);
}
function applyView(v) {
  if (!v || typeof v !== "object") return;
  if (v.fType === null || v.fType === "video" || v.fType === "image" || v.fType === "audio") fType = v.fType;
  if (typeof v.fSold === "boolean") fSold = v.fSold;
  if (v.fPosted === null || v.fPosted === "posted" || v.fPosted === "unposted") fPosted = v.fPosted;
  if (v.fStatus === null || v.fStatus === "missing" || v.fStatus === "deleted") fStatus = v.fStatus;
  if (typeof v.fFolder === "string") fFolder = v.fFolder;
  if (v.fBlur === null || v.fBlur === "blur" || v.fBlur === "sharp") fBlur = v.fBlur;
  if (v.fPersonal === null || v.fPersonal === "yes" || v.fPersonal === "no") fPersonal = v.fPersonal;
  if (typeof v.dedup === "boolean") dedup = v.dedup;
  if (typeof v.sortBy === "string") sortBy = v.sortBy;
  if (v.dateBasis === "vault" || v.dateBasis === "pub") dateBasis = v.dateBasis;
}
let lastFull = 0;
let lastSync = null;
let syncState = null;
let vaultOff = false;
let periodicOn = false;
let plaqueAction = null;
let _plaqueTimer = null;
let authLost = null;
let collectAborted = null;
let sortBy = "date";
let query = "";
let dedup = true;
let thumbIO = null;
document.addEventListener("DOMContentLoaded", init);
function init() {
  try {
    focusMedia = new URLSearchParams(location.search).get("media") || null;
  } catch (e) {
    focusMedia = null;
  }
  chrome.storage.local.get(VIEW_KEY, (d) => {
    applyView(d && d[VIEW_KEY]);
    if (focusMedia) {
      dedup = false;
      fBlur = null;
      fPersonal = null;
      fStatus = null;
      fType = null;
      fFolder = "";
    }
    initAfterView();
  });
}
function initAfterView() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (r) => {
    uiLang = r?.result?.interfaceLanguage || "ru";
    tagIgnore = new Set(r?.result?.autoTagIgnore || []);
    autoTagNew = r?.result?.autoTagNew === true;
    periodicOn = r?.result?.scheduledScanEnabled === true;
    applyI18n(document, uiLang);
    if (typeof FaiLock !== "undefined") {
      FaiLock.init({ lang: uiLang });
      FaiLock.wire("lock-btn");
    }
    if (!window._tourInit && typeof initPageTour === "function") {
      window._tourInit = true;
      initPageTour({ flag: "tourCatalog", btn: "page-tour", lang: uiLang, delay: 1800, steps: [
        { sel: "#load-new", key: "tour.cat.s1" },
        { sel: "#search", key: "tour.cat.s2" },
        { sel: ".chips", key: "tour.cat.s3" },
        { sel: "#grid .card", key: "tour.cat.s4" }
      ] });
    }
    if (!window._ctlBound) {
      window._ctlBound = true;
      bindControls();
    }
    FaiDB.requestPersist();
    loadData();
  });
}
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && ch.fansly_ai_settings && !atBusy) init();
});
function bindControls() {
  const search = document.getElementById("search");
  const clearBtn = document.getElementById("search-clear");
  let _searchTimer = null;
  const applyQuery = () => {
    query = search.value.trim().toLowerCase();
    syncSearchClear();
    clearTimeout(_searchTimer);
    _searchTimer = setTimeout(render, 180);
  };
  search.addEventListener("input", applyQuery);
  search.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape" && search.value) {
      search.value = "";
      applyQuery();
    }
  });
  clearBtn.addEventListener("click", () => {
    search.value = "";
    applyQuery();
    search.focus();
  });
  syncSearchClear();
  const sortSel = document.getElementById("sort");
  sortSel.value = sortBy;
  if (sortSel.value !== sortBy) sortSel.value = "date";
  sortSel.addEventListener("change", (e) => {
    sortBy = e.target.value;
    render();
  });
  document.getElementById("folder").addEventListener("change", (e) => {
    fFolder = e.target.value;
    render();
  });
  document.getElementById("refresh").addEventListener("click", loadData);
  document.getElementById("load-new").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "REQUEST_QUICK_VAULT_SCAN" });
    const once = () => {
      window.removeEventListener("focus", once);
      loadData();
    };
    window.addEventListener("focus", once);
  });
  document.getElementById("collect-all").addEventListener("click", () => {
    if (!confirm(t("collect.confirm", uiLang))) return;
    chrome.runtime.sendMessage({ type: "RUN_FULL_COLLECT" });
    const b = document.getElementById("collect-all");
    b.disabled = true;
    b.dataset.running = "1";
    b.textContent = t("collect.running", uiLang);
    const once = () => {
      window.removeEventListener("focus", once);
      delete b.dataset.running;
      b.disabled = false;
      b.textContent = t("collect.btn", uiLang);
      loadData();
    };
    window.addEventListener("focus", once);
  });
  document.getElementById("grab-frames").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "REQUEST_FRAMES_SCAN" });
    const once = () => {
      window.removeEventListener("focus", once);
      loadData();
    };
    window.addEventListener("focus", once);
  });
  document.getElementById("autotag").addEventListener("click", runAutoTag);
  document.getElementById("tagnav").addEventListener("click", () => {
    const p = document.getElementById("tagnav-panel");
    const open = p.style.display === "none";
    p.style.display = open ? "" : "none";
    if (open) renderTagNav();
  });
  document.getElementById("tagnav-close").addEventListener("click", () => {
    document.getElementById("tagnav-panel").style.display = "none";
  });
  document.getElementById("tagnav-find").addEventListener("input", renderTagNav);
  document.getElementById("tagnav-ignored").addEventListener("click", (e) => {
    tagNavIgnoredView = !tagNavIgnoredView;
    e.currentTarget.classList.toggle("active", tagNavIgnoredView);
    renderTagNav();
  });
  document.getElementById("at-stop").addEventListener("click", () => {
    atStop = true;
  });
  document.getElementById("at-close").addEventListener("click", () => {
    document.getElementById("at-panel").style.display = "none";
  });
  const dFrom = document.getElementById("date-from"), dTo = document.getElementById("date-to");
  dFrom.addEventListener("change", () => {
    fFrom = dFrom.value ? (/* @__PURE__ */ new Date(dFrom.value + "T00:00:00")).getTime() : null;
    render();
  });
  dTo.addEventListener("change", () => {
    fTo = dTo.value ? (/* @__PURE__ */ new Date(dTo.value + "T23:59:59")).getTime() : null;
    render();
  });
  document.getElementById("date-clear").addEventListener("click", () => {
    dFrom.value = "";
    dTo.value = "";
    fFrom = fTo = null;
    render();
  });
  const basisSel = document.getElementById("date-basis");
  if (basisSel) {
    basisSel.value = dateBasis;
    basisSel.addEventListener("change", (e) => {
      dateBasis = e.target.value;
      syncDateHint();
      render();
    });
  }
  syncDateHint();
  document.querySelectorAll(".chip[data-type]").forEach((c) => c.addEventListener("click", () => {
    const v = c.dataset.type;
    if (v === "all") {
      fType = null;
      fSold = false;
      fPosted = null;
      fStatus = null;
      fBlur = null;
      fPersonal = null;
    } else if (v === "video" || v === "image" || v === "audio") fType = fType === v ? null : v;
    else if (v === "sold") fSold = !fSold;
    else if (v === "posted" || v === "unposted") fPosted = fPosted === v ? null : v;
    refreshChips();
    render();
  }));
  document.querySelectorAll(".chip[data-status]").forEach((c) => c.addEventListener("click", () => {
    fStatus = fStatus === c.dataset.status ? null : c.dataset.status;
    refreshChips();
    render();
  }));
  document.querySelectorAll(".chip[data-blur]").forEach((c) => c.addEventListener("click", () => {
    fBlur = fBlur === c.dataset.blur ? null : c.dataset.blur;
    refreshChips();
    render();
  }));
  document.querySelectorAll(".chip[data-personal]").forEach((c) => c.addEventListener("click", () => {
    fPersonal = fPersonal === c.dataset.personal ? null : c.dataset.personal;
    refreshChips();
    render();
  }));
  document.getElementById("dedup-toggle").classList.toggle("active", dedup);
  document.getElementById("dedup-toggle").addEventListener("click", async (e) => {
    dedup = !dedup;
    e.currentTarget.classList.toggle("active", dedup);
    if (dedup && !thumbHashes) {
      const sh = document.getElementById("showing");
      await ensureThumbHashes((i, n) => {
        sh.textContent = t("catalog.dedup.calc", uiLang, { i, n });
      });
    }
    render();
  });
  refreshChips();
  thumbIO = new IntersectionObserver(onThumbVisible, { rootMargin: "1200px" });
}
function syncDateHint() {
  const box = document.getElementById("datebox");
  if (!box) return;
  const key = dateBasis === "pub" ? "catalog.filter.dateHintPub" : "catalog.filter.dateHintVault";
  box.setAttribute("data-i18n-title", key);
  box.title = t(key, uiLang);
}
function refreshChips() {
  document.querySelectorAll(".chip[data-type]").forEach((c) => {
    const v = c.dataset.type;
    const on = v === "video" || v === "image" || v === "audio" ? fType === v : v === "sold" ? fSold : v === "posted" || v === "unposted" ? fPosted === v : !fType && !fSold && !fPosted && !fStatus && !fBlur && !fPersonal;
    c.classList.toggle("active", on);
  });
  document.querySelectorAll(".chip[data-status]").forEach((c) => c.classList.toggle("active", fStatus === c.dataset.status));
  document.querySelectorAll(".chip[data-blur]").forEach((c) => c.classList.toggle("active", fBlur === c.dataset.blur));
  document.querySelectorAll(".chip[data-personal]").forEach((c) => c.classList.toggle("active", fPersonal === c.dataset.personal));
}
async function loadData() {
  const data = await new Promise((r) => chrome.storage.local.get(["fansly_earnings", "fansly_ledger", "fansly_posts", "fansly_catalog_lastfull", "fansly_catalog_lastsync", "fansly_vault_sync", "fansly_catalog_needfull", "fansly_catalog_counts", "fansly_scan_failed", "fansly_auth_lost", "fansly_scan_off", "fansly_collect_aborted"], (d) => r(d)));
  authLost = data.fansly_auth_lost || null;
  collectAborted = data.fansly_collect_aborted || null;
  syncState = data.fansly_vault_sync || VaultMachine.migrate({ needfull: data.fansly_catalog_needfull, counts: data.fansly_catalog_counts, scan_failed: data.fansly_scan_failed });
  try {
    renderAuthLost();
  } catch (e) {
  }
  let dbFail = null;
  try {
    await FaiDB.ensureMigrated();
  } catch (e) {
    dbFail = e;
    console.warn("[FanslyAI] \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430:", e && e.message);
  }
  try {
    const pr = await FaiDB.promoteFrameThumbs();
    if (pr && pr.promoted) console.log("[FanslyAI] \u043F\u0440\u0435\u0432\u044C\u044E \u0438\u0437 \u043A\u0430\u0434\u0440\u043E\u0432:", pr.promoted);
  } catch (e) {
    console.warn("[FanslyAI] \u043F\u0440\u0435\u0432\u044C\u044E \u0438\u0437 \u043A\u0430\u0434\u0440\u043E\u0432 \u043D\u0435 \u0432\u044B\u0448\u043B\u043E:", e && e.message);
  }
  catalog = await FaiDB.metaGetAll().catch((e) => {
    dbFail = e;
    console.error("[FanslyAI] \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043D\u0435 \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043B\u0441\u044F:", e);
    return {};
  });
  if (dbFail) {
    const sub = document.getElementById("subtitle");
    if (sub) sub.textContent = t("catalog.dbFail.subtitle", uiLang);
    const empty = document.getElementById("empty");
    if (empty) {
      let err = document.getElementById("empty-err");
      if (!err) {
        err = document.createElement("div");
        err.id = "empty-err";
        empty.insertBefore(err, empty.firstChild);
      }
      err.textContent = t("catalog.dbFail.body", uiLang, { err: dbFail && dbFail.message || t("catalog.dbFail.unknownErr", uiLang) });
      const stub = empty.querySelector('[data-i18n="catalog.empty"]');
      if (stub) stub.style.display = "none";
      const acts = document.getElementById("empty-acts");
      if (acts) acts.style.display = "none";
      empty.style.display = "block";
    }
    const grid = document.getElementById("grid");
    if (grid) grid.innerHTML = "";
    return;
  }
  {
    const err = document.getElementById("empty-err");
    if (err) err.remove();
    const stub = document.querySelector('#empty [data-i18n="catalog.empty"]');
    if (stub) stub.style.display = "";
    const acts = document.getElementById("empty-acts");
    if (acts) acts.style.display = "";
  }
  lastFull = data.fansly_catalog_lastfull || 0;
  lastSync = data.fansly_catalog_lastsync || null;
  vaultOff = !!(data.fansly_scan_off && data.fansly_scan_off.vault);
  try {
    renderSyncPlaque();
  } catch (e) {
  }
  for (const e of Object.values(catalog)) e._missing = !e.deleted && lastFull && e.lastSeen != null && e.lastSeen < lastFull;
  postedMap = {};
  postsByMedia = {};
  for (const p of Object.values(data.fansly_posts || {})) {
    const pubAt = postPubAt(p);
    for (const mid of p.mediaIds || []) {
      const ml = p.mediaLikes && p.mediaLikes[mid] != null ? p.mediaLikes[mid] : p.likes != null ? p.likes : null;
      const cur = postedMap[mid] || (postedMap[mid] = { likes: null });
      if (ml != null) cur.likes = Math.max(cur.likes ?? 0, ml);
      (postsByMedia[mid] || (postsByMedia[mid] = [])).push({ date: p.date || "", text: p.text || "", likes: ml, comments: p.comments, pubAt });
    }
  }
  for (const arr of Object.values(postsByMedia)) arr.sort((a, b) => (b.pubAt || 0) - (a.pubAt || 0));
  postedNames = /* @__PURE__ */ new Set();
  for (const [id, e] of Object.entries(catalog)) {
    if (postedMap[id] && e.filename) postedNames.add(e.filename.toLowerCase());
  }
  revenue = {};
  const addRev = (mediaId, handle, amount, inBundle) => {
    const r = revenue[mediaId] || (revenue[mediaId] = { count: 0, sum: 0, buyers: /* @__PURE__ */ new Set(), bundles: 0 });
    r.count++;
    r.sum += amount || 0;
    if (handle) r.buyers.add(handle);
    if (inBundle) r.bundles++;
  };
  const fromEarnings = /* @__PURE__ */ new Set();
  mediaGrossTotal = 0;
  for (const e of Object.values(data.fansly_earnings || {})) {
    if (!e || e.refunded) continue;
    if (e.type !== "media" && e.type !== "media_bundle") continue;
    const ids = Array.isArray(e.mediaIds) ? e.mediaIds : [];
    if (!ids.length) continue;
    const gross = e.net >= 0 ? e.net / 0.8 : 0;
    const size = e.bundleSize > 0 ? e.bundleSize : ids.length;
    const per = gross / size;
    mediaGrossTotal += gross;
    for (const mid of ids) {
      addRev(mid, e.buyer, per, size > 1);
      fromEarnings.add(mid);
    }
  }
  for (const [h, evs] of Object.entries(data.fansly_ledger || {}))
    for (const e of evs || []) if (e.type === "media" && e.mediaId && !fromEarnings.has(e.mediaId)) addRev(e.mediaId, h, e.amount);
  const cleaned = await cleanupTags();
  if (cleaned) console.log("[FanslyAI] \u{1F3F7} \u0432\u044B\u0447\u0438\u0449\u0435\u043D\u043E \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0441 \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D\u043D\u044B\u043C\u0438/\u0438\u0433\u043D\u043E\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u043C\u0438 \u0442\u0435\u0433\u0430\u043C\u0438:", cleaned);
  thumbs = await loadThumbs();
  thumbHashes = null;
  clusterOf = null;
  dropDeriv();
  populateFolders();
  render();
  ensureDedupReady();
  maybeAutoTagNew("\u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430");
}
async function ensureDedupReady() {
  if (!dedup || thumbHashes) return;
  const sh = document.getElementById("showing");
  await ensureThumbHashes((i, n) => {
    if (sh) sh.textContent = t("catalog.dedup.calc", uiLang, { i, n });
  });
  render();
}
function populateFolders() {
  const sel = document.getElementById("folder");
  if (!sel) return;
  const set = /* @__PURE__ */ new Set();
  for (const id in catalog) for (const f of catalog[id].folders || []) if (f) set.add(f);
  [...sel.querySelectorAll("option:not(:first-child)")].forEach((o) => o.remove());
  for (const f of [...set].sort((a, b) => a.localeCompare(b))) {
    const o = document.createElement("option");
    o.value = f;
    o.textContent = "\u{1F4C2} " + f;
    sel.appendChild(o);
  }
  if (!set.has(fFolder)) fFolder = "";
  sel.value = fFolder;
}
function loadThumbs() {
  return FaiDB.thumbGetAll().catch(() => ({}));
}
function durSeconds(d) {
  if (!d) return -1;
  return d.split(":").map((n) => parseInt(n, 10) || 0).reduce((a, n) => a * 60 + n, 0);
}
function cmpId(a, b) {
  try {
    const x = BigInt(a || 0), y = BigInt(b || 0);
    return x < y ? -1 : x > y ? 1 : 0;
  } catch (e) {
    return a > b ? 1 : a < b ? -1 : 0;
  }
}
function vaultDateMs(e) {
  if (!e || !e.date) return null;
  const s = dateWithYear(e.date, e.id);
  const m = s.match(/(\d{1,2})\s+([A-Za-z]{3,})\s+(\d{4})/);
  if (!m) return null;
  const mo = CRM.monthIndex(m[2]);
  return mo == null ? null : new Date(+m[3], mo, +m[1]).getTime();
}
function idTimeMs(id) {
  try {
    return Number(BigInt(id) >> 22n) + CRM.FANSLY_EPOCH;
  } catch (e) {
    return null;
  }
}
const dayStartMs = (ms) => {
  const d = new Date(ms);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
};
function fmtMoney(n) {
  return (+(+n).toFixed(2)).toString();
}
function dateWithYear(s, id) {
  return CRM.dateWithYear(s, id);
}
function postPubAt(p) {
  return CRM.postPubAt(p);
}
function groupDupes(list) {
  const groups = /* @__PURE__ */ new Map();
  for (const e of list) {
    const key = clusterOf && clusterOf[e.id] != null ? ["c", e.type, e.type === "video" ? e.dur || "?" : "", clusterOf[e.id]].join("|") : "id|" + e.id;
    (groups.get(key) || groups.set(key, []).get(key)).push(e);
  }
  return [...groups.values()].map((g) => {
    const rep = g.find((x) => thumbs[x.id]) || g[0];
    const sum = g.reduce((a, x) => a + x.rev.sum, 0);
    const count = g.reduce((a, x) => a + x.rev.count, 0);
    return { ...rep, dupCount: g.length, rev: { count, sum } };
  });
}
const _deriv = /* @__PURE__ */ new Map();
const dropDeriv = (id) => {
  if (id == null) _deriv.clear();
  else _deriv.delete(String(id));
};
function derivOf(id, e) {
  let d = _deriv.get(id);
  if (!d) {
    d = {
      dms: vaultDateMs({ id, date: e.date }),
      ums: idTimeMs(id),
      hay: [
        e.filename || "",
        String(id),
        e.desc || "",
        ...e.tags || [],
        ...e.autoTags || [],
        ...(e.autoTags || []).map(tagLabel)
      ].join(" ").toLowerCase()
    };
    _deriv.set(id, d);
  }
  return d;
}
function entriesFiltered() {
  let list = Object.entries(catalog).map(([id, e]) => {
    const d = derivOf(id, e);
    const x = { id, ...e, rev: revenue[id] || { count: 0, sum: 0 } };
    x._dms = d.dms;
    x._ums = d.ums;
    x._hay = d.hay;
    return x;
  });
  if (fStatus === "deleted") list = list.filter((e) => e.deleted);
  else {
    list = list.filter((e) => !e.deleted);
    if (fStatus === "missing") list = list.filter((e) => e._missing);
  }
  if (fType) list = list.filter((e) => e.type === fType);
  if (fFolder) list = list.filter((e) => (e.folders || []).includes(fFolder));
  if (fBlur === "blur") list = list.filter((e) => e.blur === true);
  if (fBlur === "sharp") list = list.filter((e) => e.blur !== true);
  if (fPersonal === "yes") list = list.filter((e) => e.personal === true);
  if (fPersonal === "no") list = list.filter((e) => e.personal !== true);
  if (fPosted === "posted") list = list.filter((e) => postedMap[e.id]);
  if (fPosted === "unposted") list = list.filter((e) => (
    // 📭 идеи для постов: не постилось НИ одной копией
    !postedMap[e.id] && !(e.filename && postedNames.has(e.filename.toLowerCase()))
  ));
  if (fFrom != null || fTo != null) {
    if (dateBasis === "pub") {
      list = list.filter((e) => (postsByMedia[e.id] || []).some((p) => p.pubAt != null && (fFrom == null || p.pubAt >= fFrom) && (fTo == null || p.pubAt <= fTo)));
    } else {
      list = list.filter((e) => {
        const d = e._dms != null ? e._dms : e._ums != null ? dayStartMs(e._ums) : null;
        return d != null && (fFrom == null || d >= fFrom) && (fTo == null || d <= fTo);
      });
    }
  }
  if (query) {
    const terms = query.split(/\s+/).filter(Boolean);
    const want = terms.filter((s) => !s.startsWith("-"));
    const skip = terms.filter((s) => s.startsWith("-") && s.length > 1).map((s) => s.slice(1));
    list = list.filter((e) => {
      const h = e._hay || "";
      return want.every((s) => h.includes(s)) && !skip.some((s) => h.includes(s));
    });
  }
  if (dedup) list = groupDupes(list);
  if (fSold) list = list.filter((e) => e.rev.count > 0);
  list.sort((a, b) => {
    if (sortBy === "revenue") return b.rev.sum - a.rev.sum;
    if (sortBy === "buys") return b.rev.count - a.rev.count;
    if (sortBy === "likes") return (postedMap[b.id]?.likes ?? -1) - (postedMap[a.id]?.likes ?? -1);
    if (sortBy === "duration") return durSeconds(b.dur) - durSeconds(a.dur);
    if (sortBy === "filename") return (a.filename || "").localeCompare(b.filename || "");
    if (sortBy === "upload") {
      const ua = a._ums, ub = b._ums;
      if (ua != null && ub != null && ua !== ub) return ub - ua;
      return cmpId(b.id, a.id);
    }
    const da = a._dms, db = b._dms;
    if (da != null && db != null && da !== db) return db - da;
    if (da != null && db == null) return -1;
    if (da == null && db != null) return 1;
    return cmpId(b.id, a.id);
  });
  return list;
}
function render() {
  const total = Object.keys(catalog).length;
  document.getElementById("subtitle").textContent = t("catalog.subtitle", uiLang, { n: total });
  const lsEl = document.getElementById("lastsync");
  if (lsEl) {
    if (!lastSync || !lastSync.at) lsEl.textContent = t("panel.sync.never", uiLang);
    else {
      const time = new Date(lastSync.at).toLocaleString(uiLang, { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
      const full = lastFull ? new Date(lastFull).toLocaleString(uiLang, { day: "2-digit", month: "2-digit" }) : "";
      lsEl.textContent = t("panel.sync.last", uiLang, { time }) + (lastSync.added > 0 ? " \xB7 " + t("panel.sync.added", uiLang, { n: lastSync.added }) : "") + " \xB7 " + (full ? t("catalog.lastFull.at", uiLang, { date: full }) : t("catalog.lastFull.never", uiLang));
    }
  }
  renderSyncPlaque();
  if (!focusMedia) saveView();
  const empty = document.getElementById("empty");
  const grid = document.getElementById("grid");
  grid.innerHTML = "";
  if (!total) {
    empty.style.display = "block";
    renderEmptyActions();
    document.getElementById("showing").textContent = "";
    return;
  }
  empty.style.display = "none";
  const list = entriesFiltered();
  document.getElementById("showing").textContent = t("catalog.showing", uiLang, { n: list.length, total });
  thumbIO.disconnect();
  if (_sentIO) _sentIO.disconnect();
  _renderList = list;
  _renderIdx = 0;
  renderMore();
  if (focusMedia) {
    const idx = list.findIndex((e) => e.id === focusMedia);
    while (idx >= 0 && _renderIdx <= idx) renderMore();
  }
  applyFocus();
}
const RENDER_CHUNK = 150;
let _renderList = null, _renderIdx = 0, _sentIO = null;
function renderMore() {
  const grid = document.getElementById("grid");
  if (!grid || !_renderList) return;
  const end = Math.min(_renderIdx + RENDER_CHUNK, _renderList.length);
  const frag = document.createDocumentFragment();
  const imgs = [];
  for (; _renderIdx < end; _renderIdx++) {
    const el = card(_renderList[_renderIdx]);
    const im = el.querySelector(".thumb[data-id]");
    if (im) imgs.push(im);
    frag.appendChild(el);
  }
  grid.appendChild(frag);
  for (const im of imgs) thumbIO.observe(im);
  updateSentinel();
}
function updateSentinel() {
  const grid = document.getElementById("grid");
  if (!grid) return;
  let s = document.getElementById("grid-sentinel");
  if (!_renderList || _renderIdx >= _renderList.length) {
    if (s) {
      try {
        _sentIO && _sentIO.unobserve(s);
      } catch (e) {
      }
      s.remove();
    }
    return;
  }
  if (!s) {
    s = document.createElement("div");
    s.id = "grid-sentinel";
    s.style.cssText = "grid-column:1/-1;height:1px";
  }
  grid.appendChild(s);
  if (!_sentIO) _sentIO = new IntersectionObserver((es) => {
    if (es.some((x) => x.isIntersecting)) renderMore();
  }, { rootMargin: "800px" });
  _sentIO.observe(s);
}
function renderAuthLost() {
  renderNotice("authlost-banner", collectCovers("auth") ? null : authLost, "catalog.authLost");
}
function renderNotice(id, flag, key) {
  let b = document.getElementById(id);
  const fresh = !!(flag && flag.at && Date.now() - flag.at < 24 * 3600 * 1e3);
  if (!fresh) {
    if (b) b.style.display = "none";
    return;
  }
  if (!b) {
    b = document.createElement("div");
    b.id = id;
    b.style.cssText = "background:rgba(240,163,94,.12);border:1px solid rgba(240,163,94,.4);border-radius:10px;padding:10px 14px;margin:0 0 14px;color:#f0a35e;font-size:13px;line-height:1.45";
    const grid = document.getElementById("grid");
    grid.parentNode.insertBefore(b, grid);
  }
  b.textContent = t(key, uiLang);
  b.style.display = "block";
}
function renderSyncPlaque() {
  let b = document.getElementById("needfull-banner");
  const d = VaultMachine.describe(syncState, { now: Date.now(), periodicOn, lastSyncAt: lastSync && lastSync.at || 0 });
  const loadNew = document.getElementById("load-new");
  if (loadNew) loadNew.disabled = !!d.busy || vaultOff;
  const collect = document.getElementById("collect-all");
  if (collect && !collect.dataset.running) collect.disabled = !!d.busy;
  const frames = document.getElementById("grab-frames");
  if (frames) {
    frames.disabled = vaultOff;
    frames.title = t(vaultOff ? "scanoff.btn.title" : "catalog.frames.title", uiLang);
  }
  if (loadNew) loadNew.title = vaultOff ? t("scanoff.btn.title", uiLang) : "";
  if (vaultOff) {
    clearTimeout(_plaqueTimer);
    _plaqueTimer = null;
    if (b) b.style.display = "none";
    return;
  }
  clearTimeout(_plaqueTimer);
  _plaqueTimer = null;
  if (d.busy) _plaqueTimer = setTimeout(renderSyncPlaque, Math.max(1e3, VaultMachine.DEAD_MS - (Date.now() - (syncState && syncState.beat || 0)) + 500));
  const dupText = !d.dups.length ? "" : d.dups.length === 1 ? t("catalog.needFull.dup", uiLang, { name: d.dups[0] }) : t("catalog.needFull.dup.list", uiLang, { list: d.dups.map((n) => "\xAB" + n + "\xBB").join(", ") });
  const fmt = (arr) => arr.slice(0, 4).map(([n, v]) => "\xAB" + n + "\xBB " + v).join(", ");
  let text = "", btnText = "";
  plaqueAction = null;
  if (d.busy) text = t("catalog.sync.busy", uiLang);
  else if (collectCovers("vault")) {
  } else if (d.note === "error") {
    text = t("panel.vault.failed", uiLang);
    btnText = t("catalog.needFull.btn", uiLang);
    plaqueAction = "REQUEST_QUICK_VAULT_SCAN";
  } else if (d.note === "aborted") {
    text = t("catalog.sync.aborted", uiLang);
    btnText = t("catalog.needFull.btn", uiLang);
    plaqueAction = "REQUEST_QUICK_VAULT_SCAN";
  } else if (d.note === "stopped") {
    text = t("catalog.sync.stopped", uiLang);
    btnText = t("catalog.needFull.btn", uiLang);
    plaqueAction = "REQUEST_QUICK_VAULT_SCAN";
  } else if (d.offer && d.note === "stale") {
    text = t("catalog.sync.stale", uiLang, { d: Math.max(1, Math.round(d.sinceLast / 864e5)) });
    btnText = t("catalog.needFull.btn", uiLang);
    plaqueAction = "REQUEST_QUICK_VAULT_SCAN";
  } else if (d.offer) {
    const short = d.short, over = d.over, one = short.length + over.length === 1 ? (short[0] || over[0])[0] : "";
    const vars = { n: d.drift, folder: one, list: fmt([...short, ...over]), short: fmt(short), extra: fmt(over) };
    const key = short.length && over.length ? "catalog.needFull.mixed" : over.length ? one ? "catalog.needFull.extra.in" : "catalog.needFull.extra.list" : short.length ? one ? d.stuck ? "catalog.needFull.banner.stuck.in" : "catalog.needFull.banner.in" : d.stuck ? "catalog.needFull.banner.stuck.list" : "catalog.needFull.banner.list" : d.stuck ? "catalog.needFull.banner.stuck" : "catalog.needFull.banner";
    text = t(key, uiLang, vars);
    btnText = d.offer === "folders" ? t("catalog.needFull.btnFolders", uiLang, { n: d.plan ? d.plan.full.length + d.plan.incr.length : short.length + over.length }) : t("catalog.needFull.btn", uiLang);
    plaqueAction = "REQUEST_TARGETED_VAULT_SCAN";
  } else if (d.note === "siteMismatch" && d.showNote) text = t("catalog.sync.mismatch", uiLang, { n: d.drift });
  if (dupText) text = dupText + (text ? " " + text : "");
  if (!text) {
    if (b) b.style.display = "none";
    return;
  }
  if (!b) {
    b = document.createElement("div");
    b.id = "needfull-banner";
    b.style.cssText = "display:flex;align-items:center;gap:12px;background:#3a2030;border:1px solid #e91e8c;border-radius:10px;padding:10px 14px;margin:0 0 14px;color:#f3a3cf;font-size:13px";
    const txt = document.createElement("span");
    txt.id = "needfull-text";
    txt.style.flex = "1";
    const btn2 = document.createElement("button");
    btn2.id = "needfull-btn";
    btn2.style.cssText = "background:#e91e8c;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap";
    btn2.addEventListener("click", () => {
      if (!plaqueAction) return;
      btn2.disabled = true;
      btn2.textContent = t("catalog.needFull.starting", uiLang);
      chrome.runtime.sendMessage({ type: plaqueAction });
    });
    const grid = document.getElementById("grid");
    grid.parentNode.insertBefore(b, grid);
    b.append(txt, btn2);
  }
  b.style.display = "flex";
  document.getElementById("needfull-text").textContent = text;
  const btn = document.getElementById("needfull-btn");
  btn.style.display = btnText ? "" : "none";
  btn.disabled = false;
  btn.textContent = btnText;
}
function collectCovers(kind) {
  const ca = collectAborted;
  if (!ca) return false;
  if (kind === "auth") return ca.reason === "auth" && !!authLost && (authLost.at || 0) <= (ca.at || 0);
  return ca.step === "vault" && !!syncState && syncState.trigger === "collectAll";
}
function applyFocus() {
  const note = document.getElementById("focusnote");
  if (!focusMedia) {
    if (note) note.style.display = "none";
    return;
  }
  const el = document.querySelector('.card[data-mid="' + CSS.escape(focusMedia) + '"]');
  if (note) {
    note.style.display = "";
    note.textContent = el ? t("catalog.focus.found", uiLang) : t("catalog.focus.missing", uiLang);
    note.style.cursor = el ? "pointer" : "";
    note.onclick = el ? () => scrollToFocus(el) : null;
  }
  if (!el) return;
  el.classList.add("focus");
  scrollToFocus(el);
}
function scrollToFocus(el) {
  const bring = () => el.scrollIntoView({ block: "center" });
  bring();
  requestAnimationFrame(bring);
  setTimeout(bring, 250);
}
function onThumbVisible(entries) {
  for (const en of entries) {
    const img = en.target, id = img.dataset.id;
    if (en.isIntersecting) {
      clearTimeout(img._dropT);
      img._dropT = null;
      const url = thumbs[id];
      if (url && !img.getAttribute("src")) {
        img.src = url;
        img.style.display = "block";
      }
    } else if (img.getAttribute("src") && !img._dropT) {
      img._dropT = setTimeout(() => {
        img._dropT = null;
        img.removeAttribute("src");
      }, 3e3);
    }
  }
}
function openInVault(filename, folders) {
  const url = "https://fansly.com/creator/vault";
  chrome.storage.local.set({ fansly_vault_search: { filename, folders: folders || [], at: Date.now() } }, () => {
    if (chrome.tabs && chrome.tabs.create) chrome.tabs.create({ url });
    else window.open(url, "_blank");
  });
}
const TYPES_WITH_LABEL = ["video", "image", "audio"];
function typeLabel(type) {
  return t("catalog.card.type." + (TYPES_WITH_LABEL.includes(type) ? type : "file"), uiLang);
}
function cardTitle(e) {
  const d = (e.desc || "").trim();
  if (d) return d.length > 70 ? d.slice(0, 70) + "\u2026" : d;
  const rec = catalog[e.id] || {};
  const manual = (rec.tags || e.tags || []).filter(Boolean);
  const auto = (rec.autoTags || e.autoTags || []).filter((x) => !tagDropped(x)).map(tagLabel);
  const tags = [...manual, ...auto].slice(0, 3);
  if (tags.length) return tags.join(" \xB7 ");
  return typeLabel(e.type) + (e.date ? " \xB7 " + dateWithYear(e.date, e.id) : "");
}
function renderEmptyActions() {
  const box = document.getElementById("empty-acts");
  if (!box || box.dataset.built) return;
  box.dataset.built = "1";
  const b = document.createElement("button");
  b.className = "btn";
  b.textContent = t("catalog.empty.scan", uiLang);
  b.addEventListener("click", () => window.open("https://fansly.com/creator/vault", "_blank", "noopener"));
  box.appendChild(b);
}
function card(e) {
  const el = document.createElement("div");
  el.className = "card";
  el.dataset.mid = e.id;
  const tw = document.createElement("div");
  tw.className = "thumbwrap";
  if (thumbs[e.id]) {
    const img = document.createElement("img");
    img.className = "thumb";
    img.dataset.id = e.id;
    img.alt = "";
    tw.appendChild(img);
  } else if (e.type === "audio") {
    const a = document.createElement("div");
    a.className = "thumb-none";
    a.textContent = "\u{1F3B5}";
    a.style.fontSize = "34px";
    tw.appendChild(a);
  } else {
    const none = document.createElement("div");
    none.className = "thumb-none";
    none.textContent = t("catalog.card.noThumb", uiLang);
    tw.appendChild(none);
  }
  const bt = document.createElement("span");
  bt.className = "badge-type";
  bt.textContent = e.type === "video" ? "\u{1F3A5}" : e.type === "audio" ? "\u{1F3B5}" : "\u{1F4F7}";
  tw.appendChild(bt);
  if (e.type === "video" && e.dur) {
    const bd = document.createElement("span");
    bd.className = "badge-dur";
    bd.textContent = e.dur;
    tw.appendChild(bd);
  }
  if (e.rev.count > 0) {
    const bs = document.createElement("span");
    bs.className = "badge-sales";
    bs.textContent = t("catalog.card.sales", uiLang, { n: e.rev.count, rev: fmtMoney(e.rev.sum) });
    const nb = e.rev.bundles || 0, solo = e.rev.count - nb;
    bs.title = t("catalog.card.sales.title", uiLang) + (nb ? "\n" + t("catalog.card.sales.split", uiLang, { solo, bundle: nb }) : "");
    tw.appendChild(bs);
  }
  if (e.dupCount > 1) {
    const bp = document.createElement("span");
    bp.className = "badge-dup";
    bp.textContent = t("catalog.card.dupes", uiLang, { n: e.dupCount });
    tw.appendChild(bp);
  }
  if (e._missing) {
    const bm = document.createElement("span");
    bm.className = "badge-missing";
    bm.textContent = t("catalog.card.missing", uiLang);
    tw.appendChild(bm);
  }
  if (e.type === "image" && e.blurScore != null) {
    const bb = document.createElement("span");
    bb.className = "badge-blur";
    const paint = () => {
      bb.textContent = e.blur ? "\u{1F32B}" : "\u{1F50E}";
      bb.title = t(e.blur ? "catalog.card.blur" : "catalog.card.sharp", uiLang) + " \xB7 score " + e.blurScore + " \u2014 " + t("catalog.card.blurClick", uiLang);
    };
    paint();
    bb.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const nv = !(e.blur === true);
      e.blur = nv;
      if (catalog[e.id]) {
        catalog[e.id].blur = nv;
        catalog[e.id].blurManual = true;
      }
      idbPatch([{ id: e.id, set: { blur: nv, blurManual: true } }]);
      paint();
    });
    tw.appendChild(bb);
  }
  const pb = document.createElement("span");
  pb.className = "badge-personal";
  const paintP = () => {
    pb.textContent = e.personal ? "\u{1F3E0}" : "\xB7";
    pb.classList.toggle("on", !!e.personal);
    pb.title = t(e.personal ? "catalog.card.personal.on" : "catalog.card.personal.off", uiLang);
  };
  paintP();
  pb.addEventListener("click", (ev) => {
    ev.stopPropagation();
    const nv = !(e.personal === true);
    e.personal = nv;
    if (catalog[e.id]) catalog[e.id].personal = nv;
    idbPatch([{ id: e.id, set: { personal: nv } }]);
    paintP();
  });
  tw.appendChild(pb);
  const act = document.createElement("button");
  act.className = "card-act";
  if (e.deleted) {
    act.textContent = "\u267B\uFE0F";
    act.title = t("catalog.card.restore.title", uiLang);
    act.addEventListener("click", (ev) => {
      ev.stopPropagation();
      restoreEntry(e.id);
    });
  } else {
    act.textContent = "\u{1F5D1}";
    act.title = t("catalog.card.delete.title", uiLang);
    act.addEventListener("click", (ev) => {
      ev.stopPropagation();
      deleteEntry(e.id);
    });
  }
  tw.appendChild(act);
  if (e.filename) {
    tw.style.cursor = "pointer";
    tw.title = t("catalog.card.openVault", uiLang);
    tw.addEventListener("click", () => openInVault(e.filename, e.folders));
  }
  el.appendChild(tw);
  const body = document.createElement("div");
  body.className = "body";
  const ttl = document.createElement("div");
  ttl.className = "cardtitle";
  ttl.textContent = cardTitle(e);
  body.appendChild(ttl);
  if (e.filename) {
    const fn = document.createElement("div");
    fn.className = "fname";
    fn.textContent = e.filename;
    fn.title = t("catalog.card.copyName", uiLang);
    fn.addEventListener("click", () => {
      navigator.clipboard.writeText(e.filename).then(() => {
        const o = fn.textContent;
        fn.textContent = t("catalog.card.copied", uiLang);
        setTimeout(() => {
          fn.textContent = o;
        }, 900);
      }).catch(() => {
      });
      chrome.storage.local.set({ fansly_vault_pick: { filename: e.filename, folders: e.folders || [], at: Date.now() } });
    });
    body.appendChild(fn);
  }
  if (e.date) {
    const dt2 = document.createElement("div");
    dt2.className = "date";
    dt2.textContent = dateWithYear(e.date, e.id);
    body.appendChild(dt2);
  }
  if ((e.frames | 0) > 0) {
    const strip = document.createElement("div");
    strip.style.cssText = "display:flex;gap:4px;flex-wrap:wrap;margin-top:4px";
    const btn = document.createElement("span");
    btn.className = "tag auto";
    btn.style.cursor = "pointer";
    btn.textContent = t("catalog.card.frames", uiLang, { n: e.frames | 0 });
    btn.title = t("catalog.card.frames.title", uiLang);
    let open = false;
    btn.addEventListener("click", async () => {
      open = !open;
      strip.innerHTML = "";
      if (!open) return;
      const urls = await FaiDB.frameGet(e.id).catch(() => []);
      if (!urls.length) {
        strip.textContent = t("catalog.card.frames.gone", uiLang);
        return;
      }
      urls.forEach((u) => {
        const im = document.createElement("img");
        im.src = u;
        im.loading = "lazy";
        im.style.cssText = "height:64px;border-radius:6px;cursor:zoom-in";
        im.addEventListener("click", () => showFrameBig(u));
        strip.appendChild(im);
      });
    });
    body.appendChild(btn);
    body.appendChild(strip);
  }
  const posts = postsByMedia[e.id] || [];
  if (posts.length) {
    const pi = document.createElement("div");
    pi.className = "postinfo";
    const hd = document.createElement("div");
    hd.className = "postinfo-h";
    hd.textContent = "\u{1F4E3} " + t("catalog.card.inPosts", uiLang, { n: posts.length });
    pi.appendChild(hd);
    for (const p of posts) {
      const ln = document.createElement("div");
      ln.className = "postline";
      const d = p.pubAt != null ? new Date(p.pubAt).toLocaleDateString(uiLang, { day: "2-digit", month: "short", year: "numeric" }) : p.date || "?";
      ln.textContent = d + (p.likes != null ? " \xB7 \u2764\uFE0F" + p.likes : "") + (p.comments != null ? " \xB7 \u{1F4AC}" + p.comments : "");
      if (p.text) ln.title = p.text;
      const tx = document.createElement("span");
      tx.className = "posttext";
      tx.textContent = p.text ? " \u2014 " + p.text.slice(0, 60) : "";
      ln.appendChild(tx);
      pi.appendChild(ln);
    }
    body.appendChild(pi);
  }
  if (e.folders && e.folders.length) {
    const fo = document.createElement("div");
    fo.className = "folders";
    fo.textContent = "\u{1F4C2} " + e.folders.join(", ");
    fo.title = e.folders.join(", ");
    body.appendChild(fo);
  }
  const tags = document.createElement("div");
  tags.className = "tags";
  const tagsAdd = document.createElement("div");
  tagsAdd.className = "tags-add-row";
  const renderTags = () => {
    tags.innerHTML = "";
    tagsAdd.innerHTML = "";
    tags.classList.toggle("expanded", tagsExpanded.has(e.id));
    const _auto = (catalog[e.id].autoTags || []).filter((t2) => !tagDropped(t2));
    const _shown = tagsExpanded.has(e.id) ? _auto : _auto.slice(0, TAG_SHOW);
    _shown.forEach((tg) => {
      const lbl = tagLabel(tg);
      const chip = document.createElement("span");
      chip.className = "tag auto";
      chip.textContent = lbl;
      const sc = (catalog[e.id].tagScores || {})[tg];
      chip.title = (lbl !== tg ? tg + " \xB7 " : "") + t("catalog.card.autoTag", uiLang) + (sc != null ? " \xB7 " + sc : "");
      chip.addEventListener("click", () => {
        const s = document.getElementById("search");
        const cur = s.value.trim();
        const already = cur.toLowerCase().includes(lbl.toLowerCase());
        s.value = already ? cur : cur ? cur + " " + lbl : lbl;
        query = s.value.trim().toLowerCase();
        syncSearchClear();
        render();
      });
      const ax = document.createElement("span");
      ax.className = "x";
      ax.textContent = "\xD7";
      ax.title = t("catalog.card.autoTag.del", uiLang);
      ax.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const rec = catalog[e.id];
        if (!rec) return;
        rec.autoTags = (rec.autoTags || []).filter((z) => z !== tg);
        if (rec.tagScores) delete rec.tagScores[tg];
        persistAutoTags([e.id]);
        renderTags();
      });
      chip.appendChild(ax);
      tags.appendChild(chip);
    });
    if (_auto.length > _shown.length) {
      const more = document.createElement("span");
      more.className = "tag auto more";
      more.textContent = "+" + (_auto.length - _shown.length);
      more.title = t("catalog.card.autoTag.more", uiLang);
      more.addEventListener("click", () => {
        tagsExpanded.add(e.id);
        renderTags();
      });
      tagsAdd.appendChild(more);
    } else if (tagsExpanded.has(e.id) && _auto.length > TAG_SHOW) {
      const less = document.createElement("span");
      less.className = "tag auto more";
      less.textContent = t("catalog.card.autoTag.less", uiLang);
      less.title = t("catalog.card.autoTag.less.title", uiLang);
      less.addEventListener("click", () => {
        tagsExpanded.delete(e.id);
        renderTags();
      });
      tagsAdd.appendChild(less);
    }
    (catalog[e.id].tags || []).forEach((tg) => {
      const chip = document.createElement("span");
      chip.className = "tag";
      chip.textContent = tg;
      const x = document.createElement("span");
      x.className = "x";
      x.textContent = "\xD7";
      x.addEventListener("click", () => {
        catalog[e.id].tags = catalog[e.id].tags.filter((z) => z !== tg);
        persistEntry(e.id);
        renderTags();
      });
      chip.appendChild(x);
      tags.appendChild(chip);
    });
    const hashOne = (x) => "#" + String(x).trim().replace(/^#+/, "").replace(/\s+/g, "_");
    const hashSeen = /* @__PURE__ */ new Set(), hashTags = [];
    for (const x of [..._shown, ...catalog[e.id].tags || []]) {
      if (!x) continue;
      const h = hashOne(x), k = h.toLowerCase();
      if (h === "#" || hashSeen.has(k)) continue;
      hashSeen.add(k);
      hashTags.push(h);
    }
    if (hashTags.length) {
      const cp = document.createElement("span");
      cp.className = "tag auto more";
      cp.textContent = "#";
      cp.title = t("catalog.card.copyTags", uiLang);
      cp.addEventListener("click", () => {
        navigator.clipboard.writeText(hashTags.join(" ")).then(() => {
          cp.textContent = "\u2713";
          setTimeout(() => {
            cp.textContent = "#";
          }, 900);
        }).catch(() => {
        });
      });
      tagsAdd.appendChild(cp);
    }
    const add = document.createElement("input");
    add.className = "tag-add";
    add.placeholder = t("catalog.card.tagAdd", uiLang);
    add.addEventListener("keydown", (ev) => {
      if (ev.key !== "Enter") return;
      const v = add.value.trim();
      if (!v) return;
      if (!catalog[e.id].tags) catalog[e.id].tags = [];
      if (!catalog[e.id].tags.includes(v)) {
        catalog[e.id].tags.push(v);
        persistEntry(e.id);
      }
      add.value = "";
      renderTags();
    });
    tagsAdd.appendChild(add);
  };
  renderTags();
  body.appendChild(tags);
  body.appendChild(tagsAdd);
  const desc = document.createElement("textarea");
  desc.className = "desc";
  desc.value = e.desc || "";
  desc.placeholder = t("catalog.card.descPh", uiLang);
  const descBtn = document.createElement("button");
  descBtn.className = "desc-btn";
  const paintDesc = () => {
    const v = (desc.value || "").trim();
    descBtn.textContent = v ? t("catalog.card.desc.btn", uiLang, { desc: v.slice(0, 24) }) : t("catalog.card.desc.btnEmpty", uiLang);
    descBtn.classList.toggle("filled", !!v);
    descBtn.title = v || t("catalog.card.desc.add", uiLang);
  };
  paintDesc();
  descBtn.addEventListener("click", () => {
    if (desc.classList.toggle("open")) desc.focus();
  });
  let dt = null;
  desc.addEventListener("input", () => {
    catalog[e.id].desc = desc.value;
    e.desc = desc.value;
    paintDesc();
    ttl.textContent = cardTitle(e);
    clearTimeout(dt);
    dt = setTimeout(() => persistEntry(e.id), 500);
  });
  body.append(descBtn, desc);
  el.appendChild(body);
  return el;
}
function deleteEntry(id) {
  idbPatch([{ id, set: { deleted: true, deletedAt: Date.now(), thumb: false } }]).then((ok) => {
    if (!ok) return;
    delete thumbs[id];
    return dropThumb(id);
  }).then(loadData, loadData);
}
function restoreEntry(id) {
  idbPatch([{ id, set: { deleted: false, deletedAt: 0 } }]).then(loadData, loadData);
}
function dropThumb(id) {
  return FaiDB.thumbDelete(id).catch(() => {
  });
}
let atStop = false, atBusy = false;
let _atKeepAlive = null;
function atKeepAliveStart() {
  try {
    if (_atKeepAlive) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = 18e3;
    gain.gain.value = document.hidden ? 0.05 : 0;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    const timer = setInterval(() => {
      gain.gain.value = document.hidden ? 0.05 : 0;
    }, 2e3);
    _atKeepAlive = { ctx, osc, timer };
    ctx.resume && ctx.resume().catch(() => {
    });
  } catch (e) {
  }
}
function atKeepAliveStop() {
  try {
    if (!_atKeepAlive) return;
    clearInterval(_atKeepAlive.timer);
    _atKeepAlive.osc.stop();
    _atKeepAlive.ctx.close();
  } catch (e) {
  }
  _atKeepAlive = null;
}
function atUI(status, { progress = null, note = "", stop = false, close = false } = {}) {
  const p = document.getElementById("at-panel");
  p.style.display = "";
  document.getElementById("at-status").textContent = status;
  document.getElementById("at-note").textContent = note;
  document.getElementById("at-stop").style.display = stop ? "" : "none";
  document.getElementById("at-close").style.display = close ? "" : "none";
  const wrap = document.getElementById("at-barwrap");
  if (progress == null) wrap.style.display = "none";
  else {
    wrap.style.display = "";
    document.getElementById("at-bar").style.width = Math.round(progress * 100) + "%";
  }
}
const _dhCv = new OffscreenCanvas(9, 8), _dhCx = _dhCv.getContext("2d", { willReadFrequently: true });
async function thumbHash(dataUrl) {
  try {
    const bmp = await createImageBitmap(await (await fetch(dataUrl)).blob());
    _dhCx.drawImage(bmp, 0, 0, 9, 8);
    bmp.close();
    const p = _dhCx.getImageData(0, 0, 9, 8).data;
    const lum = (i) => 0.299 * p[i * 4] + 0.587 * p[i * 4 + 1] + 0.114 * p[i * 4 + 2];
    let bits = "";
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) bits += lum(y * 9 + x) > lum(y * 9 + x + 1) ? "1" : "0";
    return !/0/.test(bits) || !/1/.test(bits) ? null : bits;
  } catch (e) {
    return null;
  }
}
const TAG_BLOCKED = /* @__PURE__ */ new Set(["loli", "shota", "toddlercon", "child", "baby", "age_regression", "young_child", "infant"]);
let tagIgnore = /* @__PURE__ */ new Set();
let autoTagNew = false;
const tagDropped = (t2) => TAG_BLOCKED.has(t2) || tagIgnore.has(t2);
function syncSearchClear() {
  const s = document.getElementById("search"), c = document.getElementById("search-clear");
  if (s && c) c.style.display = s.value ? "block" : "none";
}
const TAG_SHOW = 6;
const tagsExpanded = /* @__PURE__ */ new Set();
const tagLabel = (tg) => typeof TagNames !== "undefined" ? TagNames.label(tg, uiLang) : String(tg).replace(/_/g, " ");
let tagNavIgnoredView = false;
function tagStats() {
  const cnt = {}, withTags = [];
  for (const e of Object.values(catalog)) {
    if (!e || e.deleted || !(e.autoTags || []).length) continue;
    withTags.push(e);
    for (const t2 of e.autoTags) if (!TAG_BLOCKED.has(t2)) cnt[t2] = (cnt[t2] || 0) + 1;
  }
  return { total: withTags.length, rows: Object.entries(cnt).sort((a, b) => b[1] - a[1]) };
}
async function setTagIgnored(tag, ignored) {
  if (ignored) tagIgnore.add(tag);
  else tagIgnore.delete(tag);
  await new Promise((r) => chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: { autoTagIgnore: [...tagIgnore] } }, r));
  if (ignored) await cleanupTags();
  renderTagNav();
  render();
}
function renderTagNav() {
  const box = document.getElementById("tagnav-list");
  if (!box) return;
  const { total, rows } = tagStats();
  const find = (document.getElementById("tagnav-find").value || "").trim().toLowerCase();
  const list = tagNavIgnoredView ? [...tagIgnore].map((t2) => [t2, 0]) : rows.filter(([t2]) => !tagIgnore.has(t2));
  const shown = find ? list.filter(([t2]) => t2.toLowerCase().includes(find) || tagLabel(t2).toLowerCase().includes(find)) : list;
  document.getElementById("tagnav-sum").textContent = t("catalog.tagnav.summary", uiLang, { tags: rows.length, photos: total, hidden: tagIgnore.size });
  box.innerHTML = "";
  for (const [tag, n] of shown.slice(0, 400)) {
    const chip = document.createElement("span");
    chip.className = "tag auto";
    chip.style.cursor = "pointer";
    const share = total ? Math.round(n / total * 100) : 0;
    const lbl = tagLabel(tag);
    chip.textContent = lbl + (tagNavIgnoredView ? "" : ` ${n}`);
    if (!tagNavIgnoredView && share >= 40) chip.style.borderColor = "#a3743a";
    chip.title = (lbl !== tag ? tag + " \xB7 " : "") + (tagNavIgnoredView ? t("catalog.tagnav.restore", uiLang) : t("catalog.tagnav.tagTitle", uiLang, { n, share }));
    chip.addEventListener("click", () => {
      if (tagNavIgnoredView) {
        setTagIgnored(tag, false);
        return;
      }
      const s = document.getElementById("search");
      const cur = s.value.trim();
      if (!cur.toLowerCase().includes(lbl.toLowerCase())) s.value = cur ? cur + " " + lbl : lbl;
      query = s.value.trim().toLowerCase();
      syncSearchClear();
      render();
    });
    if (!tagNavIgnoredView) {
      const x = document.createElement("span");
      x.className = "x";
      x.textContent = "\xD7";
      x.title = t("catalog.tagnav.hide", uiLang);
      x.addEventListener("click", (ev) => {
        ev.stopPropagation();
        setTagIgnored(tag, true);
      });
      chip.appendChild(x);
    }
    box.appendChild(chip);
  }
  if (!shown.length) box.textContent = t("catalog.tagnav.empty", uiLang);
}
async function cleanupTags(ids) {
  const touched = [];
  for (const id of ids || Object.keys(catalog)) {
    const e = catalog[id];
    if (!e || !(e.autoTags || []).length) continue;
    const keep = e.autoTags.filter((t2) => !tagDropped(t2));
    if (keep.length === e.autoTags.length) continue;
    e.autoTags = keep;
    if (e.tagScores) {
      for (const t2 of Object.keys(e.tagScores)) if (tagDropped(t2)) delete e.tagScores[t2];
    }
    touched.push(id);
  }
  if (touched.length) await persistAutoTags(touched);
  return touched.length;
}
let thumbHashes = null, clusterOf = null;
async function ensureThumbHashes(onProgress) {
  if (thumbHashes) return thumbHashes;
  const cache = await FaiDB.hashGetAll().catch(() => ({}));
  const fresh = {};
  const h = {}, ids = Object.keys(catalog).filter((id) => thumbs[id]);
  let cacheDirty = false, fromCache = 0;
  for (let i = 0; i < ids.length; i++) {
    const id = ids[i], url = thumbs[id], c = cache[id];
    if (c && c.len === url.length && c.bits) {
      h[id] = { bits: c.bits, hi: parseInt(c.bits.slice(0, 32), 2) >>> 0, lo: parseInt(c.bits.slice(32), 2) >>> 0 };
      fromCache++;
      continue;
    }
    const bits = await thumbHash(url);
    h[id] = bits ? { bits, hi: parseInt(bits.slice(0, 32), 2) >>> 0, lo: parseInt(bits.slice(32), 2) >>> 0 } : null;
    if (bits) {
      cache[id] = fresh[id] = { len: url.length, bits };
      cacheDirty = true;
    }
    if (onProgress && i % 200 === 0) onProgress(i, ids.length);
  }
  if (cacheDirty) {
    const stale = Object.keys(cache).filter((id) => !thumbs[id]);
    FaiDB.hashPut(fresh).then(() => FaiDB.hashDelete(stale)).catch(() => {
    });
  }
  if (fromCache) console.log("[FanslyAI] \u0445\u0435\u0448\u0438 \u043F\u0440\u0435\u0432\u044C\u044E: \u0438\u0437 \u043A\u0435\u0448\u0430", fromCache, "\xB7 \u043F\u0435\u0440\u0435\u0441\u0447\u0438\u0442\u0430\u043D\u043E", ids.length - fromCache);
  thumbHashes = h;
  clusterOf = {};
  clusterIds(Object.keys(h).sort((a, b) => cmpId(b, a))).forEach((c, i) => c.forEach((id) => {
    clusterOf[id] = i;
  }));
  return h;
}
const HASH_TOL = 5;
function popcount(v) {
  v = v - (v >>> 1 & 1431655765);
  v = (v & 858993459) + (v >>> 2 & 858993459);
  v = v + (v >>> 4) & 252645135;
  return v * 16843009 >>> 24;
}
function hamDist(a, b) {
  return popcount((a.hi ^ b.hi) >>> 0) + popcount((a.lo ^ b.lo) >>> 0);
}
function clusterIds(ids) {
  const clusters = [], leaders = [];
  for (const id of ids) {
    const h = thumbHashes && thumbHashes[id];
    if (!h) {
      clusters.push([id]);
      leaders.push(null);
      continue;
    }
    let placed = false;
    for (let i = 0; i < clusters.length; i++) {
      const L = leaders[i];
      if (L && hamDist(L, h) <= HASH_TOL) {
        clusters[i].push(id);
        placed = true;
        break;
      }
    }
    if (!placed) {
      clusters.push([id]);
      leaders.push(h);
    }
  }
  return clusters;
}
async function autoTagCandidates() {
  const ids = [], blurIds = [], taggedIds = [], frameIds = [], why = { total: 0, notImage: 0, deleted: 0, blur: 0, personal: 0, noThumb: 0, already: 0, videoDone: 0 };
  const frameSet = await FaiDB.frameIds().catch(() => /* @__PURE__ */ new Set());
  for (const [id, e] of Object.entries(catalog)) {
    if (!e) continue;
    why.total++;
    if (e.deleted) {
      why.deleted++;
      continue;
    }
    if (e.type !== "image" && e.type !== "video") {
      why.notImage++;
      continue;
    }
    if (e.personal === true) {
      why.personal++;
      continue;
    }
    if (e.type === "video" && frameSet.has(id)) {
      const n = e.frames | 0;
      const done = !!(e.tagger && e.tagger.rev === AutoTag.REV && (e.tagger.frames | 0) >= n);
      if (done) {
        why.videoDone++;
        continue;
      }
      frameIds.push(id);
      continue;
    }
    const stamped = !!(e.tagger && e.tagger.rev === AutoTag.REV);
    const fromBlur = stamped && e.tagger.src === "blur";
    const hasBlurTag = (e.autoTags || []).includes("blurry");
    if (e.blur === true) {
      why.blur++;
      if (!hasBlurTag && !tagDropped("blurry")) blurIds.push(id);
      else why.already++;
      continue;
    }
    if (stamped && !fromBlur) {
      why.already++;
      taggedIds.push(id);
      continue;
    }
    if (!thumbs[id]) {
      why.noThumb++;
      continue;
    }
    ids.push(id);
  }
  await ensureThumbHashes();
  const ckey = (id) => clusterOf && clusterOf[id] != null ? "c|" + clusterOf[id] : "id|" + id;
  const groups = /* @__PURE__ */ new Map();
  for (const id of ids) {
    const k = ckey(id);
    (groups.get(k) || groups.set(k, []).get(k)).push(id);
  }
  const donors = /* @__PURE__ */ new Map();
  for (const id of taggedIds) {
    const k = ckey(id);
    if (!k.startsWith("id|") && !donors.has(k)) donors.set(k, id);
  }
  const copyPairs = [], needModel = [];
  for (const [k, g] of groups) {
    const donor = donors.get(k);
    if (donor) copyPairs.push({ donor, ids: g });
    else needModel.push(g);
  }
  const singles = [];
  const ordered = [...needModel, ...singles].map((g) => g.sort((a, b) => cmpId(b, a)));
  ordered.sort((a, b) => cmpId(b[0], a[0]));
  blurIds.sort((a, b) => cmpId(b, a));
  frameIds.sort((a, b) => cmpId(b, a));
  return { ids, why, groups: ordered, blurIds, copyPairs, frameIds };
}
let writeFailed = false, writeWarned = false;
async function idbPatch(patches) {
  if (!patches || !patches.length) return true;
  for (let i = 0; i < 3; i++) {
    try {
      const written = await FaiDB.metaPatch(patches);
      if (written < patches.length) throw new Error("\u0437\u0430\u043F\u0438\u0441\u0430\u043D\u043E " + written + " \u0438\u0437 " + patches.length + " \u2014 \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435\u0442 \u0432 \u0431\u0430\u0437\u0435");
      return true;
    } catch (e) {
      if (i < 2) {
        await new Promise((r) => setTimeout(r, 600 * (i + 1)));
        continue;
      }
      console.error("[FanslyAI] \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043D\u0435 \u043F\u0440\u0438\u043D\u044F\u043B \u0437\u0430\u043F\u0438\u0441\u044C:", e);
      if (!writeWarned) {
        writeWarned = true;
        atUI(
          t("catalog.writeFail.status", uiLang, { err: e && e.message || "" }),
          { close: true, note: t("catalog.writeFail.note", uiLang) }
        );
      }
      return false;
    }
  }
}
const RATING_ORDER = ["general", "sensitive", "questionable", "explicit"];
function hardestRating(cur, next) {
  const a = RATING_ORDER.indexOf(cur), b = RATING_ORDER.indexOf(next);
  if (b < 0) return cur;
  return b > a ? next : cur;
}
function persistAutoTags(items) {
  const patches = [];
  for (const it of items || []) {
    dropDeriv(it && typeof it === "object" ? it.id : it);
    if (it && typeof it === "object" && it.id) {
      patches.push(it);
      continue;
    }
    const src = catalog[it];
    if (!src) continue;
    patches.push({ id: it, set: { autoTags: src.autoTags || [], tagScores: src.tagScores || {}, rating: src.rating || null, tagger: src.tagger || null } });
  }
  return idbPatch(patches).then((ok) => {
    if (!ok) {
      writeFailed = true;
      atStop = true;
    }
    return ok;
  });
}
async function maybeAutoTagNew(reason) {
  if (!autoTagNew || atBusy) return;
  let ready = false;
  try {
    ready = await AutoTag.isReady();
  } catch (e) {
    return;
  }
  if (!ready) {
    const { groups: groups2, blurIds: blurIds2, frameIds: frameIds2 } = await autoTagCandidates();
    if (!groups2.length && !blurIds2.length && !frameIds2.length) return;
    atUI(
      t("catalog.autotag.needModule", uiLang, { n: groups2.length + blurIds2.length + frameIds2.length }),
      { close: true, note: t("catalog.autotag.needModule.note", uiLang) }
    );
    return;
  }
  const { groups, blurIds, frameIds } = await autoTagCandidates();
  if (!groups.length && !blurIds.length && !frameIds.length) return;
  console.log("[FanslyAI] \u{1F3F7} \u0430\u0432\u0442\u043E-\u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430 \u043D\u043E\u0432\u044B\u0445:", groups.length, "\u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0445 +", blurIds.length, "\u0431\u043B\u044E\u0440 +", frameIds.length, "\u0432\u0438\u0434\u0435\u043E \u043F\u043E \u043A\u0430\u0434\u0440\u0430\u043C |", reason);
  runAutoTag();
}
let _autoNewTimer = null, _doneTimer = null;
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local") return;
  if (ch.fansly_ai_settings) {
    const was = autoTagNew;
    autoTagNew = ch.fansly_ai_settings.newValue?.autoTagNew === true;
    if (autoTagNew && !was) maybeAutoTagNew("\u0432\u043A\u043B\u044E\u0447\u0438\u043B\u0438 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445");
  }
  if (ch.fansly_vault_sync) {
    syncState = ch.fansly_vault_sync.newValue || null;
    try {
      renderSyncPlaque();
    } catch (e) {
    }
  }
  if (ch.fansly_scan_off) {
    vaultOff = !!(ch.fansly_scan_off.newValue && ch.fansly_scan_off.newValue.vault);
    try {
      renderSyncPlaque();
    } catch (e) {
    }
  }
  if (ch.fansly_auth_lost) {
    authLost = ch.fansly_auth_lost.newValue || null;
    try {
      renderAuthLost();
    } catch (e) {
    }
  }
  if (ch.fansly_collect_aborted) {
    collectAborted = ch.fansly_collect_aborted.newValue || null;
    try {
      renderSyncPlaque();
    } catch (e) {
    }
    try {
      renderAuthLost();
    } catch (e) {
    }
  }
  if (ch.fansly_catalog_lastsync && !atBusy && !document.hidden) {
    clearTimeout(_doneTimer);
    _doneTimer = setTimeout(() => {
      if (!atBusy && !document.hidden) loadData();
    }, 1500);
  } else if (ch.fansly_catalog_lastsync) {
    _reloadPending = true;
  }
  if (!ch[FaiDB.REV_KEY] || !autoTagNew || atBusy) return;
  if (document.hidden) {
    _reloadPending = true;
    return;
  }
  clearTimeout(_autoNewTimer);
  _autoNewTimer = setTimeout(async () => {
    if (atBusy || document.hidden) {
      _reloadPending = true;
      return;
    }
    await loadData();
  }, 8e3);
});
let _reloadPending = false;
document.addEventListener("visibilitychange", () => {
  if (document.hidden || !_reloadPending || atBusy) return;
  _reloadPending = false;
  loadData();
});
async function runAutoTag() {
  if (atBusy) return;
  atBusy = true;
  atStop = false;
  writeFailed = false;
  writeWarned = false;
  let ids, why, groups, blurIds, copyPairs, frameIds;
  try {
    atUI(t("catalog.autotag.scanning", uiLang));
    ({ ids, why, groups, blurIds, copyPairs, frameIds } = await autoTagCandidates());
  } catch (e) {
    console.error("[FanslyAI] \u{1F3F7} \u043E\u0442\u0431\u043E\u0440 \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u043E\u0432:", e);
    atUI(t("catalog.autotag.fail", uiLang) + " " + (e.message || ""), { close: true });
    atBusy = false;
    return;
  }
  console.log(
    "[FanslyAI] \u{1F3F7} \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u044B:",
    ids.length,
    "| \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u043D\u0430 \u043C\u043E\u0434\u0435\u043B\u044C:",
    groups.length,
    "| \u043A\u043E\u043F\u0438\u0440\u0443\u0435\u043C \u0441 \u0433\u043E\u0442\u043E\u0432\u044B\u0445 \u0431\u043B\u0438\u0437\u043D\u0435\u0446\u043E\u0432:",
    copyPairs.reduce((a, p) => a + p.ids.length, 0),
    "| \u0431\u043B\u044E\u0440-\u0432\u0435\u0440\u0441\u0438\u0439 (\u043F\u043E\u043C\u0435\u0442\u0438\u043C \u0431\u0435\u0437 \u043C\u043E\u0434\u0435\u043B\u0438):",
    blurIds.length,
    "| \u043E\u0442\u0441\u0435\u0432:",
    why
  );
  if (copyPairs.length) {
    const touched = [];
    for (const { donor, ids: copies } of copyPairs) {
      const src = catalog[donor];
      if (!src) continue;
      for (const id of copies) {
        const e = catalog[id];
        if (!e) continue;
        e.autoTags = (src.autoTags || []).slice();
        e.tagScores = Object.assign({}, src.tagScores || {});
        e.rating = src.rating || null;
        e.tagger = Object.assign({}, src.tagger, { at: Date.now(), copiedFrom: donor });
        touched.push(id);
      }
    }
    if (touched.length) {
      await persistAutoTags(touched);
      render();
    }
  }
  if (blurIds.length) {
    for (const id of blurIds) {
      const e = catalog[id];
      if (!e) continue;
      const prev = e.autoTags || [];
      const hadModel = !!(e.tagger && e.tagger.src !== "blur");
      e.autoTags = prev.includes("blurry") ? prev : ["blurry", ...prev];
      if (!hadModel) e.tagScores = {};
      e.tagger = {
        model: hadModel ? e.tagger.model : "blur-detector",
        rev: AutoTag.REV,
        th: hadModel ? e.tagger.th : null,
        at: Date.now(),
        src: hadModel ? "model+blur" : "blur"
        // источник тегов — от него зависит, нужен ли повторный проход
      };
    }
    if (await persistAutoTags(blurIds)) atUI(t("catalog.autotag.blurDone", uiLang, { n: blurIds.length }), { close: true });
    render();
  }
  if (!groups.length && !frameIds.length) {
    const parts = [];
    if (why.already) parts.push(t("catalog.autotag.why.already", uiLang, { n: why.already }));
    if (why.noThumb) parts.push(t("catalog.autotag.why.noThumb", uiLang, { n: why.noThumb }));
    if (why.personal) parts.push(t("catalog.autotag.why.personal", uiLang, { n: why.personal }));
    if (why.notImage) parts.push(t("catalog.autotag.why.notImage", uiLang, { n: why.notImage }));
    if (why.videoDone) parts.push(t("catalog.autotag.why.videoDone", uiLang, { n: why.videoDone }));
    if (writeFailed) {
    } else if (!blurIds.length && !copyPairs.length) atUI(t("catalog.autotag.nothing", uiLang), { close: true, note: parts.join(" \xB7 ") });
    else atUI(t("catalog.autotag.doneNoModel", uiLang), { close: true, note: parts.join(" \xB7 ") });
    atBusy = false;
    return;
  }
  if (writeFailed) {
    atBusy = false;
    return;
  }
  atKeepAliveStart();
  try {
    if (!await AutoTag.isReady()) {
      if (!window.confirm(t("catalog.autotag.download.confirm", uiLang))) {
        atUI("", { close: true });
        document.getElementById("at-panel").style.display = "none";
        atBusy = false;
        return;
      }
      atUI(t("catalog.autotag.downloading", uiLang), { progress: 0, note: t("catalog.autotag.download.note", uiLang) });
      const MB = t("catalog.autotag.mb", uiLang);
      await AutoTag.download(({ phase, got, total, retry }) => {
        const mb = (got / 1048576).toFixed(0);
        const frac = total ? got / total : 0;
        const size = phase === "model" ? `${mb} ${MB}${total ? " / " + (total / 1048576).toFixed(0) + " " + MB : ""}` : "\u2026";
        atUI(t("catalog.autotag.downloading", uiLang), {
          progress: total ? frac : null,
          note: retry ? t("catalog.autotag.download.retry", uiLang, { n: retry, mb }) : size
        });
      });
    }
    atUI(t("catalog.autotag.starting", uiLang), { progress: 0 });
    await AutoTag.init();
    const pending = [];
    let t0 = Date.now();
    let tagged = 0;
    const byRep = new Map(groups.map((g) => [g[0], g]));
    await AutoTag.tagAll(
      groups.map((g) => ({ id: g[0], dataUrl: thumbs[g[0]] })),
      {
        shouldStop: () => atStop,
        onItem: (repId, res) => {
          res = {
            ...res,
            tags: res.tags.filter((t2) => !tagDropped(t2)),
            scores: Object.fromEntries(Object.entries(res.scores || {}).filter(([t2]) => !tagDropped(t2)))
          };
          const stamp = { model: AutoTag.MODEL, rev: AutoTag.REV, th: AutoTag.THRESHOLD, at: Date.now() };
          for (const id of byRep.get(repId) || [repId]) {
            const e = catalog[id];
            if (!e) continue;
            e.autoTags = res.tags;
            e.tagScores = res.scores;
            e.rating = res.rating;
            e.tagger = stamp;
            pending.push({ id, set: { autoTags: res.tags, tagScores: res.scores, rating: res.rating || null, tagger: stamp } });
            tagged++;
          }
        },
        onProgress: async (i, total, done, failed) => {
          const per = (Date.now() - t0) / Math.max(i, 1);
          const leftSec = Math.round(per * (total - i) / 1e3);
          const eta = leftSec >= 3600 ? t("catalog.autotag.eta.h", uiLang, { h: (leftSec / 3600).toFixed(1) }) : leftSec >= 90 ? t("catalog.autotag.eta.m", uiLang, { m: Math.round(leftSec / 60) }) : t("catalog.autotag.eta", uiLang, { sec: leftSec });
          atUI(t("catalog.autotag.progress", uiLang, { i, total }), {
            progress: i / total,
            stop: true,
            note: `${AutoTag.backend()} \xB7 ${(per / 1e3).toFixed(1)} ${t("catalog.autotag.perImg", uiLang)} \xB7 ${eta}` + (failed ? ` \xB7 ${t("catalog.autotag.failed", uiLang, { n: failed })}` : "")
          });
          if (pending.length >= 25) {
            const batch = pending.splice(0);
            await persistAutoTags(batch);
          }
        }
      }
    );
    if (pending.length) await persistAutoTags(pending.splice(0));
    let videosDone = 0;
    for (let vi = 0; vi < (frameIds || []).length && !atStop && !writeFailed; vi++) {
      const id = frameIds[vi];
      const urls = await FaiDB.frameGet(id).catch(() => []);
      if (!urls.length) continue;
      const items = (thumbs[id] ? [thumbs[id]] : []).concat(urls).map((dataUrl, i) => ({ id: id + "#" + i, dataUrl }));
      const scores = {};
      let rating = null, used = 0;
      await AutoTag.tagAll(items, {
        shouldStop: () => atStop,
        onItem: (_k, res) => {
          used++;
          for (const [tg, sc] of Object.entries(res.scores || {}))
            if (!tagDropped(tg) && (scores[tg] == null || sc > scores[tg])) scores[tg] = sc;
          rating = hardestRating(rating, res.rating);
        },
        onProgress: (i, total) => atUI(t("catalog.autotag.frames.progress", uiLang, { i: vi + 1, n: frameIds.length }), {
          progress: (vi + i / Math.max(total, 1)) / frameIds.length,
          stop: true,
          note: t("catalog.autotag.frames.note", uiLang, { k: total })
        })
      });
      if (atStop && used < items.length) break;
      const tags = Object.keys(scores).sort((a, b) => scores[b] - scores[a]);
      const stamp = { model: AutoTag.MODEL, rev: AutoTag.REV, th: AutoTag.THRESHOLD, at: Date.now(), frames: urls.length };
      const e = catalog[id];
      if (e) {
        e.autoTags = tags;
        e.tagScores = scores;
        e.rating = rating;
        e.tagger = stamp;
      }
      const ok = await persistAutoTags([{ id, set: { autoTags: tags, tagScores: scores, rating, tagger: stamp } }]);
      if (ok) videosDone++;
    }
    AutoTag.release();
    if (writeFailed) atUI(
      "\u26A0\uFE0F \u0420\u0430\u0437\u043C\u0435\u0442\u043A\u0430 \u041D\u0415 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u2014 \u0431\u0430\u0437\u0430 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u044C",
      { close: true, note: "\u041E\u0431\u043D\u043E\u0432\u0438 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438 \u043F\u0440\u043E\u0433\u043E\u043D. \u0417\u0430\u043A\u0440\u043E\u0439 \u043B\u0438\u0448\u043D\u0438\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F." }
    );
    else {
      const parts = [];
      if (tagged) parts.push(t("catalog.autotag.done.photos", uiLang, { n: tagged }));
      if (videosDone) parts.push(t("catalog.autotag.done.videos", uiLang, { v: videosDone }));
      const body = parts.join(" \xB7 ") || t("catalog.autotag.done.none", uiLang);
      atUI(
        t(atStop ? "catalog.autotag.stoppedLine" : "catalog.autotag.doneLine", uiLang, { body }),
        { close: true, note: autoTagNew ? t("catalog.autotag.new.on", uiLang) : t("catalog.autotag.new.off", uiLang) }
      );
    }
    render();
  } catch (e) {
    console.error("[FanslyAI] \u{1F3F7} \u0430\u0432\u0442\u043E\u0442\u0435\u0433\u0438:", e);
    atUI(t("catalog.autotag.fail", uiLang) + " " + (e.message || ""), { close: true });
  } finally {
    atKeepAliveStop();
    atBusy = false;
  }
}
function showFrameBig(dataUrl) {
  const dim = document.createElement("div");
  dim.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(6,6,12,.94);display:flex;align-items:center;justify-content:center;cursor:zoom-out";
  const img = document.createElement("img");
  img.src = dataUrl;
  img.style.cssText = "max-width:96vw;max-height:96vh;border-radius:10px";
  dim.appendChild(img);
  const close = () => {
    dim.remove();
    document.removeEventListener("keydown", onKey);
  };
  const onKey = (ev) => {
    if (ev.key === "Escape") close();
  };
  dim.addEventListener("click", close);
  document.addEventListener("keydown", onKey);
  document.body.appendChild(dim);
}
function persistEntry(id) {
  if (!catalog[id]) return;
  dropDeriv(id);
  idbPatch([{ id, base: catalog[id], set: { tags: catalog[id].tags || [], desc: catalog[id].desc || "" } }]);
}
