let uiLang = "ru";
document.addEventListener("DOMContentLoaded", init);
function init() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (r) => {
    uiLang = r?.result?.interfaceLanguage || "ru";
    applyI18n(document, uiLang);
    if (typeof FaiLock !== "undefined") {
      FaiLock.init({ lang: uiLang });
      FaiLock.wire("lock-btn");
    }
    if (!window._tourInit && typeof initPageTour === "function") {
      window._tourInit = true;
      initPageTour({ flag: "tourDiag", btn: "page-tour", lang: uiLang, delay: 1800, steps: [
        { sel: "#overview", key: "tour.diag.s1" },
        { sel: "#charts", key: "tour.diag.s2" },
        { sel: "#bcast-sec", key: "tour.diag.s3" },
        { sel: ".ask", key: "tour.diag.s4" }
        // «Спросить» с разбором — в самом низу (17.10)
      ] });
    }
    document.getElementById("refresh").addEventListener("click", loadData);
    loadData();
  });
}
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local") return;
  if (ch.fansly_ai_settings) init();
  if (ch.fansly_broadcast_stats || ch.fansly_broadcast_lastsync) refreshBcast();
  if (ch.fansly_layout_miss) refreshBcast();
  if (ch.fansly_scan_off) bcastOffSync();
});
function refreshBcast() {
  chrome.storage.local.get(["fansly_broadcast_stats", "fansly_broadcast_lastsync"], (d) => {
    renderBroadcasts(d.fansly_broadcast_stats || {}, d.fansly_broadcast_lastsync);
    const btn = document.getElementById("bcast-refresh");
    if (btn) {
      btn.disabled = false;
      btn.textContent = t("diag.bcast.refresh", uiLang);
    }
    bcastOffSync();
  });
}
function bcastOffSync() {
  chrome.storage.local.get("fansly_scan_off", (d) => {
    const btn = document.getElementById("bcast-refresh");
    if (!btn) return;
    const off = !!(d && d.fansly_scan_off && d.fansly_scan_off.broadcast);
    if (off) {
      btn.disabled = true;
      btn.dataset.off = "1";
      btn.title = t("scanoff.btn.title", uiLang);
      btn.textContent = t("diag.bcast.refresh", uiLang);
    } else if (btn.dataset.off) {
      delete btn.dataset.off;
      btn.disabled = false;
      btn.title = "";
    }
  });
}
let bcastWired = false;
function wireBcast() {
  if (bcastWired) return;
  bcastWired = true;
  const btn = document.getElementById("bcast-refresh");
  if (!btn) return;
  btn.addEventListener("click", () => {
    if (btn.dataset.off) return;
    btn.disabled = true;
    btn.textContent = t("diag.bcast.refreshing", uiLang);
    chrome.runtime.sendMessage({ type: "REQUEST_BROADCAST_SCAN" });
  });
  bcastOffSync();
}
function postPubAt(p) {
  return CRM.postPubAt(p);
}
const monthKey = (ts) => {
  const d = new Date(ts);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
};
function monthLabel(key) {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString(uiLang, { month: "short", year: "2-digit" });
}
function monthRange(keys) {
  if (!keys.length) return [];
  const sorted = [...keys].sort();
  const [minY, minM] = sorted[0].split("-").map(Number);
  const [maxY, maxM] = sorted[sorted.length - 1].split("-").map(Number);
  const out = [];
  let y = minY, m = minM;
  while (y < maxY || y === maxY && m <= maxM) {
    out.push(y + "-" + String(m).padStart(2, "0"));
    m++;
    if (m > 12) {
      m = 1;
      y++;
    }
  }
  return out;
}
function computeMonthly(posts, earnings) {
  const median = (a) => {
    if (!a.length) return null;
    const s = [...a].sort((x, y) => x - y), h = s.length >> 1;
    return s.length % 2 ? s[h] : (s[h - 1] + s[h]) / 2;
  };
  const bucket = {};
  const ensure = (k) => bucket[k] || (bucket[k] = { posts: 0, media: 0, likes: 0, mediaLikes: 0, postTotals: [], best: 0, bestPost: null, subs: 0, rev: { total: 0, media: 0, media_bundle: 0, subscription: 0, tip: 0 }, payers: {} });
  const seenPost = /* @__PURE__ */ new Set(), list = [], mediaMax = {};
  for (const p of Object.values(posts || {})) {
    const ids = (p.mediaIds || []).filter(Boolean);
    if (!ids.length) continue;
    let min = ids[0];
    for (const id of ids) {
      try {
        if (BigInt(id) < BigInt(min)) min = id;
      } catch (e) {
      }
    }
    if (seenPost.has(min)) continue;
    seenPost.add(min);
    for (const [id, v] of Object.entries(p.mediaLikes || {})) if (v != null && !(mediaMax[id] >= v)) mediaMax[id] = v;
    const at = postPubAt(p);
    if (at != null) list.push({ p, ids, at });
  }
  const seenMedia = /* @__PURE__ */ new Set();
  for (const { p, ids, at } of list.sort((x, y) => x.at - y.at)) {
    const b = ensure(monthKey(at));
    b.posts++;
    b.media += new Set(ids).size;
    let ml = 0;
    for (const id of new Set(ids)) if (!seenMedia.has(id)) {
      seenMedia.add(id);
      ml += mediaMax[id] || 0;
    }
    const total = (p.likes != null ? p.likes : 0) + ml;
    b.likes += total;
    b.mediaLikes += ml;
    b.postTotals.push(total);
    if (!b.bestPost || total > b.best) {
      b.best = total;
      b.bestPost = { date: p.date || "", text: (p.text || "").slice(0, 80) };
    }
  }
  const firstSubAt = {};
  for (const e of Object.values(earnings || {})) {
    if (e.type !== "subscription" || e.refunded || !e.buyer) continue;
    const at = e.at || 0;
    if (!at) continue;
    if (firstSubAt[e.buyer] == null || at < firstSubAt[e.buyer]) firstSubAt[e.buyer] = at;
  }
  for (const at of Object.values(firstSubAt)) ensure(monthKey(at)).subs++;
  for (const e of Object.values(earnings || {})) {
    if (e.refunded || !(e.net >= 0) || !e.at) continue;
    const gross = e.net / 0.8;
    const b = ensure(monthKey(e.at));
    b.rev.total += gross;
    if (b.rev[e.type] != null) b.rev[e.type] += gross;
    if (e.buyer) {
      const h = e.buyer.toLowerCase();
      b.payers[h] = (b.payers[h] || 0) + gross;
    }
  }
  const firstPayMonth = {};
  for (const e of Object.values(earnings || {})) {
    if (e.refunded || !(e.net >= 0) || !e.at || !e.buyer) continue;
    const h = e.buyer.toLowerCase(), k = monthKey(e.at);
    if (firstPayMonth[h] == null || k < firstPayMonth[h]) firstPayMonth[h] = k;
  }
  const months = monthRange(Object.keys(bucket));
  return months.map((k) => {
    const b = bucket[k] || ensure(k);
    const sums = Object.entries(b.payers).map(([h, v]) => ({ h, v })).sort((a, c) => c.v - a.v);
    const tot = b.rev.total;
    const share = (n) => tot > 0 ? sums.slice(0, n).reduce((s, x) => s + x.v, 0) / tot : 0;
    let acc = 0, p80 = 0;
    for (const x of sums) {
      if (acc >= tot * 0.8) break;
      acc += x.v;
      p80++;
    }
    let revNew = 0, revRepeat = 0;
    for (const x of sums) {
      if (firstPayMonth[x.h] === k) revNew += x.v;
      else revRepeat += x.v;
    }
    return {
      key: k,
      posts: b.posts,
      mediaPerPost: b.posts ? b.media / b.posts : 0,
      // Не среднее на пост (Алекс 17.10: «один пост на 121 лайк — хуже 30 постов по 40», а один залетевший пост может сделать
      // кассу за месяц): сумма за месяц — объём, лучший пост — был ли хит, «у обычного поста» — середина ряда без хита.
      likesTotal: b.likes,
      mediaLikesTotal: b.mediaLikes,
      // пост + его медиа (см. выше); из них медиа — для ИИ-разбора
      likesBest: b.best,
      bestPost: b.bestPost,
      likesTypical: median(b.postTotals),
      subs: b.subs,
      revenue: tot,
      rev: b.rev,
      payers: sums.length,
      // сколько разных людей заплатило в месяце
      top1: share(1),
      top3: share(3),
      p80,
      // столько человек дают 80% выручки месяца
      revNew,
      revRepeat
      // деньги от впервые заплативших / от уже плативших раньше
    };
  });
}
function topPayers(earnings, n = 5) {
  const m = {};
  for (const e of Object.values(earnings || {})) {
    if (e.refunded || !(e.net >= 0) || !e.buyer) continue;
    const h = e.buyer.toLowerCase(), g = e.net / 0.8;
    const o = m[h] || (m[h] = { handle: h, spent: 0, sub: 0, tip: 0, buy: 0, pays: 0, first: null, last: null });
    o.spent += g;
    o.pays++;
    if (e.type === "subscription") o.sub += g;
    else if (e.type === "tip") o.tip += g;
    else o.buy += g;
    if (e.at) {
      const k = monthKey(e.at);
      if (o.first == null || k < o.first) o.first = k;
      if (o.last == null || k > o.last) o.last = k;
    }
  }
  const all = Object.values(m).sort((a, b) => b.spent - a.spent);
  const total = all.reduce((s, x) => s + x.spent, 0);
  return {
    total,
    count: all.length,
    top: all.slice(0, n).map((o, i) => ({
      rank: i + 1,
      handle: o.handle,
      spent: Math.round(o.spent),
      // handle — только для общей нумерации на странице (numberFans), в фон не уходит
      sub: Math.round(o.sub),
      tip: Math.round(o.tip),
      buy: Math.round(o.buy),
      pays: o.pays,
      first: o.first,
      last: o.last,
      share: total > 0 ? o.spent / total : 0
    }))
  };
}
const C_POSTS = "#e91e8c", C_LIKES = "#4aa3ff", C_SUBS = "#4caf50", C_FREE = "#ff9800";
function hexA(h, a) {
  const n = parseInt(h.slice(1), 16);
  return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`;
}
function niceNum(x, round) {
  if (!(x > 0)) return 1;
  const exp = Math.floor(Math.log10(x)), f = x / Math.pow(10, exp);
  const nf = round ? f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10 : f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
  return nf * Math.pow(10, exp);
}
function needZoom(vals) {
  const clean = vals.filter((v) => v != null && isFinite(v));
  if (!clean.length) return false;
  const mx = Math.max(...clean), mn = Math.min(...clean);
  return mn > 0 && mx > 0 && (mx - mn) / mx < 0.2;
}
function axisScale(vals, n, zoom) {
  const clean = vals.filter((v) => v != null && isFinite(v));
  const mx = Math.max(...clean, 0), mn = clean.length ? Math.min(...clean) : 0;
  let lo = 0, hi = mx;
  if (zoom && mn > 0) {
    const spread = mx - mn;
    const pad = spread > 0 ? spread * 0.4 : Math.max(mx * 0.01, 1);
    lo = Math.max(0, mn - pad);
    hi = mx + pad;
  }
  if (!(hi > lo)) hi = lo + Math.max(1, Math.abs(hi) * 0.02) * n;
  let step = niceNum((hi - lo) / n, true) || 1;
  let base = Math.floor(lo / step) * step;
  for (let guard = 0; base + step * n < hi && guard < 24; guard++) {
    step = niceNum(step * 1.6, false);
    base = Math.floor(lo / step) * step;
  }
  const top = base + step * n;
  const ticks = [];
  for (let i = 0; i <= n; i++) ticks.push(Math.round((base + step * i) * 1e3) / 1e3);
  return { lo: base, top, ticks, zoomed: base > 0 };
}
function lineChart(series, get, color, fmt, xlab, zoom) {
  const xl0 = xlab || ((r) => monthLabel(r.key));
  const vals = series.map(get);
  const sc = axisScale(vals, 4, zoom === true || zoom !== false && needZoom(vals));
  const W = 340, H = 160, mL = sc.zoomed ? 44 : 32, mR = 10, mT = 12, mB = 20;
  const pw = W - mL - mR, ph = H - mT - mB, n = series.length;
  const x = (i) => mL + (n <= 1 ? pw / 2 : i / (n - 1) * pw);
  const y = (v) => mT + ph - (v - sc.lo) / (sc.top - sc.lo || 1) * ph;
  let grid = "";
  for (const tk of sc.ticks) {
    const yy = y(tk).toFixed(1);
    grid += `<line x1="${mL}" y1="${yy}" x2="${W - mR}" y2="${yy}" class="ax-grid"/><text x="${mL - 5}" y="${(+yy + 3).toFixed(1)}" class="ax-lbl" text-anchor="end">${fmt(tk)}</text>`;
  }
  const stepX = Math.max(1, Math.ceil(n / 6));
  let xl = "";
  series.forEach((r, i) => {
    if (i % stepX === 0 || i === n - 1) xl += `<text x="${x(i).toFixed(1)}" y="${H - 6}" class="ax-lbl" text-anchor="middle">${xl0(r)}</text>`;
  });
  const pts = series.map((r, i) => x(i).toFixed(1) + "," + y(get(r)).toFixed(1));
  const area = `M ${x(0).toFixed(1)},${mT + ph} L ` + pts.join(" L ") + ` L ${x(n - 1).toFixed(1)},${mT + ph} Z`;
  let dots = "";
  series.forEach((r, i) => {
    dots += `<circle cx="${x(i).toFixed(1)}" cy="${y(get(r)).toFixed(1)}" r="2.5" style="fill:${color}"><title>${xl0(r)}: ${fmt(get(r))}</title></circle>`;
  });
  const zoomNote = sc.zoomed ? `<text x="${W - mR}" y="${mT - 3}" class="ax-lbl" text-anchor="end">${t("diag.chart.zoomedAxis", uiLang)}</text>` : "";
  return `<svg viewBox="0 0 ${W} ${H}" class="chart">${grid}<path d="${area}" style="fill:${hexA(color, 0.12)}"/><polyline points="${pts.join(" ")}" style="fill:none;stroke:${color};stroke-width:2;stroke-linejoin:round;stroke-linecap:round"/>${xl}${dots}${zoomNote}</svg>`;
}
function multiChart(series, defs, fmt, xlab) {
  const xl0 = xlab || ((r) => monthLabel(r.key));
  const all = [];
  defs.forEach((d) => series.forEach((r) => {
    const v = d.get(r);
    if (v != null && isFinite(v)) all.push(v);
  }));
  const sc = axisScale(all, 4, false);
  const W = 340, H = 160, mL = 40, mR = 10, mT = 12, mB = 20;
  const pw = W - mL - mR, ph = H - mT - mB, n = series.length;
  const x = (i) => mL + (n <= 1 ? pw / 2 : i / (n - 1) * pw);
  const y = (v) => mT + ph - (v - sc.lo) / (sc.top - sc.lo || 1) * ph;
  let grid = "";
  for (const tk of sc.ticks) {
    const yy = y(tk).toFixed(1);
    grid += `<line x1="${mL}" y1="${yy}" x2="${W - mR}" y2="${yy}" class="ax-grid"/><text x="${mL - 5}" y="${(+yy + 3).toFixed(1)}" class="ax-lbl" text-anchor="end">${fmt(tk)}</text>`;
  }
  const stepX = Math.max(1, Math.ceil(n / 6));
  let xl = "";
  series.forEach((r, i) => {
    if (i % stepX === 0 || i === n - 1) xl += `<text x="${x(i).toFixed(1)}" y="${H - 6}" class="ax-lbl" text-anchor="middle">${xl0(r)}</text>`;
  });
  let body = "";
  defs.forEach((d) => {
    const valid = series.map((r, i) => ({ v: d.get(r), i, r })).filter((o) => o.v != null && isFinite(o.v));
    if (!valid.length) return;
    body += `<polyline points="${valid.map((o) => x(o.i).toFixed(1) + "," + y(o.v).toFixed(1)).join(" ")}" style="fill:none;stroke:${d.color};stroke-width:2;stroke-linejoin:round;stroke-linecap:round"/>`;
    valid.forEach((o) => {
      body += `<circle cx="${x(o.i).toFixed(1)}" cy="${y(o.v).toFixed(1)}" r="2.2" style="fill:${d.color}"><title>${xl0(o.r)} \xB7 ${d.name}: ${fmt(o.v)}</title></circle>`;
    });
  });
  const legend = '<div class="legend">' + defs.map((d) => `<span><i style="background:${d.color}"></i>${d.name}</span>`).join("") + "</div>";
  return legend + `<svg viewBox="0 0 ${W} ${H}" class="chart">${grid}${xl}${body}</svg>`;
}
function multiCard(title, cv, series, defs, fmt) {
  return `<div class="chartcard"><div class="ct">${title}</div><div class="cv">${cv}</div>${multiChart(series, defs, fmt)}</div>`;
}
function dualChart(series, defs, xlab) {
  const xl0 = xlab || ((r) => monthLabel(r.key));
  const N = 4;
  const W = 560, H = 235, mL = 48, mR = defs.length > 1 ? 52 : 12, mT = 14, mB = 26;
  const pw = W - mL - mR, ph = H - mT - mB, n = series.length;
  const scales = defs.map((d) => axisScale(series.map(d.get), N, d.zoom === true || d.zoom !== false && needZoom(series.map(d.get))));
  const x = (i) => mL + (n <= 1 ? pw / 2 : i / (n - 1) * pw);
  const yOf = (s, v) => mT + ph - (v - s.lo) / (s.top - s.lo || 1) * ph;
  let svg = "";
  scales[0].ticks.forEach((tk, i) => {
    const yy = yOf(scales[0], tk).toFixed(1);
    svg += `<line x1="${mL}" y1="${yy}" x2="${W - mR}" y2="${yy}" class="ax-grid"/>`;
    svg += `<text x="${mL - 5}" y="${(+yy + 3).toFixed(1)}" class="ax-lbl" text-anchor="end" style="fill:${defs[0].color}">${defs[0].fmt(tk)}</text>`;
    if (defs.length > 1) svg += `<text x="${W - mR + 5}" y="${(+yy + 3).toFixed(1)}" class="ax-lbl" style="fill:${defs[1].color}">${defs[1].fmt(scales[1].ticks[i])}</text>`;
  });
  const stepX = Math.max(1, Math.ceil(n / 7));
  series.forEach((r, i) => {
    if (i % stepX === 0 || i === n - 1) svg += `<text x="${x(i).toFixed(1)}" y="${H - 8}" class="ax-lbl" text-anchor="middle">${xl0(r)}</text>`;
  });
  defs.forEach((d, di) => {
    const sc = scales[di];
    const valid = series.map((r, i) => ({ v: d.get(r), i, r })).filter((o) => o.v != null && isFinite(o.v));
    if (!valid.length) return;
    const pts = valid.map((o) => x(o.i).toFixed(1) + "," + yOf(sc, o.v).toFixed(1));
    svg += `<polyline points="${pts.join(" ")}" style="fill:none;stroke:${d.color};stroke-width:2;stroke-linejoin:round;stroke-linecap:round"/>`;
    valid.forEach((o) => {
      svg += `<circle cx="${x(o.i).toFixed(1)}" cy="${yOf(sc, o.v).toFixed(1)}" r="2.5" style="fill:${d.color}"><title>${xl0(o.r)} \xB7 ${d.name}: ${d.fmt(o.v)}</title></circle>`;
    });
  });
  const zoomed = scales.some((s) => s.zoomed);
  if (zoomed) svg += `<text x="${W - mR}" y="${mT - 4}" class="ax-lbl" text-anchor="end">\u043E\u0441\u044C \u043F\u0440\u0438\u0431\u043B\u0438\u0436\u0435\u043D\u0430</text>`;
  const legend = '<div class="legend">' + defs.map((d) => `<span><i style="background:${d.color}"></i>${d.name}</span>`).join("") + "</div>";
  return legend + `<svg viewBox="0 0 ${W} ${H}" class="chart">${svg}</svg>`;
}
function chartCard(titleKey, series, get, color, fmt) {
  const last = series.length ? get(series[series.length - 1]) : 0;
  return `<div class="chartcard">
    <div class="ct">${t(titleKey, uiLang)}</div>
    <div class="cv">${fmt(last)}<small>${monthLabel(series[series.length - 1].key)}</small></div>
    ${lineChart(series, get, color, fmt)}
  </div>`;
}
function dayLabel(key) {
  const p = key.split("-");
  return p[2] + "." + p[1];
}
function subsDailyChart(daily) {
  const title = t("diag.chart.subsDaily", uiLang);
  const days = Object.keys(daily || {}).sort().slice(-30);
  const pts = days.filter((k) => daily[k] && daily[k].followers != null).map((k) => ({ key: k, followers: daily[k].followers }));
  if (pts.length < 2) return `<div class="chartcard"><div class="ct">${title}</div><div style="color:#666;font-size:12px;padding:10px 0">${t("diag.subsDaily.empty", uiLang)}</div></div>`;
  const last = pts[pts.length - 1].followers, first = pts[0].followers;
  const d = last - first;
  const delta = d === 0 ? "" : (d > 0 ? "+" : "\u2212") + Math.abs(d).toLocaleString(uiLang) + " " + t("diag.chart.overDays", uiLang, { n: pts.length }) + " \xB7 ";
  return `<div class="chartcard"><div class="ct">${title}</div><div class="cv">${last.toLocaleString(uiLang)}<small>${delta}${dayLabel(pts[pts.length - 1].key)}</small></div>${lineChart(pts, (p) => p.followers, C_FREE, (n) => Math.round(n).toLocaleString(uiLang), (p) => dayLabel(p.key), true)}</div>`;
}
function overviewCharts(series, daily) {
  const monFol = {};
  for (const k of Object.keys(daily || {}).sort()) if (daily[k] && daily[k].followers != null) monFol[k.slice(0, 7)] = daily[k].followers;
  const int0 = (v) => Math.round(v).toLocaleString(uiLang);
  const one = (v) => (Math.round(v * 10) / 10).toLocaleString(uiLang);
  const content = `<div class="chartcard"><div class="ct">${t("diag.overview.content.title", uiLang)}</div><div class="cs">${t("diag.overview.content.subTotal", uiLang)}</div>` + dualChart(series, [
    { name: t("diag.table.posts", uiLang), color: C_POSTS, get: (r) => r.posts, fmt: int0, zoom: false },
    { name: t("diag.table.likesTotal", uiLang), color: C_LIKES, get: (r) => r.likesTotal, fmt: int0, zoom: false }
  ]) + "</div>";
  const audDefs = [];
  if (Object.keys(monFol).length) audDefs.push({ name: t("diag.table.freeSubs", uiLang), color: C_FREE, get: (r) => monFol[r.key] != null ? monFol[r.key] : null, fmt: int0 });
  audDefs.push({ name: t("diag.table.subs", uiLang), color: C_SUBS, get: (r) => r.subs, fmt: int0, zoom: false });
  const audSub = audDefs.length > 1 ? t("diag.overview.audience.sub.both", uiLang) : t("diag.overview.audience.sub.subsOnly", uiLang);
  const audience = `<div class="chartcard"><div class="ct">${t("diag.overview.audience.title", uiLang)}</div><div class="cs">${audSub}</div>` + dualChart(series, audDefs) + "</div>";
  return content + audience;
}
function renderReport(rep, data) {
  const L = (k, v) => t(k, uiLang, v), cols = (k) => L(k).split("|"), esc = escapeHtml;
  const usd = (n) => "$" + Math.round(n || 0).toLocaleString(uiLang);
  const pc = (x) => x == null ? "\u2014" : Math.round(x * 100) + "%";
  const dt = (at) => at ? new Date(at).toLocaleDateString(uiLang, { day: "numeric", month: "short", year: "numeric" }) : "\u2014";
  const tbl = (head, rows) => '<div class="tablewrap"><table><thead><tr>' + head.map((x) => "<th>" + esc(x) + "</th>").join("") + "</tr></thead><tbody>" + rows.map((r2) => "<tr>" + r2.map((c2) => "<td>" + c2 + "</td>").join("") + "</tr>").join("") + "</tbody></table></div>";
  const who = (f) => esc(f.name && f.name !== f.handle ? f.name + " (@" + f.handle + ")" : "@" + f.handle);
  const st = (f) => f.deleted ? L("diag.rep.st.deleted") : f.active ? L("diag.rep.st.active") : f.expired ? L("diag.rep.st.gone") : "\u2014";
  const csv = (kind) => '<button class="csv-btn" data-csv="' + kind + '" title="' + esc(L("diag.csv.tip")) + '">' + esc(L("diag.csv.btn")) + "</button>";
  const sec = (k, kind) => '<div class="rsec">' + esc(L(k)) + (kind ? csv(kind) : "") + "</div>", note = (s, tail) => '<div class="rnote">' + esc(s) + (tail || "") + "</div>";
  const m = rep.money, o = rep.overview, c = rep.concentration, r = rep.risk, od = rep.orders;
  const subsAt = Math.max(0, ...Object.values(data.fansly_subs || {}).map((s) => s && s.syncedAt || 0));
  let h = "<h2>" + esc(L("diag.rep.title")) + "</h2>";
  h += '<div class="src">' + esc(L("diag.rep.src", { n: m.n, from: dt(m.first), to: dt(m.last), earnAt: dt(data.fansly_earnings_lastsync && data.fansly_earnings_lastsync.at), subsAt: dt(subsAt || null) })) + "</div>";
  if (m.orphanN) h += '<div class="src">' + esc(L("diag.rep.orphan", { sum: usd(m.orphan), pct: pc(m.total ? m.orphan / m.total : 0), n: m.orphanN })) + "</div>";
  if (m.inferredN) h += '<div class="src">' + esc(L("diag.rep.inferred", { sum: usd(m.inferred), n: m.inferredN, fans: m.inferredFans })) + "</div>";
  h += sec("diag.rep.money.title") + note(L("diag.rep.money", { total: usd(m.total), sub: pc(m.total ? m.sub / m.total : null), buy: pc(m.total ? m.buy / m.total : null), tip: pc(m.total ? m.tip / m.total : null), subbed: o.subbed, active: o.active, gone: o.gone }));
  if (rep.tiers.length) h += sec("diag.rep.tiers.title", "tiers") + tbl(cols("diag.rep.tiers.head"), rep.tiers.map((x) => [
    esc(x.name || L("diag.rep.tier.none")),
    x.fans,
    x.active,
    x.gone,
    pc(x.churn),
    x.months ?? "\u2014",
    usd(x.perFan),
    usd(x.median),
    pc(x.spent ? x.buy / x.spent : null),
    pc(x.likers)
  ]));
  if (c.payers) h += sec("diag.rep.conc.title", "top") + note(L("diag.rep.conc", { n80: c.n80, payers: c.payers, top5: pc(c.top5), top20: pc(c.top20) })) + tbl(cols("diag.rep.top.head"), c.top.map((f, i) => [i + 1, who(f), usd(f.spent), esc(f.tier || "\u2014"), st(f), f.likedAgo == null ? "\u2014" : esc(L("diag.rep.daysAgo", { n: f.likedAgo }))]));
  const list = (a) => a.length ? " \xB7 " + esc(L("diag.rep.most")) + ": " + a.join(", ") : "";
  h += sec("diag.rep.risk.title") + note(L("diag.rep.risk.off", { n: r.renewOff, price: usd(r.renewOffPrice), spent: usd(r.renewOffSpent) })) + note(L("diag.rep.risk.winback", { n: r.winback.length, spent: usd(r.winback.reduce((s, f) => s + f.spent, 0)) }), list(r.winback.slice(0, 5).map((f) => who(f) + " " + usd(f.spent)))) + note(L("diag.rep.risk.gone", { n: r.gonePaid, spent: usd(r.gonePaidSpent), median: usd(r.gonePaidMedian) }));
  if (od.briefs) h += sec("diag.rep.orders.title") + note(L("diag.rep.briefs", { n: od.briefs, paid: od.briefsPaid, stale: od.briefsStale }));
  if (rep.cohorts.length) h += sec("diag.rep.coh.title", "cohorts") + tbl(cols("diag.rep.coh.head"), rep.cohorts.map((k) => [esc(monthLabel(k.month)), k.came, k.active, usd(k.spent)])) + note(L("diag.rep.coh.note"));
  document.getElementById("report").innerHTML = h;
  lastRep = rep;
  const no = numberFans(rep);
  lastReportText = CRM.reportForAI(rep, (f) => "\u2116" + (no.get((f.handle || "").toLowerCase()) || "?"));
}
let lastSeries = [], lastBroadcasts = [], lastPayers = null, lastReportText = "", lastRep = null;
async function loadData() {
  const keys = [.../* @__PURE__ */ new Set(["fansly_posts", "fansly_earnings", "fansly_broadcast_stats", "fansly_broadcast_lastsync", "fansly_stats_daily", ...CRM.STORE_KEYS])];
  const data = await new Promise((r) => chrome.storage.local.get(keys, (d) => r(d)));
  const contacts = await new Promise((r) => chrome.runtime.sendMessage({ type: "GET_ALL_CONTACTS" }, (resp) => r(resp && resp.result || {})));
  const series = computeMonthly(data.fansly_posts, data.fansly_earnings);
  const daily = data.fansly_stats_daily || {};
  lastSeries = series;
  lastPayers = topPayers(data.fansly_earnings);
  const empty = document.getElementById("empty"), content = document.getElementById("content");
  if (!series.length) {
    empty.style.display = "block";
    content.style.display = "none";
    renderEmptyActions();
    return;
  }
  empty.style.display = "none";
  content.style.display = "block";
  document.getElementById("range").textContent = t("diag.range", uiLang, { from: monthLabel(series[0].key), to: monthLabel(series[series.length - 1].key), n: series.length });
  const int0 = (n) => String(Math.round(n));
  const one = (n) => (Math.round(n * 10) / 10).toLocaleString(uiLang, { minimumFractionDigits: 0, maximumFractionDigits: 1 });
  document.getElementById("overview").innerHTML = overviewCharts(series, daily);
  const last = series[series.length - 1];
  const mny = (n) => "$" + Math.round(n).toLocaleString(uiLang);
  const pct = (n) => Math.round(n) + "%";
  const L = (k) => t(k, uiLang);
  const revMix = multiCard(L("diag.chart.revMix"), mny(last.revenue), series, [
    { name: L("diag.leg.subs"), color: C_SUBS, get: (r) => r.rev.subscription },
    { name: L("diag.leg.tips"), color: C_FREE, get: (r) => r.rev.tip },
    { name: L("diag.leg.buys"), color: C_LIKES, get: (r) => r.rev.media + r.rev.media_bundle }
  ], mny);
  const conc = multiCard(L("diag.chart.concentration"), pct(last.top3 * 100), series, [
    { name: L("diag.leg.top1"), color: C_POSTS, get: (r) => r.top1 * 100 },
    { name: L("diag.leg.top3"), color: C_LIKES, get: (r) => r.top3 * 100 }
  ], pct);
  const intL = (n) => Math.round(n || 0).toLocaleString(uiLang);
  const likesCard = multiCard(L("diag.chart.likesMonth"), intL(last.likesTotal), series, [
    { name: L("diag.leg.likesTotal"), color: C_LIKES, get: (r) => r.likesTotal },
    { name: L("diag.leg.likesBest"), color: C_POSTS, get: (r) => r.likesBest }
  ], intL);
  const nvr = multiCard(L("diag.chart.newVsRepeat"), mny(last.revRepeat), series, [
    { name: L("diag.leg.newPayers"), color: C_SUBS, get: (r) => r.revNew },
    { name: L("diag.leg.repeatPayers"), color: C_LIKES, get: (r) => r.revRepeat }
  ], mny);
  document.getElementById("charts").innerHTML = chartCard("diag.chart.posts", series, (r) => r.posts, C_POSTS, int0) + likesCard + // лайки за месяц и лучший пост (17.10)
  chartCard("diag.chart.subs", series, (r) => r.subs, C_SUBS, int0) + subsDailyChart(daily) + // подписчики за последние 30 дней (ежедневный срез из шапки)
  revMix + conc + nvr;
  try {
    const fans = CRM.allFans(data, contacts, {});
    fanHandles = fans.map((f) => (f.handle || "").toLowerCase()).filter((h) => h.length >= 4);
    renderReport(CRM.businessReport(fans, data.fansly_earnings, Date.now(), data.fansly_ledger), data);
  } catch (e) {
    console.warn("[FanslyAI] \u0440\u0430\u0437\u0431\u043E\u0440 \u0431\u0438\u0437\u043D\u0435\u0441\u0430 \u043D\u0435 \u043F\u043E\u0441\u0442\u0440\u043E\u0438\u043B\u0441\u044F \u2014", e);
    document.getElementById("report").innerHTML = "";
  }
  const money = (n) => "$" + Math.round(n).toLocaleString(uiLang);
  const num = (n) => Math.round(n || 0).toLocaleString(uiLang);
  const curKey = monthKey(Date.now());
  const head = `<thead><tr>
    <th>${t("diag.table.month", uiLang)}</th>
    <th>${t("diag.table.posts", uiLang)}</th>
    <th>${t("diag.table.media", uiLang)}</th>
    <th>${t("diag.table.likesTotal", uiLang)}</th>
    <th>${t("diag.table.likesBest", uiLang)}</th>
    <th>${t("diag.table.likesTypical", uiLang)}</th>
    <th>${t("diag.table.subs", uiLang)}</th>
    <th>${t("diag.table.revenue", uiLang)}</th>
  </tr></thead>`;
  const body = series.map((r) => `<tr>
    <td class="month">${monthLabel(r.key)}${r.key === curKey ? " *" : ""}</td>
    <td>${r.posts || "\u2014"}</td>
    <td>${r.posts ? one(r.mediaPerPost) : "\u2014"}</td>
    <td>${r.posts ? num(r.likesTotal) : "\u2014"}</td>
    <td${r.bestPost ? ` title="${escapeHtml(t("diag.tip.bestPost", uiLang, { date: r.bestPost.date || "\u2014" }) + (r.bestPost.text ? " \u2014 \xAB" + r.bestPost.text + "\xBB" : ""))}"` : ""}>${r.posts ? num(r.likesBest) : "\u2014"}</td>
    <td>${r.posts && r.likesTypical != null ? one(r.likesTypical) : "\u2014"}</td>
    <td>${r.subs || "\u2014"}</td>
    <td>${r.revenue >= 0.5 ? money(r.revenue) : "\u2014"}</td>
  </tr>`).join("");
  document.getElementById("table").innerHTML = head + "<tbody>" + body + "</tbody>";
  document.getElementById("partial-note").textContent = series.some((r) => r.key === curKey) ? t("diag.month.partial", uiLang, { m: monthLabel(curKey) }) : "";
  document.getElementById("likes-note").textContent = t("diag.note.likes", uiLang);
  renderBroadcasts(data.fansly_broadcast_stats || {}, data.fansly_broadcast_lastsync);
  wireBcast();
  wireAsk();
}
function renderEmptyActions() {
  const box = document.getElementById("empty-acts");
  if (!box || box.dataset.built) return;
  box.dataset.built = "1";
  chrome.storage.local.get("fansly_creator_handle", (d) => {
    const handle = d.fansly_creator_handle;
    const mk = (label, url, sec) => {
      const b = document.createElement("button");
      b.className = "btn" + (sec ? " sec" : "");
      b.textContent = label;
      b.addEventListener("click", () => window.open(url, "_blank", "noopener"));
      return b;
    };
    if (handle) box.appendChild(mk(t("diag.empty.scanPosts", uiLang), "https://fansly.com/" + encodeURIComponent(handle) + "/posts"));
    box.appendChild(mk(t("diag.empty.scanEarnings", uiLang), "https://fansly.com/creator/wallet/history", !!handle));
  });
}
function bShortDate(b) {
  if (b.at) return new Date(b.at).toLocaleDateString(uiLang, { day: "2-digit", month: "short", year: "2-digit" });
  return (b.label || "").replace(/^[A-Za-zА-Яа-я]+,\s*/, "");
}
function renderBroadcasts(store, lastsync) {
  const box = document.getElementById("bcast");
  const emptyEl = document.getElementById("bcast-empty");
  const syncEl = document.getElementById("bcast-sync");
  if (syncEl) {
    syncEl.textContent = lastsync && lastsync.at ? t("diag.bcast.lastsync", uiLang, { time: new Date(lastsync.at).toLocaleString(uiLang, { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) }) : t("diag.bcast.never", uiLang);
  }
  const list = Object.values(store).map((b) => ({ ...b, rate: b.reach > 0 ? b.open / b.reach : null })).sort((a, b) => (a.at || 0) - (b.at || 0));
  lastBroadcasts = list;
  if (!list.length) {
    box.style.display = "none";
    if (emptyEl) emptyEl.style.display = "block";
    return;
  }
  if (emptyEl) emptyEl.style.display = "none";
  box.style.display = "block";
  const rates = list.map((b) => b.rate).filter((r) => r != null).sort((a, b) => a - b);
  const median = rates.length ? rates[Math.floor(rates.length / 2)] : null;
  const lowCut = median != null ? median * 0.6 : null;
  const withReach = list.filter((b) => b.rate != null);
  document.getElementById("bcast-chart").innerHTML = withReach.length >= 2 ? `<div class="chartcard" style="margin-bottom:12px;max-width:520px"><div class="ct">${t("diag.bcast.openRateChart", uiLang)}</div>` + // шире карточки не растягиваем: высота растёт вместе с шириной (Алекс 17.10: «огромный»)
  lineChart(withReach, (b) => b.rate * 100, C_LIKES, (n) => Math.round(n) + "%", bShortDate) + "</div>" : "";
  const pct = (r) => r == null ? "\u2014" : (Math.round(r * 1e3) / 10).toLocaleString(uiLang) + "%";
  const money = (n) => "$" + Math.round(n || 0).toLocaleString(uiLang);
  const head = `<thead><tr>
    <th>${t("diag.bcast.date", uiLang)}</th>
    <th>${t("diag.bcast.reach", uiLang)}</th>
    <th>${t("diag.bcast.openRate", uiLang)}</th>
    <th>${t("diag.bcast.sales", uiLang)}</th>
    <th>${t("diag.table.revenue", uiLang)}</th>
    <th style="text-align:left">${t("diag.bcast.preview", uiLang)}</th>
  </tr></thead>`;
  const body = list.map((b) => {
    const low = lowCut != null && b.rate != null && b.rate < lowCut;
    return `<tr${low ? ' class="lowopen"' : ""}>
      <td class="month">${escapeHtml(bShortDate(b))}</td>
      <td>${b.reach != null ? b.reach.toLocaleString(uiLang) : "\u2014"}</td>
      <td>${pct(b.rate)}${low ? " \u26A0\uFE0F" : ""}</td>
      <td>${b.sale != null ? b.sale : "\u2014"}</td>
      <td>${b.revenue >= 0.5 ? money(b.revenue) : "\u2014"}</td>
      <td style="text-align:left;color:#8a8aa5;max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(b.preview || "")}</td>
    </tr>`;
  }).join("");
  document.getElementById("bcast-table").innerHTML = head + "<tbody>" + body + "</tbody>";
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}
const CSV_NAMES = { monthly: "mesyacy", bcast: "rassylki", tiers: "tiry", top: "top10", cohorts: "kto-ostayotsya" };
function csvNum(x, d = 0) {
  if (x == null || !isFinite(x)) return "";
  const s = String(Math.round(x * 10 ** d) / 10 ** d);
  return uiLang === "en" ? s : s.replace(".", ",");
}
function csvPct(x) {
  return x == null ? "" : csvNum(x * 100, 1);
}
function csvWhen(at) {
  const d = new Date(at), p = (n) => String(n).padStart(2, "0");
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
}
function csvCell(v) {
  const s = v == null ? "" : String(v);
  return /[;"\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function csvRows(kind) {
  const L = (k) => t(k, uiLang), cols = (k) => L(k).split("|");
  if (kind === "monthly") return [
    [L("diag.table.month"), L("diag.table.posts"), L("diag.table.media"), L("diag.table.likesTotal"), L("diag.table.likesBest"), L("diag.table.likesTypical"), L("diag.table.subs"), L("diag.table.revenue") + ", $"],
    ...lastSeries.map((r) => [r.key, r.posts, csvNum(r.mediaPerPost, 1), r.posts ? r.likesTotal : "", r.posts ? r.likesBest : "", r.posts && r.likesTypical != null ? csvNum(r.likesTypical, 1) : "", r.subs, csvNum(r.revenue, 2)])
  ];
  if (kind === "bcast") return [
    [L("diag.bcast.date"), L("diag.bcast.reach"), L("diag.bcast.openRate") + ", %", L("diag.bcast.sales"), L("diag.table.revenue") + ", $", L("diag.bcast.preview")],
    ...lastBroadcasts.map((b) => [b.at ? csvWhen(b.at) : b.label || "", b.reach ?? "", csvPct(b.rate), b.sale ?? "", csvNum(b.revenue || 0, 2), b.preview || ""])
  ];
  const rep = lastRep;
  if (!rep) return null;
  const st = (f) => f.deleted ? L("diag.rep.st.deleted") : f.active ? L("diag.rep.st.active") : f.expired ? L("diag.rep.st.gone") : "";
  if (kind === "tiers") {
    const h = cols("diag.rep.tiers.head");
    for (const i of [4, 8, 9]) h[i] += ", %";
    for (const i of [6, 7]) h[i] += ", $";
    return [h, ...rep.tiers.map((x) => [x.name || L("diag.rep.tier.none"), x.fans, x.active, x.gone, csvPct(x.churn), x.months ?? "", csvNum(x.perFan, 2), csvNum(x.median, 2), csvPct(x.spent ? x.buy / x.spent : null), csvPct(x.likers)])];
  }
  if (kind === "top") {
    const h = cols("diag.rep.top.head");
    h[2] += ", $";
    h[5] += ", " + L("diag.csv.daysAgo");
    return [h, ...rep.concentration.top.map((f, i) => [i + 1, f.name && f.name !== f.handle ? f.name + " (@" + f.handle + ")" : "@" + f.handle, csvNum(f.spent, 2), f.tier || "", st(f), f.likedAgo ?? ""])];
  }
  if (kind === "cohorts") {
    const h = cols("diag.rep.coh.head");
    h[3] += ", $";
    return [h, ...rep.cohorts.map((k) => [k.month, k.came, k.active, csvNum(k.spent, 2)])];
  }
  return null;
}
function csvExport(kind) {
  const rows = csvRows(kind);
  if (!rows) return;
  const text = "\uFEFF" + rows.map((r) => r.map(csvCell).join(";")).join("\r\n") + "\r\n";
  const d = /* @__PURE__ */ new Date(), p = (n) => String(n).padStart(2, "0"), a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  a.download = `dinamika-${CSV_NAMES[kind] || kind}-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
}
document.addEventListener("click", (e) => {
  const b = e.target && e.target.closest && e.target.closest("[data-csv]");
  if (b) csvExport(b.dataset.csv);
});
let askWired = false, askRun = null;
const askTurns = [];
let fanNames = [], fanHandles = [];
function numberFans(rep) {
  if (!askTurns.length) fanNames = [];
  const no = new Map(fanNames.map((f, i) => [f.handle.toLowerCase(), i + 1]));
  const add = (handle, name) => {
    const l = (handle || "").toLowerCase();
    if (!l || no.has(l)) return;
    fanNames.push({ handle, name: name || handle });
    no.set(l, fanNames.length);
  };
  for (const f of rep && rep.concentration && rep.concentration.top || []) add(f.handle, f.name);
  for (const p of lastPayers && lastPayers.top || []) add(p.handle, p.handle);
  if (lastPayers) for (const p of lastPayers.top) p.rank = no.get((p.handle || "").toLowerCase()) || p.rank;
  return no;
}
function fanWho(n) {
  const f = fanNames[n - 1];
  return f ? f.name && f.name !== f.handle ? f.name + " (@" + f.handle + ")" : "@" + f.handle : null;
}
function deanon(s) {
  return String(s || "").replace(/№\s?(\d{1,3})(?!\d)/g, (m, n) => fanWho(+n) || m);
}
function maskFans(q) {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), pairs = [], numbered = new Set(fanNames.map((f) => f.handle.toLowerCase()));
  fanNames.forEach((f, i) => {
    const n = "\u2116" + (i + 1);
    pairs.push(["@" + f.handle, n], [f.handle, n]);
    if (f.name && f.name !== f.handle && f.name.length >= 3) pairs.push([f.name, n]);
  });
  for (const h of fanHandles) if (!numbered.has(h)) pairs.push(["@" + h, "[\u0434\u0440\u0443\u0433\u043E\u0439 \u0444\u0430\u043D]"], [h, "[\u0434\u0440\u0443\u0433\u043E\u0439 \u0444\u0430\u043D]"]);
  let out = String(q || "");
  for (const [s, n] of pairs.sort((a, b) => b[0].length - a[0].length))
    out = out.replace(new RegExp("(^|[^\\p{L}\\p{N}_@])" + esc(s) + "(?![\\p{L}\\p{N}_])", "giu"), (m, pre) => pre + n);
  return out.replace(/@[\p{L}\p{N}_.]+/gu, "[\u0434\u0440\u0443\u0433\u043E\u0439 \u0444\u0430\u043D]");
}
function askTranscript() {
  const when = (/* @__PURE__ */ new Date()).toLocaleString(uiLang, { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const out = [t("diag.ask.transcriptTitle", uiLang, { when }), ""];
  for (const m of askTurns) out.push(m.role === "user" ? t("diag.ask.you", uiLang) + ": " + (m.label || m.content) : t("diag.ask.ai", uiLang) + ": " + deanon(m.content), "");
  return out.join("\n").trim() + "\n";
}
function askFlash(btn, text) {
  const was = btn.textContent;
  btn.textContent = text;
  setTimeout(() => {
    btn.textContent = was;
  }, 1500);
}
async function askCopy(btn) {
  const text = askTranscript();
  let ok = false;
  try {
    await navigator.clipboard.writeText(text);
    ok = true;
  } catch (e) {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      ok = document.execCommand("copy");
      ta.remove();
    } catch (e2) {
    }
  }
  askFlash(btn, t(ok ? "diag.ask.copied" : "diag.ask.copyFailed", uiLang));
}
function askSave() {
  const d = /* @__PURE__ */ new Date(), p = (n) => String(n).padStart(2, "0"), a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([askTranscript()], { type: "text/plain;charset=utf-8" }));
  a.download = `razbor-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.txt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
}
function renderAskLog() {
  const log = document.getElementById("ask-log");
  if (!log) return;
  log.innerHTML = askTurns.map((m) => m.role === "user" ? '<div class="ask-q">' + escapeHtml(m.label || m.content) + "</div>" : '<div class="ask-a">' + escapeHtml(deanon(m.content)) + "</div>").join("") + (askLive ? '<div class="ask-q pending">' + escapeHtml(askLive) + "</div>" : "") + (askPending ? '<div class="ask-q queued">\u23F3 ' + escapeHtml(askPending) + "</div>" : "");
  log.style.display = askTurns.length || askLive || askPending ? "" : "none";
  const tools = document.getElementById("ask-tools");
  if (tools) tools.style.display = askTurns.length ? "" : "none";
}
let askPending = null, askBusy = false, askLive = null;
function askNext() {
  const next = askPending;
  askPending = null;
  if (next && askRun) askRun(void 0, next);
}
function askDone(r, q, label) {
  askTurns.push({ role: "user", content: r.ask || q, label }, { role: "assistant", content: r.text });
  askLive = null;
  renderAskLog();
}
function askAfter(r, typed, review) {
  askLive = null;
  if (r && r.success && r.text) return;
  const input = document.getElementById("ask-input"), back = [review ? "" : typed, askPending || ""].filter(Boolean).join("\n");
  askPending = null;
  if (back && input && !input.value.trim()) input.value = back;
  renderAskLog();
}
function wireAsk() {
  if (askWired) return;
  askWired = true;
  const input = document.getElementById("ask-input"), btn = document.getElementById("ask-btn"), out = document.getElementById("ask-answer");
  const run = (mode, queued) => {
    const review = mode === "review", fromInput = !review && queued == null;
    const typed = review ? "" : String(fromInput ? input.value || "" : queued).trim();
    if (!review && !typed) return;
    if (askBusy) {
      if (!review) {
        askPending = askPending ? askPending + "\n" + typed : typed;
        if (fromInput) input.value = "";
        out.textContent = t("diag.ask.queued", uiLang);
        renderAskLog();
      }
      return;
    }
    askPending = null;
    if (fromInput) input.value = "";
    const q = maskFans(typed);
    askBusy = true;
    const label = review ? t("diag.ask.reviewLabel", uiLang) : typed;
    askLive = label;
    renderAskLog();
    out.style.display = "block";
    out.textContent = t(review ? "diag.ask.thinkingReview" : "diag.ask.thinking", uiLang);
    const box = out.closest(".ask");
    if (review && box && box.scrollIntoView) box.scrollIntoView({ behavior: "smooth", block: "start" });
    const round1 = (n) => Math.round(n * 10) / 10;
    const hist = askTurns.length > 8 ? askTurns.slice(0, 2).concat(askTurns.slice(-6)) : askTurns;
    const context = {
      question: q,
      mode: review ? "review" : void 0,
      report: lastReportText,
      // «Разбор бизнеса» обезличенно — номера вместо ников
      turns: hist.map((m) => ({ role: m.role, content: m.content })),
      uiLang,
      // Помесячно: постинг + СТРУКТУРА выручки (по типам) + концентрация (на скольких людях держится).
      // Без последних двух разрезов в кадре оставался только постинг — и разбор всегда сводился к «постить чаще».
      monthly: lastSeries.map((r) => ({
        m: monthLabel(r.key),
        posts: r.posts,
        media: round1(r.mediaPerPost),
        likes: r.likesTotal,
        likesMedia: r.mediaLikesTotal,
        likesBest: r.likesBest,
        likesTypical: r.likesTypical == null ? null : round1(r.likesTypical),
        subs: r.subs,
        rev: Math.round(r.revenue),
        revSub: Math.round(r.rev.subscription),
        revTip: Math.round(r.rev.tip),
        revBuy: Math.round(r.rev.media + r.rev.media_bundle),
        payers: r.payers,
        top1: Math.round(r.top1 * 100),
        top3: Math.round(r.top3 * 100),
        p80: r.p80,
        revNew: Math.round(r.revNew),
        revRepeat: Math.round(r.revRepeat)
      })),
      payers: lastPayers && { ...lastPayers, top: lastPayers.top.map(({ handle, ...x }) => x) },
      // обезличенно: номер вместо ника (handle — только странице)
      broadcasts: lastBroadcasts.map((b) => ({ date: bShortDate(b), reach: b.reach, open: b.open, sale: b.sale, rev: Math.round(b.revenue || 0) }))
    };
    chrome.runtime.sendMessage({ type: "DIAG_ASK", context }, (r) => {
      askBusy = false;
      if (typeof askAfter === "function") askAfter(r, typed, review);
      if (chrome.runtime.lastError) {
        out.textContent = t("diag.ask.error", uiLang);
        return;
      }
      if (r && r.success && r.text) {
        askDone(r, q, label);
        out.textContent = "";
        out.style.display = "none";
        askNext();
      } else if (r && r.subscriptionExpired) out.textContent = t("panel.status.subscriptionExpired", uiLang);
      else if (r && r.quotaExhausted) out.textContent = t("panel.status.quotaExhausted", uiLang);
      else if (r && r.busy) out.textContent = t("diag.ask.busy", uiLang);
      else out.textContent = t("diag.ask.error", uiLang);
    });
  };
  askRun = run;
  const aiBtn = document.getElementById("rep-ai-btn");
  if (aiBtn) aiBtn.addEventListener("click", () => run("review"));
  const cp = document.getElementById("ask-copy"), sv = document.getElementById("ask-save");
  if (cp) cp.addEventListener("click", () => askCopy(cp));
  if (sv) sv.addEventListener("click", askSave);
  btn.addEventListener("click", () => run());
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      run();
    }
  });
}
