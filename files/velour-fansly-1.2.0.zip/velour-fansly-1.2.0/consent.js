self.FaiConsent = (() => {
  "use strict";
  const REV = 2;
  const Z = 2147483646;
  const LANGS = [
    ["ru", "\u{1F1F7}\u{1F1FA} \u0420\u0443\u0441\u0441\u043A\u0438\u0439"],
    ["en", "\u{1F1EC}\u{1F1E7} English"],
    ["es", "\u{1F1EA}\u{1F1F8} Espa\xF1ol"],
    ["de", "\u{1F1E9}\u{1F1EA} Deutsch"],
    ["fr", "\u{1F1EB}\u{1F1F7} Fran\xE7ais"],
    ["tr", "\u{1F1F9}\u{1F1F7} T\xFCrk\xE7e"]
  ];
  let shown = false, onDone = null;
  let scale = 1, cardEl = null;
  function applyScale() {
    if (!cardEl) return;
    cardEl.style.transform = scale !== 1 ? `scale(${scale})` : "";
    cardEl.style.maxHeight = scale !== 1 ? 90 / scale + "vh" : "90vh";
  }
  function setScale(k) {
    scale = k > 0 ? k : 1;
    applyScale();
  }
  const alive = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  };
  const T = (k, lang, fb) => {
    try {
      return (typeof t === "function" ? t(k, lang) : null) || fb;
    } catch (e) {
      return fb;
    }
  };
  const mk = (tag, css, txt) => {
    const e = document.createElement(tag);
    e.style.cssText = css;
    if (txt != null) e.textContent = txt;
    return e;
  };
  function guessLang() {
    const nav = (navigator.language || "ru").slice(0, 2).toLowerCase();
    return LANGS.some(([c]) => c === nav) ? nav : "en";
  }
  function paint(lang0) {
    let lang = lang0;
    const dim = mk("div", `position:fixed;inset:0;z-index:${Z};background:rgba(6,6,12,.93);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif`);
    dim.id = "fai-consent";
    const card = mk("div", "width:min(460px,92vw);max-height:90vh;overflow:auto;background:#12121f;border:2px solid #e91e8c;border-radius:16px;padding:20px 22px;color:#f0f0f0;box-shadow:0 12px 48px rgba(0,0,0,.6)");
    const title = mk("div", "font-size:17px;font-weight:800;color:#f3a3cf;margin-bottom:12px;text-align:center", T("consent.title", lang, "\u041F\u0430\u0440\u0430 \u0441\u043B\u043E\u0432, \u043F\u0440\u0435\u0436\u0434\u0435 \u0447\u0435\u043C \u043D\u0430\u0447\u0430\u0442\u044C"));
    const langRow = mk("div", "display:flex;align-items:center;gap:8px;margin-bottom:14px");
    const langLbl = mk("span", "font-size:12px;color:#8a8aa5;flex-shrink:0", T("consent.lang", lang, "\u042F\u0437\u044B\u043A \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430"));
    const sel = document.createElement("select");
    sel.style.cssText = "flex:1;background:#0d0d1e;border:1px solid #2e2e50;border-radius:8px;padding:7px 10px;color:#e0e0e0;font-size:13px;font-family:inherit";
    for (const [code, label] of LANGS) {
      const o = document.createElement("option");
      o.value = code;
      o.textContent = label;
      sel.appendChild(o);
    }
    sel.value = lang;
    langRow.append(langLbl, sel);
    const body = mk("div", "font-size:13px;line-height:1.6;color:#e6e6f0;white-space:pre-line", T("consent.body", lang, ""));
    const ok = mk("button", "width:100%;margin-top:16px;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit", T("consent.ok", lang, "\u041F\u043E\u043D\u044F\u0442\u043D\u043E, \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C"));
    const no = mk("button", "width:100%;margin-top:8px;background:none;color:#8a8aa5;border:none;padding:8px;font-size:12px;cursor:pointer;text-decoration:underline;font-family:inherit", T("consent.decline", lang, "\u041D\u0435 \u0441\u0435\u0439\u0447\u0430\u0441"));
    sel.addEventListener("change", () => {
      lang = sel.value;
      title.textContent = T("consent.title", lang, title.textContent);
      langLbl.textContent = T("consent.lang", lang, langLbl.textContent);
      body.textContent = T("consent.body", lang, body.textContent);
      ok.textContent = T("consent.ok", lang, ok.textContent);
      no.textContent = T("consent.decline", lang, no.textContent);
    });
    no.addEventListener("click", () => {
      try {
        chrome.runtime.sendMessage(
          { type: "SAVE_SETTINGS", settings: { masterEnabled: false, privacyDeclinedAt: Date.now() } },
          () => void chrome.runtime.lastError
        );
      } catch (e) {
      }
      dim.remove();
      shown = false;
      onDone = null;
    });
    ok.addEventListener("click", () => {
      try {
        chrome.runtime.sendMessage({
          type: "SAVE_SETTINGS",
          settings: { privacyConsentAt: Date.now(), privacyConsentRev: REV, interfaceLanguage: lang, nativeLanguage: lang }
        }, () => void chrome.runtime.lastError);
      } catch (e) {
      }
      dim.remove();
      try {
        if (typeof applyI18n === "function") applyI18n(document, lang);
      } catch (e) {
      }
      const cb = onDone;
      onDone = null;
      if (cb) {
        try {
          cb(lang);
        } catch (e) {
        }
      }
    });
    card.append(title, langRow, body, ok, no);
    dim.appendChild(card);
    cardEl = card;
    applyScale();
    document.body.appendChild(dim);
  }
  function ask(cb) {
    if (shown || document.getElementById("fai-consent") || !alive()) return;
    shown = true;
    chrome.storage.local.get("fansly_ai_settings", (d) => {
      const s = d && d.fansly_ai_settings || {};
      if (s.privacyConsentAt && (s.privacyConsentRev | 0) >= REV) return;
      onDone = cb || null;
      paint(s.interfaceLanguage || guessLang());
    });
  }
  const given = () => new Promise((r) => {
    if (!alive()) return r(true);
    chrome.storage.local.get("fansly_ai_settings", (d) => {
      const s = d && d.fansly_ai_settings || {};
      r(!!(s.privacyConsentAt && (s.privacyConsentRev | 0) >= REV));
    });
  });
  return { ask, given, REV, setScale };
})();
