(function() {
  "use strict";
  let q, qa, selStr, PLAT;
  function init(deps) {
    const d = deps || {};
    const missing = ["sel", "plat"].filter((k) => d[k] == null);
    if (missing.length) console.warn("[FanslyAI] Parsers.init: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439:", missing.join(", "));
    ({ q, qa, selStr } = d.sel || {});
    PLAT = d.plat;
  }
  function hashString(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (h << 5) - h + str.charCodeAt(i);
      h |= 0;
    }
    return Math.abs(h).toString(16);
  }
  function parseFanslyTs(text) {
    if (!text) return null;
    text = text.trim();
    if (/^today\b/i.test(text)) {
      const d2 = /* @__PURE__ */ new Date();
      d2.setHours(0, 0, 0, 0);
      return d2.getTime();
    }
    if (/^yesterday\b/i.test(text)) {
      const d2 = /* @__PURE__ */ new Date();
      d2.setHours(0, 0, 0, 0);
      return d2.getTime() - 864e5;
    }
    const rel = text.match(/^(\d+)\s*([smhd])$/i);
    if (rel) return Date.now() - parseInt(rel[1], 10) * { s: 1e3, m: 6e4, h: 36e5, d: 864e5 }[rel[2].toLowerCase()];
    if (!/[A-Za-z]{3}\s+\d/.test(text)) return null;
    const p = Date.parse(text);
    if (isNaN(p)) return null;
    const d = new Date(p);
    if (!/\d{4}/.test(text)) {
      const now = /* @__PURE__ */ new Date();
      d.setFullYear(now.getFullYear());
      if (d.getTime() > now.getTime() + 864e5) d.setFullYear(now.getFullYear() - 1);
    }
    return d.getTime();
  }
  function bodyMediaEl(node) {
    return [...qa("media", node)].find((el) => !el.closest(".message-reply") && !el.closest("app-account-avatar")) || null;
  }
  function bodyMediaId(node) {
    const el = [...node.querySelectorAll("app-media[data-media-id]")].find((m) => !m.classList.contains("preview") && !m.classList.contains("album-cover-media") && !m.classList.contains("avatar") && !m.closest(".message-reply") && !m.closest("app-account-avatar") && !(m.parentElement && m.parentElement.closest("app-media")));
    return el ? el.getAttribute("data-media-id") : null;
  }
  function detectMediaType(node, opts = {}) {
    const skipReply = !opts.includeReply;
    const has = (sel) => [...node.querySelectorAll(sel)].some((el) => !el.closest("app-account-avatar") && (!skipReply || !el.closest(".message-reply")));
    if (/viaTenor/i.test(node.textContent || "") || /tenor\.com/i.test(node.innerHTML || "")) return "gif";
    if (has(".blur-overlay")) return "blurred";
    if (has("audio, .audio-wrapper, .fa-waveform-lines")) return "audio";
    if (has("app-account-media-bundle")) return "bundle";
    if (has("video")) return "video";
    if (has("img, .image-placeholder-wrapper")) return "photo";
    return "media";
  }
  function detectMediaLocked(node) {
    if (bodyHas(node, "lockedGate")) return true;
    const t = node.textContent || "";
    return /\$\s?\d|\bunlock for\b|\bbuy to (unlock|view)\b|купить за|разблокировать за/i.test(t);
  }
  function detectPaidState(node) {
    const stack = [...node.querySelectorAll(".purchased-content")].find((s) => !s.closest(".message-reply"));
    if (!stack) return null;
    const tip = stack.textContent || "";
    if (/not\s+yet\s+purchased/i.test(tip)) return "unpaid";
    if (/has\s+purchased/i.test(tip)) return "paid";
    if (q("paidUnbought", stack)) return "unpaid";
    if (!q("paidBadge", stack)) return bodyHas(node, "lockedGate") ? null : "free";
    return null;
  }
  function bodyHas(node, key) {
    try {
      return [...node.querySelectorAll(selStr(key))].some((el) => !el.closest(".message-reply"));
    } catch (e) {
      return false;
    }
  }
  function cleanContactName(raw) {
    if (!raw) return raw;
    let name = raw.replace(/\s+/g, " ").trim();
    name = name.replace(/\s*(Edit User Notes|Add to List|Block User|Report User|Unsubscribe|Manage Subscription).*$/i, "").trim();
    name = name.replace(/\s*\b(active now|last seen|online|offline)\b.*$/i, "").replace(/\s*(был[а(]|была? в сети|в сети|онлайн|не в сети|была? недавно).*$/i, "").replace(/\s*\d+\s*(мин|час|сек|дн|min|h|hour|sec|day).*назад.*$/i, "").replace(/\s*\|\s*/g, " ").replace(/\s+Gallery$/i, "").replace(/\s+/g, " ").trim();
    return name;
  }
  self.Parsers = { init, hashString, parseFanslyTs, bodyMediaEl, bodyMediaId, detectMediaType, detectMediaLocked, detectPaidState, cleanContactName };
})();
