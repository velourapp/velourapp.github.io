(function() {
  const ORIGIN = "https://fansly.com";
  const KEY = "fansly_page_overrides";
  const DEFAULT = {
    subs: { url: "/creator/subscribers", paths: ["/creator/subscribers"] },
    vault: { url: "/creator/vault", paths: ["/creator/vault"] },
    earnings: { url: "/creator/wallet/history", paths: ["/creator/wallet", "/creator/earnings"] },
    // с 19.10 кошелёк — /creator/wallet/history; старый /creator/earnings/wallet с 20.10 ведёт на выплаты (/creator/wallet/payouts, истории там нет) — фон открывает историю напрямую
    broadcast: { url: "/creator/chat", paths: ["/creator/chat"] },
    notifications: { url: "/notifications", paths: ["/notifications"] },
    posts: { url: "/{handle}/posts", paths: ["/*/posts", "/posts"] }
    // личная лента /<ник>/posts и стены /posts/wall/*
  };
  const KEYS = Object.keys(DEFAULT);
  const SEG = /^[A-Za-z0-9_.~-]+$/;
  const okSeg = (s) => SEG.test(s) && !/^\.+$/.test(s);
  const MAX_LEN = 120, MAX_PATHS = 6;
  let ovr = null;
  const segs = (p) => String(p || "").split("?")[0].split("#")[0].split("/").filter(Boolean);
  function patternMatch(pattern, path) {
    const ps = segs(pattern), xs = segs(path);
    if (!ps.length || xs.length < ps.length) return false;
    for (let i = 0; i < ps.length; i++) if (ps[i] !== "*" && ps[i] !== xs[i]) return false;
    return true;
  }
  function pageOf(key) {
    const d = DEFAULT[key];
    if (!d) return null;
    const o = ovr && ovr[key];
    return o ? { url: o.url || d.url, paths: o.paths || d.paths } : d;
  }
  function urlOf(key, vars) {
    const p = pageOf(key);
    if (!p) return null;
    let u = p.url;
    if (u.includes("{handle}")) {
      const h = vars && vars.handle;
      if (!h) return null;
      u = u.split("{handle}").join(encodeURIComponent(h));
    }
    return ORIGIN + u;
  }
  function at(key, path) {
    const p = pageOf(key);
    return !!p && p.paths.some((x) => patternMatch(x, path));
  }
  function keyAt(path) {
    for (const k of KEYS) if (at(k, path)) return k;
    return null;
  }
  function validUrl(u) {
    if (typeof u !== "string" || u.length > MAX_LEN || u[0] !== "/") return false;
    const s = segs(u);
    return s.length > 0 && u.split("/").slice(1).every((x) => x === "" || x === "{handle}" || okSeg(x)) && !u.includes("//");
  }
  function validPattern(p) {
    if (typeof p !== "string" || p.length > MAX_LEN || p[0] !== "/" || p.includes("//") || /[?#]/.test(p)) return false;
    const s = segs(p);
    return s.length > 0 && s.every((x) => x === "*" || okSeg(x)) && s.some((x) => x !== "*");
  }
  function valid(raw) {
    const pages = raw && typeof raw === "object" && !Array.isArray(raw) ? raw.pages : null;
    const sec = pages && typeof pages === "object" && !Array.isArray(pages) ? pages.fansly : null;
    if (!sec || typeof sec !== "object" || Array.isArray(sec)) return null;
    const out = {};
    for (const k of KEYS) {
      const v = sec[k];
      if (!v || typeof v !== "object" || Array.isArray(v)) continue;
      const e = {};
      if (validUrl(v.url)) e.url = v.url;
      if (Array.isArray(v.paths)) {
        const list = v.paths.filter(validPattern).slice(0, MAX_PATHS);
        if (list.length) e.paths = list;
      }
      if (e.url || e.paths) out[k] = e;
    }
    return Object.keys(out).length ? out : null;
  }
  function setOverrides(o) {
    ovr = o ? valid({ pages: { fansly: o } }) : null;
  }
  const ready = new Promise((resolve) => {
    try {
      chrome.storage.local.get(KEY, (d) => {
        setOverrides(d && d[KEY]);
        resolve();
      });
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area === "local" && ch[KEY]) setOverrides(ch[KEY].newValue);
      });
    } catch (e) {
      resolve();
    }
  });
  globalThis.ScanPages = { ORIGIN, KEY, DEFAULT, KEYS, ready, valid, setOverrides, pageOf, urlOf, at, keyAt, patternMatch };
})();
