(function() {
  const BUILD = true ? "full" : "full";
  function initNav() {
    try {
      FaiConsent.ask((lang) => {
        try {
          applyI18n(document, lang);
        } catch (e) {
        }
      });
    } catch (e) {
    }
    const page = location.pathname.split("/").pop() || "dashboard.html";
    document.querySelectorAll(".pagenav .nav-in").forEach((a) => {
      const href = a.getAttribute("href");
      if (BUILD === "store" && href !== "dashboard.html") {
        a.remove();
        return;
      }
      if (href === page) a.classList.add("active");
    });
    const posts = document.getElementById("nav-posts");
    if (!posts) return;
    try {
      chrome.storage.local.get("fansly_creator_handle", (d) => {
        const h = d && d.fansly_creator_handle;
        if (h) posts.href = "https://fansly.com/" + encodeURIComponent(h) + "/posts";
        else posts.style.display = "none";
      });
    } catch (e) {
      posts.style.display = "none";
    }
  }
  const STEP_KEY = { subs: "collect.step.subs", vault: "collect.step.vault", posts: "collect.step.posts", earnings: "collect.step.earnings", notifhist: "collect.step.notifhist" };
  function showAborted(info, lang) {
    if (document.getElementById("fai-collect-aborted")) return;
    const nav = document.querySelector(".pagenav");
    if (!nav) return;
    const T = (k, v) => {
      try {
        return t(k, lang, v);
      } catch (e) {
        return "";
      }
    };
    const step = T(STEP_KEY[info.step] || "") || "";
    const bar = document.createElement("div");
    bar.id = "fai-collect-aborted";
    bar.style.cssText = "display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:rgba(240,163,94,.12);border:1px solid rgba(240,163,94,.4);color:#f0a35e;border-radius:10px;padding:10px 13px;margin:12px 0;font-size:13px;line-height:1.45";
    const txt = document.createElement("span");
    txt.style.flex = "1";
    txt.textContent = info.reason === "auth" ? step ? T("collect.auth.step", { step }) : T("collect.auth") : info.reason === "failed" && step ? T("collect.failed.step", { step }) : info.reason === "stopped" && step ? T("collect.stopped.step", { step }) : step ? T("collect.aborted.step", { step }) : T("collect.aborted");
    const go = document.createElement("button");
    go.style.cssText = "background:#e91e8c;color:#fff;border:none;border-radius:8px;padding:7px 13px;font-size:12px;cursor:pointer;font-family:inherit";
    go.textContent = T("collect.resume");
    go.addEventListener("click", () => {
      go.disabled = true;
      chrome.runtime.sendMessage({ type: "RESUME_FULL_COLLECT", from: info.step || "subs" }, () => void chrome.runtime.lastError);
      bar.remove();
    });
    const hide = document.createElement("button");
    hide.style.cssText = "background:none;border:none;color:#8a8aa5;font-size:12px;cursor:pointer;text-decoration:underline;font-family:inherit";
    hide.textContent = T("collect.aborted.hide");
    hide.addEventListener("click", () => {
      chrome.storage.local.set({ fansly_collect_aborted: Object.assign({}, info, { hidden: true }) });
      bar.remove();
    });
    bar.append(txt, go, hide);
    nav.insertAdjacentElement("afterend", bar);
  }
  function checkAborted() {
    try {
      chrome.storage.local.get(["fansly_collect_aborted", "fansly_ai_settings"], (d) => {
        const info = d && d.fansly_collect_aborted;
        if (!info || info.hidden) return;
        const lang = d.fansly_ai_settings && d.fansly_ai_settings.interfaceLanguage || "ru";
        showAborted(info, lang);
      });
    } catch (e) {
    }
  }
  function showLayout(all, off, lang) {
    const old = document.getElementById("fai-layout-miss");
    if (old) old.remove();
    all = all || {};
    off = off || {};
    const offAreas = Object.keys(off).filter((a) => off[a] && !off[a].hidden);
    const areas = Object.keys(all).filter((a) => all[a] && !all[a].hidden && !off[a]);
    const nav = document.querySelector(".pagenav");
    if (!areas.length && !offAreas.length || !nav) return;
    const T = (k, v) => {
      try {
        return t(k, lang, v);
      } catch (e) {
        return "";
      }
    };
    const since = (at) => {
      const d = new Date(at || Date.now());
      return d.toLocaleString(lang, (/* @__PURE__ */ new Date()).toDateString() === d.toDateString() ? { hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    };
    const bar = document.createElement("div");
    bar.id = "fai-layout-miss";
    bar.style.cssText = "display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:rgba(240,163,94,.12);border:1px solid rgba(240,163,94,.4);color:#f0a35e;border-radius:10px;padding:10px 13px;margin:12px 0;font-size:13px;line-height:1.45";
    const txt = document.createElement("div");
    txt.style.flex = "1";
    for (const a of offAreas) {
      const line = document.createElement("div");
      line.textContent = T(off[a].below === "*" ? "scanoff.banner" : "scanoff.banner.old", { page: T("layout.page." + a) });
      txt.appendChild(line);
    }
    for (const a of areas) {
      const line = document.createElement("div");
      line.textContent = T("layout.miss.banner", { page: T("layout.page." + a), what: T("layout.what." + a), since: since(all[a].at) });
      txt.appendChild(line);
    }
    const hide = document.createElement("button");
    hide.style.cssText = "background:none;border:none;color:#8a8aa5;font-size:12px;cursor:pointer;text-decoration:underline;font-family:inherit";
    hide.textContent = T("layout.miss.hide");
    hide.addEventListener("click", () => {
      const hid = (src) => {
        const next = {};
        for (const a in src) next[a] = Object.assign({}, src[a], { hidden: true });
        return next;
      };
      const put = {};
      if (Object.keys(all).length) put.fansly_layout_miss = hid(all);
      if (Object.keys(off).length) put.fansly_scan_off = hid(off);
      chrome.storage.local.set(put);
      bar.remove();
    });
    bar.append(txt, hide);
    (document.getElementById("fai-collect-aborted") || nav).insertAdjacentElement("afterend", bar);
  }
  function checkLayout() {
    try {
      chrome.storage.local.get(["fansly_layout_miss", "fansly_scan_off", "fansly_ai_settings"], (d) => {
        const lang = d && d.fansly_ai_settings && d.fansly_ai_settings.interfaceLanguage || "ru";
        showLayout(d && d.fansly_layout_miss, d && d.fansly_scan_off, lang);
      });
    } catch (e) {
    }
  }
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== "local") return;
      if (ch.fansly_layout_miss || ch.fansly_scan_off) checkLayout();
      if (!ch.fansly_collect_aborted) return;
      const old = document.getElementById("fai-collect-aborted");
      if (old) old.remove();
      if (ch.fansly_collect_aborted.newValue) checkAborted();
    });
  } catch (e) {
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => {
    initNav();
    checkAborted();
    checkLayout();
  });
  else {
    initNav();
    checkAborted();
    checkLayout();
  }
})();
