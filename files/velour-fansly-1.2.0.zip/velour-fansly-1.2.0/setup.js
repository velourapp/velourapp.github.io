const BASE_STEPS = ["step-welcome", "step-profile", "step-features", "step-scans", "step-interval", "step-tg-optin"];
const TG_STEPS = ["step-tg-bot", "step-tg-group", "step-tg-verify"];
let idx = 0;
let settings = {};
let _proxyBase = "https://api.velourff.com";
let tgWanted = false;
let tgToken = "";
let tgBotUsername = "";
let tgChatId = "";
let tgVerified = false;
let uiLang = "ru";
const T = (key, vars) => t(key, uiLang, vars);
function $(id) {
  return document.getElementById(id);
}
function sendMsg(msg) {
  return new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r || { success: false, error: "no response" })));
}
function steps() {
  return tgWanted ? [...BASE_STEPS, ...TG_STEPS, "step-privacy", "step-finish"] : [...BASE_STEPS, "step-privacy", "step-finish"];
}
const STEP_NAME = {
  "step-welcome": "setup.stepName.welcome",
  "step-profile": "setup.stepName.profile",
  "step-features": "setup.stepName.features",
  "step-scans": "setup.stepName.scans",
  "step-interval": "setup.stepName.interval",
  "step-tg-optin": "setup.stepName.tgOptin",
  "step-tg-bot": "setup.stepName.tgBot",
  "step-tg-group": "setup.stepName.tgGroup",
  "step-tg-verify": "setup.stepName.tgVerify",
  "step-privacy": "setup.stepName.privacy",
  "step-finish": "setup.stepName.finish"
};
function renderProgress() {
  const p = $("progress");
  const list = steps();
  p.innerHTML = "";
  list.forEach((_, i) => {
    const d = document.createElement("div");
    d.className = "dot" + (i === idx ? " active" : i < idx ? " done" : "");
    p.appendChild(d);
  });
  const lbl = $("progressLabel");
  if (lbl) {
    lbl.textContent = "";
    lbl.appendChild(document.createTextNode(T("setup.stepOf", { n: idx + 1, total: list.length })));
    const b = document.createElement("b");
    b.textContent = T(STEP_NAME[list[idx]] || "");
    lbl.appendChild(b);
  }
}
function updateNav() {
  const list = steps();
  const cur = list[idx];
  $("backBtn").style.visibility = idx === 0 ? "hidden" : "visible";
  const last = idx === list.length - 1;
  $("nextBtn").textContent = last ? T("setup.btn.done") : T("setup.btn.next");
  $("nextBtn").disabled = cur === "step-tg-verify" && !tgVerified || cur === "step-scans" && !document.querySelector('input[name="scanmode"]:checked');
}
function showStep() {
  const list = steps();
  const cur = list[idx];
  [
    "step-welcome",
    "step-profile",
    "step-features",
    "step-scans",
    "step-interval",
    "step-tg-optin",
    "step-tg-bot",
    "step-tg-group",
    "step-tg-verify",
    "step-privacy",
    "step-finish"
  ].forEach((id) => {
    const el = $(id);
    if (el) el.classList.toggle("active", id === cur);
  });
  if (cur === "step-tg-group") $("tg-botname").textContent = tgBotUsername ? "@" + tgBotUsername : "";
  setTgSetupActive(TG_STEPS.includes(cur));
  renderProgress();
  updateNav();
  window.scrollTo({ top: 0, behavior: "smooth" });
}
let _tgSetupTimer = null;
function setTgSetupActive(on) {
  try {
    sendMsg({ type: "TG_SETUP_ACTIVE", on });
  } catch (e) {
  }
  clearInterval(_tgSetupTimer);
  _tgSetupTimer = null;
  if (on) _tgSetupTimer = setInterval(() => {
    try {
      sendMsg({ type: "TG_SETUP_ACTIVE", on: true });
    } catch (e) {
    }
  }, 5 * 60 * 1e3);
}
window.addEventListener("beforeunload", () => {
  try {
    chrome.runtime.sendMessage({ type: "TG_SETUP_ACTIVE", on: false });
  } catch (e) {
  }
});
function loadSettings(cb) {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (r) => {
    settings = r && r.result || {};
    const lang = settings.interfaceLanguage || "ru";
    uiLang = lang;
    $("langSel").value = lang;
    applyI18n(document, lang);
    if (settings.nativeLanguage) $("nativeLanguage").value = settings.nativeLanguage;
    $("licenseKey").value = settings.licenseKey || "";
    _proxyBase = (settings.proxyBaseUrl || "https://api.velourff.com").replace(/\/+$/, "");
    $("f-dossier").checked = settings.collectDossier !== false;
    $("f-crm").checked = settings.crmEnabled !== false;
    $("f-coach").checked = settings.coachEnabled !== false;
    if (settings.setupCompleted) {
      const want = settings.scheduledScanEnabled === true ? "auto" : "manual";
      const r2 = document.querySelector('input[name="scanmode"][value="' + want + '"]');
      if (r2) r2.checked = true;
    }
    $("f-notif").checked = settings.notificationsEnabled === true;
    const h = String(Math.max(1, parseInt(settings.scheduledScanHours, 10) || 1));
    const radio = document.querySelector(`input[name="interval"][value="${h}"]`) || document.querySelector('input[name="interval"][value="1"]');
    if (radio) radio.checked = true;
    if (settings.telegramBotToken) {
      tgToken = settings.telegramBotToken;
      $("tg-token").value = tgToken;
    }
    if (cb) cb();
  });
}
async function checkLicense() {
  const key = $("licenseKey").value.trim();
  const base = _proxyBase;
  const st = $("licenseStatus");
  if (!key) {
    st.className = "status err";
    st.textContent = T("setup.st.needKey");
    return;
  }
  st.className = "status";
  st.textContent = T("setup.st.checking");
  try {
    const resp = await fetch(base + "/health", { method: "GET" });
    if (!resp.ok) {
      st.className = "status err";
      st.textContent = T("setup.st.serverCode", { code: resp.status });
      return;
    }
  } catch (e) {
    st.className = "status err";
    st.textContent = T("setup.st.noServer");
    return;
  }
  try {
    const r = await fetch(base + "/v1/translate", {
      method: "POST",
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ text: "ok", targetLang: "en" })
    });
    if (r.ok) {
      st.className = "status ok";
      st.textContent = T("setup.st.keyOk");
      return;
    }
    if (r.status === 401 || r.status === 403) {
      st.className = "status err";
      st.textContent = T("setup.st.keyBad");
      return;
    }
    st.className = "status err";
    st.textContent = T("setup.st.keyCheckFailCode", { code: r.status });
  } catch (e) {
    st.className = "status err";
    st.textContent = T("setup.st.keyCheckFailNet");
  }
}
async function checkBot() {
  tgToken = $("tg-token").value.trim();
  const st = $("tg-bot-status");
  if (!tgToken) {
    st.className = "status err";
    st.textContent = T("setup.st.needToken");
    return;
  }
  st.className = "status";
  st.textContent = T("setup.st.checking");
  const r = await sendMsg({ type: "TG_VALIDATE_BOT", token: tgToken });
  if (r.success) {
    tgBotUsername = r.username || "";
    st.className = "status ok";
    st.textContent = T("setup.st.botOk", { name: tgBotUsername });
  } else {
    st.className = "status err";
    st.textContent = T("setup.st.tokenBad", { err: r.error || T("setup.err.generic") });
  }
}
const CHK_KEY = {
  admin: "setup.chk.admin",
  topics: "setup.chk.topics",
  forum: "setup.chk.forum",
  private: "setup.chk.private"
};
const BLOCKER_KEY = {
  public: "setup.blocker.public",
  no_forum: "setup.blocker.noForum",
  not_admin: "setup.blocker.notAdmin",
  no_manage_topics: "setup.blocker.noManageTopics"
};
function renderChecklist(rep) {
  const box = $("tg-checklist");
  if (!rep || !rep.success) {
    box.innerHTML = rep && rep.needChat ? `<div class="chk"><div class="blocker-msg">${T("setup.chk.needChat")}</div></div>` : "";
    return;
  }
  const row = (ok, label) => `<div class="${ok ? "ok" : "bad"}">${ok ? "\u2705" : "\u274C"} ${label}</div>`;
  let html = '<div class="chk">';
  html += row(rep.isAdmin, T(CHK_KEY.admin));
  html += row(rep.canManageTopics, T(CHK_KEY.topics));
  html += row(rep.isForum, T(CHK_KEY.forum));
  html += row(!rep.isPublic, T(CHK_KEY.private));
  if ((rep.warnings || []).includes("no_invite")) html += `<div class="warn">${T("setup.chk.noInvite")}</div>`;
  (rep.problems || []).forEach((p) => {
    if (BLOCKER_KEY[p]) html += `<div class="blocker-msg">${T(BLOCKER_KEY[p])}</div>`;
  });
  html += "</div>";
  box.innerHTML = html;
}
async function runVerify() {
  tgToken = $("tg-token").value.trim();
  const btn = $("tg-verify-btn");
  const st = $("tg-verify-status");
  if (!tgToken) {
    st.className = "status err";
    st.textContent = T("setup.st.tokenFirst");
    return;
  }
  btn.disabled = true;
  st.className = "status";
  st.textContent = T("setup.st.verifying");
  const r = await sendMsg({ type: "TG_VERIFY_SETUP", token: tgToken });
  btn.disabled = false;
  if (!r.success) {
    renderChecklist(r);
    st.className = "status err";
    st.textContent = r.needChat ? T("setup.st.noGroup") : T("setup.st.verifyFail", { err: r.error || T("setup.err.generic") });
    tgVerified = false;
    updateNav();
    return;
  }
  renderChecklist(r);
  if ((r.problems || []).length) {
    st.className = "status err";
    st.textContent = T("setup.st.fixRed");
    tgVerified = false;
    updateNav();
    return;
  }
  st.textContent = T("setup.st.topicsMaking");
  const topics = await sendMsg({ type: "TG_SETUP_TOPICS", token: tgToken, chatId: r.chatId, wizard: true });
  if (!topics.success) {
    st.className = "status err";
    st.textContent = T("setup.st.topicsFail", { err: topics.error || "" });
    tgVerified = false;
    updateNav();
    return;
  }
  tgChatId = r.chatId;
  $("tg-chatid").value = tgChatId;
  await sendMsg({ type: "SAVE_SETTINGS", settings: { telegramEnabled: true, telegramBotToken: tgToken, telegramChatId: tgChatId, tgTopics: true } });
  setTgSetupActive(false);
  tgVerified = true;
  st.className = "status ok";
  st.textContent = T("setup.st.tgDone");
  updateNav();
}
function collectDraft() {
  const draft = {};
  const key = $("licenseKey").value.trim();
  if (key) {
    draft.licenseKey = key;
    draft.useProxy = true;
  }
  draft.collectDossier = $("f-dossier").checked;
  draft.crmEnabled = $("f-crm").checked;
  draft.coachEnabled = $("f-coach").checked;
  const sm = document.querySelector('input[name="scanmode"]:checked');
  draft.scheduledScanEnabled = !!(sm && sm.value === "auto");
  draft.notificationsEnabled = $("f-notif").checked;
  const iv = document.querySelector('input[name="interval"]:checked');
  draft.scheduledScanHours = iv ? parseInt(iv.value, 10) : 1;
  draft.setupCompleted = true;
  return draft;
}
function finish() {
  const draft = collectDraft();
  const st = $("finishStatus");
  st.className = "status ok";
  st.textContent = T("setup.st.saving");
  chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: draft }, () => {
    st.textContent = T("setup.st.saved");
    $("nextBtn").disabled = true;
    if ($("f-firstScan").checked) {
      chrome.runtime.sendMessage({ type: "RUN_SCHEDULED_SCAN_NOW" });
      st.textContent = T("setup.st.savedScan");
    }
  });
}
function next() {
  const list = steps();
  const cur = list[idx];
  if (cur === "step-welcome") {
    const key = $("licenseKey").value.trim();
    if (key) chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: { licenseKey: key, useProxy: true } });
  }
  if (cur === "step-tg-bot") {
    tgToken = $("tg-token").value.trim();
    if (!tgToken) {
      const st = $("tg-bot-status");
      st.className = "status err";
      st.textContent = T("setup.st.needTokenNext");
      return;
    }
  }
  if (idx === list.length - 1) {
    finish();
    return;
  }
  idx++;
  showStep();
}
function back() {
  if (idx > 0) {
    idx--;
    showStep();
  }
}
document.addEventListener("DOMContentLoaded", () => {
  loadSettings(() => showStep());
  $("langSel").addEventListener("change", (e) => {
    const lang = e.target.value;
    settings.interfaceLanguage = lang;
    uiLang = lang;
    applyI18n(document, lang);
    updateNav();
    chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: { interfaceLanguage: lang } });
  });
  $("nativeLanguage").addEventListener("change", (e) => {
    settings.nativeLanguage = e.target.value;
    chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: { nativeLanguage: e.target.value } });
  });
  document.querySelectorAll('input[name="scanmode"]').forEach((r) => r.addEventListener("change", updateNav));
  $("nextBtn").addEventListener("click", next);
  $("backBtn").addEventListener("click", back);
  $("checkLicenseBtn").addEventListener("click", checkLicense);
  $("licenseKeyEye").addEventListener("click", () => {
    const inp = $("licenseKey");
    const btn = $("licenseKeyEye");
    const show = inp.type === "password";
    inp.type = show ? "text" : "password";
    btn.textContent = show ? T("setup.btn.keyHide") : T("setup.btn.keyShow");
    btn.title = show ? T("setup.btn.keyHide.title") : T("setup.btn.keyShow.title");
  });
  $("licenseBuyLink")?.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.sendMessage({ type: "OPEN_PRICING" });
  });
  $("ownKeysLink").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("options.html") }));
  $("openOnboardingBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") }));
  $("tg-optin").addEventListener("change", (e) => {
    tgWanted = e.target.checked;
    renderProgress();
    updateNav();
  });
  $("tg-check-bot").addEventListener("click", checkBot);
  $("tg-verify-btn").addEventListener("click", runVerify);
});
