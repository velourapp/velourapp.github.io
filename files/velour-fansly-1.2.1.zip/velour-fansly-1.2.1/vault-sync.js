(function() {
  "use strict";
  let sendSafe, q, qa, qm, selStr, waitForElement, synthClick, waitVisible, startKeepAlive, stopKeepAlive, reportBug, bugCrumb, getSettingsAsync, bugStackFrames, layout;
  const DEPS = ["send", "sel", "waitForElement", "synthClick", "waitVisible", "keepAlive", "report", "crumb", "getSettings", "stack", "layout"];
  function init(deps) {
    const d = deps || {};
    const missing = DEPS.filter((k) => d[k] == null);
    if (missing.length) console.warn("[FanslyAI] VaultSync.init: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439:", missing.join(", "));
    sendSafe = d.send;
    ({ q, qa, qm, selStr } = d.sel || {});
    waitForElement = d.waitForElement;
    synthClick = d.synthClick;
    waitVisible = d.waitVisible;
    startKeepAlive = d.keepAlive && d.keepAlive.start;
    stopKeepAlive = d.keepAlive && d.keepAlive.stop;
    reportBug = d.report;
    bugCrumb = d.crumb;
    getSettingsAsync = d.getSettings;
    bugStackFrames = d.stack;
    layout = d.layout || { seen() {
    } };
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function layoutMissError(key) {
    const e = new Error("vault: Fansly, \u043F\u043E\u0445\u043E\u0436\u0435, \u043F\u0435\u0440\u0435\u0434\u0435\u043B\u0430\u043B \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u2014 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \xAB" + key + "\xBB");
    e.layoutMiss = { area: "vault", key };
    return e;
  }
  const subText = (el) => VaultCounts.clean(el && el.textContent);
  let uiLang = "ru";
  let onPhase = null;
  let phaseHold = 0, phaseOpen = false;
  async function phaseBegin(kind) {
    if (phaseOpen) return;
    phaseOpen = true;
    if (onPhase) await onPhase("begin", { kind });
  }
  function phaseEnd(zoom) {
    if (phaseHold > 0) return;
    phaseOpen = false;
    if (onPhase) onPhase("end", { zoom });
  }
  const VAULT = {
    MAX_PASSES: 1200,
    // страховка от бесконечного скролла (виртуальная лента vault высокая)
    BOTTOM_STREAK: 4,
    // столько проходов подряд «контейнер не сдвинулся» = дно ленты (надёжнее, чем «нет новых id»)
    STAGNANT_SAFETY: 30,
    // страховка: очень долго нет новых id (напр. неверный скроллер) → выходим
    // Качество тумб (Alex 2026-08-15): было 200px/0.5 — мы сами ужимали исходник (~360px в ленте) вдвое и жали
    // агрессивно → мыло в каталоге и мусор на вход автотегам (WD14 ресайзит к 448 и дорисовывала детали).
    // 512 — потолок: `scale = min(1, MAX/сторона)` НЕ апскейлит, так что реально сохраняем оригинал как есть.
    THUMB_MAX: 512,
    // сторона тумбы, px (потолок; меньше оригинала не растягиваем)
    THUMB_Q: 0.85,
    // качество jpeg
    // ПЕРЕНОС: зум вкладки под вуалью (был здесь как SCAN_ZOOM) остался в content.js — им пользуются ещё ранняя вуаль и скан постов.
    THUMB_WAIT: 5e3,
    // мс: ждём прогруз превью видимых тайлов перед захватом (при малом зуме их много разом)
    THUMB_WAIT_FIRST: 12e3,
    // мс: ПЕРВЫЙ пасс после входа в папку — весь экран blob-картинок грузится разом, 5с не хватало (свежие медиа оставались без превью, особенно при быстром инкременте)
    BLUR_LAP: 15,
    // блюр-детект фото: порог сырой дисперсии лапласиана (ниже = кандидат в блюр)
    BLUR_NORM: 8,
    // и порог нормализованной (спасает тёмные резкие). Блюр = обе НИЖЕ порогов (калибровано вручную 2026-08)
    // Кадры из видео (Alex 2026-08-19). Размер и качество — как у тумб: на вход модели идёт один масштаб.
    FRAME_CAP: 12,
    // потолок кадров на ролик (часовой ролик иначе съел бы весь бюджет разметки)
    FRAME_SEEK_MS: 6e3,
    // ждём готовности кадра после перемотки; не дождались — кадр ПРОПУСКАЕМ (чёрный хуже, чем никакой)
    FRAME_PLAYER_MS: 8e3,
    // ждём подъёма плеера после клика по кнопке
    FRAME_HASH_TOL: 5,
    // ближе этого по 64-битному хешу — кадр считаем повтором предыдущего (внутри ОДНОГО ролика)
    running: false,
    framesRunning: false,
    // своя занятость: VAULT.running защищает только syncVault
    stopRequested: false,
    // «⏹ Остановить» (шаг 4): ставит VaultSync.stop(); циклы смотрят на границе прохода и папки; start() сбрасывает на каждую операцию
    LOCK_PAUSE_MS: 15e3
    // на паузе (вкладка спрятана) метка блокировки освежается с этим шагом — втрое короче TTL, иначе её перебила бы другая вкладка (край шага 5, закрыт 28.09)
  };
  async function sendMeta(msg, tries = 3) {
    for (let i = 0; i < tries; i++) {
      const r = await sendSafe(msg);
      if (r && r.success) return r;
      if (i < tries - 1) await sleep(600 * (i + 1));
    }
    return null;
  }
  const VAULT_LOCK = "fansly_vault_lock", VAULT_LOCK_TTL = 45e3, VAULT_LOCK_SETTLE = 150;
  const VAULT_OWNER = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const vaultLockRead = () => new Promise((r) => chrome.storage.local.get(VAULT_LOCK, (d) => r(d && d[VAULT_LOCK] || null)));
  const vaultLockFresh = (l) => !!(l && l.at && Date.now() - l.at < VAULT_LOCK_TTL);
  async function vaultLockActive() {
    const l = await vaultLockRead();
    return vaultLockFresh(l) && l.owner !== VAULT_OWNER;
  }
  const vaultLockTouch = () => new Promise((r) => chrome.storage.local.set({ [VAULT_LOCK]: { at: Date.now(), owner: VAULT_OWNER } }, r));
  async function vaultLockClear() {
    const l = await vaultLockRead();
    if (l && l.owner && l.owner !== VAULT_OWNER && vaultLockFresh(l)) return false;
    await new Promise((r) => chrome.storage.local.remove(VAULT_LOCK, r));
    return true;
  }
  async function vaultLockAcquire(setStatus) {
    for (let round = 0; round < 3; round++) {
      if (await vaultLockActive()) {
        setStatus(t("panel.vault.lockWait", uiLang));
        for (let i = 0; i < 180 && await vaultLockActive(); i++) await sleep(1e3);
      }
      await vaultLockTouch();
      await sleep(VAULT_LOCK_SETTLE);
      const l = await vaultLockRead();
      if (!l || l.owner === VAULT_OWNER) return true;
    }
    return false;
  }
  async function vaultPausedWait() {
    await vaultLockTouch();
    const iv = setInterval(() => {
      vaultLockTouch().catch(() => {
      });
    }, VAULT.LOCK_PAUSE_MS);
    try {
      await waitVisible();
    } finally {
      clearInterval(iv);
    }
  }
  function vaultCleanText(el) {
    return (el.textContent || "").replace(/\s+/g, " ").trim();
  }
  function vaultDuration(tile) {
    const pt = q("vaultPlayTime", tile);
    if (!pt) return "";
    const prog = q("vaultProgress", pt);
    const raw = prog ? (pt.textContent || "").replace(prog.textContent || "", "") : pt.textContent || "";
    return raw.replace(/\s+/g, " ").trim();
  }
  function vaultCellMeta(tile) {
    let node = tile.parentElement;
    for (let i = 0; i < 6 && node; i++) {
      const fn = q("vaultFileName", node);
      const dt = q("vaultFileDate", node);
      if (fn || dt) return { filename: fn ? vaultCleanText(fn) : "", date: dt ? vaultCleanText(dt) : "" };
      node = node.parentElement;
    }
    return { filename: "", date: "" };
  }
  function vaultType(tile, filename) {
    if (q("vaultAudioMark", tile)) return "audio";
    const m = (filename || "").toLowerCase().match(/\.([a-z0-9]+)(?:\?|$)/);
    if (m) {
      if (/^(mp4|mov|m4v|webm|avi|mkv|ts|m3u8)$/.test(m[1])) return "video";
      if (/^(jpe?g|png|gif|webp|heic|heif|bmp)$/.test(m[1])) return "image";
    }
    return q("vaultVideoMark", tile) ? "video" : "image";
  }
  function vaultCaptureThumb(tile) {
    try {
      const img = q("vaultThumbImg", tile);
      if (!img || !img.complete) return null;
      const w = img.naturalWidth, h = img.naturalHeight;
      if (!w || !h) return null;
      const scale = Math.min(1, VAULT.THUMB_MAX / Math.max(w, h));
      const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
      const c = document.createElement("canvas");
      c.width = cw;
      c.height = ch;
      c.getContext("2d").drawImage(img, 0, 0, cw, ch);
      return c.toDataURL("image/jpeg", VAULT.THUMB_Q);
    } catch (e) {
      return null;
    }
  }
  function vaultDurSec(str) {
    const parts = String(str || "").trim().split(":").map((n) => parseInt(n, 10));
    if (!parts.length || parts.some((n) => !Number.isFinite(n))) return -1;
    return parts.reduce((a, n) => a * 60 + n, 0);
  }
  function framePlan(dur) {
    if (!(dur > 3)) return [];
    const end = Math.max(0, dur - 2);
    if (dur <= 40) return [end];
    const step = Math.max(dur <= 120 ? 30 : 60, end / VAULT.FRAME_CAP);
    const out = [];
    for (let t2 = step; t2 < end - step / 2; t2 += step) out.push(t2);
    out.push(end);
    return out;
  }
  function videoOnce(el, ev, ms) {
    return new Promise((res) => {
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        el.removeEventListener(ev, h);
        res(ok);
      };
      const h = () => finish(true);
      el.addEventListener(ev, h);
      const timer = setTimeout(() => finish(false), ms);
    });
  }
  function videoSeek(v, t2) {
    return new Promise((resolve) => {
      const target = Math.max(0, Math.min(t2, (v.duration || 0) - 0.05));
      let done = false, poll = null, timer = null;
      const good = () => !v.seeking && v.readyState >= 2 && Math.abs(v.currentTime - target) < 0.5;
      const finish = (ok) => {
        if (done) return;
        done = true;
        clearInterval(poll);
        clearTimeout(timer);
        v.removeEventListener("seeked", onSeeked);
        resolve(ok);
      };
      const onSeeked = () => {
        if (good()) finish(true);
      };
      v.addEventListener("seeked", onSeeked);
      poll = setInterval(() => {
        if (good()) finish(true);
      }, 200);
      timer = setTimeout(() => finish(false), VAULT.FRAME_SEEK_MS);
      try {
        v.currentTime = target;
      } catch (e) {
        finish(false);
      }
    });
  }
  function captureVideoFrame(v) {
    const w = v.videoWidth, h = v.videoHeight;
    if (!w || !h) return null;
    const scale = Math.min(1, VAULT.THUMB_MAX / Math.max(w, h));
    const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
    const c = document.createElement("canvas");
    c.width = cw;
    c.height = ch;
    c.getContext("2d").drawImage(v, 0, 0, cw, ch);
    return c.toDataURL("image/jpeg", VAULT.THUMB_Q);
  }
  let _fhCx = null;
  function fhContext() {
    if (!_fhCx) {
      const c = document.createElement("canvas");
      c.width = 8;
      c.height = 8;
      _fhCx = c.getContext("2d", { willReadFrequently: true });
    }
    return _fhCx;
  }
  function frameHash(v) {
    try {
      const cx = fhContext();
      cx.drawImage(v, 0, 0, 8, 8);
      const d = cx.getImageData(0, 0, 8, 8).data;
      const g = new Array(64);
      let sum = 0;
      for (let i = 0; i < 64; i++) {
        const l = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
        g[i] = l;
        sum += l;
      }
      const mean = sum / 64;
      let hi = 0, lo = 0;
      for (let i = 0; i < 32; i++) if (g[i] > mean) hi |= 1 << i;
      for (let i = 32; i < 64; i++) if (g[i] > mean) lo |= 1 << i - 32;
      return { hi: hi >>> 0, lo: lo >>> 0 };
    } catch (e) {
      return null;
    }
  }
  function framePop(x) {
    x = x - (x >>> 1 & 1431655765);
    x = (x & 858993459) + (x >>> 2 & 858993459);
    x = x + (x >>> 4) & 252645135;
    return x * 16843009 >>> 24;
  }
  const frameDist = (a, b) => framePop((a.hi ^ b.hi) >>> 0) + framePop((a.lo ^ b.lo) >>> 0);
  const frameHover = (el) => {
    const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    for (const type of ["pointerover", "mouseover", "pointerenter", "mouseenter", "pointermove", "mousemove"])
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
  };
  const frameClick = (el) => {
    const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
  };
  async function grabFramesForTile(tile, onStep) {
    frameHover(tile);
    await sleep(150);
    let play = q("vaultPlayBtn", tile);
    if (!play) {
      await sleep(400);
      play = q("vaultPlayBtn", tile);
    }
    if (play && play.closest(selStr("vaultPreviewPoster"))) play = null;
    if (!play) return { frames: [], reason: "no_player" };
    const mo = new MutationObserver(() => {
      const el = q("vaultVideoEl", tile);
      if (el) {
        el.muted = true;
        el.volume = 0;
      }
    });
    mo.observe(tile, { childList: true, subtree: true });
    try {
      frameHover(play);
      await sleep(120);
      frameClick(play);
      let v = null;
      for (let i = 0; i < Math.ceil(VAULT.FRAME_PLAYER_MS / 200); i++) {
        if (q("vaultModalClose")) {
          const x = q("vaultModalClose");
          if (x) x.click();
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          return { frames: [], reason: "modal" };
        }
        v = q("vaultVideoEl", tile);
        if (v && v.readyState >= 1 && v.duration > 0) break;
        await sleep(200);
      }
      if (!v || !(v.duration > 0)) return { frames: [], reason: "no_video" };
      v.muted = true;
      v.volume = 0;
      if (!v.paused) await videoOnce(v, "playing", 2e3);
      try {
        v.pause();
      } catch (e) {
      }
      const plan = framePlan(v.duration);
      if (!plan.length) return { frames: [], dur: v.duration, skipped: 0, reason: "short" };
      const frames = [], hashes = [];
      let skipped = 0;
      for (let i = 0; i < plan.length; i++) {
        if (!v.isConnected) break;
        if (onStep) onStep(i + 1, plan.length);
        if (!await videoSeek(v, plan[i])) {
          skipped++;
          continue;
        }
        let url;
        try {
          url = captureVideoFrame(v);
        } catch (e) {
          try {
            reportBug("frame_tainted", { err: e && e.name || "err" });
          } catch (_) {
          }
          return { frames, dur: v.duration, skipped, reason: "tainted" };
        }
        if (!url) {
          skipped++;
          continue;
        }
        const h = frameHash(v);
        if (h && hashes.some((p) => frameDist(p, h) <= VAULT.FRAME_HASH_TOL)) {
          skipped++;
          continue;
        }
        if (h) hashes.push(h);
        frames.push(url);
        await vaultLockTouch();
      }
      try {
        v.pause();
      } catch (e) {
      }
      return { frames, dur: v.duration, skipped, reason: "" };
    } finally {
      mo.disconnect();
    }
  }
  let _blurCv = null;
  function blurCanvas() {
    if (!_blurCv) _blurCv = document.createElement("canvas");
    return _blurCv;
  }
  function vaultBlurMetrics(tile) {
    try {
      const img = q("vaultThumbImg", tile);
      if (!img || !img.complete || !img.naturalWidth) return null;
      const S = 200, cv = blurCanvas();
      cv.width = S;
      cv.height = S;
      const cx = cv.getContext("2d", { willReadFrequently: true });
      cx.drawImage(img, 0, 0, S, S);
      const d = cx.getImageData(0, 0, S, S).data;
      const g = new Float32Array(S * S);
      let gs = 0, gs2 = 0;
      for (let i = 0; i < S * S; i++) {
        const v = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
        g[i] = v;
        gs += v;
        gs2 += v * v;
      }
      const grayVar = gs2 / (S * S) - (gs / (S * S)) ** 2;
      const b = new Float32Array(S * S);
      for (let y = 1; y < S - 1; y++) for (let x = 1; x < S - 1; x++) {
        const i = y * S + x;
        b[i] = (g[i - S - 1] + 2 * g[i - S] + g[i - S + 1] + 2 * g[i - 1] + 4 * g[i] + 2 * g[i + 1] + g[i + S - 1] + 2 * g[i + S] + g[i + S + 1]) / 16;
      }
      let sum = 0, sum2 = 0, n = 0;
      for (let y = 2; y < S - 2; y++) for (let x = 2; x < S - 2; x++) {
        const i = y * S + x;
        const L = b[i - S] + b[i - 1] + b[i + 1] + b[i + S] - 4 * b[i];
        sum += L;
        sum2 += L * L;
        n++;
      }
      const lap = sum2 / n - (sum / n) ** 2;
      return { lap: Math.round(lap * 10) / 10, norm: Math.round(1e3 * lap / (grayVar + 1) * 10) / 10 };
    } catch (e) {
      return null;
    }
  }
  async function vaultWaitThumbs(scroller, catalog, maxMs) {
    const t0 = Date.now();
    let jiggles = 0, sawTiles = false;
    const isAudio = (tile) => !!q("vaultAudioMark", tile);
    while (Date.now() - t0 < maxMs) {
      const tiles = vaultContentTiles();
      if (tiles.length) sawTiles = true;
      const pending = tiles.filter((tile) => {
        const id = tile.getAttribute("data-media-id");
        if (!id) return false;
        const e = catalog[id];
        if (e && e.thumb) return false;
        if (isAudio(tile)) return false;
        const r = tile.getBoundingClientRect();
        if (r.bottom <= 0 || r.top >= innerHeight || !r.height) return false;
        const img = q("vaultThumbImg", tile);
        return !img || !(img.complete && img.naturalWidth > 0);
      });
      if (!pending.length && (sawTiles || Date.now() - t0 > 1500)) return;
      if (scroller && Date.now() - t0 > 500 && (Date.now() - t0) / 1200 > jiggles) {
        jiggles++;
        try {
          const top = scroller.scrollTop;
          scroller.scrollTop = Math.max(0, top - 40);
          await sleep(90);
          scroller.scrollTop = top;
        } catch (e) {
        }
      }
      await sleep(200);
    }
  }
  function vaultContentTiles(root) {
    return [...qa("vaultTile", root)].filter(
      (m) => !qm("mediaPreview", m) && !qm("vaultCoverMedia", m) && !qm("vaultAvatar", m) && !(m.parentElement && m.parentElement.closest(selStr("vaultMediaNest")))
    );
  }
  function vaultFindScroller() {
    const tile = vaultContentTiles()[0];
    let n = tile && tile.parentElement;
    while (n && n !== document.body) {
      const oy = getComputedStyle(n).overflowY;
      if ((oy === "auto" || oy === "scroll") && n.scrollHeight > n.clientHeight + 40) return n;
      n = n.parentElement;
    }
    return q("vaultScroller") || document.scrollingElement || document.documentElement;
  }
  async function vaultPullMore(scroller, ms = 5e3) {
    const h0 = scroller.scrollHeight;
    const t0 = Date.now();
    for (let i = 0; Date.now() - t0 < ms; i++) {
      const top = scroller.scrollTop;
      try {
        scroller.scrollTop = Math.max(0, top - 150 - i * 60);
      } catch (e) {
      }
      await sleep(150);
      try {
        scroller.scrollTop = top + 600;
      } catch (e) {
      }
      await sleep(600);
      if (scroller.scrollHeight > h0 + 100) return true;
    }
    return false;
  }
  function vaultQuickMenu() {
    return [...qa("vaultMenu")].find(
      (menu) => [...qa("vaultBubble", menu)].some((b) => /^(All|Overview|Posts)$/i.test((b.textContent || "").replace(/\s+/g, " ").trim()))
    ) || q("vaultMenu");
  }
  function vaultCollectSources() {
    const menu = vaultQuickMenu();
    if (!menu) return [];
    const sources = [];
    const add = (name, kind) => {
      const n = VaultCounts.clean(name);
      if (!n || /^(Overview|All)$/i.test(n)) return;
      sources.push({ name: n, kind });
    };
    for (const b of qa("vaultBubbleTop", menu)) add(b.textContent || "", "bubble");
    for (const dd of qa("vaultMore", menu)) for (const it of qa("vaultMoreItem", dd)) add(subText(q("vaultFolderName", it)), "dropdown");
    return VaultCounts.firstByName(sources);
  }
  async function vaultGoToSource(src, setStatus) {
    setStatus(t("panel.vault.folder", uiLang, { name: src.name }));
    const menu = vaultQuickMenu();
    const before = vaultContentTiles()[0]?.getAttribute("data-media-id") || null;
    const STAMP = "faiWas";
    vaultContentTiles().forEach((t2) => {
      t2.dataset[STAMP] = "1";
    });
    const scr0 = vaultFindScroller();
    const h0 = scr0 ? scr0.scrollHeight : 0;
    const activeName = () => {
      const a = menu && q("vaultBubbleActive", menu);
      return a ? (a.textContent || "").replace(/\s+/g, " ").trim() : "";
    };
    const act0 = activeName();
    let item = null;
    if (src.kind === "bubble") {
      const b = menu && [...qa("vaultBubbleTop", menu)].find((x) => (x.textContent || "").replace(/\s+/g, " ").trim() === src.name);
      if (!b) return false;
      synthClick(b);
    } else {
      const dd = menu && q("vaultMore", menu);
      const more = dd && q("vaultMoreToggle", dd);
      if (more) {
        synthClick(more);
        await sleep(450);
      }
      const it = dd && [...qa("vaultMoreItem", dd)].find((x) => subText(q("vaultFolderName", x)) === src.name);
      if (!it) return false;
      synthClick(q("vaultFolderName", it) || it);
      item = it;
    }
    let stable = 0;
    for (let i = 0; i < 40; i++) {
      await sleep(300);
      const act = activeName();
      if (src.kind === "bubble" ? act === src.name : act !== act0 || item && qm("vaultItemActive", item)) {
        if (++stable >= 2) return true;
        continue;
      }
      const tiles = vaultContentTiles();
      if (!tiles.length) {
        stable = 0;
        continue;
      }
      const topChanged = tiles[0].getAttribute("data-media-id") !== before;
      const fresh = tiles.reduce((n, t2) => n + (t2.dataset[STAMP] ? 0 : 1), 0);
      const scr = vaultFindScroller();
      const hChanged = scr && h0 && Math.abs(scr.scrollHeight - h0) > Math.max(1e3, h0 * 0.2);
      if (topChanged || fresh >= Math.max(3, tiles.length * 0.5) || hChanged) {
        if (++stable >= 2) return true;
      } else stable = 0;
    }
    return false;
  }
  async function vaultEnterVault(setStatus, preferName) {
    setStatus(preferName ? t("panel.vault.enterFolder", uiLang, { name: preferName }) : t("panel.vault.enter", uiLang));
    await waitForElement(selStr("vaultReady"), 2e4).catch(() => {
    });
    const inside = () => !!([...qa("vaultMenu")].some((m) => q("vaultBubble", m)) || vaultContentTiles().length);
    if (inside()) return { ok: true, name: "" };
    const nameOf = (a) => (q("vaultAlbumName", a)?.textContent || "").replace(/\s+/g, " ").trim();
    const wantMatch = (a) => {
      const nm = nameOf(a);
      return nm && (preferName ? nm.toLowerCase() === preferName.toLowerCase() : !/^all$/i.test(nm));
    };
    let target = null, targetName = "";
    for (let i = 0; i < 30; i++) {
      if (inside()) return { ok: true, name: "" };
      for (const a of qa("vaultAlbum")) {
        if (wantMatch(a)) {
          target = a;
          targetName = nameOf(a);
          break;
        }
      }
      if (target) break;
      await sleep(400);
    }
    if (!target) {
      const all = [...qa("vaultAlbum")];
      target = all.find((a) => nameOf(a) && !/^all$/i.test(nameOf(a))) || all.find((a) => nameOf(a)) || all[0];
      targetName = target ? nameOf(target) : "";
    }
    if (!target) return { ok: inside(), name: "" };
    const click = async () => {
      try {
        target.scrollIntoView({ block: "center" });
      } catch (e) {
      }
      await sleep(250);
      synthClick(q("vaultAlbumMedia", target) || target);
    };
    await click();
    for (let i = 0; i < 30; i++) {
      await sleep(400);
      if (inside()) return { ok: true, name: targetName };
    }
    await click();
    for (let i = 0; i < 20; i++) {
      await sleep(400);
      if (inside()) return { ok: true, name: targetName };
    }
    return { ok: inside(), name: inside() ? targetName : "" };
  }
  async function vaultBackToOverview() {
    const menu = vaultQuickMenu();
    const ov = menu && [...qa("vaultBubbleTop", menu)].find((b) => /^Overview$/i.test((b.textContent || "").replace(/\s+/g, " ").trim()));
    if (!ov) return qa("vaultAlbum").length > 0;
    synthClick(ov);
    for (let i = 0; i < 30; i++) {
      await sleep(300);
      if (qa("vaultAlbum").length) return true;
    }
    return qa("vaultAlbum").length > 0;
  }
  function vaultReadFolderCounts() {
    return VaultCounts.read(document, { q, qa });
  }
  async function vaultPollFolderCounts() {
    let site = { counts: {}, dups: [], dupTiles: 0 }, prev = null, same = 0;
    for (let i = 0; i < 40; i++) {
      site = vaultReadFolderCounts();
      const sig = JSON.stringify(site);
      same = sig === prev && Object.keys(site.counts).length ? same + 1 : 0;
      prev = sig;
      if (same >= 2) return site;
      await sleep(400);
    }
    return site;
  }
  async function catalogFolderCounts(lastFull) {
    const r = await sendMeta({ type: "CATALOG_META_COUNTS", lastFull: lastFull || 0 });
    return r ? { total: r.total, per: r.per } : null;
  }
  function vaultDupReport(site) {
    if (!site.dups.length) return;
    console.warn("[FanslyAI] vault: \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u0430\u043F\u043E\u043A \u0441 \u043E\u0434\u043D\u0438\u043C \u0438\u043C\u0435\u043D\u0435\u043C:", site.dups.join(", "), "\u2014 \u0441\u0432\u0435\u0440\u0438\u0442\u044C \u0438\u0445 \u043D\u0435\u043B\u044C\u0437\u044F: \u0432 \u0441\u0432\u0435\u0440\u043A\u0435 \u043D\u0435 \u0443\u0447\u0430\u0441\u0442\u0432\u0443\u044E\u0442, \u0442\u0435\u0433\u0438 \u043D\u0435 \u043F\u0435\u0440\u0435\u0441\u043E\u0431\u0438\u0440\u0430\u044E\u0442\u0441\u044F");
    reportBug("vault_dupname", { folders: site.dups.length, got: site.dupTiles });
  }
  async function vaultThumbGapFolders() {
    const r = await sendMeta({ type: "CATALOG_META_GAPS" });
    return r && r.folders || [];
  }
  async function vaultSweepFromOverview(setStatus) {
    const ov = VaultCounts.tiles(document, { q, qa });
    if (!ov.complete) {
      console.log("[FanslyAI] vault: \u0443\u0431\u043E\u0440\u043A\u0443 \u043F\u0430\u043F\u043E\u043A \u043F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u043B \u2014 \u0441\u043F\u0438\u0441\u043E\u043A Overview \u043D\u0435\u043F\u043E\u043B\u043E\u043D: \u043F\u043B\u0438\u0442\u043E\u043A", ov.real, "\xB7 \u0441 \u0438\u043C\u0435\u043D\u0430\u043C\u0438", ov.labeled, "\xB7 \u043F\u0443\u0441\u0442\u044B\u0445 \u043D\u0435 \u0432 \u0445\u0432\u043E\u0441\u0442\u0435", ov.holes);
      return;
    }
    const sweep = await sendMeta({ type: "CATALOG_FOLDERS_SWEEP", keep: ov.names });
    if (sweep && sweep.touched) {
      console.log("[FanslyAI] vault: \u043F\u0430\u043F\u043E\u043A \u0438\u0441\u0447\u0435\u0437\u043B\u043E \u0441 \u0441\u0430\u0439\u0442\u0430:", (sweep.dropped || []).join(", "), "\xB7 \u0442\u0435\u0433 \u0441\u043D\u044F\u0442 \u0443", sweep.touched, "\u043C\u0435\u0434\u0438\u0430");
      await new Promise((r) => chrome.storage.local.set({ fansly_catalog_lastsync: { at: Date.now(), added: 0 } }, r));
      setStatus(t("panel.vault.foldersGone", uiLang, { names: (sweep.dropped || []).join(", "), n: sweep.touched }));
      await sleep(1500);
    }
  }
  async function vaultDoscan(setStatus, drifted, gaps) {
    const nm = VaultCounts.key;
    const full = (gaps || []).slice();
    const incr = (drifted || []).filter((f) => !full.some((g) => nm(g) === nm(f)));
    if (full.length || incr.length) console.log("[FanslyAI] \u0434\u043E\u0441\u043A\u0430\u043D: \u043F\u043E\u043B\u043D\u044B\u043C \u2014", full.join(", ") || "\u2014", "\xB7 \u0434\u043E\u0431\u043E\u0440\u043E\u043C \u2014", incr.join(", ") || "\u2014");
    const out = { added: 0, reachedEndAll: true, snap: null, stopped: false };
    const take = (r) => {
      if (!r) {
        out.reachedEndAll = false;
        return;
      }
      out.added += r.added | 0;
      out.reachedEndAll = out.reachedEndAll && !!r.reachedEndAll;
      if (r.snap) out.snap = r.snap;
      if (r.stopped) out.stopped = true;
    };
    phaseHold++;
    try {
      if (incr.length) take(await syncVault(setStatus, true, incr));
      if (full.length && !VAULT.stopRequested) take(await syncVault(setStatus, false, full));
    } finally {
      phaseHold--;
      if (phaseOpen) phaseEnd(true);
    }
    return out;
  }
  async function vaultCheckCounts(setStatus, periodic) {
    startKeepAlive();
    try {
      if (await vaultLockActive()) {
        setStatus(t("panel.vault.lockWait", uiLang));
        if (periodic) return { drift: -1, drifted: null, snap: null, busy: true };
        for (let i = 0; i < 180 && await vaultLockActive(); i++) await sleep(1e3);
      }
      setStatus(t("panel.vault.checking", uiLang));
      await waitForElement([selStr("vaultAlbum"), selStr("vaultTile")].filter(Boolean).join(", "), 15e3).catch(() => {
      });
      if (!q("vaultAlbum")) await vaultBackToOverview();
      const site = await vaultPollFolderCounts();
      if (!Object.keys(site.counts).length) return { drift: -1, drifted: null, snap: null };
      const st = await new Promise((r) => chrome.storage.local.get("fansly_catalog_lastfull", (d) => r(d)));
      const ours = await catalogFolderCounts(st.fansly_catalog_lastfull || 0);
      if (!ours) return { drift: -1, drifted: null, snap: null };
      vaultDupReport(site);
      const { drift, byFolder } = VaultCounts.drift(site, ours, 0);
      const drifted = Object.entries(byFolder).filter(([n, v]) => !/^all$/i.test(n) && v.diff > 0).map(([n]) => n);
      return { drift, drifted, snap: { at: Date.now(), site: site.counts, ours, dups: site.dups } };
    } finally {
      stopKeepAlive();
    }
  }
  async function syncVault(setStatus, incremental = false, onlyFolders = null) {
    if (VAULT.running) return;
    if (VAULT.framesRunning) return;
    if (await vaultLockActive()) {
      setStatus(t("panel.vault.lockWait", uiLang));
      for (let i = 0; i < 180 && await vaultLockActive(); i++) await sleep(1e3);
    }
    VAULT.running = true;
    try {
      bugCrumb("vault_sync");
      try {
        const _l = await new Promise((r) => chrome.storage.local.get(VAULT_LOCK, (d) => r(d[VAULT_LOCK])));
        if (_l && _l.at && Date.now() - _l.at >= VAULT_LOCK_TTL) reportBug("stale_lock", { ageMs: Date.now() - _l.at });
      } catch (e) {
      }
      startKeepAlive();
      await phaseBegin(onlyFolders ? "quick" : "full");
      await vaultLockAcquire(setStatus);
      await waitForElement(selStr("vaultReady"), 15e3).catch(() => {
      });
      if (!q("vaultAlbum")) await vaultBackToOverview();
      let site = await vaultPollFolderCounts();
      let siteCounts = site.counts;
      const enter = await vaultEnterVault(setStatus, onlyFolders && onlyFolders[0] || null);
      if (!enter.ok) {
        const cnt = await sendMeta({ type: "CATALOG_META_COUNT" });
        if (cnt && cnt.count > 0) throw layoutMissError("vaultEnter");
        reportBug("sel_miss", { key: "vaultEnter", got: 0 });
        setStatus(t("panel.vault.noAlbums", uiLang));
        return;
      }
      let currentOpen = enter.name;
      const idsResp = await sendMeta({ type: "CATALOG_META_IDS" });
      if (!idsResp) {
        setStatus(t("panel.vault.dbFail", uiLang));
        return;
      }
      const knownBefore = new Set(idsResp.ids || []);
      const syncStartedAt = Date.now();
      const catalog = {};
      const dirty = /* @__PURE__ */ new Set();
      const addedIds = /* @__PURE__ */ new Set();
      let thumbBatch = [], reachedEndAll = true, lostWrites = 0, stopped = false;
      const SCAN_FIELDS = ["type", "filename", "date", "lastSeen", "folders", "thumb", "thumbTry", "thumbFromFrame", "dur", "blur", "blurScore", "blurNorm"];
      const patchOf = (id) => {
        const e = catalog[id];
        if (!e) return null;
        const set = {};
        for (const f of SCAN_FIELDS) if (e[f] !== void 0) set[f] = e[f];
        return { id, set, base: { tags: [], desc: "", addedAt: e.addedAt || Date.now() } };
      };
      const ensureMeta = async (ids) => {
        const need = ids.filter((id) => id && catalog[id] === void 0 && knownBefore.has(id));
        if (!need.length) return;
        const r = await sendMeta({ type: "CATALOG_META_GET", ids: need });
        if (!r) return;
        for (const id of need) catalog[id] = r.items && r.items[id] ? r.items[id] : null;
      };
      const flushThumbs = async () => {
        if (!thumbBatch.length) return;
        const items = thumbBatch;
        thumbBatch = [];
        const r = await sendSafe({ type: "CATALOG_THUMB_PUT", items });
        if (r && r.success) {
          for (const it of items) {
            const e = catalog[it.id];
            if (e) {
              e.thumb = true;
              if (e.thumbTry) e.thumbTry = 0;
              if (e.thumbFromFrame) e.thumbFromFrame = false;
              dirty.add(it.id);
            }
          }
        }
      };
      const persistMeta = async () => {
        if (!dirty.size) return;
        const ids = [...dirty];
        const patches = ids.map(patchOf).filter(Boolean);
        const r = patches.length ? await sendMeta({ type: "CATALOG_META_PATCH", patches }) : { success: true };
        if (r) {
          for (const id of ids) dirty.delete(id);
        } else {
          lostWrites++;
          console.warn("[FanslyAI] \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043D\u0435 \u043F\u0440\u0438\u043D\u044F\u043B \u043F\u0430\u0447\u043A\u0443 \u0438\u0437", ids.length, "\u2014 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u043C \u0441\u043E \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0439");
        }
      };
      const navSources = vaultCollectSources();
      if (!navSources.length) {
        if (knownBefore.size) throw layoutMissError("vaultNav");
        reportBug("sel_miss", { key: "vaultNav", got: 0 });
        setStatus(t("panel.vault.noAlbums", uiLang));
        return;
      }
      let sources = navSources;
      const catCounts = await catalogFolderCounts(0);
      const catIn = (name) => {
        if (!catCounts || !catCounts.per) return 0;
        const k = VaultCounts.key(name);
        let n = 0;
        for (const f in catCounts.per) if (VaultCounts.key(f) === k) n += catCounts.per[f];
        return n;
      };
      if (onlyFolders && onlyFolders.length) sources = sources.filter((s) => onlyFolders.some((f) => f.toLowerCase() === s.name.toLowerCase()));
      const scanDiag = [];
      let blindFolders = 0;
      const sameFolder = (a, b) => VaultCounts.key(a) === VaultCounts.key(b);
      for (const src of sources) {
        if (VAULT.stopRequested) {
          stopped = true;
          reachedEndAll = false;
          break;
        }
        bugCrumb("vault_folder");
        if (currentOpen && sameFolder(src.name, currentOpen)) {
        } else {
          let opened2 = await vaultGoToSource(src, setStatus);
          if (!opened2) {
            await sleep(1500);
            opened2 = await vaultGoToSource(src, setStatus);
          }
          if (!opened2) {
            reachedEndAll = false;
            reportBug("sel_miss", { key: "folderOpen", got: 0 });
            scanDiag.push({ name: src.name, scanned: 0, reachedEnd: false, opened: false });
            continue;
          }
          currentOpen = src.name;
        }
        await sleep(3e3);
        const tagFolder = !/^All$/i.test(src.name);
        const dupFolder = !!src.dup || VaultCounts.isDup(site, src.name);
        if (dupFolder) console.warn("[FanslyAI] vault: \xAB" + src.name + "\xBB \u2014 \u0438\u043C\u044F \u043D\u043E\u0441\u0438\u0442 \u043D\u0435 \u043E\u0434\u043D\u0430 \u043F\u0430\u043F\u043A\u0430: \u0438\u0434\u0443 \u0432 \u043F\u0435\u0440\u0432\u0443\u044E, \u0446\u0435\u043B\u044C \u043F\u043E \u0441\u0447\u0451\u0442\u0447\u0438\u043A\u0443 \u0438 \u043F\u0435\u0440\u0435\u0441\u0431\u043E\u0440\u043A\u0443 \u0442\u0435\u0433\u043E\u0432 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430\u044E");
        const folderTarget = dupFolder ? null : (() => {
          for (const k in siteCounts) if (k.toLowerCase() === src.name.toLowerCase()) return siteCounts[k];
          return null;
        })();
        const seen = /* @__PURE__ */ new Set();
        const skipped = /* @__PURE__ */ new Set();
        let knownStreak = 0, incrDone = false, stagnant = 0, bottomStreak = 0, hitTarget = false;
        const scroller = vaultFindScroller();
        const startTop = scroller.scrollTop;
        let passCount = 0, maxTop = startTop;
        for (let pass = 0; pass < VAULT.MAX_PASSES && bottomStreak < VAULT.BOTTOM_STREAK && stagnant < VAULT.STAGNANT_SAFETY && !incrDone; pass++) {
          if (VAULT.stopRequested) {
            stopped = true;
            break;
          }
          passCount = pass + 1;
          if (document.hidden) {
            setStatus(t("panel.vault.veil.paused", uiLang));
            await vaultPausedWait();
            setStatus(t("panel.vault.veil.resumed", uiLang));
            await sleep(600);
          }
          await vaultLockTouch();
          const before = seen.size;
          await ensureMeta(vaultContentTiles().map((tl) => tl.getAttribute("data-media-id")));
          await vaultWaitThumbs(scroller, catalog, pass === 0 ? VAULT.THUMB_WAIT_FIRST : VAULT.THUMB_WAIT);
          const tiles = vaultContentTiles();
          await ensureMeta(tiles.map((tl) => tl.getAttribute("data-media-id")));
          let sawStale = false;
          for (const tile of tiles) {
            if (tile.dataset.faiWas) {
              sawStale = true;
              continue;
            }
            const id = tile.getAttribute("data-media-id");
            if (!id) continue;
            if (catalog[id] === void 0 && knownBefore.has(id)) {
              skipped.add(id);
              continue;
            }
            skipped.delete(id);
            if (!seen.has(id)) {
              seen.add(id);
              if (incremental) {
                if (knownBefore.has(id)) knownStreak++;
                else knownStreak = 0;
              }
              const meta = vaultCellMeta(tile);
              const entry = catalog[id] || { addedAt: Date.now(), thumb: false, folders: [] };
              if (!knownBefore.has(id)) addedIds.add(id);
              entry.type = vaultType(tile, meta.filename);
              if (meta.filename) entry.filename = meta.filename;
              if (meta.date) entry.date = meta.date;
              entry.lastSeen = Date.now();
              if (tagFolder) entry.folders = [.../* @__PURE__ */ new Set([...entry.folders || [], src.name])];
              catalog[id] = entry;
              dirty.add(id);
            }
            const e = catalog[id];
            if (e && (!e.thumb || e.thumbFromFrame)) {
              const dataUrl = vaultCaptureThumb(tile);
              if (dataUrl) thumbBatch.push({ id, dataUrl });
            }
            if (e && e.type === "video" && !e.dur) {
              const d = vaultDuration(tile);
              if (d) {
                e.dur = d;
                dirty.add(id);
              }
            }
            if (e && e.type === "image" && e.blurScore == null) {
              const m = vaultBlurMetrics(tile);
              if (m) {
                e.blurScore = m.lap;
                e.blurNorm = m.norm;
                if (!e.blurManual) e.blur = m.lap < VAULT.BLUR_LAP && m.norm < VAULT.BLUR_NORM;
                dirty.add(id);
              }
            }
          }
          if (incremental && knownStreak >= 40) {
            incrDone = true;
            break;
          }
          const growing = pass === 0;
          if (folderTarget != null && seen.size >= folderTarget && !sawStale && !growing) {
            hitTarget = true;
            const inBatch = new Set(thumbBatch.map((x) => x.id));
            const needMore = tiles.some((tl) => {
              const tid = tl.getAttribute("data-media-id");
              const e = tid && catalog[tid];
              return e && !e.thumb && !inBatch.has(tid) && e.type !== "audio";
            });
            if (!needMore) break;
          }
          if (thumbBatch.length >= 25) await flushThumbs();
          setStatus(t("panel.vault.scanningFolder", uiLang, { name: src.name, n: seen.size }));
          const beforeTop = scroller.scrollTop;
          const step = Math.max(Math.round(scroller.clientHeight * 0.8), 400);
          try {
            scroller.scrollTop = beforeTop + step;
          } catch (e) {
          }
          if (scroller.scrollTop <= beforeTop + 2 && tiles.length) {
            try {
              tiles[tiles.length - 1].scrollIntoView({ block: "end", behavior: "auto" });
            } catch (e) {
            }
          }
          await sleep(900 + Math.random() * 600);
          if (scroller.scrollTop > maxTop) maxTop = scroller.scrollTop;
          if (scroller.scrollTop <= beforeTop + 2) {
            if (await vaultPullMore(scroller)) bottomStreak = 0;
            else bottomStreak++;
            if (scroller.scrollTop > maxTop) maxTop = scroller.scrollTop;
          } else bottomStreak = 0;
          if (seen.size === before) stagnant++;
          else stagnant = 0;
          if (pass % 10 === 9) {
            await persistMeta();
            await vaultLockTouch();
          }
        }
        const expected = dupFolder ? 0 : tagFolder ? folderTarget != null ? folderTarget : catIn(src.name) : knownBefore.size;
        const blind = !seen.size && !skipped.size && !stopped && expected > 0;
        if (blind) blindFolders++;
        const folderDone = !blind && (hitTarget || bottomStreak >= VAULT.BOTTOM_STREAK || incrDone || stagnant >= VAULT.STAGNANT_SAFETY);
        if (!folderDone || skipped.size) reachedEndAll = false;
        await flushThumbs();
        await persistMeta();
        const sliceComplete = folderTarget == null || seen.size >= folderTarget;
        if (!incremental && tagFolder && !dupFolder && !blind && sliceComplete && (hitTarget || bottomStreak >= VAULT.BOTTOM_STREAK)) {
          const r = await sendMeta({ type: "CATALOG_META_UNTAG", folder: src.name, keepIds: [.../* @__PURE__ */ new Set([...seen, ...skipped])] });
          if (r && r.changed) {
            const normF = VaultCounts.key;
            for (const id of Object.keys(catalog)) {
              if (seen.has(id)) continue;
              if (dirty.has(id) || addedIds.has(id)) {
                const e = catalog[id];
                if (e && Array.isArray(e.folders)) e.folders = e.folders.filter((f) => normF(f) !== normF(src.name));
              } else delete catalog[id];
            }
          }
        }
        scanDiag.push({ name: src.name, scanned: seen.size, reachedEnd: folderDone, opened: true, passes: passCount, moved: Math.round(maxTop - startTop), sh: scroller.scrollHeight, ch: scroller.clientHeight });
      }
      const opened = scanDiag.filter((d) => d.opened);
      if (blindFolders && opened.length && opened.every((d) => !d.scanned)) throw layoutMissError("vaultTile");
      if (opened.some((d) => d.scanned > 0)) layout.seen("vault");
      await flushThumbs();
      for (const id in catalog) {
        const e = catalog[id];
        if (!e || e.thumb || e.type === "audio") continue;
        if (!(e.lastSeen >= syncStartedAt)) continue;
        e.thumbTry = (e.thumbTry | 0) + 1;
        dirty.add(id);
      }
      await persistMeta();
      if (reachedEndAll && !incremental && !onlyFolders) {
        await new Promise((r) => chrome.storage.local.set({ fansly_catalog_lastfull: syncStartedAt }, r));
      }
      if (!reachedEndAll && !stopped) reportBug("vault_notend", { folders: scanDiag.filter((d) => d.opened && !d.reachedEnd).length });
      if (lostWrites) reportBug("catalog_write_fail", { batches: lostWrites });
      await new Promise((r) => chrome.storage.local.set({ fansly_catalog_lastsync: { at: Date.now(), added: addedIds.size } }, r));
      if (!Object.keys(siteCounts).length) {
        await vaultBackToOverview();
        site = vaultReadFolderCounts();
        siteCounts = site.counts;
      }
      if (navSources.length && !stopped) {
        const keep = [.../* @__PURE__ */ new Set([...navSources.map((s) => s.name), ...VaultCounts.names(site)])];
        const sweep = await sendMeta({ type: "CATALOG_FOLDERS_SWEEP", keep });
        if (sweep && sweep.touched) {
          console.log("[FanslyAI] vault: \u043F\u0430\u043F\u043E\u043A \u0438\u0441\u0447\u0435\u0437\u043B\u043E \u0441 \u0441\u0430\u0439\u0442\u0430:", (sweep.dropped || []).join(", "), "\xB7 \u0442\u0435\u0433 \u0441\u043D\u044F\u0442 \u0443", sweep.touched, "\u043C\u0435\u0434\u0438\u0430");
          setStatus(t("panel.vault.foldersGone", uiLang, { names: (sweep.dropped || []).join(", "), n: sweep.touched }));
          await sleep(1500);
        }
      }
      const siteFor = (name) => {
        for (const k in siteCounts) if (k.toLowerCase() === name.toLowerCase()) return siteCounts[k];
        return null;
      };
      const diag = scanDiag.map((d) => ({ ...d, site: siteFor(d.name), short: siteFor(d.name) != null && d.scanned < siteFor(d.name) }));
      const worst = diag.filter((d) => d.short && d.opened).sort((a, b) => b.site - b.scanned - (a.site - a.scanned))[0];
      if (worst && !incremental) reportBug("vault_short", { got: worst.scanned, exp: worst.site, moved: worst.moved, passes: worst.passes });
      for (const k of VaultCounts.missed(siteCounts, scanDiag.map((d) => d.name), onlyFolders)) diag.push({ name: k, scanned: null, site: siteFor(k), reachedEnd: false, opened: false, missing: true });
      const totalResp = await sendMeta({ type: "CATALOG_META_COUNT" });
      const catalogTotal = totalResp ? totalResp.count : null;
      await new Promise((r) => chrome.storage.local.set({ fansly_catalog_scandiag: { v: 2, at: Date.now(), incremental, folders: diag, catalogTotal, stopped } }, r));
      let snap = null;
      if (Object.keys(siteCounts).length) {
        const lf = await new Promise((r) => chrome.storage.local.get("fansly_catalog_lastfull", (d) => r(d.fansly_catalog_lastfull || 0)));
        const ours = await catalogFolderCounts(lf);
        if (ours) {
          vaultDupReport(site);
          snap = { at: Date.now(), site: siteCounts, ours, dups: site.dups };
        }
      }
      setStatus(t(stopped ? "panel.vault.stopped" : "panel.vault.done", uiLang, { n: catalogTotal != null ? catalogTotal : knownBefore.size + addedIds.size }));
      return { added: addedIds.size, reachedEndAll, snap, stopped };
    } finally {
      VAULT.running = false;
      stopKeepAlive();
      phaseEnd(true);
      await vaultLockClear();
    }
  }
  async function vaultGrabFrames(setStatus) {
    if (VAULT.running || VAULT.framesRunning) {
      setStatus(t("panel.vault.frames.busy", uiLang));
      return;
    }
    if (await vaultLockActive()) {
      setStatus(t("panel.vault.lockWait", uiLang));
      for (let i = 0; i < 180 && await vaultLockActive(); i++) await sleep(1e3);
    }
    VAULT.framesRunning = true;
    let videos = 0, shots = 0, failed = 0, stoppedBy = "";
    try {
      bugCrumb("vault_frames");
      startKeepAlive();
      await phaseBegin("frames");
      await vaultLockAcquire(setStatus);
      setStatus(t("panel.vault.frames.start", uiLang));
      const listResp = await sendMeta({ type: "CATALOG_VIDEO_LIST" });
      if (!listResp) {
        setStatus(t("panel.vault.dbFail", uiLang));
        return;
      }
      const s = await getSettingsAsync();
      const parsed = parseInt(s.frameMinVideoSec, 10);
      const minSec = Number.isFinite(parsed) && parsed >= 0 ? parsed : 120;
      const FRAME_TRIES = 3;
      const todo = /* @__PURE__ */ new Map();
      const triesOf = /* @__PURE__ */ new Map();
      let tooShort = 0, noDur = 0, giveUp = 0;
      for (const v of listResp.items || []) {
        if (v.hasFrames) continue;
        if ((v.framesTry | 0) >= FRAME_TRIES) {
          giveUp++;
          continue;
        }
        const d = vaultDurSec(v.dur);
        if (d < 0) {
          noDur++;
          continue;
        }
        if (d < minSec) {
          tooShort++;
          continue;
        }
        todo.set(v.id, (v.folders || []).filter(Boolean));
        triesOf.set(v.id, v.framesTry | 0);
      }
      if (giveUp) console.log("[FanslyAI] \u{1F3AC} \u043E\u0442\u043B\u043E\u0436\u0435\u043D\u044B \u043F\u043E\u0441\u043B\u0435", FRAME_TRIES, "\u043D\u0435\u0443\u0434\u0430\u0447\u043D\u044B\u0445 \u043F\u043E\u043F\u044B\u0442\u043E\u043A:", giveUp);
      if (noDur) console.log("[FanslyAI] \u{1F3AC} \u0431\u0435\u0437 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438:", noDur, "\u2014 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u044B");
      if (!todo.size) {
        setStatus(t("panel.vault.frames.none", uiLang) + (tooShort ? " \xB7 " + t("panel.vault.frames.short", uiLang, { n: tooShort }) : "") + (giveUp ? " \xB7 " + t("panel.vault.frames.giveUp", uiLang, { n: giveUp }) : ""));
        return;
      }
      const total = todo.size;
      console.log("[FanslyAI] \u{1F3AC} \u043A \u0441\u044A\u0451\u043C\u043A\u0435 \u0440\u043E\u043B\u0438\u043A\u043E\u0432:", total, "\xB7 \u043A\u043E\u0440\u043E\u0447\u0435 \u043F\u043E\u0440\u043E\u0433\u0430 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E:", tooShort, "\xB7 \u043F\u043E\u0440\u043E\u0433, \u0441:", minSec);
      const norm = VaultCounts.key;
      const anyWithoutFolder = [...todo.values()].some((f) => !f.length);
      await waitForElement(selStr("vaultReady"), 15e3).catch(() => {
      });
      const siteCounts = q("vaultAlbum") ? (await vaultPollFolderCounts()).counts : {};
      const sizeOf = (name) => {
        for (const k in siteCounts) if (norm(k) === norm(name)) return siteCounts[k];
        return Infinity;
      };
      const pick = (list) => list.slice().sort((a, b) => sizeOf(a) - sizeOf(b))[0] || "";
      const needOrig = [...new Set([...todo.values()].filter((f) => f.length).map(pick))].sort((a, b) => sizeOf(a) - sizeOf(b));
      const need = new Set(needOrig.map(norm));
      const enter = await vaultEnterVault(setStatus, needOrig[0] || null);
      if (!enter.ok) {
        reportBug("sel_miss", { key: "vaultEnter", got: 0 });
        setStatus(t("panel.vault.noAlbums", uiLang));
        return;
      }
      let currentOpen = enter.name;
      const sameFolder = (a, b) => norm(a) === norm(b);
      const all = vaultCollectSources();
      if (!all.length) {
        reportBug("sel_miss", { key: "vaultNav", got: 0 });
        setStatus(t("panel.vault.noAlbums", uiLang));
        return;
      }
      const wanted = all.filter((src) => need.has(norm(src.name))).sort((a, b) => sizeOf(a.name) - sizeOf(b.name));
      const sources = anyWithoutFolder ? [...wanted, ...all.filter((src) => !need.has(norm(src.name)))] : wanted;
      for (const src of sources) {
        if (VAULT.stopRequested) stoppedBy = "user";
        if (!todo.size || stoppedBy) break;
        bugCrumb("vault_frames_folder");
        if (currentOpen && sameFolder(src.name, currentOpen)) {
        } else {
          let opened = await vaultGoToSource(src, setStatus);
          if (!opened) {
            await sleep(1500);
            opened = await vaultGoToSource(src, setStatus);
          }
          if (!opened) {
            reportBug("sel_miss", { key: "folderOpen", got: 0 });
            continue;
          }
          currentOpen = src.name;
        }
        await sleep(3e3);
        const scroller = vaultFindScroller();
        let bottomStreak = 0;
        for (let pass = 0; pass < VAULT.MAX_PASSES && bottomStreak < VAULT.BOTTOM_STREAK && todo.size && !stoppedBy; pass++) {
          if (VAULT.stopRequested) {
            stoppedBy = "user";
            break;
          }
          if (document.hidden) {
            setStatus(t("panel.vault.frames.paused", uiLang));
            await vaultPausedWait();
            setStatus(t("panel.vault.frames.resumed", uiLang));
            await sleep(600);
          }
          await vaultLockTouch();
          const tiles = vaultContentTiles().filter((tile) => {
            const id = tile.getAttribute("data-media-id");
            if (!id || !todo.has(id)) return false;
            const r = tile.getBoundingClientRect();
            return r.height > 0 && r.bottom > 0 && r.top < innerHeight;
          });
          for (const tile of tiles) {
            if (stoppedBy) break;
            const id = tile.getAttribute("data-media-id");
            if (!todo.has(id)) continue;
            tile.scrollIntoView({ block: "center" });
            await sleep(250);
            const done = videos + failed + 1;
            setStatus(t("panel.vault.frames.shot", uiLang, { i: done, n: total, k: 0 }));
            const res = await grabFramesForTile(tile, (k, kn) => setStatus(t("panel.vault.frames.seeking", uiLang, { i: done, n: total, k, total: kn })));
            if (res.reason === "modal") {
              stoppedBy = "modal";
              break;
            }
            if (res.reason === "tainted") {
              stoppedBy = "tainted";
              break;
            }
            if (res.frames.length) {
              const put = await sendMeta({ type: "CATALOG_FRAME_PUT", items: res.frames.map((dataUrl, idx) => ({ id, idx, dataUrl })) });
              if (!put) {
                console.warn("[FanslyAI] \u{1F3AC} \u043A\u0430\u0434\u0440\u044B \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043B\u0438\u0441\u044C:", id);
                failed++;
                todo.delete(id);
                continue;
              }
              shots += res.frames.length;
              videos++;
              await sendMeta({ type: "CATALOG_META_PATCH", patches: [{ id, set: { frames: res.frames.length, framesAt: Date.now() } }] });
              setStatus(t("panel.vault.frames.shot", uiLang, { i: videos + failed, n: total, k: res.frames.length }));
            } else {
              failed++;
              const tries = res.reason === "short" ? FRAME_TRIES : (triesOf.get(id) | 0) + 1;
              await sendMeta({ type: "CATALOG_META_PATCH", patches: [{ id, set: { frames: 0, framesAt: Date.now(), framesTry: tries } }] });
              console.warn("[FanslyAI] \u{1F3AC} \u0431\u0435\u0437 \u043A\u0430\u0434\u0440\u043E\u0432:", id, "\xB7", res.reason || "\u043F\u0443\u0441\u0442\u043E", "\xB7 \u043F\u043E\u043F\u044B\u0442\u043A\u0430", tries, "\u0438\u0437", FRAME_TRIES);
            }
            todo.delete(id);
            await vaultLockTouch();
          }
          const beforeTop = scroller.scrollTop;
          scroller.scrollTop = beforeTop + Math.max(Math.round(scroller.clientHeight * 0.8), 400);
          await sleep(900 + Math.random() * 600);
          if (scroller.scrollTop <= beforeTop + 2) {
            if (await vaultPullMore(scroller)) bottomStreak = 0;
            else bottomStreak++;
          } else bottomStreak = 0;
        }
      }
      if (stoppedBy === "user") setStatus(t("panel.vault.frames.stopped", uiLang, { v: videos, k: shots }));
      else if (stoppedBy === "modal") setStatus(t("panel.vault.frames.modal", uiLang));
      else if (stoppedBy === "tainted") setStatus(t("panel.vault.frames.tainted", uiLang));
      else setStatus(t("panel.vault.frames.done", uiLang, { v: videos, k: shots }) + (failed ? " \xB7 " + t("panel.vault.frames.fail", uiLang, { n: failed }) : ""));
      console.log("[FanslyAI] \u{1F3AC} \u0441\u044A\u0451\u043C\u043A\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430: \u0440\u043E\u043B\u0438\u043A\u043E\u0432", videos, "\xB7 \u043A\u0430\u0434\u0440\u043E\u0432", shots, "\xB7 \u043D\u0435 \u0432\u044B\u0448\u043B\u043E", failed, stoppedBy ? "\xB7 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E: " + stoppedBy : "");
    } catch (e) {
      console.error("[FanslyAI] \u{1F3AC} \u0441\u044A\u0451\u043C\u043A\u0430 \u043A\u0430\u0434\u0440\u043E\u0432:", e);
      try {
        reportBug("exception", { src: "content", scan: "frames", ...bugStackFrames(e) });
      } catch (_) {
      }
      setStatus(t("panel.vault.frames.fail", uiLang, { n: failed || 1 }));
    } finally {
      VAULT.framesRunning = false;
      stopKeepAlive();
      phaseEnd(true);
      await vaultLockClear();
    }
  }
  async function vaultTypeSearch(input, filename, root) {
    for (let i = 0, n = -1, same = 0; i < 25 && same < 3; i++) {
      const m = vaultContentTiles(root).length;
      same = m > 0 && m === n ? same + 1 : 0;
      n = m;
      if (same < 3) await sleep(200);
    }
    const want = VaultCounts.clean(filename).toLowerCase();
    const labels = () => [...qa("vaultFileName", root)].map((el) => VaultCounts.clean(el.textContent).toLowerCase());
    const found = () => {
      const l = labels();
      return l.length > 0 && l.every((x) => x.includes(want));
    };
    const canCheck = labels().length > 0;
    const put = (v) => {
      input.value = v;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    };
    input.focus();
    put(filename);
    let res = canCheck ? "stuck" : "blind";
    for (let attempt = 0; attempt <= 2 && res === "stuck"; attempt++) {
      if (attempt) {
        if (!input.isConnected) {
          res = "gone";
          break;
        }
        if (input.value !== filename) {
          res = "user";
          break;
        }
        put(filename + " ");
        await sleep(700);
        if (input.value !== filename + " ") {
          res = "user";
          break;
        }
        put(filename);
      }
      for (let i = 0; i < 20; i++) {
        await sleep(200);
        if (found()) {
          res = attempt ? "nudged" : "ok";
          break;
        }
      }
    }
    if (res !== "ok") console.log("[FanslyAI] \u043F\u043E\u0438\u0441\u043A \u0444\u0430\u0439\u043B\u0430 \u0432 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435:", res);
    return res;
  }
  async function vaultSearchFile(filename, folders, setStatus) {
    setStatus(t("panel.vault.searching", uiLang, { name: filename.slice(0, 40) }));
    if (!(await vaultEnterVault(setStatus)).ok) {
      setStatus(t("panel.vault.searchFail", uiLang));
      return;
    }
    if (folders && folders.length) {
      const sources = vaultCollectSources();
      const src = folders.map((f) => sources.find((s) => VaultCounts.key(s.name) === VaultCounts.key(f))).find(Boolean);
      if (src) await vaultGoToSource(src, setStatus);
    }
    const findSearchBubble = () => {
      const btn = q("vaultSearchBtn");
      if (btn) return btn;
      const menu = vaultQuickMenu();
      let b = menu && [...qa("vaultBubble", menu)].find((x) => q("vaultSearchIcon", x));
      if (!b) b = [...qa("vaultBubble")].find((x) => q("vaultSearchIcon", x));
      return b || null;
    };
    let bubble = null;
    for (let i = 0; i < 25; i++) {
      bubble = findSearchBubble();
      if (bubble) break;
      await sleep(400);
    }
    if (!bubble) {
      setStatus(t("panel.vault.searchFail", uiLang));
      return;
    }
    let input = q("vaultSearchInput");
    if (!input) {
      synthClick(bubble);
      for (let i = 0; i < 20; i++) {
        await sleep(300);
        input = q("vaultSearchInput");
        if (input) break;
      }
    }
    if (!input) {
      setStatus(t("panel.vault.searchFail", uiLang));
      return;
    }
    await vaultTypeSearch(input, filename);
    setStatus(t("panel.vault.searchDone", uiLang, { name: filename.slice(0, 40) }));
  }
  function setCall(o) {
    uiLang = o && o.lang || uiLang;
    if (!VAULT.running && !VAULT.framesRunning) onPhase = o && o.onPhase || null;
  }
  async function start(o) {
    setCall(o);
    VAULT.stopRequested = false;
    const st = o && o.onProgress || (() => {
    });
    switch (o && o.mode) {
      case "check":
        return vaultCheckCounts(st, !!(o && o.periodic));
      // → { drift, drifted, snap }; periodic — при чужом скане пропуск цикла
      case "targeted":
        return vaultDoscan(st, o.folders && o.folders.drifted, o.folders && o.folders.gaps);
      case "full":
        return syncVault(st, false, null);
      case "frames":
        return vaultGrabFrames(st);
      case "sweep":
        return vaultSweepFromOverview(st);
    }
    throw new Error("VaultSync.start: \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C \xAB" + (o && o.mode) + "\xBB");
  }
  const gapFolders = () => vaultThumbGapFolders();
  function findFile(filename, folders, o) {
    setCall(o);
    return vaultSearchFile(filename, folders, o && o.onProgress || (() => {
    }));
  }
  const status = () => ({ running: VAULT.running ? "sync" : VAULT.framesRunning ? "frames" : null, stopRequested: VAULT.stopRequested });
  function stop() {
    VAULT.stopRequested = true;
    return !!(VAULT.running || VAULT.framesRunning);
  }
  const release = () => vaultLockClear();
  self.VaultSync = { init, start, stop, release, gapFolders, findFile, status, typeSearch: vaultTypeSearch };
})();
