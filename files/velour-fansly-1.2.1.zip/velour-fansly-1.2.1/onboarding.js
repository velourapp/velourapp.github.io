const INTERVIEW_SYSTEM_PROMPT = `You are a friendly onboarding assistant for an adult content creator. Your job: interview them in a warm, natural chat to learn about themselves and their offerings, so the tool can later help them reply to fans in their own voice. This is a business setup, NOT roleplay \u2014 do not flirt or be explicit.

Rules:
- Ask about ONE thing at a time. Branch naturally from their answers, acknowledge briefly, keep your messages short (1-3 sentences).
- Cover, over the conversation: how they describe themselves to fans (name/persona, a short bio); age and city (optional \u2014 skip if they'd rather not); what content/services they offer; custom-order boundaries (what they will and won't do \u2014 taboo); and what they like / dislike in how they chat with fans.
- Don't dump all questions at once. Don't use a rigid checklist tone. Sound human.
- Detect the creator's language from their replies and respond in that language.
- After you have enough (roughly 6\u201310 exchanges), tell them warmly that you have what you need and to click "Done" to review and save. Do not keep going forever.
- Never invent facts about them. If they skip something, move on.

Start by greeting them and asking how they'd describe themselves to a new fan.`;
const EXTRACT_PROMPT_FACTS = `Read the interview transcript below. Extract ONLY what the creator actually stated about themselves. Output a single JSON object, nothing else. Keys (all strings; use "" if not mentioned \u2014 never invent):
{
  "name": "",            // persona/display name they use with fans
  "age": "",             // e.g. "24" (only if stated)
  "city": "",            // only if stated
  "about": "",           // short self-description / bio, as they'd present to fans
  "taboo": "",           // what they will NOT do / off-limits
  "styleDraft": ""       // 1-2 sentence rough description of their chatting style (tone, warmth, playfulness), inferred from HOW they wrote
}
Rules: base everything strictly on the transcript. Do not add, assume, or embellish. If unsure, leave "".`;
const FLIRT_SYSTEM_PROMPT = `You are playing the role of a FAN chatting with a content creator, to help calibrate the creator's natural flirting and chatting style. This is a private calibration \u2014 the "fan" is you, not a real person. Play a believable, warm, genuinely-into-them fan the WHOLE time; make it feel real and fun, never like a survey or an interrogation. Even when you later push, stay affectionate and playful \u2014 never turn into a cold negotiator.

Your goal: over about 8\u201310 short messages, draw out the creator's FULL range \u2014 both their tender, flirty, emotional side AND their firm, business-savvy side \u2014 in ONE natural conversation. One message per turn; react to what they just said, then move on. Follow this arc:

FIRST, genuinely build warmth and a little spark \u2014 this is where their sweet, flirty voice lives, so give it real room and DON'T rush past it into business:
1. Warm compliment / praise \u2014 how do they take praise?
2. A personal, direct question \u2014 do they deflect or open up?
3. Something playful, teasing, or a light neg \u2014 how do they joke back, do they tease you in return?
4. A tender, flirty advance \u2014 let the spark build; how do they get sweet/intimate, escalate, or steer?

THEN, still warm and playful (not colder), test the firmer side:
5. A "money moment": ask for something for free or off-platform (a pic, a private call, meeting up) \u2014 do they just give in, or redirect you toward their paid content / subscription / customs?
6. Gently push once more past their first no \u2014 how do they hold a limit while staying warm? Press a little even if they seem game, so their boundary voice actually shows.

Rules:
- ONE message per turn, short (1\u20132 sentences), like a real DM.
- Give the warm/intimate part (1\u20134) genuine room BEFORE money and boundaries \u2014 a chat that's all business misses half of who they are. But you MUST still reach the money moment (5) and a boundary push (6) before wrapping.
- Keep YOUR own messages flirty but tasteful \u2014 do NOT write explicit sexual content yourself. Let the creator set the tone and explicitness; you're drawing out THEIR style, not performing yours.
- Detect the creator's language from their replies and write in it.
- Once you've covered the whole arc (around 8\u201310 exchanges), warmly say that's enough to get a real feel for them and to click "Done".

Start with message #1 \u2014 a warm compliment, as a fan.`;
const EXTRACT_PROMPT_STYLE = `Below is a short calibration chat where a content creator (labeled "Creator:") replied to a fan (labeled "AI:"). Analyze ONLY the "Creator:" lines to capture their chatting/flirting style, so we can imitate their voice later. Output a single JSON object, nothing else:
{
  "description": "",  // 2-4 sentences: tone, warmth, playfulness, how they tease, how they set boundaries and redirect pushy fans toward paid content, emoji/punctuation habits, typical message length, signature phrases. Describe the STYLE; do not quote explicit content here.
  "examples": []      // 4-8 of the creator's most characteristic short replies, VERBATIM (taken from the "Creator:" lines), that capture their voice
}
Rules: base everything strictly on the creator's own ("Creator:") messages. Do not invent. If the chat is short, extract what you can. Output only the JSON.`;
const EXTRACT_PROMPT_REALDIALOG = `Below is a content creator's CURRENT style profile, then a NEW real chat log between her ("Creator:") and a fan ("Fan:"). Produce an UPDATED, CONSOLIDATED profile that merges what is already known with what this new chat reveals \u2014 keep it TIGHT, do NOT let it grow.
Output a single JSON object, nothing else:
{
  "description": "",  // ONE tight paragraph, 3-5 sentences MAX. Merge the existing description with new traits from this chat: keep the most defining traits, cut repetition and redundancy. This REPLACES the old description and must stand alone.
  "examples": [],     // up to 15 of her best, most DIVERSE voice-rich lines, chosen from BOTH the existing examples AND this chat's Creator lines. Copy each chosen line VERBATIM \u2014 never rewrite, translate or invent a line. Prefer variety (opener, tease, boundary, upsell, humor, tender) and DROP near-duplicates. Also DROP any TRANSACTIONAL line \u2014 a specific price/amount quote, prepayment or scheduling/logistics ("2-min vid = $25", "$12 prepayment", "let me know if you're in") \u2014 even if it has flirty wording: those exact numbers do not generalize, and upsell voice is better captured by lines that tease toward paid content WITHOUT quoting figures. (A number used purely in a joke or banter, e.g. self-deprecating humor, is fine \u2014 keep those.) This REPLACES the old example list.
  "coverage": []      // which situations occurred in THIS new chat, choose from: "opener","tease","boundary","upsell","sexting","smalltalk" \u2014 list ONLY what genuinely happened
}
Rules: base the description on real behaviour (existing profile + this chat), do not invent traits. Examples must be copied VERBATIM from the provided existing examples or the Creator's real lines. Output only the JSON.`;
let uiLang = "ru";
let messages = [];
let currentSettings = null;
let busy = false;
const _modeParam = new URLSearchParams(location.search).get("mode");
let mode = _modeParam === "flirt" ? "flirt" : _modeParam === "realdialog" ? "realdialog" : "facts";
let rdTranscript = "";
let rdSourceLines = [];
const COVERAGE_ALL = ["opener", "tease", "boundary", "upsell", "sexting", "smalltalk"];
function $(id) {
  return document.getElementById(id);
}
function scrollFeedDown() {
  const feed = $("feed");
  feed.scrollTop = feed.scrollHeight;
}
function renderMessage(role, text) {
  const el = document.createElement("div");
  el.className = "msg " + role;
  el.textContent = text;
  $("feed").appendChild(el);
  scrollFeedDown();
  return el;
}
function setBusy(v) {
  busy = v;
  $("sendBtn").disabled = v;
  $("doneBtn").disabled = v;
  $("input").disabled = v;
}
function openOptions(e) {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
}
function parseFactsLeniently(raw) {
  const empty = { name: "", age: "", city: "", about: "", taboo: "", styleDraft: "" };
  if (typeof raw !== "string" || !raw.trim()) return empty;
  let s = raw.trim();
  s = s.replace(/^```[a-z]*\s*/i, "").replace(/```\s*$/i, "").trim();
  const first = s.indexOf("{");
  const last = s.lastIndexOf("}");
  if (first === -1 || last === -1 || last < first) return empty;
  s = s.slice(first, last + 1);
  let obj;
  try {
    obj = JSON.parse(s);
  } catch (e) {
    try {
      obj = JSON.parse(s.replace(/,\s*([}\]])/g, "$1"));
    } catch (e2) {
      return empty;
    }
  }
  if (!obj || typeof obj !== "object") return empty;
  const out = {};
  for (const k of Object.keys(empty)) out[k] = typeof obj[k] === "string" ? obj[k] : "";
  return out;
}
const LANG_NAMES = { en: "English", ru: "Russian", uk: "Ukrainian", es: "Spanish", pt: "Portuguese", de: "German", fr: "French", it: "Italian", pl: "Polish", tr: "Turkish" };
function chatSystemPrompt() {
  const base = mode === "flirt" ? FLIRT_SYSTEM_PROMPT : INTERVIEW_SYSTEM_PROMPT;
  const code = currentSettings && currentSettings.nativeLanguage || uiLang || "en";
  const langName = LANG_NAMES[code] || "English";
  return `${base}

LANGUAGE: Write your FIRST message in ${langName}, and keep the whole conversation in ${langName} \u2014 unless the creator clearly writes to you in a different language, then switch to match them.`;
}
function sendOnboardingChat(msgsForCall) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "ONBOARDING_CHAT", messages: msgsForCall, system: chatSystemPrompt() }, (r) => resolve(r || { success: false, error: "no response" }));
  });
}
function handleChatFailure(r) {
  if (r.blocked) {
    $("blockedBanner").classList.add("show");
  } else if (r.error === "no AI key") {
    $("keyBanner").classList.add("show");
  } else {
    renderMessage("status", t("onboarding.err.generic", uiLang));
  }
}
async function startInterview() {
  setBusy(true);
  const thinking = renderMessage("status", t("onboarding.status.thinking", uiLang));
  const r = await sendOnboardingChat([{ role: "user", content: "(start)" }]);
  thinking.remove();
  setBusy(false);
  if (!r.success) {
    handleChatFailure(r);
    return;
  }
  messages.push({ role: "assistant", content: r.text });
  renderMessage("assistant", r.text);
}
async function sendTurn() {
  if (busy) return;
  const text = $("input").value.trim();
  if (!text) return;
  $("blockedBanner").classList.remove("show");
  messages.push({ role: "user", content: text });
  const userEl = renderMessage("user", text);
  $("input").value = "";
  setBusy(true);
  const thinking = renderMessage("status", t("onboarding.status.thinking", uiLang));
  const r = await sendOnboardingChat(messages);
  thinking.remove();
  setBusy(false);
  if (!r.success) {
    messages.pop();
    userEl.remove();
    $("input").value = text;
    handleChatFailure(r);
    return;
  }
  messages.push({ role: "assistant", content: r.text });
  renderMessage("assistant", r.text);
}
function sendOnboardingExtract(extractPrompt) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "ONBOARDING_EXTRACT", messages, extractPrompt }, (r) => resolve(r || { success: false, error: "no response" }));
  });
}
function fillField(id, extracted, existing) {
  $(id).value = extracted && extracted.trim() ? extracted : existing || "";
}
async function runFactsExtraction() {
  if (busy) return;
  setBusy(true);
  const thinking = renderMessage("status", t("onboarding.status.extracting", uiLang));
  const r = await sendOnboardingExtract(EXTRACT_PROMPT_FACTS);
  thinking.remove();
  setBusy(false);
  if (!r.success) {
    handleChatFailure(r);
    return;
  }
  const facts = parseFactsLeniently(r.text);
  const s = currentSettings || {};
  const styleExisting = s.creatorProfile?.styleProfile?.description || "";
  fillField("f-name", facts.name, s.creatorName);
  fillField("f-age", facts.age, s.creatorAge);
  fillField("f-city", facts.city, s.creatorCity);
  fillField("f-about", facts.about, s.creatorAbout);
  fillField("f-taboo", facts.taboo, s.customTaboo);
  fillField("f-styleDraft", facts.styleDraft, styleExisting);
  $("previewSection").classList.add("show");
  $("previewSection").scrollIntoView({ behavior: "smooth" });
}
function parseStyleLeniently(raw) {
  const empty = { description: "", examples: [] };
  if (typeof raw !== "string" || !raw.trim()) return empty;
  let s = raw.trim().replace(/^```[a-z]*\s*/i, "").replace(/```\s*$/i, "").trim();
  const first = s.indexOf("{"), last = s.lastIndexOf("}");
  if (first === -1 || last === -1 || last < first) return empty;
  s = s.slice(first, last + 1);
  let obj;
  try {
    obj = JSON.parse(s);
  } catch (e) {
    try {
      obj = JSON.parse(s.replace(/,\s*([}\]])/g, "$1"));
    } catch (e2) {
      return empty;
    }
  }
  if (!obj || typeof obj !== "object") return empty;
  return {
    description: typeof obj.description === "string" ? obj.description : "",
    examples: Array.isArray(obj.examples) ? obj.examples.filter((x) => typeof x === "string" && x.trim()) : []
  };
}
async function runStyleExtraction() {
  if (busy) return;
  setBusy(true);
  const thinking = renderMessage("status", t("onboarding.status.extractingStyle", uiLang));
  const r = await sendOnboardingExtract(EXTRACT_PROMPT_STYLE);
  thinking.remove();
  setBusy(false);
  if (!r.success) {
    handleChatFailure(r);
    return;
  }
  const style = parseStyleLeniently(r.text);
  const sNow = currentSettings || {};
  const existing = sNow.creatorProfile?.styleProfile || {};
  $("f-styleDescription").value = style.description || existing.description || sNow.styleDescription || "";
  const exArr = style.examples.length ? style.examples : Array.isArray(existing.fewShotExamples) && existing.fewShotExamples.length ? existing.fewShotExamples : sNow.styleExamples ? sNow.styleExamples.split("\n").map((x) => x.trim()).filter(Boolean) : [];
  $("f-styleExamples").value = exArr.join("\n");
  $("stylePreviewSection").classList.add("show");
  $("stylePreviewSection").scrollIntoView({ behavior: "smooth" });
}
function switchToFlirt() {
  mode = "flirt";
  messages = [];
  $("feed").innerHTML = "";
  $("previewSection").classList.remove("show");
  $("toFlirtBtn").style.display = "none";
  $("input").value = "";
  applyModeTitles();
  startInterview();
  $("feed").scrollIntoView({ behavior: "smooth" });
}
function applyModeTitles() {
  const titleKey = mode === "flirt" ? "onboarding.flirt.title" : mode === "realdialog" ? "onboarding.rd.title" : "onboarding.title";
  const subKey = mode === "flirt" ? "onboarding.flirt.subtitle" : mode === "realdialog" ? "onboarding.rd.subtitle" : "onboarding.subtitle";
  $("ob-title").textContent = t(titleKey, uiLang);
  $("ob-sub").textContent = t(subKey, uiLang);
  $("skipToStyleRow").style.display = mode === "facts" ? "block" : "none";
  if (mode === "realdialog") {
    $("doneRow").style.display = "none";
    const ir = document.querySelector(".inputRow");
    if (ir) ir.style.display = "none";
  }
}
function saveStyle() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (sResp) => {
    const s = sResp?.result || {};
    const exArr = $("f-styleExamples").value.split("\n").map((x) => x.trim()).filter(Boolean);
    s.creatorProfile = s.creatorProfile || {};
    s.creatorProfile.styleProfile = s.creatorProfile.styleProfile || {};
    s.creatorProfile.styleProfile.description = $("f-styleDescription").value;
    s.creatorProfile.styleProfile.fewShotExamples = exArr;
    s.creatorProfile.lastUpdated = s.creatorProfile.lastUpdated || {};
    s.creatorProfile.lastUpdated.style = Date.now();
    s.styleExamples = exArr.join("\n");
    s.styleDescription = $("f-styleDescription").value;
    chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: s }, () => {
      $("styleSaveStatus").textContent = t("onboarding.status.savedStyle", uiLang);
    });
  });
}
async function startRealDialog() {
  const pending = await new Promise((res) => chrome.storage.local.get("fansly_realdialog_pending", (d) => res(d.fansly_realdialog_pending)));
  chrome.storage.local.remove("fansly_realdialog_pending");
  if (!pending || !pending.transcript) {
    renderMessage("status", t("onboarding.rd.noData", uiLang));
    return;
  }
  rdTranscript = pending.transcript;
  await runRealDialogExtraction();
}
function transcriptCreatorLines(transcript) {
  return (transcript || "").split("\n").filter((l) => /^\s*Creator:/i.test(l)).map((l) => l.replace(/^\s*Creator:\s*/i, "").trim()).filter(Boolean);
}
function normLine(x) {
  return (x || "").toLowerCase().replace(/\s+/g, " ").trim();
}
function verbatimExamples(aiExamples, sourceLines, cap) {
  const byNorm = /* @__PURE__ */ new Map();
  sourceLines.forEach((l) => {
    const n = normLine(l);
    if (n && !byNorm.has(n)) byNorm.set(n, l);
  });
  const out = [], seen = /* @__PURE__ */ new Set();
  for (const ex of aiExamples || []) {
    const n = normLine(ex), src = byNorm.get(n);
    if (src && !seen.has(n)) {
      seen.add(n);
      out.push(src);
      if (out.length >= cap) break;
    }
  }
  return out;
}
function parseRealDialog(raw) {
  const empty = { description: "", examples: [], coverage: [] };
  if (typeof raw !== "string" || !raw.trim()) return empty;
  let s = raw.trim().replace(/^```[a-z]*\s*/i, "").replace(/```\s*$/i, "").trim();
  const first = s.indexOf("{"), last = s.lastIndexOf("}");
  if (first === -1 || last === -1 || last < first) return empty;
  s = s.slice(first, last + 1);
  let obj;
  try {
    obj = JSON.parse(s);
  } catch (e) {
    try {
      obj = JSON.parse(s.replace(/,\s*([}\]])/g, "$1"));
    } catch (e2) {
      return empty;
    }
  }
  if (!obj || typeof obj !== "object") return empty;
  return {
    description: typeof obj.description === "string" ? obj.description : "",
    examples: Array.isArray(obj.examples) ? obj.examples.filter((x) => typeof x === "string" && x.trim()) : [],
    coverage: Array.isArray(obj.coverage) ? obj.coverage.filter((x) => typeof x === "string" && x.trim()) : []
  };
}
async function runRealDialogExtraction() {
  setBusy(true);
  const thinking = renderMessage("status", t("onboarding.rd.analyzing", uiLang));
  const s = currentSettings || {};
  const existingDesc = (s.styleDescription || s.creatorProfile?.styleProfile?.description || "").trim();
  const existingEx = (s.styleExamples || "").split("\n").map((x) => x.trim()).filter(Boolean);
  rdSourceLines = existingEx.concat(transcriptCreatorLines(rdTranscript));
  const profileBlock = `

CURRENT PROFILE:
Description: ${existingDesc || "(none yet)"}
Existing examples:
${existingEx.length ? existingEx.join("\n") : "(none yet)"}`;
  const r = await new Promise((res) => chrome.runtime.sendMessage(
    { type: "ONBOARDING_EXTRACT", messages: [], extractPrompt: EXTRACT_PROMPT_REALDIALOG + profileBlock, transcript: rdTranscript },
    (resp) => res(resp || { success: false, error: "no response" })
  ));
  thinking.remove();
  setBusy(false);
  if (!r.success) {
    handleChatFailure(r);
    return;
  }
  renderRealDialogPreview(parseRealDialog(r.text));
}
function renderRealDialogPreview(rd) {
  const s = currentSettings || {};
  const existingEx = (s.styleExamples || "").split("\n").map((x) => x.trim()).filter(Boolean);
  const existingDesc = (s.styleDescription || s.creatorProfile?.styleProfile?.description || "").trim();
  const verbatim = verbatimExamples(rd.examples, rdSourceLines, 15);
  const finalEx = verbatim.length ? verbatim : existingEx.slice(0, 15);
  $("f-rdDescription").value = rd.description || existingDesc;
  $("f-rdExamples").value = finalEx.join("\n");
  const found = new Set(rd.coverage.map((c) => c.toLowerCase()));
  $("rdCoverage").innerHTML = COVERAGE_ALL.map((c) => `<span class="rd-chip ${found.has(c) ? "on" : "off"}">${found.has(c) ? "\u2713" : "\u2014"} ${t("onboarding.rd.cov." + c, uiLang)}</span>`).join(" ");
  $("rdCoverageHint").textContent = COVERAGE_ALL.some((c) => !found.has(c)) ? t("onboarding.rd.covHint", uiLang) : "";
  $("realdialogSection").classList.add("show");
  $("realdialogSection").scrollIntoView({ behavior: "smooth" });
}
function saveRealDialog() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (sResp) => {
    const s = sResp?.result || {};
    const exArr = $("f-rdExamples").value.split("\n").map((x) => x.trim()).filter(Boolean);
    s.styleExamples = exArr.join("\n");
    s.styleDescription = $("f-rdDescription").value;
    s.creatorProfile = s.creatorProfile || {};
    s.creatorProfile.styleProfile = s.creatorProfile.styleProfile || {};
    s.creatorProfile.styleProfile.description = s.styleDescription;
    s.creatorProfile.styleProfile.fewShotExamples = exArr;
    s.creatorProfile.lastUpdated = s.creatorProfile.lastUpdated || {};
    s.creatorProfile.lastUpdated.realDialog = Date.now();
    chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: s }, () => {
      $("rdSaveStatus").textContent = t("onboarding.status.savedStyle", uiLang);
    });
  });
}
function saveProfile() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (sResp) => {
    const s = sResp?.result || {};
    s.creatorName = $("f-name").value;
    s.creatorAge = $("f-age").value;
    s.creatorCity = $("f-city").value;
    s.creatorAbout = $("f-about").value;
    s.customTaboo = $("f-taboo").value;
    s.creatorProfile = s.creatorProfile || {};
    s.creatorProfile.styleProfile = s.creatorProfile.styleProfile || {};
    s.creatorProfile.styleProfile.description = $("f-styleDraft").value;
    s.creatorProfile.lastUpdated = s.creatorProfile.lastUpdated || {};
    s.creatorProfile.lastUpdated.facts = Date.now();
    chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: s }, () => {
      $("saveStatus").textContent = t("onboarding.status.saved", uiLang);
      $("toFlirtBtn").style.display = "block";
    });
  });
}
document.addEventListener("DOMContentLoaded", () => {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (sResp) => {
    currentSettings = sResp?.result || {};
    uiLang = currentSettings.interfaceLanguage || "ru";
    applyI18n(document, uiLang);
    applyModeTitles();
    if (mode === "realdialog") startRealDialog();
    else startInterview();
  });
  $("sendBtn").addEventListener("click", sendTurn);
  $("input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendTurn();
    }
  });
  $("doneBtn").addEventListener("click", () => mode === "flirt" ? runStyleExtraction() : runFactsExtraction());
  $("saveBtn").addEventListener("click", saveProfile);
  $("toFlirtBtn").addEventListener("click", switchToFlirt);
  $("saveStyleBtn").addEventListener("click", saveStyle);
  $("saveRealDialogBtn").addEventListener("click", saveRealDialog);
  $("skipToStyleLink").addEventListener("click", (e) => {
    e.preventDefault();
    if (!busy) switchToFlirt();
  });
  $("keyBannerLink").addEventListener("click", openOptions);
});
