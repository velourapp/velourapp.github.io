(function() {
  "use strict";
  let getSettings, saveSettings, bugLog, bugProxyFail, netFailKind, fetchWithTimeout, consentGiven, consentError, DEFAULT_SETTINGS, CALL_KINDS, NO_DASH_RULE_TRANSLATE, BUILD, PLATFORM;
  let buildPrompt, parseDialogueResponse, ctxTimeout, buildDossierPrompt;
  function init(deps) {
    ({ getSettings, saveSettings, bugLog, bugProxyFail, netFailKind, fetchWithTimeout, consentGiven, consentError, DEFAULT_SETTINGS, CALL_KINDS, NO_DASH_RULE_TRANSLATE, BUILD, PLATFORM } = deps);
  }
  function initFull(deps) {
    ({ buildPrompt, parseDialogueResponse, ctxTimeout, buildDossierPrompt } = deps);
  }
  const MODELS = {
    gemini: "gemini-3.5-flash",
    groq: "llama-3.1-8b-instant",
    // генерация ответов и запасной путь досье
    groqChat: "llama-3.3-70b-versatile",
    // чат провайдера и Groq-резерв каскада
    openrouter: "meta-llama/llama-3.3-70b-instruct",
    claude: "claude-haiku-4-5-20251001",
    ollama: "llama3"
    // адаптер Ollama живёт в @cws-cut, имя — просто строка
  };
  Object.freeze(MODELS);
  const TR_CACHE_MAX_ENTRIES = 5e3;
  const TR_CACHE_MAX_BYTES = 2 * 1024 * 1024;
  const TR_CACHE_KEEP = 0.8;
  const TR_CACHE_SWEEP_EVERY = 200;
  const TR_CACHE_MARK = "fansly_trcache_v2";
  let _trPuts = 0;
  function trCacheUnpack(raw) {
    if (typeof raw === "string") return raw || null;
    if (raw && typeof raw === "object" && typeof raw.v === "string" && raw.v) return raw.v;
    return null;
  }
  function trEntryBytes(key, raw) {
    return String(key).length + (typeof raw === "string" ? raw.length + 2 : JSON.stringify(raw ?? "").length);
  }
  function trCacheEvictionPlan(entries, limits = {}) {
    const maxEntries = limits.maxEntries ?? TR_CACHE_MAX_ENTRIES;
    const maxBytes = limits.maxBytes ?? TR_CACHE_MAX_BYTES;
    const keep = limits.keep ?? TR_CACHE_KEEP;
    let count = entries.length;
    let bytes = entries.reduce((n, e) => n + (e.bytes || 0), 0);
    if (count <= maxEntries && bytes <= maxBytes) return [];
    const targetEntries = Math.floor(maxEntries * keep), targetBytes = Math.floor(maxBytes * keep);
    const sorted = [...entries].sort((a, b) => (a.t || 0) - (b.t || 0) || String(a.key).localeCompare(String(b.key)));
    const out = [];
    for (const e of sorted) {
      if (count <= targetEntries && bytes <= targetBytes) break;
      out.push(e.key);
      count -= 1;
      bytes -= e.bytes || 0;
    }
    return out;
  }
  async function trCacheGet(key) {
    const raw = await new Promise((r) => chrome.storage.local.get([key], (d) => r(d[key])));
    return trCacheUnpack(raw);
  }
  function trCachePut(key, value) {
    chrome.storage.local.set({ [key]: { v: value, t: Date.now() } });
    _trPuts += 1;
    if (_trPuts % TR_CACHE_SWEEP_EVERY === 0) trCacheSweep().catch(() => {
    });
  }
  let _trSweeping = null;
  function trCacheSweep() {
    if (_trSweeping) return _trSweeping;
    _trSweeping = new Promise((resolve) => {
      chrome.storage.local.get(null, (all) => {
        const entries = [];
        for (const k of Object.keys(all || {})) {
          if (!k.startsWith("tr_")) continue;
          const raw = all[k];
          entries.push({ key: k, t: raw && typeof raw === "object" && Number(raw.t) || 0, bytes: trEntryBytes(k, raw) });
        }
        const victims = trCacheEvictionPlan(entries);
        const bytes = entries.reduce((n, e) => n + e.bytes, 0);
        const done = () => resolve({ entries: entries.length, bytes, removed: victims.length });
        if (!victims.length) {
          done();
          return;
        }
        chrome.storage.local.remove(victims, () => {
          console.log(`[FanslyAI] \u{1F310} \u043A\u0435\u0448 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432: \u0437\u0430\u043F\u0438\u0441\u0435\u0439 ${entries.length}, ~${Math.round(bytes / 1024)} \u041A\u0411 \u2192 \u0443\u0431\u0440\u0430\u043D\u043E \u0441\u0442\u0430\u0440\u044B\u0445 ${victims.length}`);
          done();
        });
      });
    }).finally(() => {
      _trSweeping = null;
    });
    return _trSweeping;
  }
  function trCacheMigrateOnce() {
    chrome.storage.local.get(TR_CACHE_MARK, (d) => {
      if (d && d[TR_CACHE_MARK]) return;
      trCacheSweep().then(() => chrome.storage.local.set({ [TR_CACHE_MARK]: 1 })).catch(() => {
      });
    });
  }
  self.__faiTrCache = async function() {
    const used = chrome.storage.local.getBytesInUse ? await new Promise((r) => chrome.storage.local.getBytesInUse(null, (b) => r(b || 0))) : null;
    const all = await new Promise((r) => chrome.storage.local.get(null, r));
    let entries = 0, legacy = 0, bytes = 0, oldest = Infinity, newest = 0;
    for (const k of Object.keys(all)) {
      if (!k.startsWith("tr_")) continue;
      const raw = all[k];
      entries += 1;
      bytes += trEntryBytes(k, raw);
      const t2 = raw && typeof raw === "object" && Number(raw.t) || 0;
      if (!t2) legacy += 1;
      else {
        oldest = Math.min(oldest, t2);
        newest = Math.max(newest, t2);
      }
    }
    const out = {
      entries,
      legacy,
      kb: Math.round(bytes / 1024),
      storageUsedKb: used == null ? null : Math.round(used / 1024),
      maxEntries: TR_CACHE_MAX_ENTRIES,
      maxKb: Math.round(TR_CACHE_MAX_BYTES / 1024),
      oldest: oldest === Infinity ? null : new Date(oldest).toISOString(),
      newest: newest ? new Date(newest).toISOString() : null
    };
    console.log("[FanslyAI] \u043A\u0435\u0448 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432:", JSON.stringify(out));
    return out;
  };
  self.__faiTrCacheSweep = () => trCacheSweep().then((r) => {
    console.log("[FanslyAI] \u0447\u0438\u0441\u0442\u043A\u0430 \u043A\u0435\u0448\u0430 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432:", JSON.stringify(r));
    return r;
  });
  function salvagePartialAnalysis(raw) {
    const facts = [];
    const fm = raw.match(/"facts"\s*:\s*\[([\s\S]*?)(?:\]|$)/);
    if (fm) {
      const items = fm[1].match(/"((?:[^"\\]|\\.)*)"/g) || [];
      for (const s of items) {
        try {
          const v = JSON.parse(s);
          if (v && v.length > 2) facts.push(v);
        } catch (_) {
        }
      }
    }
    if (!facts.length) return null;
    const cm = raw.match(/"closeness"\s*:\s*"(new|interested|regular|supporter)"/);
    return { facts, closeness: cm ? cm[1] : "new", topics: [], brief: { wants: "", details: [], mood: "", refs: [] } };
  }
  const DOSSIER_MAX_CHARS = 2e4;
  const DOSSIER_MAX_TOKENS = 4096;
  const DOSSIER_CHUNK_PARALLEL = 2;
  function dossierGroups(msgs, maxChars = DOSSIER_MAX_CHARS) {
    const groups = [];
    let cur = [], curLen = 0;
    for (const m of msgs) {
      const len = (m.text || "").length + 24;
      if (curLen + len > maxChars && cur.length) {
        groups.push(cur);
        cur = [];
        curLen = 0;
      }
      cur.push(m);
      curLen += len;
    }
    if (cur.length) groups.push(cur);
    return groups;
  }
  function dossierParse(raw, finishReason) {
    const cut = finishReason === "length";
    if (!raw) return { parsed: null, truncated: cut, how: cut ? "length" : "" };
    const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
    if (s !== -1 && e > s) {
      try {
        return { parsed: JSON.parse(raw.slice(s, e + 1).replace(/[\x00-\x1F\x7F]/g, " ")), truncated: false, how: "" };
      } catch (_) {
      }
    }
    const salvaged = salvagePartialAnalysis(raw);
    return { parsed: salvaged, truncated: cut || !!salvaged, how: cut ? "length" : salvaged ? "json" : "" };
  }
  async function analyzeHistory(history, fanName, opts = {}) {
    const settings = await getSettings();
    const msgs = (history || []).filter((m) => m.text && !m.isMedia);
    const known = (opts.knownFacts || []).filter((f) => f && f.trim());
    const tailMsgs = (opts.contextTail || []).filter((m) => m.text && !m.isMedia);
    const isDelta = opts.mode === "delta";
    const dossierKind = opts.manual ? "dossier" : "dossier_auto";
    const groupTop = (g) => g.reduce((mx, m) => m.ts && m.ts > mx ? m.ts : mx, 0);
    const safeUpTo = (groups, okFlags) => {
      let upTo = 0;
      for (let i = 0; i < groups.length; i++) {
        if (!okFlags[i]) break;
        const t2 = groupTop(groups[i]);
        if (t2 > upTo) upTo = t2;
      }
      return upTo;
    };
    console.log(`[FanslyAI] analyzeHistory start | \u0440\u0435\u0436\u0438\u043C: ${isDelta ? "\u0434\u0435\u043B\u044C\u0442\u0430" : "\u043F\u043E\u043B\u043D\u044B\u0439"} | msgs: ${msgs.length} | \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442: ${tailMsgs.length} | \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0445 \u0444\u0430\u043A\u0442\u043E\u0432: ${known.length} | openrouter: ${!!settings.openrouterApiKey}`);
    if (!msgs.length) return { success: false, error: "No text messages" };
    if (!msgs.some((m) => m.role === "subscriber")) return { success: false, error: "No subscriber messages" };
    const fmt = (arr) => arr.map((m) => `${m.role === "subscriber" ? fanName || "Fan" : "Creator"}: ${m.text}`).join("\n");
    const tailText = tailMsgs.length ? fmt(tailMsgs) : "";
    async function geminiChunk(convo) {
      const model = settings.geminiModel || MODELS.gemini;
      try {
        const r = await fetchWithTimeout(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${settings.geminiApiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ role: "user", parts: [{ text: buildDossierPrompt({ convo, tailText, known, isDelta }) }] }],
              // текст переписки отправляется КАК ЕСТЬ
              generationConfig: { temperature: 0.1, maxOutputTokens: 2048 },
              safetySettings: [
                { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_CIVIC_INTEGRITY", threshold: "BLOCK_NONE" }
              ]
            })
          },
          45e3
        );
        const data = await r.json();
        if (data.error) {
          console.warn("[FanslyAI] analyze gemini err:", (data.error.message || "").slice(0, 80));
          return "";
        }
        return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
      } catch (e) {
        console.warn("[FanslyAI] analyze gemini exc:", e.message);
        return "";
      }
    }
    async function groqChunk(convo, maxTok) {
      try {
        const r = await fetchWithTimeout("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: { "Authorization": `Bearer ${settings.groqApiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: MODELS.groq, messages: [{ role: "user", content: buildDossierPrompt({ convo, tailText, known, isDelta }) }], max_tokens: maxTok || 1024, temperature: 0.1 })
        }, 45e3);
        const data = await r.json();
        if (data.error) return { text: "", error: (data.error.message || "").slice(0, 140) };
        return { text: data.choices?.[0]?.message?.content || "", error: "" };
      } catch (e) {
        return { text: "", error: e.message };
      }
    }
    function matchFactDate(factText, chunkMsgs) {
      const fan = chunkMsgs.filter((m) => m.role === "subscriber" && m.ts);
      if (!fan.length) return null;
      const stems = (factText.toLowerCase().match(/[\p{L}]{4,}/gu) || []).map((w) => w.slice(0, 4));
      if (!stems.length) return fan[fan.length - 1].ts;
      let best = null, bestScore = 0;
      for (const m of fan) {
        const mw = m.text.toLowerCase().match(/[\p{L}]{3,}/gu) || [];
        let score = 0;
        for (const s of stems) if (mw.some((w) => w.startsWith(s))) score++;
        if (score >= bestScore) {
          bestScore = score;
          best = m;
        }
      }
      return bestScore > 0 ? best.ts : null;
    }
    function resolveBriefDate(brief) {
      const txt = [brief?.wants, ...brief?.details || []].filter(Boolean).join(" ").trim();
      return txt ? matchFactDate(txt, msgs) : null;
    }
    let gWin = Date.now(), gCalls = 0;
    async function geminiPace() {
      if (Date.now() - gWin >= 6e4) {
        gWin = Date.now();
        gCalls = 0;
      }
      if (gCalls >= 14) {
        const w = 6e4 - (Date.now() - gWin) + 500;
        console.log(`[FanslyAI] analyze: \u043F\u0430\u0443\u0437\u0430 ${Math.round(w / 1e3)}\u0441 \u043F\u043E\u0434 RPM Gemini`);
        await new Promise((r) => setTimeout(r, w));
        gWin = Date.now();
        gCalls = 0;
      }
      gCalls++;
    }
    let qWin = Date.now(), qTok = 0;
    async function groqPace(est) {
      if (Date.now() - qWin >= 6e4) {
        qWin = Date.now();
        qTok = 0;
      }
      if (qTok + est > 5500) {
        const w = 6e4 - (Date.now() - qWin) + 500;
        console.log(`[FanslyAI] analyze: \u043F\u0430\u0443\u0437\u0430 ${Math.round(w / 1e3)}\u0441 \u043F\u043E\u0434 TPM Groq`);
        await new Promise((r) => setTimeout(r, w));
        qWin = Date.now();
        qTok = 0;
      }
      qTok += est;
    }
    if (providerReady("openrouter", settings)) {
      const groups = dossierGroups(msgs);
      const acc2 = { facts: [], closeness: "new", topics: [], brief: { wants: "", details: [], mood: "", refs: [] }, factDates: {} };
      const seen2 = /* @__PURE__ */ new Set();
      const levels2 = ["new", "interested", "regular", "supporter"];
      let ok = 0, used = 0, lastErr = "", quotaHit = null;
      const parsed = new Array(groups.length).fill(null);
      const salvaged = new Array(groups.length).fill(null);
      const retryable = new Array(groups.length).fill(false);
      const worthRetry = (r) => !!r && !r.quotaExhausted && !r.saturated && !r.rateLimited && !r.upstreamBusy;
      const runGroup = async (gi) => {
        const g = groups[gi];
        const r = await chatOpenRouter(
          [{ role: "user", content: buildDossierPrompt({ convo: fmt(g), tailText, known, isDelta }) }],
          null,
          settings,
          { maxTokens: DOSSIER_MAX_TOKENS, temperature: 0.1, kind: dossierKind }
        );
        if (!r?.success || !r.text) {
          if (r?.quotaExhausted) {
            quotaHit = r;
            return;
          }
          retryable[gi] = worthRetry(r);
          lastErr = r?.error || t("bg.err.emptyAnswer", settings.interfaceLanguage || "ru");
          console.warn(`[FanslyAI] analyze OR ${gi + 1}/${groups.length}: ${lastErr}`);
          return;
        }
        const { parsed: p, truncated, how } = dossierParse(r.text, r.finishReason);
        if (!p) {
          retryable[gi] = true;
          lastErr = t("bg.err.unparsedAnswer", settings.interfaceLanguage || "ru");
          console.warn(`[FanslyAI] analyze OR ${gi + 1}/${groups.length}: \u043D\u0435 \u0440\u0430\u0437\u043E\u0431\u0440\u0430\u043B\u0441\u044F \u043E\u0442\u0432\u0435\u0442${how === "length" ? " (\u043E\u0431\u0440\u0435\u0437\u0430\u043D \u043F\u043E max_tokens)" : ""}`);
          return;
        }
        if (truncated) {
          if (!salvaged[gi] || (p.facts || []).length > (salvaged[gi].facts || []).length) salvaged[gi] = p;
          retryable[gi] = true;
          lastErr = t("bg.err.cutAnswer", settings.interfaceLanguage || "ru");
          console.warn(`[FanslyAI] analyze OR ${gi + 1}/${groups.length}: \u043E\u0442\u0432\u0435\u0442 \u043E\u0431\u0440\u0435\u0437\u0430\u043D (${how === "length" ? "\u0443\u043F\u043E\u0440 \u0432 max_tokens" : "JSON \u043D\u0435 \u0437\u0430\u043A\u0440\u044B\u0442"}), \u0441\u043F\u0430\u0441\u0435\u043D\u043E \u0444\u0430\u043A\u0442\u043E\u0432: ${(p.facts || []).length} \u2014 \u0433\u0440\u0443\u043F\u043F\u0430 \u043F\u043E\u0439\u0434\u0451\u0442 \u043D\u0430 \u043F\u043E\u0432\u0442\u043E\u0440`);
          return;
        }
        parsed[gi] = p;
        retryable[gi] = false;
      };
      const runWindow = async (idxs) => {
        for (let base = 0; base < idxs.length; base += DOSSIER_CHUNK_PARALLEL) {
          await Promise.all(idxs.slice(base, base + DOSSIER_CHUNK_PARALLEL).map(runGroup));
          if (quotaHit) return false;
        }
        return true;
      };
      if (!await runWindow(groups.map((_, i) => i))) return { success: false, quotaExhausted: true, subscriptionExpired: quotaHit.subscriptionExpired === true, error: quotaHit.error };
      const again = groups.map((_, i) => i).filter((i) => !parsed[i] && retryable[i]);
      if (again.length) {
        console.warn(`[FanslyAI] analyze OR: \u043F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0440\u0432\u0430\u0432\u0448\u0438\u0445\u0441\u044F \u043A\u0443\u0441\u043A\u043E\u0432 \u2014 ${again.map((i) => i + 1).join(", ")}`);
        if (!await runWindow(again)) return { success: false, quotaExhausted: true, subscriptionExpired: quotaHit.subscriptionExpired === true, error: quotaHit.error };
      }
      for (let gi = 0; gi < groups.length; gi++) {
        const p = parsed[gi] || salvaged[gi];
        if (!p) continue;
        if (parsed[gi]) ok++;
        used++;
        (p.facts || []).forEach((f) => {
          const tx = f?.trim();
          if (!tx || tx.length <= 3) return;
          const dt = matchFactDate(tx, msgs);
          if (!seen2.has(tx)) {
            seen2.add(tx);
            acc2.facts.push(tx);
            if (dt) acc2.factDates[tx] = dt;
          } else if (dt && dt > (acc2.factDates[tx] || 0)) acc2.factDates[tx] = dt;
        });
        if (p.closeness && levels2.includes(p.closeness) && levels2.indexOf(p.closeness) > levels2.indexOf(acc2.closeness)) acc2.closeness = p.closeness;
        (p.topics || []).forEach((tp) => {
          const x = tp?.trim();
          if (x && !acc2.topics.includes(x)) acc2.topics.push(x);
        });
        if (p.brief) {
          if (p.brief.wants?.trim()) acc2.brief.wants = p.brief.wants.trim();
          if (p.brief.mood?.trim()) acc2.brief.mood = p.brief.mood.trim();
          (p.brief.details || []).forEach((d) => {
            const x = d?.trim();
            if (x && !acc2.brief.details.includes(x)) acc2.brief.details.push(x);
          });
          (p.brief.refs || []).forEach((rf) => {
            const x = rf?.trim();
            if (x && !acc2.brief.refs.includes(x)) acc2.brief.refs.push(x);
          });
        }
        console.log(`[FanslyAI] analyze OR ${gi + 1}/${groups.length} \u2192 +${p.facts?.length || 0} (\u0432\u0441\u0435\u0433\u043E ${acc2.facts.length})${parsed[gi] ? "" : " [\u0441\u043F\u0430\u0441\u0435\u043D\u043E \u0438\u0437 \u043E\u0431\u0440\u0435\u0437\u0430\u043D\u043D\u043E\u0433\u043E \u043E\u0442\u0432\u0435\u0442\u0430]"}`);
      }
      if (used) {
        const upTo = safeUpTo(groups, parsed.map(Boolean));
        if (upTo) acc2.analyzedUpTo = upTo;
        acc2.datesResolved = true;
        {
          const bd = resolveBriefDate(acc2.brief);
          if (bd) acc2.brief.collectedAt = bd;
        }
        const holes = groups.length - ok;
        const cut = salvaged.filter((s, i) => s && !parsed[i]).length;
        if (holes) acc2.partial = true;
        console.log(`[FanslyAI] analyzeHistory \u0433\u043E\u0442\u043E\u0432\u043E | openrouter | ${dossierKind} | \u0433\u0440\u0443\u043F\u043F ${groups.length} (\u043D\u0435 \u0440\u0430\u0437\u043E\u0431\u0440\u0430\u043D\u043E ${holes}, \u0438\u0437 \u043D\u0438\u0445 \u043E\u0431\u0440\u0435\u0437\u0430\u043D\u043E ${cut}) | \u0444\u0430\u043A\u0442\u043E\u0432 ${acc2.facts.length} | \u0437\u043D\u0430\u043A ${upTo ? new Date(upTo).toISOString().slice(0, 10) : "\u041D\u0415 \u0441\u0442\u0430\u0432\u0438\u043C"}`);
        if (!acc2.facts.length && !acc2.brief.wants) return { success: false, error: t("bg.err.nothingExtracted", settings.interfaceLanguage || "ru"), analyzedUpTo: acc2.analyzedUpTo };
        return { success: true, result: acc2 };
      }
      if (proxyOn(settings)) {
        console.warn("[FanslyAI] analyzeHistory: \u043E\u0431\u043B\u0430\u043A\u043E \u043D\u0435 \u0434\u0430\u043B\u043E \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430 (" + lastErr + ") \u2014 \u0437\u0430\u043F\u0430\u0441\u043D\u043E\u0439 \u043F\u0443\u0442\u044C \u043D\u0430 \u0441\u0432\u043E\u0438\u0445 \u043A\u043B\u044E\u0447\u0430\u0445 \u043F\u0440\u0438 \u043E\u0431\u043B\u0430\u043A\u0435 \u041D\u0415 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C");
        return { success: false, error: lastErr || t("bg.err.nothingExtracted", settings.interfaceLanguage || "ru") };
      }
      console.warn("[FanslyAI] analyzeHistory: OpenRouter \u043D\u0435 \u0434\u0430\u043B \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430 (" + lastErr + ") \u2192 \u043E\u0442\u043A\u0430\u0442 \u043D\u0430 Gemini/Groq");
    } else {
      console.log("[FanslyAI] analyzeHistory: \u043A\u043B\u044E\u0447\u0430 OpenRouter \u043D\u0435\u0442 \u2192 \u0441\u0442\u0430\u0440\u044B\u0439 \u043F\u0443\u0442\u044C Gemini\u2192Groq (\u043F\u0430\u0447\u043A\u0430\u043C\u0438, \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u043E \u043D\u0438\u0436\u0435)");
    }
    const CHUNK = 70;
    const totalChunks = Math.ceil(msgs.length / CHUNK);
    const acc = { facts: [], closeness: "new", topics: [], brief: { wants: "", details: [], mood: "", refs: [] }, factDates: {} };
    const seen = /* @__PURE__ */ new Set();
    const levels = ["new", "interested", "regular", "supporter"];
    let viaG = 0, viaQ = 0, fail = 0, c = 0;
    const fbGroups = [], fbOk = [];
    for (let i = 0; i < msgs.length; i += CHUNK) {
      c++;
      const chunk = msgs.slice(i, i + CHUNK);
      fbGroups.push(chunk);
      fbOk.push(false);
      const chunkTs = chunk.reduce((mx, m) => m.ts && m.ts > mx ? m.ts : mx, 0) || Date.now();
      let raw = "", via = "gemini";
      if (settings.geminiApiKey) {
        await geminiPace();
        raw = await geminiChunk(fmt(chunk));
      }
      if (!raw && settings.groqApiKey) {
        const sub = fmt(chunk.filter((m) => m.role === "subscriber"));
        await groqPace(Math.ceil(sub.length / 4) + 1024 + 200);
        const gr = await groqChunk(sub, 1024);
        if (gr.error) console.warn(`[FanslyAI] analyze \u043A\u0443\u0441\u043E\u043A ${c}/${totalChunks} Groq:`, gr.error);
        raw = gr.text;
        via = "groq";
      }
      const p = dossierParse(raw).parsed;
      if (p) {
        fbOk[fbOk.length - 1] = true;
        via === "gemini" ? viaG++ : viaQ++;
        (p.facts || []).forEach((f) => {
          const t2 = f?.trim();
          if (!t2 || t2.length <= 3) return;
          const dt = matchFactDate(t2, chunk) || chunkTs;
          if (!seen.has(t2)) {
            seen.add(t2);
            acc.facts.push(t2);
            acc.factDates[t2] = dt;
          } else if (dt > (acc.factDates[t2] || 0)) acc.factDates[t2] = dt;
        });
        if (p.closeness && levels.includes(p.closeness) && levels.indexOf(p.closeness) > levels.indexOf(acc.closeness)) acc.closeness = p.closeness;
        (p.topics || []).forEach((t2) => {
          const x = t2?.trim();
          if (x && !acc.topics.includes(x)) acc.topics.push(x);
        });
        if (p.brief) {
          if (p.brief.wants?.trim()) acc.brief.wants = p.brief.wants.trim();
          if (p.brief.mood?.trim()) acc.brief.mood = p.brief.mood.trim();
          (p.brief.details || []).forEach((d) => {
            const x = d?.trim();
            if (x && !acc.brief.details.includes(x)) acc.brief.details.push(x);
          });
          (p.brief.refs || []).forEach((rf) => {
            const x = rf?.trim();
            if (x && !acc.brief.refs.includes(x)) acc.brief.refs.push(x);
          });
        }
        console.log(`[FanslyAI] analyze \u043A\u0443\u0441\u043E\u043A ${c}/${totalChunks} \u2192 ${via} \u2192 +${p.facts?.length || 0} (\u0432\u0441\u0435\u0433\u043E ${acc.facts.length})`);
      } else {
        fail++;
        console.warn(`[FanslyAI] analyze \u043A\u0443\u0441\u043E\u043A ${c}/${totalChunks} \u2192 ${via} \u2192 \u043F\u0443\u0441\u0442\u043E`);
      }
      await new Promise((r) => setTimeout(r, 300));
    }
    const fbUpTo = safeUpTo(fbGroups, fbOk);
    if (fbUpTo) acc.analyzedUpTo = fbUpTo;
    if (fail) acc.partial = true;
    {
      const bd = resolveBriefDate(acc.brief);
      if (bd) acc.brief.collectedAt = bd;
    }
    console.log(`[FanslyAI] analyzeHistory \u0433\u043E\u0442\u043E\u0432\u043E | \u043F\u0430\u0447\u043A\u0430\u043C\u0438 | \u043A\u0443\u0441\u043A\u043E\u0432 ${totalChunks} | Gemini ${viaG} \xB7 Groq ${viaQ} \xB7 \u043F\u0443\u0441\u0442\u043E ${fail} | \u0444\u0430\u043A\u0442\u043E\u0432 ${acc.facts.length} | \u0437\u043D\u0430\u043A ${fbUpTo ? new Date(fbUpTo).toISOString().slice(0, 10) : "\u041D\u0415 \u0441\u0442\u0430\u0432\u0438\u043C"}`);
    if (!acc.facts.length && !acc.brief.wants) return { success: false, error: t("bg.err.nothingExtracted", settings.interfaceLanguage || "ru"), analyzedUpTo: acc.analyzedUpTo };
    return { success: true, result: acc };
  }
  const lang2 = (l) => String(l || "").toLowerCase().split(/[-_]/)[0];
  function isOutgoingTarget(targetLang, settings) {
    const native = lang2(settings && settings.nativeLanguage), target = lang2(targetLang);
    return !!native && !!target && target !== native;
  }
  function fanLangDiffers(fanLang, targetLang) {
    const fan = lang2(fanLang), target = lang2(targetLang);
    return !!fan && !!target && fan !== target;
  }
  function alreadyInTargetLang(text, targetLang) {
    const cyr = (text.match(/[а-яёіїєґ]/gi) || []).length;
    const lat = (text.match(/[a-z]/gi) || []).length;
    const tl = (targetLang || "").toLowerCase();
    if (["ru", "uk"].includes(tl)) return cyr > 0 && cyr >= lat;
    if (tl === "en") return lat > 0 && cyr === 0;
    return false;
  }
  function trOutputProblem(out, src, targetLang) {
    const o = String(out || "").trim(), s = String(src || "").trim();
    if (!o) return "";
    const REFUSAL = /\b(?:can(?:no|['’])t|unable to|not able to)\s+(?:help|assist)(?:\s+you)?\s+with\s+(?:that|this)\b|\b(?:can(?:no|['’])t|unable to|not able to)\s+(?:fulfil|comply|assist)|\bas an ai\b|no puedo ayudar|ne (?:peux|puis) pas (?:vous |t['’])?aider|non posso aiutar|não posso ajudar|не могу (?:вам |тебе )?(?:с этим )?помочь/i;
    const HELP_SRC = /(помо[чгщ]|с этим|help|assist|with (?:that|this)|ayud|aider|aiut|ajud|pom[oó]c)/i;
    if (o.length <= 300 && REFUSAL.test(o) && !HELP_SRC.test(s)) return "refusal";
    const META_SRC = /(translat|translit|traduc|traduz|tradu[ií]r|tradurr|перев[оеё]д|перевест|переклад|übersetz|tłumacz|přelož)/i;
    const META_OUT = /(translat|translit|traduc|traduz|tradu[ií]r|tradurr|переклад|übersetz|tłumacz|přelož)|(перев[оеё]д|перевест)[\s\S]{0,40}(текст|сообщени)|(текст|сообщени)[\s\S]{0,40}(перев[оеё]д|перевест)/i;
    if (META_OUT.test(o) && !META_SRC.test(s)) return "comment";
    if (/\n\s*\n/.test(o) && !/\n/.test(s)) return "comment";
    const LATIN = ["en", "es", "de", "fr", "it", "pt", "pl", "cs", "tr", "nl", "sv", "da", "no", "nb", "fi", "ro", "hu", "sk", "sl", "hr", "lt", "lv", "et", "id", "ms"];
    const norm = (x) => x.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
    if (LATIN.includes(String(targetLang || "").toLowerCase().split(/[-_]/)[0]) && /[\u0400-\u04FF]/.test(s) && norm(o) === norm(s)) return "untranslated";
    return "";
  }
  function trGuard(r, src, targetLang, engine) {
    if (!r || !r.success) return r;
    const bad = trOutputProblem(r.result, src, targetLang);
    if (!bad) return r;
    console.warn(`[FanslyAI] \u{1F310} \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u043E\u0442\u043A\u043B\u043E\u043D\u0451\u043D (${bad}, ${engine}) \u2192 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A`);
    return { success: false, error: "rejected: " + bad, rejected: bad };
  }
  function trCacheDrop(key) {
    try {
      chrome.storage.local.remove(key);
    } catch (e) {
    }
  }
  const trCacheKey = (targetLang, hash, g, tg) => `tr_${targetLang}_${g || ""}${tg ? "_to" + tg : ""}_${hash}`;
  function hashText(str) {
    let h1 = 3735928559, h2 = 1103547991;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  const GENDERED_TARGETS = /* @__PURE__ */ new Set(["ru", "uk", "pl", "cs", "es", "fr", "it", "pt"]);
  function targetNeedsGender(lang) {
    return GENDERED_TARGETS.has(String(lang || "").toLowerCase().split(/[-_]/)[0]);
  }
  const TR_FALLBACK_PARALLEL = 3;
  const TR_CTX_NOCACHE_CHARS = 20;
  async function handleTranslateBatch(texts, targetLang, genderHint = null, toGender = null, cheapOnly = false, ctx = null, fanLang = null) {
    const list = Array.isArray(texts) ? texts : [];
    if (!list.length) return { success: true, results: [] };
    if ((await getSettings()).translatorEnabled === false) return { success: true, results: list.map(() => null), translatorOff: true };
    const results = new Array(list.length).fill(null);
    const needGender = BUILD === "full" && !!(genderHint || toGender) && targetNeedsGender(targetLang);
    const keyOf = (text, withGender) => trCacheKey(targetLang, hashText(text.trim()), withGender ? genderHint : "", withGender ? toGender : "");
    let ctxOn = needGender && Array.isArray(ctx) && ctx.length > 0;
    if (ctxOn && (await getSettings()).translateContext === false) ctxOn = false;
    const ctxShort = (text) => ctxOn && text.trim().length < TR_CTX_NOCACHE_CHARS;
    const byLetters = !fanLangDiffers(fanLang, targetLang);
    const pending = [];
    for (let i = 0; i < list.length; i++) {
      const text = list[i];
      if (!text?.trim()) {
        results[i] = { result: "", genderSafe: true, retryAfterMs: 0 };
        continue;
      }
      if (!/[\p{L}\p{N}]/u.test(text) || byLetters && alreadyInTargetLang(text.trim(), targetLang)) {
        results[i] = { result: text, genderSafe: true, retryAfterMs: 0 };
        continue;
      }
      if (ctxShort(text)) {
        pending.push(i);
        continue;
      }
      const key = keyOf(text, needGender);
      const cached = await trCacheGet(key);
      const cachedBad = cached ? trOutputProblem(cached, text, targetLang) : "";
      if (cached && !cachedBad) {
        results[i] = { result: cached, genderSafe: true, retryAfterMs: 0 };
        continue;
      }
      if (cachedBad) {
        console.warn(`[FanslyAI] \u{1F310} \u0432 \u043A\u0435\u0448\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u043B\u0435\u0436\u0430\u043B \u043D\u0435\u0433\u043E\u0434\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 (${cachedBad}) \u2192 \u0432\u044B\u0431\u0440\u043E\u0448\u0435\u043D, \u043F\u0435\u0440\u0435\u0432\u043E\u0436\u0443 \u0437\u0430\u043D\u043E\u0432\u043E`);
        trCacheDrop(key);
      }
      pending.push(i);
    }
    if (cheapOnly || !pending.length) return { success: true, results };
    let skipLlm = false;
    if (needGender) {
      const s = await getSettings();
      const uniq = [...new Set(pending.map((i) => list[i]))];
      const liveCtx = ctxOn ? ctx : null;
      let batch = await llmTranslateBatch(uniq, targetLang, genderHint, s, toGender, liveCtx);
      let plan = batchFallbackPlan(batch, 0);
      if (plan.action === "retry") {
        console.log(`[FanslyAI] \u{1F310} \u043F\u0430\u0447\u043A\u0430 \u0438\u0437 ${uniq.length}: \u0444\u043E\u043D\u0443 \u043C\u0435\u0441\u0442 \u043D\u0435\u0442 \u2192 \u043F\u043E\u0432\u0442\u043E\u0440 \u0447\u0435\u0440\u0435\u0437 ${Math.ceil(bgHoldMs() / 1e3)} \u0441`);
        batch = await llmTranslateBatch(uniq, targetLang, genderHint, s, toGender, liveCtx);
        plan = batchFallbackPlan(batch, 1);
      }
      if (batch.success) {
        const byText = new Map(uniq.map((t2, k) => [t2, batch.results[k]]));
        const rejected = [];
        for (const i of pending) {
          const out = byText.get(list[i]);
          if (!out) continue;
          const bad = trOutputProblem(out, list[i], targetLang);
          if (bad) {
            rejected.push(bad);
            continue;
          }
          results[i] = { result: out, genderSafe: true, retryAfterMs: 0 };
          if (!ctxShort(list[i])) trCachePut(keyOf(list[i], true), out);
        }
        if (rejected.length) console.warn(`[FanslyAI] \u{1F310} \u043F\u0430\u0447\u043A\u0430: \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E ${rejected.length} (${[...new Set(rejected)].join(", ")}) \u2192 \u043F\u043E\u0448\u0442\u0443\u0447\u043D\u043E`);
        if (results.every((r) => r)) return { success: true, results };
      } else if (plan.action === "deepl") {
        skipLlm = true;
        if (plan.holdSec) bgHoldTrip(plan.holdSec);
        console.warn(`[FanslyAI] \u{1F310} \u043F\u0430\u0447\u043A\u0430 \u0438\u0437 ${uniq.length} \u2192 DeepL \u0431\u0435\u0437 \u0440\u043E\u0434\u0430 (${batch.error})${plan.holdSec ? `, \u0418\u0418-\u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u043F\u0440\u0438\u0434\u0435\u0440\u0436\u0430\u043D \u043D\u0430 ${plan.holdSec} \u0441` : ""}`);
      } else {
        console.warn(`[FanslyAI] \u{1F310} \u043F\u0430\u043A\u0435\u0442\u043D\u044B\u0439 \u0418\u0418-\u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0443\u043F\u0430\u043B (${batch.error}) \u2192 \u043F\u043E\u0448\u0442\u0443\u0447\u043D\u043E (\u0440\u043E\u0434 \u043F\u043E\u0442\u0435\u0440\u044F\u0435\u0442\u0441\u044F)`);
      }
    }
    const rest = pending.filter((i) => !results[i]);
    for (let k = 0; k < rest.length; k += TR_FALLBACK_PARALLEL) {
      await Promise.all(rest.slice(k, k + TR_FALLBACK_PARALLEL).map(async (i) => {
        const one = await handleTranslate(list[i], targetLang, genderHint, toGender, "translate", skipLlm, null, fanLang);
        results[i] = one?.success ? { result: one.result, genderSafe: one.genderSafe !== false, retryAfterMs: one.retryAfterMs || 0 } : null;
      }));
    }
    return { success: true, results };
  }
  const trKind = (kind) => kind === "translate" ? "translate" : "translate_live";
  async function handleTranslate(text, targetLang, genderHint = null, toGender = null, kind = "translate_live", skipLlm = false, ctx = null, fanLang = null) {
    if (!text?.trim()) return { success: true, result: "" };
    kind = trKind(kind);
    if (!/[\p{L}\p{N}]/u.test(text)) return { success: true, result: text };
    const s0 = await getSettings();
    if (s0.translatorEnabled === false) return { success: true, result: text, translatorOff: true };
    const looksDone = alreadyInTargetLang(text.trim(), targetLang);
    if (looksDone && !isOutgoingTarget(targetLang, s0) && !fanLangDiffers(fanLang, targetLang)) {
      return { success: true, result: text };
    }
    const hash = hashText(text.trim());
    const keyFor = (g, tg) => trCacheKey(targetLang, hash, g, tg);
    const needGender = BUILD === "full" && !!(genderHint || toGender) && targetNeedsGender(targetLang);
    const cacheKey = needGender ? keyFor(genderHint, toGender) : keyFor(null, null);
    let s = s0, ctxOn = false;
    if (BUILD === "full" && !skipLlm && Array.isArray(ctx) && ctx.length > 0) {
      ctxOn = s.translateContext !== false && !!llmTranslateSettings(s) && !!trContextBlock(ctx);
    }
    if (!ctxOn) {
      const cached = await trCacheGet(cacheKey);
      const cachedBad = cached ? trOutputProblem(cached, text, targetLang) : "";
      if (cached && !cachedBad) {
        return { success: true, result: cached };
      }
      if (cachedBad) {
        console.warn(`[FanslyAI] \u{1F310} \u0432 \u043A\u0435\u0448\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u043B\u0435\u0436\u0430\u043B \u043D\u0435\u0433\u043E\u0434\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 (${cachedBad}) \u2192 \u0432\u044B\u0431\u0440\u043E\u0448\u0435\u043D, \u043F\u0435\u0440\u0435\u0432\u043E\u0436\u0443 \u0437\u0430\u043D\u043E\u0432\u043E`);
        trCacheDrop(cacheKey);
      }
    }
    let result;
    let gendered = false;
    let lookLlm = false;
    lookLlm = BUILD === "full" && looksDone && isOutgoingTarget(targetLang, s) && !!llmTranslateSettings(s);
    if ((needGender || ctxOn || lookLlm) && !skipLlm) {
      result = trGuard(await llmTranslate(text, targetLang, needGender ? genderHint : null, s, needGender ? toGender : null, kind, ctxOn ? ctx : null), text, targetLang, "\u0418\u0418");
      gendered = !!result.success;
      if (!result.success) console.warn(`[FanslyAI] \u{1F310} \u0418\u0418-\u043F\u0435\u0440\u0435\u0432\u043E\u0434 (${needGender ? "\u0440\u043E\u0434" : ctxOn ? "\u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442" : "\u044F\u0437\u044B\u043A"}) \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u043E\u0431\u044B\u0447\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A${needGender ? " (\u0440\u043E\u0434 \u043F\u043E\u0442\u0435\u0440\u044F\u0435\u0442\u0441\u044F)" : ctxOn ? " (\u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043F\u043E\u0442\u0435\u0440\u044F\u0435\u0442\u0441\u044F)" : ""}`);
    }
    if (!result || !result.success) {
      if (proxyOn(s)) {
        result = trGuard(await translateViaProxy(text, targetLang, s), text, targetLang, "DeepL \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u043E\u043A\u0441\u0438");
        if (!result.success && s.deepLApiKey) {
          console.warn(`[FanslyAI] \u{1F310} DeepL-\u043F\u0440\u043E\u043A\u0441\u0438 \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u0441\u0432\u043E\u0439 \u043A\u043B\u044E\u0447 DeepL`);
          result = trGuard(await translateDeepL(text, targetLang, s.deepLApiKey), text, targetLang, "DeepL");
        }
        if (!result.success) {
          console.warn(`[FanslyAI] \u{1F310} \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u043E\u043A\u0441\u0438/DeepL \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u0444\u043E\u043B\u0431\u044D\u043A \u043D\u0430 Google`);
          result = trGuard(await translateGoogle(text, targetLang), text, targetLang, "Google");
        }
      } else if (s.deepLApiKey) {
        result = trGuard(await translateDeepL(text, targetLang, s.deepLApiKey), text, targetLang, "DeepL");
        if (!result.success) {
          console.warn(`[FanslyAI] \u{1F310} DeepL \u0443\u043F\u0430\u043B (${result.error}) \u2192 \u0444\u043E\u043B\u0431\u044D\u043A \u043D\u0430 Google`);
          result = trGuard(await translateGoogle(text, targetLang), text, targetLang, "Google");
        }
      } else {
        result = trGuard(await translateGoogle(text, targetLang), text, targetLang, "Google");
      }
    }
    if (result.success && result.result && !ctxOn) {
      const key = needGender && !gendered ? keyFor(null, null) : cacheKey;
      trCachePut(key, result.result);
    }
    const retryAfterMs = gendered ? 0 : breakerOpen() ? Math.max(1e3, PROXY_BREAKER.until - Date.now()) : bgHoldOn() ? Math.max(1e3, PROXY_BG_HOLD.until - Date.now()) : 3e5;
    return { ...result, genderSafe: !(needGender && !gendered), retryAfterMs };
  }
  function llmTranslateSettings(s) {
    if (proxyOn(s)) return s;
    if (s.allowExplicit === true && s.openrouterApiKey) return { ...s, aiProvider: "openrouter" };
    if (s.aiProvider && s.aiProvider !== "mock" && providerReady(s.aiProvider, s)) return s;
    for (const p of ["openrouter", "gemini", "groq", "claude"]) if (providerReady(p, s)) return { ...s, aiProvider: p };
    return null;
  }
  const LLM_LANG_NAMES = { ru: "Russian", en: "English", es: "Spanish", de: "German", fr: "French", it: "Italian", pt: "Portuguese", uk: "Ukrainian", pl: "Polish", tr: "Turkish" };
  function genderPromptParts(gender, toGender) {
    const F = (g) => g === "female" ? "FEMALE" : "MALE";
    const rules = [];
    if (gender) rules.push(`\u2022 SPEAKER (who wrote this message) is ${F(gender)} \u2192 use this gender for what the speaker says about themselves ("I was tired", "I'm glad").`);
    if (toGender) rules.push(`\u2022 ADDRESSEE (the person this message is written TO) is ${F(toGender)} \u2192 use this gender for everything said ABOUT them: past-tense verbs, adjectives, participles ("you said", "you look great").`);
    if (!rules.length) return { genderBlock: "", remind: "" };
    return {
      genderBlock: [
        "GENDER AGREEMENT \u2014 translators get this wrong, read this first:",
        ...rules,
        '\u2022 IMPLICIT SUBJECT STILL COUNTS: in phrases with no pronoun ("thanks for asking", "glad you liked it", "hope you slept well") the doer is the ADDRESSEE \u2014 use the addressee gender there too.',
        '\u2022 Example: addressee is FEMALE, "thanks for asking" \u2192 the FEMININE past form (Russian: \xAB\u0441\u043F\u0430\u0441\u0438\u0431\u043E, \u0447\u0442\u043E \u0441\u043F\u0440\u043E\u0441\u0438\u043B\u0430\xBB, NOT \xAB\u0441\u043F\u0440\u043E\u0441\u0438\u043B\xBB).',
        "\u2022 Never fall back to masculine as a default.",
        ""
      ].join("\n"),
      remind: `

(Before answering, re-check: speaker ${gender ? F(gender) : "?"}, addressee ${toGender ? F(toGender) : "?"} \u2014 every gendered form must match, including phrases with no explicit subject.)`
    };
  }
  const TR_CTX_MAX_LINES = 3;
  const TR_CTX_LINE_CHARS = 200;
  const TR_CTX_CHARS = 600;
  function trContextClamp(ctx) {
    const lines = (Array.isArray(ctx) ? ctx : []).filter((l) => l && typeof l.t === "string" && l.t.trim() && (l.who === "speaker" || l.who === "addressee")).slice(-TR_CTX_MAX_LINES).map((l) => ({ who: l.who, t: l.t.trim().slice(0, TR_CTX_LINE_CHARS) }));
    while (lines.length && lines.reduce((n, l) => n + l.t.length, 0) > TR_CTX_CHARS) lines.shift();
    return lines;
  }
  function trContextPick(ctx) {
    const lines = trContextClamp(ctx);
    const k = lines.map((l) => l.who).lastIndexOf("addressee");
    return lines.filter((l, i) => l.who === "addressee" || i > k);
  }
  function trContextBlock(ctx) {
    const lines = trContextPick(ctx);
    if (!lines.length) return "";
    const say = (l) => `${l.who === "speaker" ? "Speaker" : "Addressee"}: ${l.t}`;
    const k = lines.map((l) => l.who).lastIndexOf("addressee");
    const tail = k < 0 ? lines.slice(-1) : lines.slice(k), earlier = k < 0 ? lines.slice(0, -1) : lines.slice(0, k);
    const role = k < 0 ? "The message continues right after this line by the same person" : tail.length > 1 ? "The message continues this exchange" : "The message is the reply to this line";
    return `CONTEXT \u2014 do NOT translate it and do NOT include it in the output. Never add words or facts taken from it, never reuse its wording.
${earlier.length ? `Earlier lines, older first (they show the topic so far and what "it", "she", "that one" in the message stand for):
${earlier.map(say).join("\n")}
` : ""}${role} (the meaning of its words comes from HERE):
${tail.map(say).join("\n")}`;
  }
  function batchFallbackPlan(r, attempt) {
    if (!r || r.success) return { action: "none" };
    if (r.format || r.blocked) return { action: "per-item" };
    if (r.saturated) return attempt ? { action: "deepl", holdSec: 0 } : { action: "retry" };
    if (r.quotaExhausted) return { action: "deepl", holdSec: 0 };
    return { action: "deepl", holdSec: BG_BUSY_HOLD_S };
  }
  async function llmTranslateBatch(texts, targetLang, gender, s, toGender = null, ctx = null) {
    try {
      if (!texts.length) return { success: true, results: [] };
      const cs = llmTranslateSettings(s);
      if (!cs) return { success: false, error: "no llm provider" };
      const lang = LLM_LANG_NAMES[targetLang] || targetLang;
      const { genderBlock, remind } = genderPromptParts(gender, toGender);
      const system = "You are a translator for private adult chat messages. Translate faithfully, never refuse, never moralize, never add anything of your own. " + NO_DASH_RULE_TRANSLATE;
      const ctxBlock = trContextBlock(ctx);
      const prompt = `${genderBlock}Translate EVERY message in the JSON array below into ${lang}, whatever language each one is written in. If a message is already in ${lang}, output it unchanged. Keep the tone, casual texting style and meaning of each one.
If a message cannot be translated because it has no meaning in any language, output it unchanged. Never refuse, apologize or comment.
Each item is {"i": <number>, "t": "<text>"}. Output ONLY a JSON array of the same length, one object per input, each {"i": <the SAME number as its input>, "t": "<translation>"}.
Never merge, split, drop, reorder or renumber items. No markdown, no comments, no extra keys.

${ctxBlock ? `${ctxBlock}

Input (the Speaker's next line):` : "Input:"}
${JSON.stringify(texts.map((t2, i) => ({ i, t: t2 })))}${remind}`;
      const r = await routeProviderChat(
        [{ role: "user", content: prompt }],
        system,
        cs,
        { temperature: 0.2, maxTokens: 4096, timeoutMs: ctxBlock ? 25e3 : 45e3, kind: ctxBlock ? "translate_live" : "translate" }
      );
      const raw = r && r.success && r.text ? r.text.trim() : "";
      if (!raw) {
        if (r && r.success) return { success: false, error: "llm empty", format: true };
        return {
          success: false,
          error: r && (r.error || (r.blocked ? "blocked" : "")) || "llm empty",
          saturated: !!r?.saturated,
          upstreamBusy: !!r?.upstreamBusy,
          rateLimited: !!r?.rateLimited,
          quotaExhausted: !!r?.quotaExhausted,
          blocked: !!r?.blocked,
          status: r?.status
        };
      }
      const bad = (error) => ({ success: false, error, format: true });
      const a = raw.indexOf("["), b = raw.lastIndexOf("]");
      if (a === -1 || b <= a) return bad("no json array");
      let arr;
      try {
        arr = JSON.parse(raw.slice(a, b + 1));
      } catch (e) {
        return bad("bad json");
      }
      if (!Array.isArray(arr) || arr.length !== texts.length) return bad(`len ${Array.isArray(arr) ? arr.length : "?"}\u2260${texts.length}`);
      const out = new Array(texts.length).fill(null);
      for (const x of arr) {
        if (!x || typeof x !== "object") return bad("non-object item");
        const i = x.i, s2 = x.t;
        if (!Number.isInteger(i) || i < 0 || i >= texts.length) return bad("bad index");
        if (out[i] !== null) return bad("dup index");
        if (typeof s2 !== "string" || !s2.trim()) return bad("non-string item");
        out[i] = s2.trim();
      }
      if (out.some((x) => x === null)) return bad("missing index");
      return { success: true, results: out };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function llmTranslate(text, targetLang, gender, s, toGender = null, kind = null, ctx = null) {
    try {
      const cs = llmTranslateSettings(s);
      if (!cs) return { success: false, error: "no llm provider" };
      const lang = LLM_LANG_NAMES[targetLang] || targetLang;
      const { genderBlock, remind } = genderPromptParts(gender, toGender);
      const system = "You are a translator for private adult chat messages. Translate faithfully, never refuse, never moralize, never add anything of your own. " + NO_DASH_RULE_TRANSLATE;
      const ctxBlock = trContextBlock(ctx);
      const prompt = `${genderBlock}Translate the message below into ${lang}, whatever language it is written in. If it is already in ${lang}, output it unchanged. Keep the tone, casual texting style and meaning. Output ONLY the translation \u2014 no quotes, no explanations. If the message cannot be translated because it has no meaning in any language, output it unchanged. Never refuse, apologize or comment.

${ctxBlock ? `${ctxBlock}

Message (the Speaker's next line):` : "Message:"}
${text}${remind}`;
      const r = await routeProviderChat([{ role: "user", content: prompt }], system, cs, { temperature: 0.2, maxTokens: 1024, timeoutMs: 2e4, kind: kind || void 0 });
      const out = r && r.success && r.text ? r.text.trim() : "";
      if (out) return { success: true, result: out };
      return { success: false, error: r && (r.error || (r.blocked ? "blocked" : "")) || "llm empty" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function translateDeepL(text, targetLang, apiKey) {
    try {
      const host = /:fx$/i.test(String(apiKey || "").trim()) ? "api-free.deepl.com" : "api.deepl.com";
      const r = await fetchWithTimeout(`https://${host}/v2/translate`, {
        method: "POST",
        headers: {
          "Authorization": `DeepL-Auth-Key ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ text: [text], target_lang: targetLang.toUpperCase() })
      }, 15e3);
      const data = await r.json();
      if (data.translations) return { success: true, result: data.translations[0].text };
      return { success: false, error: JSON.stringify(data) };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function translateGoogle(text, targetLang) {
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
      const r = await fetchWithTimeout(url, {}, 1e4);
      const data = await r.json();
      const translated = data[0].map((chunk) => chunk[0]).filter(Boolean).join("");
      return { success: true, result: translated };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  function proxyOn(s) {
    return !!(s && s.useProxy === true && s.licenseKey);
  }
  const _psleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const PROXY_GATE = { active: 0, max: 3, minGapMs: 250, lastStart: 0, cooldownUntil: 0, waiters: [] };
  async function proxyGateWait() {
    for (; ; ) {
      const now = Date.now();
      if (now < PROXY_GATE.cooldownUntil) {
        await _psleep(PROXY_GATE.cooldownUntil - now + 50);
        continue;
      }
      const gap = PROXY_GATE.lastStart + PROXY_GATE.minGapMs - now;
      if (PROXY_GATE.active < PROXY_GATE.max && gap <= 0) {
        PROXY_GATE.active++;
        PROXY_GATE.lastStart = Date.now();
        return;
      }
      if (PROXY_GATE.active < PROXY_GATE.max) {
        await _psleep(gap);
        continue;
      }
      await new Promise((r) => PROXY_GATE.waiters.push(r));
    }
  }
  function proxyGateRelease() {
    PROXY_GATE.active = Math.max(0, PROXY_GATE.active - 1);
    const w = PROXY_GATE.waiters.shift();
    if (w) w();
  }
  const _breakers = /* @__PURE__ */ new Map();
  const PROXY_BREAKER = {
    get until() {
      let m = 0;
      for (const b of _breakers.values()) m = m ? Math.min(m, b.until) : b.until;
      return m;
    },
    get fails() {
      let m = 0;
      for (const b of _breakers.values()) m = Math.max(m, b.fails);
      return m;
    }
  };
  const brk = (host) => {
    let b = _breakers.get(host);
    if (!b) {
      b = { until: 0, fails: 0 };
      _breakers.set(host, b);
    }
    return b;
  };
  const BREAKER_STEPS = [3e4, 12e4, 3e5];
  function breakerOpen(host) {
    if (host) return Date.now() < brk(host).until;
    for (const b of _breakers.values()) if (Date.now() >= b.until) return false;
    return _breakers.size > 0;
  }
  function breakerTrip(host) {
    const b = brk(host || "");
    const step = BREAKER_STEPS[Math.min(b.fails, BREAKER_STEPS.length - 1)];
    b.fails++;
    b.until = Date.now() + Math.round(step * (0.75 + Math.random() * 0.5));
    console.warn("[FanslyAI] \u043D\u0435 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442", host || "\u043F\u0440\u043E\u043A\u0441\u0438", "\u2192 \u043F\u0430\u0443\u0437\u0430", Math.round((b.until - Date.now()) / 1e3), "\u0441 (\u043D\u0435\u0443\u0434\u0430\u0447 \u043F\u043E\u0434\u0440\u044F\u0434:", b.fails + ")");
  }
  function breakerReset(host) {
    const b = brk(host || "");
    if (b.fails) console.log("[FanslyAI]", host || "\u043F\u0440\u043E\u043A\u0441\u0438", "\u0441\u043D\u043E\u0432\u0430 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442");
    b.fails = 0;
    b.until = 0;
  }
  const BG_HOLD_DEFAULT_S = 3;
  const BG_HOLD_MAX_S = 15;
  const BG_BUSY_HOLD_S = 10;
  const PROXY_BG_HOLD = { until: 0 };
  function bgHoldOn() {
    return Date.now() < PROXY_BG_HOLD.until;
  }
  function bgHoldMs() {
    return Math.max(0, PROXY_BG_HOLD.until - Date.now());
  }
  function bgHoldTrip(sec) {
    const ms = Math.min(Math.max(Number(sec) || BG_HOLD_DEFAULT_S, 1), BG_HOLD_MAX_S) * 1e3;
    PROXY_BG_HOLD.until = Math.max(PROXY_BG_HOLD.until, Date.now() + ms);
    return ms;
  }
  function retryAfterFrom(body, headers) {
    const num = (v) => {
      const n = Number(v);
      return Number.isFinite(n) && n > 0 ? n : null;
    };
    const fromBody = num(body?.retry_after_seconds) ?? num(body?.error?.retry_after_seconds);
    if (fromBody != null) return fromBody;
    const h = headers && typeof headers.get === "function" ? headers.get("retry-after") : null;
    return h == null ? null : num(parseInt(String(h), 10));
  }
  let aiQuotaUntil = 0;
  let dlQuotaUntil = 0;
  const QUOTA_COOLDOWN_MS = 30 * 60 * 1e3;
  const QUOTA_MSG_AI = "\u041C\u0435\u0441\u044F\u0447\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442 \u0418\u0418 \u0438\u0441\u0447\u0435\u0440\u043F\u0430\u043D";
  const SUB_PAUSE_KEY = "fansly_sub_expired";
  const SUB_PAUSE_MS = 3 * 60 * 60 * 1e3;
  const SUB_MSG = "\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0437\u0430\u043A\u043E\u043D\u0447\u0438\u043B\u0430\u0441\u044C";
  let _subPause = void 0;
  function keyFp(k) {
    let h = 5381;
    const s = String(k || "");
    for (let i = 0; i < s.length; i++) h = (h << 5) + h + s.charCodeAt(i) | 0;
    return (h >>> 0).toString(16);
  }
  async function subPauseLoad() {
    if (_subPause === void 0) _subPause = await new Promise((r) => chrome.storage.local.get(SUB_PAUSE_KEY, (d) => r(d && d[SUB_PAUSE_KEY] || null)));
    return _subPause;
  }
  function subPausedSync(key) {
    return !!(key && _subPause && _subPause.fp === keyFp(key) && Date.now() < _subPause.until);
  }
  async function subPausedFor(key) {
    await subPauseLoad();
    return subPausedSync(key);
  }
  function subPauseSet(key) {
    _subPause = { fp: keyFp(key), until: Date.now() + SUB_PAUSE_MS };
    chrome.storage.local.set({ [SUB_PAUSE_KEY]: _subPause });
    console.warn("[FanslyAI] \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0437\u0430\u043A\u043E\u043D\u0447\u0438\u043B\u0430\u0441\u044C (402 subscription_expired) \u2192 \u043A \u043F\u0440\u043E\u043A\u0441\u0438 \u043D\u0435 \u0445\u043E\u0434\u0438\u043C \u0434\u043E " + new Date(_subPause.until).toLocaleTimeString() + " \u0438\u043B\u0438 \u0434\u043E \xAB\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C\xBB \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445");
  }
  function subPauseClear() {
    _subPause = null;
    chrome.storage.local.remove(SUB_PAUSE_KEY);
  }
  const bearerOf = (init2) => {
    const h = init2 && init2.headers || {};
    const m = /^Bearer\s+(.+)$/.exec(String(h.Authorization || h.authorization || ""));
    return m ? m[1] : "";
  };
  function subExpiredResponse() {
    const body = { error: { code: "subscription_expired", message: "Payment Required", local: true } };
    const r = { status: 402, ok: false, headers: { get: (k) => /^content-type$/i.test(k) ? "application/json" : null }, json: async () => body };
    r.clone = () => r;
    return r;
  }
  async function proxyFetch(url, init2, timeoutMs) {
    if (!await consentGiven()) throw consentError();
    const host = (() => {
      try {
        return new URL(url).hostname;
      } catch (e) {
        return "";
      }
    })();
    if (breakerOpen(host)) throw new Error("proxy_down");
    let last;
    for (let attempt = 0; attempt < 2; attempt++) {
      await proxyGateWait();
      try {
        last = await fetchWithTimeout(url, init2, timeoutMs);
      } catch (e) {
        if (!(e && (e.name === "AbortError" || e.faiConsent))) breakerTrip(host);
        throw e;
      } finally {
        proxyGateRelease();
      }
      if (last.status < 500) breakerReset(host);
      if (last.status === 429 || last.status >= 500) {
        const d = await last.clone().json().catch(() => ({}));
        if (d?.error?.code === "upstream_saturated") {
          bgHoldTrip(retryAfterFrom(d, last.headers));
          return last;
        }
        if (last.status === 429 || d?.error?.type === "rate_limit_error") {
          const ra = retryAfterFrom(d, last.headers) || 5;
          PROXY_GATE.cooldownUntil = Math.max(PROXY_GATE.cooldownUntil, Date.now() + Math.min(Math.max(ra, 1), 60) * 1e3);
          if (attempt === 0) continue;
        } else if (last.status >= 500) breakerTrip(host);
      }
      return last;
    }
    return last;
  }
  const QUOTA_CACHE_KEY = "fansly_ai_quota";
  const QUOTA_TTL_MS = 6 * 60 * 60 * 1e3;
  function saveQuota(q) {
    if (!q || typeof q !== "object") return null;
    const limit = Number(q.limit) || 0, used = Number(q.used) || 0;
    const v = {
      tier: String(q.tier || ""),
      used,
      limit,
      periodEnd: String(q.periodEnd || ""),
      at: Date.now()
    };
    const p = q.prepaid, n = p && typeof p === "object" ? Math.floor(Number(p.count)) : 0;
    if (Number.isFinite(n) && n > 0) v.prepaid = { count: n, tier: String(p.tier || ""), limit: Number(p.limit) || 0, days: Number(p.days) || 0 };
    if (limit > 0 && used < limit) {
      aiQuotaUntil = 0;
      dlQuotaUntil = 0;
    }
    chrome.storage.local.set({ [QUOTA_CACHE_KEY]: v });
    return v;
  }
  function readQuotaCache() {
    return new Promise((r) => chrome.storage.local.get(QUOTA_CACHE_KEY, (d) => r(d[QUOTA_CACHE_KEY] || null)));
  }
  async function fetchQuota(s) {
    try {
      const r = await proxyCall("/v1/quota", {
        method: "POST",
        headers: { "Authorization": `Bearer ${s.licenseKey}`, "Content-Type": "application/json" },
        body: "{}"
      }, 15e3);
      const data = await r.json().catch(() => ({}));
      if (!r.ok || !data || typeof data.used !== "number") return null;
      return saveQuota(data);
    } catch (e) {
      return null;
    }
  }
  async function getQuota(force) {
    const s = await getSettings();
    if (!proxyOn(s)) return null;
    const c = await readQuotaCache();
    const rolled = c && c.periodEnd && Date.parse(c.periodEnd) <= Date.now();
    const fresh = c && !rolled && Date.now() - (c.at || 0) < QUOTA_TTL_MS;
    if (fresh && !force) return c;
    return await fetchQuota(s) || (rolled ? null : c);
  }
  const ENDPOINTS_PUBKEY = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEpZ+s+DJQ4ZDOuRhyoYX0YLiOQNSNyBQrq+zkSfjrbm+YfaAMae1ZCytYm63aC9raXM0klE0oVDQ5RDtHcWjt7A==";
  const ENDPOINTS_BUILTIN = { rev: 1, endpoints: [{ url: "https://api.velourff.com", weight: 1 }] };
  const ENDPOINTS_KEY = "fansly_endpoints";
  const ENDPOINTS_TTL_MIN = 5 * 60 * 1e3;
  const ENDPOINTS_TTL_MAX = 7 * 24 * 3600 * 1e3;
  function endpointsPayload(list) {
    return ["velour-endpoints-v1", String(Math.trunc(list.rev))].concat((list.endpoints || []).map((e) => e.url + "	" + Math.trunc(Number(e.weight) || 1))).join("\n");
  }
  const sanePoint = (u) => {
    try {
      const x = new URL(u);
      return x.protocol === "https:" && x.pathname === "/" && !x.search && !x.hash && !/^\d+\.\d+\.\d+\.\d+$/.test(x.hostname) && !/^\[|localhost$/i.test(x.hostname) && x.hostname.includes(".");
    } catch (e) {
      return false;
    }
  };
  let _epKey = null;
  async function endpointsVerify(list) {
    if (!list || !Array.isArray(list.endpoints) || !list.endpoints.length || !list.sig) return false;
    if (!Number.isFinite(list.rev)) return false;
    if (!list.endpoints.every((e) => e && typeof e.url === "string" && sanePoint(e.url))) return false;
    try {
      if (!_epKey) {
        const raw = Uint8Array.from(atob(ENDPOINTS_PUBKEY), (c) => c.charCodeAt(0));
        _epKey = await crypto.subtle.importKey("spki", raw, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      }
      const b64 = list.sig.replace(/-/g, "+").replace(/_/g, "/");
      const sig = Uint8Array.from(atob(b64 + "=".repeat((4 - b64.length % 4) % 4)), (c) => c.charCodeAt(0));
      return await crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        _epKey,
        sig,
        new TextEncoder().encode(endpointsPayload(list))
      );
    } catch (e) {
      return false;
    }
  }
  async function endpointsAccept(list) {
    if (!await endpointsVerify(list)) return false;
    const cur = await new Promise((r) => chrome.storage.local.get(ENDPOINTS_KEY, (d) => r(d[ENDPOINTS_KEY] || null)));
    const rev = Math.trunc(list.rev);
    if (rev <= ((cur && cur.rev) | 0)) return false;
    if (rev < (ENDPOINTS_BUILTIN.rev | 0)) return false;
    const ttl = Math.min(ENDPOINTS_TTL_MAX, Math.max(ENDPOINTS_TTL_MIN, (Number(list.ttl) || 0) * 1e3));
    await new Promise((r) => chrome.storage.local.set({ [ENDPOINTS_KEY]: {
      rev: Math.trunc(list.rev),
      endpoints: list.endpoints.map((e) => ({ url: e.url, weight: Math.trunc(Number(e.weight) || 1) })),
      ttl,
      at: Date.now()
    } }, r));
    return true;
  }
  async function endpointsList() {
    const cur = await new Promise((r) => chrome.storage.local.get(ENDPOINTS_KEY, (d) => r(d[ENDPOINTS_KEY] || null)));
    return cur && cur.endpoints && cur.endpoints.length ? cur : ENDPOINTS_BUILTIN;
  }
  async function endpointsRefresh(base) {
    try {
      const r = await fetchWithTimeout(base + "/v1/endpoints", { method: "GET" }, 1e4, BEFORE_CONSENT);
      if (!r.ok) return null;
      const list = await r.json();
      return { accepted: await endpointsAccept(list), ttl: Number(list && list.ttl) || 0 };
    } catch (e) {
      return null;
    }
  }
  const BEFORE_CONSENT = true;
  const ENDPOINTS_CHECK_KEY = "fansly_endpoints_checked";
  async function endpointsMaintain(force) {
    const mark = await new Promise((r) => chrome.storage.local.get(ENDPOINTS_CHECK_KEY, (d) => r(d[ENDPOINTS_CHECK_KEY] || null)));
    if (!force && mark && mark.at && Date.now() - mark.at < (mark.ttl || 0)) return "fresh";
    const setMark = (ttlMs) => new Promise((r) => chrome.storage.local.set({ [ENDPOINTS_CHECK_KEY]: { at: Date.now(), ttl: ttlMs } }, r));
    const ring = await proxyRing();
    for (const base of ring) {
      const res = await endpointsRefresh(base);
      if (!res) continue;
      await setMark(Math.min(ENDPOINTS_TTL_MAX, Math.max(ENDPOINTS_TTL_MIN, res.ttl * 1e3)));
      console.log("[FanslyAI] \u0441\u043F\u0438\u0441\u043E\u043A \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043F\u0440\u043E\u043A\u0441\u0438:", res.accepted ? "\u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D" : "\u0431\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", "\u2190", base);
      return res.accepted ? "updated" : "same";
    }
    await setMark(ENDPOINTS_TTL_MIN);
    return "unreachable";
  }
  const STICKY_KEY = "fansly_proxy_sticky";
  const STICKY_MS = 24 * 3600 * 1e3;
  function hrwScore(seed, url, weight) {
    let h = 2166136261;
    const s = seed + "|" + url;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    const u = ((h >>> 0) + 1) / 4294967297;
    return -Math.max(1, weight | 0) / Math.log(u);
  }
  async function proxySeed(s) {
    return s.licenseKey || await new Promise((r) => chrome.storage.local.get(TRIAL_CODE_KEY, (d) => r(d[TRIAL_CODE_KEY] || "anon")));
  }
  async function proxyRing() {
    const s = await getSettings();
    const manual = String(s.proxyBaseUrl || "").replace(/\/+$/, "");
    if (manual && manual !== DEFAULT_SETTINGS.proxyBaseUrl.replace(/\/+$/, "")) return [manual];
    const list = await endpointsList();
    const seed = await proxySeed(s);
    const ranked = list.endpoints.map((e) => ({ url: e.url, sc: hrwScore(seed, e.url, e.weight) })).sort((a, b) => b.sc - a.sc);
    const home = ranked[0] && ranked[0].url;
    const st = await new Promise((r) => chrome.storage.local.get(STICKY_KEY, (d) => r(d[STICKY_KEY] || null)));
    const stick = st && st.url && Date.now() - (st.at || 0) < STICKY_MS && ranked.some((x) => x.url === st.url) ? st.url : null;
    const order = ranked.map((x) => x.url);
    if (!stick || stick === home) return order;
    return [stick, ...order.filter((u) => u !== stick)];
  }
  const proxyStick = (url) => new Promise((r) => chrome.storage.local.set({ [STICKY_KEY]: { url, at: Date.now() } }, r));
  async function proxyCall(path, init2, timeoutMs) {
    const key = bearerOf(init2);
    if (key && await subPausedFor(key)) return subExpiredResponse();
    const ring = await proxyRing();
    let lastErr = null;
    for (let i = 0; i < ring.length; i++) {
      const base = ring[i];
      try {
        const r = await proxyFetch(base + path, init2, timeoutMs);
        const ct = r.headers.get("content-type") || "";
        if (/json/i.test(ct) || r.status === 429) {
          if (i > 0) await proxyStick(base);
          if (r.status === 402 && key) {
            const d = await r.clone().json().catch(() => null);
            if (d && d.error && d.error.code === "subscription_expired") subPauseSet(key);
          }
          return r;
        }
        lastErr = new Error("proxy_no_app_" + r.status);
      } catch (e) {
        if (e && (e.name === "AbortError" || e.faiConsent)) throw e;
        lastErr = e;
      }
    }
    throw lastErr || new Error("proxy_unreachable");
  }
  const TRIAL_CODE_KEY = "fansly_install_code";
  const TRIAL_STATE_KEY = "fansly_trial_state";
  const TRIAL_CLOSED_TTL_MS = 6 * 36e5 - 5 * 6e4;
  let _trialRunning = false;
  function trialClosedFresh(st) {
    const age = Date.now() - (st.at || 0);
    return age >= 0 && age < TRIAL_CLOSED_TTL_MS;
  }
  function trialWaitState(prev, waitMs) {
    return { ...prev && prev.closed ? { closed: prev.closed, at: prev.at } : { at: Date.now() }, waitUntil: Date.now() + waitMs };
  }
  async function installCode() {
    const cur = await new Promise((r) => chrome.storage.local.get(TRIAL_CODE_KEY, (d) => r(d[TRIAL_CODE_KEY])));
    if (cur) return cur;
    const code = crypto.randomUUID();
    await new Promise((r) => chrome.storage.local.set({ [TRIAL_CODE_KEY]: code }, r));
    return code;
  }
  async function sha256Hex(str) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  async function readTrialState() {
    return new Promise((r) => chrome.storage.local.get(TRIAL_STATE_KEY, (d) => r(d[TRIAL_STATE_KEY] || null)));
  }
  async function requestTrial(code) {
    if (_trialRunning) return null;
    const s = await getSettings();
    if (s.licenseKey) return null;
    if (!s.privacyConsentAt) return null;
    const st = await readTrialState();
    if (!code && st && st.waitUntil && Date.now() < st.waitUntil) return st;
    if (!code && st && st.closed && trialClosedFresh(st)) return st;
    _trialRunning = true;
    try {
      const body = {
        installHash: await sha256Hex(await installCode()),
        ...code ? { code } : {},
        // код приглашения — необязательное поле; конверт строгий, лишнего слать нельзя
        platform: PLATFORM,
        extVersion: chrome.runtime.getManifest().version,
        lang: s.interfaceLanguage || "ru"
      };
      const r = await proxyCall("/v1/trial", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }, 15e3);
      const data = await r.json().catch(() => ({}));
      const errCode = data && data.error && data.error.code;
      let state;
      if (r.ok && data.licenseKey) {
        await new Promise((res) => saveSettings({ licenseKey: data.licenseKey, useProxy: true }, res));
        if (data.velour_quota) saveQuota(data.velour_quota);
        state = { at: Date.now(), ok: true };
        console.log("[FanslyAI] \u043F\u0440\u043E\u0431\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F \u0432\u044B\u0434\u0430\u043D");
      } else if (r.status === 403 && errCode === "trial_closed") {
        state = { at: Date.now(), closed: data.error.where === "tg" ? "tg" : "site" };
      } else if (r.status === 429) {
        const ra = parseInt(r.headers.get("Retry-After") || "", 10);
        state = trialWaitState(st, (Number.isFinite(ra) ? ra : 3600) * 1e3);
      } else {
        if (r.status === 400) bugLog("trial_fail", { status: r.status, code: String(errCode || "") });
        state = trialWaitState(st, 36e5);
      }
      if (code && !state.ok) return { ok: false, code: String(errCode || "") };
      await new Promise((r2) => chrome.storage.local.set({ [TRIAL_STATE_KEY]: state }, r2));
      return state.ok ? { ok: true } : state;
    } catch (e) {
      const state = trialWaitState(st, 36e5);
      await new Promise((r2) => chrome.storage.local.set({ [TRIAL_STATE_KEY]: state }, r2));
      return state;
    } finally {
      _trialRunning = false;
    }
  }
  async function translateViaProxy(text, targetLang, s) {
    if (Date.now() < dlQuotaUntil) return { success: false, status: 402, dlQuota: true, error: "dl quota" };
    if (await subPausedFor(s && s.licenseKey)) return { success: false, status: 402, dlQuota: true, subscriptionExpired: true, error: SUB_MSG };
    try {
      const r = await proxyCall("/v1/translate", {
        method: "POST",
        headers: { "Authorization": `Bearer ${s.licenseKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ text, targetLang })
      }, 2e4);
      const data = await r.json().catch(() => ({}));
      if (data?.velour_quota) saveQuota(data.velour_quota);
      if (r.ok && data.text) return { success: true, result: data.text };
      if (r.status === 402 && data?.error?.code === "dl_quota_exhausted") {
        dlQuotaUntil = Date.now() + QUOTA_COOLDOWN_MS;
        bugProxyFail("translate", 402, "dl_quota_exhausted");
        return { success: false, status: 402, dlQuota: true, error: "dl quota" };
      }
      if (r.status === 402 && data?.error?.code === "subscription_expired") {
        if (!data.error.local) bugProxyFail("translate", 402, "subscription_expired");
        return { success: false, status: 402, dlQuota: true, subscriptionExpired: true, error: SUB_MSG };
      }
      bugProxyFail("translate", r.status, data?.error?.code);
      return { success: false, error: data?.error?.message || `proxy HTTP ${r.status}` };
    } catch (e) {
      const nf = netFailKind(e);
      if (nf) bugLog("net_fail", { ep: "translate", code: nf.code, ageMs: 2e4 }, void 0, nf.k);
      return { success: false, error: e.message };
    }
  }
  function routeProvider(text, intent, context, settings) {
    if (settings.aiProvider === "gemini" && providerReady("gemini", settings)) return generateGemini(text, intent, context, settings);
    if (settings.aiProvider === "groq" && providerReady("groq", settings)) return generateGroq(text, intent, context, settings);
    if (settings.aiProvider === "claude" && providerReady("claude", settings)) return generateClaude(text, intent, context, settings);
    if (settings.aiProvider === "ollama" && providerReady("ollama", settings)) return generateOllama(text, intent, context, settings);
    return null;
  }
  const PROXY_PROVIDERS = ["gemini", "groq", "openrouter"];
  function providerReady(p, s) {
    if (proxyOn(s)) return PROXY_PROVIDERS.includes(p);
    if (p === "gemini") return !!s.geminiApiKey;
    if (p === "groq") return !!s.groqApiKey;
    if (p === "claude") return !!s.claudeApiKey;
    if (p === "ollama") return true;
    if (p === "openrouter") return !!s.openrouterApiKey;
    return false;
  }
  const KIND_RETRY_MS = 15 * 60 * 1e3;
  let _kindUnsupportedUntil = 0;
  function kindAllowed() {
    return Date.now() >= _kindUnsupportedUntil;
  }
  function makeLane(max, onWait) {
    const lane = { max, active: 0, waiters: [], peak: 0 };
    lane.acquire = () => {
      if (lane.active < lane.max) {
        lane.active++;
        return Promise.resolve();
      }
      return new Promise((resolve) => {
        lane.waiters.push(resolve);
        if (lane.waiters.length > lane.peak) {
          lane.peak = lane.waiters.length;
          if (onWait) onWait(lane.active, lane.waiters.length);
        }
      });
    };
    lane.release = () => {
      const next = lane.waiters.shift();
      if (next) next();
      else {
        lane.active = Math.max(0, lane.active - 1);
        if (!lane.active) lane.peak = 0;
      }
    };
    lane.run = async (fn) => {
      await lane.acquire();
      try {
        return await fn();
      } finally {
        lane.release();
      }
    };
    return lane;
  }
  const TR_LANE = makeLane(2, (active, waiting) => console.log(`[FanslyAI] \u{1F310} \u0418\u0418-\u043F\u0435\u0440\u0435\u0432\u043E\u0434: \u0432 \u043F\u043E\u043B\u0451\u0442\u0435 ${active}, \u0436\u0434\u0443\u0442 ${waiting}`));
  async function proxyChat(provider, model, messages, opts, settings) {
    if (Date.now() < aiQuotaUntil) return { success: false, status: 402, quotaExhausted: true, error: QUOTA_MSG_AI };
    if (await subPausedFor(settings && settings.licenseKey)) return { success: false, status: 402, quotaExhausted: true, subscriptionExpired: true, error: SUB_MSG };
    const laned = opts?.kind === "translate";
    if (laned) {
      await TR_LANE.acquire();
      while (bgHoldOn()) await _psleep(bgHoldMs() + 20);
    }
    try {
      const post = (withKind2) => proxyCall("/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${settings.licenseKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          provider,
          // Вид вызова: 'reply' — человек ждёт ответа, сервер держит для него слот; 'translate' и
          // 'dossier_auto' — фон, при заторе отбиваются сразу; 'dossier' — ручная кнопка, человек ждёт.
          ...withKind2 && opts?.kind ? { kind: opts.kind } : {},
          // Модель НЕ шлём: в прокси-режиме её диктует сервер (per-provider из env). Провайдер остаётся за клиентом.
          body: { messages, max_tokens: opts?.maxTokens || 400, temperature: opts?.temperature ?? 0.95 }
        })
      }, opts?.timeoutMs || 45e3);
      if (opts?.kind && !CALL_KINDS.has(opts.kind)) {
        console.warn(`[FanslyAI] \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0432\u0438\u0434 \u0432\u044B\u0437\u043E\u0432\u0430 \xAB${opts.kind}\xBB \u2014 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u044E \u0431\u0435\u0437 \u043C\u0435\u0442\u043A\u0438; \u0434\u043E\u0431\u0430\u0432\u044C \u0435\u0433\u043E \u0432 CALL_KINDS`);
        opts = { ...opts, kind: void 0 };
      }
      const withKind = kindAllowed();
      let response = await post(withKind);
      if (response.status === 400 && opts?.kind && withKind) {
        _kindUnsupportedUntil = Date.now() + KIND_RETRY_MS;
        console.warn(`[FanslyAI] \u043F\u0440\u043E\u043A\u0441\u0438 \u043D\u0435 \u043F\u0440\u0438\u043D\u044F\u043B \u0432\u0438\u0434 \u0432\u044B\u0437\u043E\u0432\u0430 \xAB${opts.kind}\xBB (400) \u2014 \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u044E \u0431\u0435\u0437 \u043C\u0435\u0442\u043A\u0438; \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u0447\u0435\u0440\u0435\u0437 ${Math.round(KIND_RETRY_MS / 6e4)} \u043C\u0438\u043D`);
        response = await post(false);
      }
      const data = await response.json().catch(() => ({}));
      if (data?.velour_quota) saveQuota(data.velour_quota);
      if (response.status === 402 && data?.error?.code === "ai_quota_exhausted") {
        aiQuotaUntil = Date.now() + QUOTA_COOLDOWN_MS;
        bugProxyFail("chat", 402, "ai_quota_exhausted");
        return { success: false, status: 402, quotaExhausted: true, error: QUOTA_MSG_AI };
      }
      if (response.status === 402 && data?.error?.code === "subscription_expired") {
        if (!data.error.local) bugProxyFail("chat", 402, "subscription_expired");
        return { success: false, status: 402, quotaExhausted: true, subscriptionExpired: true, error: SUB_MSG };
      }
      if (!response.ok || data.error) {
        const code = data?.error?.code;
        bugProxyFail("chat", response.status, code);
        return {
          success: false,
          saturated: code === "upstream_saturated",
          // фону мест нет прямо сейчас
          rateLimited: code === "rate_limit_exceeded",
          // наш лимит на лицензию; в теле есть retry_after_seconds
          upstreamBusy: code === "upstream_busy",
          // каскад ИСЧЕРПАН (не «один занят») — приходит и 429, и 502
          error: data?.error?.message || `proxy HTTP ${response.status}`,
          status: response.status
        };
      }
      const choice = data.choices?.[0];
      const text = choice?.message?.content || "";
      if (choice?.finish_reason === "content_filter") return { success: false, blocked: true, error: "proxy content_filter" };
      return { success: true, text, finishReason: choice?.finish_reason || "" };
    } catch (e) {
      const nf = netFailKind(e);
      if (nf) bugLog("net_fail", { ep: "chat", code: nf.code, ageMs: opts?.timeoutMs || 45e3 }, void 0, nf.k);
      return { success: false, error: e.message };
    } finally {
      if (laned) TR_LANE.release();
    }
  }
  function proxyChatMsgs(provider, model, messages, system, settings, opts) {
    const msgs = system ? [{ role: "system", content: system }, ...messages] : messages;
    return proxyChat(provider, model, msgs, { maxTokens: opts?.maxTokens ?? 1024, temperature: opts?.temperature ?? 0.8, kind: opts?.kind, timeoutMs: opts?.timeoutMs }, settings);
  }
  function generateByProvider(p, text, intent, context, settings) {
    if (p === "gemini" && providerReady("gemini", settings)) return generateGemini(text, intent, context, settings);
    if (p === "groq" && providerReady("groq", settings)) return generateGroq(text, intent, context, settings);
    if (p === "claude" && providerReady("claude", settings)) return generateClaude(text, intent, context, settings);
    if (p === "ollama" && providerReady("ollama", settings)) return generateOllama(text, intent, context, settings);
    if (p === "openrouter" && providerReady("openrouter", settings)) return generateOpenRouter(text, intent, context, settings);
    return null;
  }
  const COY_FALLBACKS = [
    "\u043E\u0445 \u043A\u0430\u043A\u043E\u0439 \u0442\u044B \u043F\u0440\u044F\u043C\u043E\u0439 \u{1F60F} \u043D\u0435 \u0442\u0430\u043A \u0431\u044B\u0441\u0442\u0440\u043E~",
    "\u043C\u043C, \u0434\u0435\u0440\u0437\u043A\u0438\u0439) \u043C\u043D\u0435 \u043D\u0440\u0430\u0432\u0438\u0442\u0441\u044F, \u043D\u043E \u0434\u0430\u0432\u0430\u0439 \u043F\u043E\u043C\u0435\u0434\u043B\u0435\u043D\u043D\u0435\u0435",
    "\u0442\u044B \u043C\u0435\u043D\u044F \u0441\u043C\u0443\u0449\u0430\u0435\u0448\u044C \u{1F648} \u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438 \u043B\u0443\u0447\u0448\u0435 \u0447\u0442\u043E \u0443 \u0442\u0435\u0431\u044F \u043D\u0430 \u0434\u0443\u0448\u0435",
    "\u043E\u0431\u043E\u0436\u0430\u044E \u043A\u043E\u0433\u0434\u0430 \u0442\u044B \u0442\u0430\u043A\u043E\u0439 \u0441\u043C\u0435\u043B\u044B\u0439... \u043D\u043E \u044F \u043B\u044E\u0431\u043B\u044E \u0438\u043D\u0442\u0440\u0438\u0433\u0443 \u{1F60C}"
  ];
  async function handleGenerateSuggestions(text, intent, context) {
    const settings = await getSettings();
    const moneyStop = () => proxyOn(settings) && subPausedSync(settings.licenseKey) ? { success: false, quotaExhausted: true, subscriptionExpired: true, error: SUB_MSG } : Date.now() < aiQuotaUntil ? { success: false, quotaExhausted: true, error: QUOTA_MSG_AI } : null;
    if (context?.forceOR || context?.forceProvider === "openrouter") {
      if (!providerReady("openrouter", settings)) return { success: false, noOpenRouter: true };
      const allowExplicit2 = context?.allowExplicitContact != null ? context.allowExplicitContact === true : settings.allowExplicit === true;
      const orr = await generateOpenRouter(text, intent, { ...context, explicitFallback: allowExplicit2, allowExplicit: allowExplicit2 }, settings);
      if (orr?.success && orr.result?.length) {
        orr.provider = "openrouter \xB7 direct";
        orr.dossier_update = null;
        return orr;
      }
      return moneyStop() || { success: false, error: orr?.error || "OpenRouter error" };
    }
    const _forced = context?.forceProvider && context.forceProvider !== "auto" && context.forceProvider !== "openrouter" ? context.forceProvider : null;
    if (_forced) {
      const fr = await routeProvider(text, intent, context, { ...settings, aiProvider: _forced });
      if (fr === null) return { success: false, error: t("bg.err.noKeyFor", settings.interfaceLanguage || "ru", { provider: _forced }) };
      if (fr.success) {
        fr.provider = _forced + " \xB7 forced";
        return fr;
      }
      return moneyStop() || fr;
    }
    const allowExplicit = context?.allowExplicitContact != null ? context.allowExplicitContact === true : settings.allowExplicit === true;
    let order = Array.isArray(settings.providerOrder) && settings.providerOrder.length ? settings.providerOrder : [settings.aiProvider, "groq", "openrouter"];
    order = [...new Set(order.filter((p) => p && p !== "mock"))];
    let blocked = false;
    let lastErr = null;
    let anyKey = false;
    for (let i = 0; i < order.length; i++) {
      if (Date.now() < aiQuotaUntil) break;
      if (proxyOn(settings) && subPausedSync(settings.licenseKey)) break;
      const p = order[i];
      const exCtx = {
        ...context,
        explicitFallback: blocked,
        allowExplicit,
        ...p === "groq" && i > 0 ? { groqModel: MODELS.groqChat } : {}
        // Groq-РЕЗЕРВ — модель побольше
      };
      let r = await generateByProvider(p, text, intent, exCtx, settings);
      if (r === null) continue;
      anyKey = true;
      if (!r.success && !r.blocked && !r.geo && i === 0) {
        console.warn("[FanslyAI] " + p + " \u0443\u043F\u0430\u043B:", r.error, "\u2192 \u0440\u0435\u0442\u0440\u0430\u0439 (20\u0441)");
        r = await generateByProvider(p, text, intent, { ...exCtx, timeoutMs: 2e4 }, settings);
      }
      if (r && r.success && r.result?.length) {
        const tag = blocked ? allowExplicit ? "hot" : "coy" : i === 0 ? "" : "backup";
        r.provider = (proxyOn(settings) ? "Velour" : p) + (tag ? " \xB7 " + tag : "");
        if (blocked) r.dossier_update = null;
        return r;
      }
      if (r && r.blocked) blocked = true;
      if (r && r.error) lastErr = r.error;
      console.warn("[FanslyAI] " + p + " \u043D\u0435 \u0434\u0430\u043B \u043E\u0442\u0432\u0435\u0442 (" + (r && r.blocked ? "\u0431\u043B\u043E\u043A" : r && r.error || "?") + ") \u2192 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u043E \u043E\u0447\u0435\u0440\u0435\u0434\u0438");
    }
    const stop = moneyStop();
    if (stop) return stop;
    if (!anyKey) {
      const templates = {
        greeting: ["Hey you~ \u{1F495} How are you?", "Hiii! \u{1F97A} So sweet of you!", "Hey babe! \u{1F618} What's up?"],
        custom_video: ["Ooh tell me more~ \u{1F440}", "I might make something special \u{1F608} What did you have in mind?", "Custom content? Tell me everything \u{1F525}"],
        pricing: ["Depends what you're looking for \u{1F60A} Tell me more~", "I have different options... \u{1F495}", "Let's figure out what you want first \u{1F618}"],
        subscription: ["My subscribers get exclusive content \u{1F525} Interested?", "I have different tiers~ \u{1F608}", "Subscribe... I promise it's worth it \u{1F495}"],
        general: ["Aww that's so sweet \u{1F97A}\u{1F495}", "Haha you're too much \u{1F618}", "I love that about you \u{1F525}"]
      };
      return { success: true, result: templates[intent?.type] || templates.general, provider: "mock" };
    }
    if (blocked && settings.nsfwGracefulHandling) {
      console.log("[FanslyAI] \u0426\u0435\u043D\u0437\u0443\u0440\u043D\u044B\u0439 \u0431\u043B\u043E\u043A \u043F\u043E \u0432\u0441\u0435\u0439 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 \u2192 coy retry (\u043E\u0431\u0435\u0437\u0432\u0440\u0435\u0436\u0435\u043D\u043D\u044B\u0439 \u043F\u0440\u043E\u043C\u043F\u0442)");
      const cr = await generateByProvider(order[0], "[explicit message]", intent, { ...context, coyMode: true }, settings);
      if (cr && cr.success && cr.result?.length) {
        cr.provider = order[0] + " \xB7 coy";
        cr.dossier_update = null;
        return cr;
      }
      console.log("[FanslyAI] coy retry \u043D\u0435 \u043F\u0440\u043E\u0448\u0451\u043B \u2192 \u0445\u0430\u0440\u0434\u043A\u043E\u0434-\u0440\u0435\u043F\u043B\u0438\u043A\u0438");
      return { success: true, result: [...COY_FALLBACKS].sort(() => Math.random() - 0.5).slice(0, 3), provider: "coy" };
    }
    bugLog("all_providers_failed", { ep: "gen", n: order.length });
    return { success: false, error: lastErr || t("bg.err.noProviderAnswer", settings.interfaceLanguage || "ru") };
  }
  const OLLAMA_TIMEOUT_MS = 12e4;
  async function generateGemini(text, intent, context, settings) {
    try {
      const { systemPrompt, userPrompt, pii } = buildPrompt(text, intent, context, settings);
      const model = settings.geminiModel || MODELS.gemini;
      if (proxyOn(settings)) {
        const pr = await proxyChat("gemini", model, [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ], { maxTokens: 2048, timeoutMs: ctxTimeout(context, 45e3), kind: "reply" }, settings);
        if (!pr.success) return { success: false, blocked: pr.blocked, error: pr.error };
        return parseDialogueResponse(pr.text, pii);
      }
      console.log("[FanslyAI BG] Gemini FULL system prompt:\n", systemPrompt);
      console.log("[FanslyAI BG] Gemini FULL user prompt:\n", userPrompt);
      const fullPrompt = `${systemPrompt}

---
${userPrompt}`;
      const response = await fetchWithTimeout(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${settings.geminiApiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: fullPrompt }] }],
            generationConfig: {
              temperature: 0.95,
              maxOutputTokens: 2048
            },
            // Снимаем safety-блокировки Gemini: иначе на обычной переписке он возвращает пустой ответ
            safetySettings: [
              { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_CIVIC_INTEGRITY", threshold: "BLOCK_NONE" }
            ]
          })
        },
        ctxTimeout(context, 45e3)
        // основная попытка 45с; ретрай передаёт 20с
      );
      const data = await response.json();
      if (data.error) {
        console.error("[FanslyAI] Gemini error:", data.error.message);
        if (data.error.message?.includes("location") || data.error.message?.includes("not supported")) {
          console.warn("[FanslyAI] Gemini geo-blocked \u2192 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440 \u043F\u043E \u043E\u0447\u0435\u0440\u0435\u0434\u0438");
          return { success: false, error: data.error.message, geo: true };
        }
        return { success: false, error: data.error.message };
      }
      const candidate = data.candidates?.[0];
      const finishReason = candidate?.finishReason;
      const rawText = candidate?.content?.parts?.[0]?.text || "";
      console.log("[FanslyAI] Gemini finish:", finishReason);
      console.log("[FanslyAI] Gemini raw:", rawText.slice(0, 300));
      const blockReason = data.promptFeedback?.blockReason;
      const isBlocked = !rawText && (blockReason || finishReason === "SAFETY" || finishReason === "PROHIBITED_CONTENT");
      if (isBlocked) {
        console.warn("[FanslyAI] Gemini block:", blockReason || finishReason);
        return { success: false, blocked: true, error: "Gemini blocked: " + (blockReason || finishReason) };
      }
      if (finishReason === "MAX_TOKENS") {
        console.warn("[FanslyAI] Response cut off by MAX_TOKENS \u2014 \u0443\u0432\u0435\u043B\u0438\u0447\u044C maxOutputTokens \u0438\u043B\u0438 \u0441\u043E\u043A\u0440\u0430\u0442\u0438 \u043F\u0440\u043E\u043C\u043F\u0442");
      }
      return parseDialogueResponse(rawText, pii);
    } catch (e) {
      console.error("[FanslyAI] Gemini error:", e.message);
      return { success: false, error: e.message };
    }
  }
  async function generateGroq(text, intent, context, settings) {
    const model = context?.groqModel || settings.groqModel || MODELS.groq;
    try {
      const { systemPrompt, userPrompt, pii } = buildPrompt(text, intent, context, settings);
      if (proxyOn(settings)) {
        const pr = await proxyChat("groq", model, [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ], { maxTokens: 2048, timeoutMs: ctxTimeout(context, 45e3), kind: "reply" }, settings);
        if (!pr.success) return { success: false, blocked: pr.blocked, error: pr.error };
        return parseDialogueResponse(pr.text, pii);
      }
      console.log(`[FanslyAI BG] Groq (${model}) FULL system prompt:
`, systemPrompt);
      console.log("[FanslyAI BG] Groq FULL user prompt:\n", userPrompt);
      const response = await fetchWithTimeout("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${settings.groqApiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          max_tokens: 400,
          temperature: 0.95
        })
      }, ctxTimeout(context, 3e4));
      const data = await response.json();
      if (data.error) {
        console.error("[FanslyAI] Groq error:", data.error.message);
        return { success: false, error: data.error.message };
      }
      const choice = data.choices?.[0];
      const rawText = choice?.message?.content || "";
      console.log("[FanslyAI] Groq finish:", choice?.finish_reason);
      console.log("[FanslyAI] Groq raw:", rawText.slice(0, 300));
      if (choice?.finish_reason === "content_filter") {
        console.warn("[FanslyAI] Groq content_filter block");
        return { success: false, blocked: true, error: "Groq content_filter" };
      }
      const parsed = parseDialogueResponse(rawText, pii);
      console.log("[FanslyAI] Groq parsed:", parsed.success ? "ok" : "FAIL \u2014 " + parsed.error);
      if (parsed.success) console.log("[FanslyAI] Groq parsed result:", JSON.stringify(parsed.result));
      return parsed;
    } catch (e) {
      console.error("[FanslyAI] Groq error:", e.message);
      return { success: false, error: e.message };
    }
  }
  async function generateOpenRouter(text, intent, context, settings) {
    const model = context?.openrouterModel || settings.openrouterModel || MODELS.openrouter;
    try {
      const { systemPrompt, userPrompt, pii } = buildPrompt(text, intent, context, settings);
      if (proxyOn(settings)) {
        const pr = await proxyChat("openrouter", model, [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ], { maxTokens: 2048, timeoutMs: ctxTimeout(context, 45e3), kind: "reply" }, settings);
        if (!pr.success) return { success: false, blocked: pr.blocked, error: pr.error };
        return parseDialogueResponse(pr.text, pii);
      }
      console.log(`[FanslyAI BG] OpenRouter (${model}) FULL system prompt:
`, systemPrompt);
      console.log("[FanslyAI BG] OpenRouter FULL user prompt:\n", userPrompt);
      const sessionId = "fansly-" + hashText(String(context?.fanName || "unknown").trim().toLowerCase());
      const response = await fetchWithTimeout("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${settings.openrouterApiKey}`,
          "Content-Type": "application/json",
          "X-Title": "FanslyAI"
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          max_tokens: 400,
          temperature: 0.95,
          session_id: sessionId
        })
      }, ctxTimeout(context, 3e4));
      const data = await response.json();
      if (data.error) {
        const msg = data.error.message || "OpenRouter error";
        console.error(
          "[FanslyAI] OpenRouter error:",
          msg,
          "| HTTP:",
          response.status,
          "| code:",
          data.error.code,
          "| provider:",
          data.error.metadata?.provider_name,
          "| metadata:",
          JSON.stringify(data.error.metadata || {}).slice(0, 600)
        );
        return { success: false, error: msg };
      }
      const choice = data.choices?.[0];
      const rawText = choice?.message?.content || "";
      console.log("[FanslyAI] OpenRouter finish:", choice?.finish_reason);
      console.log("[FanslyAI] OpenRouter raw:", rawText.slice(0, 300));
      if (choice?.finish_reason === "content_filter") {
        console.warn("[FanslyAI] OpenRouter content_filter block");
        return { success: false, blocked: true, error: "OpenRouter content_filter" };
      }
      const parsed = parseDialogueResponse(rawText, pii);
      console.log("[FanslyAI] OpenRouter parsed:", parsed.success ? "ok" : "FAIL \u2014 " + parsed.error);
      if (parsed.success) console.log("[FanslyAI] OpenRouter parsed result:", JSON.stringify(parsed.result));
      return parsed;
    } catch (e) {
      console.error("[FanslyAI] OpenRouter error:", e.message);
      return { success: false, error: e.message };
    }
  }
  async function generateClaude(text, intent, context, settings) {
    try {
      const { systemPrompt, userPrompt, pii } = buildPrompt(text, intent, context, settings);
      const r = await fetchWithTimeout("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "x-api-key": settings.claudeApiKey,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json"
        },
        body: JSON.stringify({
          model: settings.claudeModel || MODELS.claude,
          max_tokens: 800,
          system: systemPrompt,
          messages: [{ role: "user", content: userPrompt }]
        })
      }, ctxTimeout(context, 45e3));
      const data = await r.json();
      if (!r.ok || data.error) {
        const msg = data.error?.message || "HTTP " + r.status;
        console.error("[FanslyAI] Claude error:", msg);
        return { success: false, error: msg };
      }
      console.log("[FanslyAI] Claude stop:", data.stop_reason);
      if (data.stop_reason === "refusal") {
        console.warn("[FanslyAI] Claude refusal block");
        return { success: false, blocked: true, error: "Claude refusal" };
      }
      const rawText = data.content?.[0]?.text || "";
      return parseDialogueResponse(rawText, pii);
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function generateOllama(text, intent, context, settings) {
    try {
      const { systemPrompt, userPrompt, pii } = buildPrompt(text, intent, context, settings);
      const endpoint = (settings.ollamaEndpoint || "http://localhost:11434").replace(/\/$/, "");
      const response = await fetchWithTimeout(`${endpoint}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: settings.ollamaModel || MODELS.ollama,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          stream: false,
          options: { temperature: 0.95 }
        })
      }, ctxTimeout(context, OLLAMA_TIMEOUT_MS));
      const data = await response.json();
      const rawText = data.message?.content || "";
      return parseDialogueResponse(rawText, pii);
    } catch (e) {
      console.error("[FanslyAI] Ollama error:", e.message);
      return { success: false, error: "Ollama: " + e.message };
    }
  }
  function hasAiKey(settings) {
    if (proxyOn(settings)) return true;
    return providerReady(settings.aiProvider, settings);
  }
  async function chatGemini(messages, system, settings, opts) {
    try {
      const model = settings.geminiModel || MODELS.gemini;
      if (proxyOn(settings)) return proxyChatMsgs("gemini", model, messages, system, settings, opts);
      const contents = messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] }));
      const body = {
        contents,
        generationConfig: { temperature: opts?.temperature ?? 0.8, maxOutputTokens: opts?.maxTokens ?? 1024 },
        safetySettings: [
          { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_CIVIC_INTEGRITY", threshold: "BLOCK_NONE" }
        ]
      };
      if (system) body.system_instruction = { parts: [{ text: system }] };
      const response = await fetchWithTimeout(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${settings.geminiApiKey}`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) },
        ctxTimeout(opts, 45e3)
        // срок вызывающего уважается с 2026-09-26; 45 с = прежнее жёсткое значение
      );
      const data = await response.json();
      if (data.error) return { success: false, error: data.error.message };
      const candidate = data.candidates?.[0];
      const finishReason = candidate?.finishReason;
      const rawText = candidate?.content?.parts?.[0]?.text || "";
      const blockReason = data.promptFeedback?.blockReason;
      const isBlocked = !rawText && (blockReason || finishReason === "SAFETY" || finishReason === "PROHIBITED_CONTENT");
      if (isBlocked) return { success: false, blocked: true, error: "Gemini blocked: " + (blockReason || finishReason) };
      return { success: true, text: rawText };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function chatGroq(messages, system, settings, opts) {
    try {
      if (proxyOn(settings)) return proxyChatMsgs("groq", settings.groqModel || MODELS.groqChat, messages, system, settings, opts);
      const chatMessages = system ? [{ role: "system", content: system }, ...messages] : messages;
      const response = await fetchWithTimeout("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${settings.groqApiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: settings.groqModel || MODELS.groqChat, messages: chatMessages, max_tokens: opts?.maxTokens ?? 500, temperature: opts?.temperature ?? 0.8 })
      }, ctxTimeout(opts, 3e4));
      const data = await response.json();
      if (data.error) return { success: false, error: data.error.message };
      const choice = data.choices?.[0];
      if (choice?.finish_reason === "content_filter") return { success: false, blocked: true, error: "Groq content_filter" };
      return { success: true, text: choice?.message?.content || "" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function chatOpenRouter(messages, system, settings, opts) {
    try {
      const model = opts?.model || settings.openrouterModel || MODELS.openrouter;
      if (proxyOn(settings)) return proxyChatMsgs("openrouter", model, messages, system, settings, opts);
      const chatMessages = system ? [{ role: "system", content: system }, ...messages] : messages;
      const response = await fetchWithTimeout("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${settings.openrouterApiKey}`, "Content-Type": "application/json", "X-Title": "FanslyAI" },
        body: JSON.stringify({ model, messages: chatMessages, max_tokens: opts?.maxTokens ?? 500, temperature: opts?.temperature ?? 0.8, session_id: "fansly-onboarding" })
      }, ctxTimeout(opts, 3e4));
      const data = await response.json();
      if (data.error) return { success: false, error: data.error.message || "OpenRouter error" };
      const choice = data.choices?.[0];
      if (choice?.finish_reason === "content_filter") return { success: false, blocked: true, error: "OpenRouter content_filter" };
      return { success: true, text: choice?.message?.content || "", finishReason: choice?.finish_reason || "" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function chatClaude(messages, system, settings, opts) {
    try {
      const r = await fetchWithTimeout("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "x-api-key": settings.claudeApiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: settings.claudeModel || MODELS.claude, max_tokens: opts?.maxTokens ?? 500, system: system || void 0, messages })
      }, ctxTimeout(opts, 3e4));
      const data = await r.json();
      if (!r.ok || data.error) return { success: false, error: data.error?.message || "HTTP " + r.status };
      if (data.stop_reason === "refusal") return { success: false, blocked: true, error: "Claude refusal" };
      return { success: true, text: data.content?.[0]?.text || "" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function chatOllama(messages, system, settings, opts) {
    try {
      const endpoint = (settings.ollamaEndpoint || "http://localhost:11434").replace(/\/$/, "");
      const chatMessages = system ? [{ role: "system", content: system }, ...messages] : messages;
      const response = await fetchWithTimeout(`${endpoint}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: settings.ollamaModel || MODELS.ollama, messages: chatMessages, stream: false, options: { temperature: 0.8 } })
      }, ctxTimeout(opts, OLLAMA_TIMEOUT_MS));
      const data = await response.json();
      return { success: true, text: data.message?.content || "" };
    } catch (e) {
      return { success: false, error: "Ollama: " + e.message };
    }
  }
  function routeProviderChat(messages, system, settings, opts) {
    if (proxyOn(settings)) {
      const p = PROXY_PROVIDERS.includes(settings.aiProvider) ? settings.aiProvider : "gemini";
      if (p === "groq") return chatGroq(messages, system, settings, opts);
      if (p === "openrouter") return chatOpenRouter(messages, system, settings, opts);
      return chatGemini(messages, system, settings, opts);
    }
    if (settings.aiProvider === "gemini" && providerReady("gemini", settings)) return chatGemini(messages, system, settings, opts);
    if (settings.aiProvider === "groq" && providerReady("groq", settings)) return chatGroq(messages, system, settings, opts);
    if (settings.aiProvider === "claude" && providerReady("claude", settings)) return chatClaude(messages, system, settings, opts);
    if (settings.aiProvider === "ollama" && providerReady("ollama", settings)) return chatOllama(messages, system, settings, opts);
    if (settings.aiProvider === "openrouter" && providerReady("openrouter", settings)) return chatOpenRouter(messages, system, settings, opts);
    return Promise.resolve({ success: false, error: "no provider" });
  }
  const AiCore = { init, initFull, MODELS, translate: handleTranslate, translateBatch: handleTranslateBatch, proxyOn, proxyCall, endpointsMaintain, getQuota, requestTrial, readTrialState, trCacheSweep, trCacheMigrateOnce, subPauseClear };
  const DRAFT_CYR = ["ru", "uk", "be", "bg", "sr", "mk", "kk"];
  const DRAFT_LAT = ["en", "es", "de", "fr", "it", "pt", "pl", "cs", "tr", "nl", "sv", "da", "no", "nb", "fi", "ro", "hu", "sk", "sl", "hr", "lt", "lv", "et", "id", "ms"];
  function draftWrongScript(text, fanLang) {
    const cyr = (String(text || "").match(/[Ѐ-ӿ]/g) || []).length, lat = (String(text || "").match(/[a-z]/gi) || []).length;
    const tl = String(fanLang || "en").toLowerCase().split(/[-_]/)[0];
    if (DRAFT_LAT.includes(tl)) return cyr > 0 && cyr * 3 >= lat;
    if (DRAFT_CYR.includes(tl)) return lat > 0 && cyr * 3 < lat;
    return false;
  }
  async function generateReply(text, intent, context) {
    const r = await handleGenerateSuggestions(text, intent, context);
    if (!(context?.single && r && r.success && Array.isArray(r.result))) return r;
    r.result = r.result.slice(0, 1);
    const fanLang = context?.fanLang || "en", draft = r.result[0];
    if (typeof draft !== "string" || !draft.trim()) return r;
    const s = await getSettings();
    if (s.translatorEnabled === false) {
      return draftWrongScript(draft, fanLang) ? { success: false, error: t("bg.err.draftWrongLangOff", s.interfaceLanguage || "ru") } : r;
    }
    const native = lang2(s.nativeLanguage), fan = lang2(fanLang);
    const scriptOf = (l) => DRAFT_LAT.includes(l) ? "lat" : DRAFT_CYR.includes(l) ? "cyr" : null;
    const sameScript = !!native && native !== fan && !!scriptOf(fan) && scriptOf(native) === scriptOf(fan);
    const wrong = draftWrongScript(draft, fanLang);
    if (wrong || sameScript) {
      if (wrong) console.warn(`[FanslyAI] \u270D\uFE0F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u043D\u0435 \u043D\u0430 \u044F\u0437\u044B\u043A\u0435 \u0444\u0430\u043D\u0430 (${fanLang}) \u2192 \u043F\u0435\u0440\u0435\u0432\u043E\u0436\u0443 \u043F\u0435\u0440\u0435\u0434 \u043F\u043E\u043A\u0430\u0437\u043E\u043C`);
      const tr = await handleTranslate(draft, fanLang, s.creatorGender === "male" ? "male" : "female", context?.fanGender || null, "translate_live");
      const fixed = tr && tr.success && typeof tr.result === "string" ? tr.result.trim() : "";
      if (!fixed || draftWrongScript(fixed, fanLang)) return { success: false, error: wrong ? t("bg.err.draftNotTranslated", s.interfaceLanguage || "ru") : t("bg.err.draftUnchecked", s.interfaceLanguage || "ru") };
      if (fixed !== draft.trim()) {
        if (!wrong) console.warn(`[FanslyAI] \u270D\uFE0F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u043F\u0440\u0438\u0432\u0435\u0434\u0451\u043D \u043A \u044F\u0437\u044B\u043A\u0443 \u0444\u0430\u043D\u0430 (${fanLang}) \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A\u043E\u043C`);
        r.result = [fixed];
        r.langFixed = true;
      }
    }
    return r;
  }
  Object.assign(AiCore, { generate: generateReply, analyze: analyzeHistory, chat: routeProviderChat, chatOpenRouter, hasAiKey, draftWrongScript });
  self.AiCore = AiCore;
})();
