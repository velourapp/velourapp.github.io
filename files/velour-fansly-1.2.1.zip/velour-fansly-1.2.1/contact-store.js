(function() {
  "use strict";
  let state, hashString, sendSafe, renderDossier, renderBrief;
  const DEPS = ["state", "hashString", "send", "renderDossier"];
  function init(deps) {
    const d = deps || {};
    const missing = DEPS.filter((k) => d[k] == null);
    if (missing.length) console.warn("[FanslyAI] ContactStore.init: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439:", missing.join(", "));
    state = d.state;
    hashString = d.hashString;
    sendSafe = d.send;
    renderDossier = d.renderDossier;
  }
  function initBackground(deps) {
    const d = deps || {};
    if (d.hashString == null) console.warn("[FanslyAI] ContactStore.initBackground: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439: hashString");
    hashString = d.hashString;
  }
  function keyOfId(id) {
    return "fai_contact_" + id;
  }
  function keyOfName(name) {
    return "fai_contact_" + hashString(name || "unknown");
  }
  function keyOfCurrent() {
    return state.currentContactId ? keyOfId(state.currentContactId) : keyOfName(state.currentContact);
  }
  function contactDataIsCurrent() {
    return !!state.contactData && state._dataFor === keyOfCurrent();
  }
  function emptyDossier() {
    return { facts: [], closeness: "new", topics: [], lastMessageAt: null };
  }
  function defaultContact(name) {
    return {
      name,
      handle: null,
      nameHistory: [],
      gender: "male",
      totalMsgs: 0,
      lang: "en",
      note: "",
      isSubscribed: false,
      dossier: emptyDossier(),
      brief: null,
      excludeFromAuto: false,
      // личный контакт — карусель его пропускает
      allowExplicit: null
      // пер-контакт оверрайд общей настройки: null=как в ней, true=разрешён, false=запрещён. Кнопки больше нет (Алекс 03.11): новых отметок не появится, сохранённые действуют
      // closed_toxic (токсичность, todo 48) и confirmOverride (todo 50) сняты 2026-10-08
      // вместе с фичами: в старых записях поля остаются как есть, читать их некому.
    };
  }
  const QUEUE_GUARD_MS = 5e3;
  const tails = /* @__PURE__ */ new Map();
  const qstat = { ops: 0, waited: 0, maxWaitMs: 0, timeouts: 0, refused: 0 };
  function withKey(key, op) {
    qstat.ops++;
    const prev = tails.get(key);
    const start = () => {
      try {
        return Promise.resolve(op());
      } catch (e) {
        return Promise.reject(e);
      }
    };
    const result = prev ? waitTurn(prev, key).then(start) : start();
    const tail = result.then(() => {
    }, () => {
    });
    tails.set(key, tail);
    tail.then(() => {
      if (tails.get(key) === tail) tails.delete(key);
    });
    return result;
  }
  function waitTurn(prev, key) {
    qstat.waited++;
    const t0 = Date.now();
    return new Promise((go) => {
      let over = false, timer = null;
      const pass = (timedOut) => {
        if (over) return;
        over = true;
        if (timedOut) {
          qstat.timeouts++;
          console.warn("[FanslyAI] ContactStore: \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 " + key + " \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0430\u0441\u044C \u0437\u0430 " + QUEUE_GUARD_MS + " \u043C\u0441 \u2014 \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u043E\u0442\u043F\u0443\u0441\u043A\u0430\u0435\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443");
        } else if (timer != null) {
          try {
            clearTimeout(timer);
          } catch (e) {
          }
        }
        qstat.maxWaitMs = Math.max(qstat.maxWaitMs, Date.now() - t0);
        go();
      };
      try {
        timer = setTimeout(() => {
          if (Date.now() - t0 >= QUEUE_GUARD_MS) pass(true);
        }, QUEUE_GUARD_MS);
      } catch (e) {
      }
      prev.then(() => pass(false));
    });
  }
  function queueStats() {
    return { ops: qstat.ops, waited: qstat.waited, maxWaitMs: qstat.maxWaitMs, timeouts: qstat.timeouts, refused: qstat.refused, pending: tails.size };
  }
  async function loadContact(name, handle = null) {
    const primaryKey = keyOfCurrent();
    return new Promise((resolve) => withKey(primaryKey, () => new Promise((done) => {
      chrome.storage.local.get(null, (all) => {
        let data = all[primaryKey] || null;
        let dirty = false;
        for (const [k, v] of Object.entries(all)) {
          if (k === primaryKey || !k.startsWith("fai_contact_") || !v) continue;
          const suffix = k.slice("fai_contact_".length);
          const isNumericId = /^\d{12,}$/.test(suffix);
          if (isNumericId) continue;
          const sameHandle = handle && v.handle && v.handle === handle;
          const sameName = v.name && v.name === name;
          if (!(sameHandle || sameName)) continue;
          if (!data) {
            data = v;
            console.log(`[FanslyAI] \u043A\u043E\u043D\u0442\u0430\u043A\u0442 "${name}": ${k} \u2192 ${primaryKey} (\u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F)`);
          } else console.log(`[FanslyAI] \u043A\u043E\u043D\u0442\u0430\u043A\u0442 "${name}": \u0443\u0434\u0430\u043B\u044F\u044E \u0434\u0443\u0431\u043B\u044C ${k} (\u043A\u0430\u043D\u043E\u043D ${primaryKey})`);
          chrome.storage.local.remove(k);
          dirty = true;
        }
        if (data) {
          if (dirty) chrome.storage.local.set({ [primaryKey]: data }, done);
          else done();
          resolve(data);
          return;
        }
        done();
        resolve(defaultContact(name));
      });
    })));
  }
  function saveContact(name, updates) {
    const key = keyOfCurrent();
    if (state.contactData && state._dataFor === key) {
      Object.assign(state.contactData, updates);
      const rec = state.contactData;
      withKey(key, () => new Promise((done) => chrome.storage.local.get([key], (st) => {
        try {
          const fresh = st && st[key];
          chrome.storage.local.set({ [key]: fresh ? Object.assign(fresh, updates) : rec }, done);
        } catch (e) {
          done();
          throw e;
        }
      })));
      return;
    }
    if (state.contactData) {
      qstat.refused++;
      console.warn("[FanslyAI] ContactStore: \u043E\u0442\u043A\u0430\u0437 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 " + key + " \u2014 \u0432 \u043F\u0430\u043C\u044F\u0442\u0438 " + (state._dataFor ? "\u0437\u0430\u043F\u0438\u0441\u044C \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0447\u0430\u0442\u0430 (" + state._dataFor + ")" : "\u0437\u0430\u0433\u043B\u0443\u0448\u043A\u0430 \u0431\u0435\u0437 \u043F\u0440\u043E\u0438\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u044F") + "; \u043F\u043E\u043B\u044F: " + Object.keys(updates || {}).join(", "));
      return;
    }
    withKey(key, () => new Promise((done) => chrome.storage.local.get(key, (data) => {
      try {
        const existing = data[key] || defaultContact(name);
        chrome.storage.local.set({ [key]: Object.assign({}, existing, updates) }, done);
      } catch (e) {
        done();
        throw e;
      }
    })));
  }
  function patchRecord(key, patch) {
    return withKey(key, () => new Promise((res) => {
      try {
        chrome.storage.local.get([key], (d) => {
          try {
            const rec = d && d[key];
            if (!rec) {
              res(false);
              return;
            }
            const p = typeof patch === "function" ? patch(rec) : patch;
            Object.assign(rec, p || {});
            chrome.storage.local.set({ [key]: rec }, () => res(true));
          } catch (e) {
            res(false);
          }
        });
      } catch (e) {
        res(false);
      }
    }));
  }
  function pinnedOf(d) {
    return d && d.manualFacts || [];
  }
  function isPinned(d, fact) {
    return pinnedOf(d).includes(fact);
  }
  function applyScanMarks(d, update) {
    if (update.analyzedUpTo) d.analyzedUpTo = Math.max(d.analyzedUpTo || 0, update.analyzedUpTo);
    if (update.partial) d.partialScan = true;
    else if (update.facts) delete d.partialScan;
  }
  function keepPinnedOnly(d) {
    const pin = pinnedOf(d);
    const kept = {};
    pin.forEach((f) => {
      if (d.factDates && d.factDates[f]) kept[f] = d.factDates[f];
    });
    d.facts = pin.slice();
    d.factDates = kept;
    d.topics = [];
  }
  function initFull(deps) {
    const d = deps || {};
    if (d.renderBrief == null) console.warn("[FanslyAI] ContactStore.initFull: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0435\u0439: renderBrief");
    renderBrief = d.renderBrief;
  }
  function emptyBrief() {
    return { wants: "", details: [], mood: "", refs: [], collectedAt: null, collectedAtMsg: null };
  }
  const CLOSENESS = ["new", "interested", "regular", "supporter"];
  function applyDossierUpdate(update, replace = false, target = null) {
    const name = target ? target.name : state.currentContact;
    const data = target ? target.data : contactDataIsCurrent() ? state.contactData : null;
    if (!data || !name) return;
    const d = data.dossier || emptyDossier();
    if (!d.factDates) d.factDates = {};
    if (!d.manualFacts) d.manualFacts = [];
    if (replace) keepPinnedOnly(d);
    applyScanMarks(d, update);
    if (update.facts?.length) {
      update.facts.forEach((f) => {
        const trimmed = f?.trim();
        if (trimmed && trimmed.length > 3 && !d.facts.includes(trimmed)) {
          d.facts.push(trimmed);
          const fd = update.factDates?.[trimmed];
          if (fd) d.factDates[trimmed] = fd;
          else if (!update.datesResolved) d.factDates[trimmed] = Date.now();
        }
      });
    }
    const levels = CLOSENESS;
    if (update.closeness && levels.includes(update.closeness)) {
      if (replace) d.closeness = update.closeness;
      else {
        const cur = levels.indexOf(d.closeness || "new");
        const nxt = levels.indexOf(update.closeness);
        if (nxt > cur) d.closeness = update.closeness;
      }
    }
    if (update.topics?.length) {
      update.topics.forEach((t2) => {
        const trimmed = t2?.trim();
        if (trimmed && !d.topics.includes(trimmed)) d.topics.push(trimmed);
      });
    }
    data.dossier = d;
    savePatchTo(target, name, { dossier: d });
    if (data === state.contactData) renderDossier();
  }
  function savePatchTo(target, name, patch) {
    if (target && target.id && target.id !== state.currentContactId) {
      const key = keyOfId(target.id);
      withKey(key, () => new Promise((done) => chrome.storage.local.get([key], (st) => {
        try {
          const c = st[key] || Object.assign({}, target.data || defaultContact(name));
          Object.assign(c, patch);
          chrome.storage.local.set({ [key]: c }, done);
        } catch (e) {
          done();
          throw e;
        }
      })));
    } else {
      saveContact(name, patch);
    }
  }
  function applyBrief(brief, target = null, rebuild = false) {
    const name = target ? target.name : state.currentContact;
    const data = target ? target.data : contactDataIsCurrent() ? state.contactData : null;
    if (!brief || !data || !name) return;
    const hasContent = brief.wants && brief.wants.trim() || brief.details?.length || brief.mood && brief.mood.trim() || brief.refs?.length;
    if (!hasContent) return;
    const isNew = !data.brief;
    const b = data.brief || emptyBrief();
    const before = JSON.stringify([b.wants, b.mood, b.details, b.refs]);
    if (rebuild) {
      b.wants = "";
      b.mood = "";
      b.details = [];
      b.refs = [];
    }
    if (brief.wants && brief.wants.trim()) b.wants = brief.wants.trim();
    if (brief.mood && brief.mood.trim()) b.mood = brief.mood.trim();
    const toArr = (v) => Array.isArray(v) ? v : typeof v === "string" && v.trim() ? [v] : [];
    toArr(brief.details).forEach((d) => {
      const t2 = (typeof d === "string" ? d : String(d ?? "")).trim();
      if (t2 && !b.details.includes(t2)) b.details.push(t2);
    });
    toArr(brief.refs).forEach((r) => {
      const t2 = (typeof r === "string" ? r : String(r ?? "")).trim();
      if (t2 && !b.refs.includes(t2)) b.refs.push(t2);
    });
    if (isNew || JSON.stringify([b.wants, b.mood, b.details, b.refs]) !== before) b.collectedAt = brief.collectedAt || Date.now();
    if (isNew || b.collectedAtMsg == null) b.collectedAtMsg = data.totalMsgs || 0;
    data.brief = b;
    savePatchTo(target, name, { brief: b });
    if (data === state.contactData) renderBrief();
    if (isNew) {
      const snippet = b.wants || b.details[0] || t("panel.brief.detailsInPanel", state.uiLang);
      sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "brief", fan: name, text: t("panel.tg.briefCollected", state.uiLang, { name, snippet: snippet.slice(0, 80) }) });
    }
  }
  async function mergeAnalysisIntoContact(name, id, result, replace = false) {
    const key = id ? keyOfId(id) : keyOfName(name);
    return withKey(key, () => mergeAnalysisNow(key, name, result, replace));
  }
  async function mergeAnalysisNow(key, name, result, replace) {
    const data = await new Promise((res) => chrome.storage.local.get([key], (d) => res(d[key]))) || defaultContact(name);
    if (!data.dossier) data.dossier = emptyDossier();
    if (!data.dossier.factDates) data.dossier.factDates = {};
    if (!data.dossier.manualFacts) data.dossier.manualFacts = [];
    if (replace) keepPinnedOnly(data.dossier);
    applyScanMarks(data.dossier, result);
    (result.facts || []).forEach((f) => {
      const t2 = f?.trim();
      if (t2 && t2.length > 3 && !data.dossier.facts.includes(t2)) {
        data.dossier.facts.push(t2);
        const fd = result.factDates?.[t2];
        if (fd) data.dossier.factDates[t2] = fd;
        else if (!result.datesResolved) data.dossier.factDates[t2] = Date.now();
      }
    });
    const levels = CLOSENESS;
    if (result.closeness && levels.includes(result.closeness)) {
      if (replace) data.dossier.closeness = result.closeness;
      else if (levels.indexOf(result.closeness) > levels.indexOf(data.dossier.closeness || "new")) {
        data.dossier.closeness = result.closeness;
      }
    }
    (result.topics || []).forEach((t2) => {
      const x = t2?.trim();
      if (x && !data.dossier.topics.includes(x)) data.dossier.topics.push(x);
    });
    const br = result.brief;
    if (br && (br.wants || br.details?.length || br.mood || br.refs?.length)) {
      const wasNew = !data.brief;
      const b = data.brief || emptyBrief();
      const before = JSON.stringify([b.wants, b.mood, b.details, b.refs]);
      if (br.wants?.trim()) b.wants = br.wants.trim();
      if (br.mood?.trim()) b.mood = br.mood.trim();
      (br.details || []).forEach((d) => {
        const x = d?.trim();
        if (x && !b.details.includes(x)) b.details.push(x);
      });
      (br.refs || []).forEach((r2) => {
        const x = r2?.trim();
        if (x && !b.refs.includes(x)) b.refs.push(x);
      });
      if (wasNew || JSON.stringify([b.wants, b.mood, b.details, b.refs]) !== before) b.collectedAt = br.collectedAt || Date.now();
      if (b.collectedAtMsg == null) b.collectedAtMsg = data.totalMsgs || 0;
      data.brief = b;
    }
    await new Promise((res) => chrome.storage.local.set({ [key]: data }, () => res()));
    console.log("[FanslyAI] \u0410\u043D\u0430\u043B\u0438\u0437 \u0437\u0430\u043F\u0438\u0441\u0430\u043D \u0432 \u0444\u043E\u043D \u0434\u043B\u044F", name, "| \u0444\u0430\u043A\u0442\u043E\u0432 \u0442\u0435\u043F\u0435\u0440\u044C", data.dossier.facts.length);
  }
  function readContactRecord(id) {
    const key = keyOfId(id);
    return new Promise((r) => {
      try {
        chrome.storage.local.get(key, (d) => r(d[key] || null));
      } catch (e) {
        r(null);
      }
    });
  }
  async function loadExcludedIds() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (all) => {
        const set = /* @__PURE__ */ new Set();
        for (const [k, v] of Object.entries(all)) {
          if (k.startsWith("fai_contact_") && v?.excludeFromAuto) {
            set.add(k.replace("fai_contact_", ""));
          }
        }
        resolve(set);
      });
    });
  }
  function loadExcludedContacts() {
    return new Promise((res) => chrome.storage.local.get(null, (all) => {
      const out = [];
      for (const [k, v] of Object.entries(all)) {
        if (k.startsWith("fai_contact_") && v?.excludeFromAuto) out.push({ id: k.replace("fai_contact_", ""), name: v.name || "" });
      }
      res(out);
    }));
  }
  function setContactExcludedById(id, val) {
    return patchRecord(keyOfId(id), { excludeFromAuto: val });
  }
  const ContactStore = { init, keyOfId, keyOfName, keyOfCurrent, contactDataIsCurrent, defaultContact, loadContact, saveContact, pinnedOf, isPinned, applyScanMarks, keepPinnedOnly, queueStats, initBackground, patchRecord };
  Object.assign(ContactStore, { initFull, applyDossierUpdate, savePatchTo, applyBrief, mergeAnalysisIntoContact, readContactRecord, loadExcludedIds, loadExcludedContacts, setContactExcludedById });
  self.ContactStore = ContactStore;
})();
