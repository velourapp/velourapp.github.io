(function() {
  "use strict";
  let getSettings, saveSettings, fetchWithTimeout, generatePost, startInviteFlow;
  async function notifyTelegram(token, chatId, text, threadId, retries = 0, replyMarkup = null) {
    if (!token || !chatId) return { success: false, error: "no token/chat" };
    const send = async (tid = threadId) => {
      const body = { chat_id: chatId, text, disable_web_page_preview: true };
      if (tid) body.message_thread_id = tid;
      if (replyMarkup) body.reply_markup = replyMarkup;
      return tgApi(token, "sendMessage", body);
    };
    const gone = (d) => !d.ok && /thread not found/i.test(d.description || "");
    try {
      let data = await send();
      for (let i = 0; i < retries && gone(data) && threadId; i++) {
        await new Promise((r) => setTimeout(r, 1e3 * (i + 1)));
        data = await send();
      }
      if (gone(data) && threadId) {
        const fresh = await healTopic(token, chatId, threadId);
        if (fresh) {
          data = await send(fresh);
          for (let i = 0; i < 3 && gone(data); i++) {
            await new Promise((r) => setTimeout(r, 1e3 * (i + 1)));
            data = await send(fresh);
          }
        }
      }
      if (!data.ok) {
        console.warn("[FanslyAI] Telegram \u043E\u0442\u043A\u0430\u0437\u0430\u043B:", data.description);
        return { success: false, error: data.description };
      }
      return { success: true, message_id: data.result?.message_id };
    } catch (e) {
      console.warn("[FanslyAI] Telegram error:", e.message);
      return { success: false, error: e.message };
    }
  }
  const _dlgSent = /* @__PURE__ */ new Map();
  const DLG_DEDUP_TTL = 9e4;
  function dedupDialogueLines(text, marked, preDeduped = false) {
    const now = Date.now();
    for (const [k, ts] of _dlgSent) if (now - ts > DLG_DEDUP_TTL) _dlgSent.delete(k);
    const out = [];
    for (const line of String(text || "").split("\n")) {
      const key = line.trim();
      if (!key) {
        out.push(line);
        continue;
      }
      if (_dlgSent.has(key)) continue;
      if (preDeduped) {
        out.push(line);
        continue;
      }
      _dlgSent.set(key, now);
      if (marked) marked.push(key);
      out.push(line);
    }
    if (_dlgSent.size > 500) {
      const excess = _dlgSent.size - 500;
      let i = 0;
      for (const k of _dlgSent.keys()) {
        if (i++ >= excess) break;
        _dlgSent.delete(k);
      }
    }
    return out.join("\n");
  }
  const DLG_LINE_RE = /^💬 (.+?) (🤖|👤) ([\s\S]*)$/;
  const DLG_FAN_MARK = "\u{1F464}";
  function formatDialogueText(text, withName, lang) {
    const ownPrefix = t("bg.tg.ownPrefix", lang);
    return String(text || "").split("\n").map((line) => {
      const m = line.match(DLG_LINE_RE);
      if (!m) return line;
      const [, name, mark, body] = m;
      const own = mark === "\u{1F916}";
      if (!withName) return own ? ownPrefix + body : `${DLG_FAN_MARK} ${body}`;
      return own ? `${name} \xB7 ${ownPrefix}${body}` : `${DLG_FAN_MARK} ${name}: ${body}`;
    }).join("\n");
  }
  function collapseSentEcho(text) {
    const kept = String(text || "").split("\n").filter((l) => !/^✅ → /.test(l));
    return kept.join("\n");
  }
  const TG_STATUS_MUTE = /^(🔁|🌙|⏳)/;
  let _lastStatus = { text: "", ts: 0 };
  async function handleTelegramNotify(notifyType, text, token, chatId, fan, variantCount = 3, handle = null, preDeduped = false, extra = null) {
    const marked = [];
    const prevStatus = _lastStatus;
    const r = await handleTelegramNotifySend(marked, notifyType, text, token, chatId, fan, variantCount, handle, preDeduped, extra);
    if (r && r.success === false) {
      for (const k of marked) _dlgSent.delete(k);
      if (notifyType === "status" && _lastStatus.text === text) _lastStatus = prevStatus;
      if (marked.length) console.warn("[FanslyAI] \u0422\u0413: \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435 \u0443\u0434\u0430\u043B\u0430\u0441\u044C \u2192 \u0441\u043D\u044F\u043B \u043F\u043E\u043C\u0435\u0442\u043A\u0438 \u0441 " + marked.length + " \u0441\u0442\u0440\u043E\u043A (\u0440\u0435\u0442\u0440\u0430\u0439 \u043F\u0440\u043E\u0439\u0434\u0451\u0442)");
    }
    return r;
  }
  async function handleTelegramNotifySend(marked, notifyType, text, token, chatId, fan, variantCount = 3, handle = null, preDeduped = false, extra = null) {
    const s = await getSettings();
    const lang = s.interfaceLanguage || "ru";
    const tok = token || s.telegramBotToken;
    const cid = chatId || s.telegramChatId;
    if (!tok || !cid) return { success: false, error: t("bg.err.noTokenChatId", lang) };
    if (notifyType !== "test") {
      const al = await getTgAlert();
      if (al && al.kind === "bot_removed") return { success: false, error: "bot removed from group" };
      if (tgPausedState(al, await getTgHold(), await getTgGroupAlert())) return { success: false, error: "paused: unconfirmed member, bot without rights or public group" };
    }
    if (s.masterEnabled === false && notifyType !== "test" && notifyType !== "status") return { success: false, error: "master off" };
    if (s.carouselEnabled === false && notifyType !== "test") return { success: false, error: t("bg.err.mirrorOff", lang) };
    if (notifyType === "status") {
      const now = Date.now();
      if (_lastStatus.text === text && now - _lastStatus.ts < 9e4) return { success: true, deduped: true };
      _lastStatus = { text, ts: now };
    }
    if (notifyType !== "test") {
      if (!s.telegramEnabled) return { success: false, error: "tg off" };
      if (notifyType !== "digest" && notifyType !== "status" && notifyType !== "variants" && notifyType !== "outreach") {
        const gate = { brief: s.tgNotifyBrief, dialogue: true };
        if (gate[notifyType] === false) return { success: false, error: "type off" };
      }
    }
    if (notifyType === "status" && TG_STATUS_MUTE.test(String(text || "").trim())) return { success: true, muted: true };
    if (notifyType === "dialogue") {
      text = dedupDialogueLines(text, marked, preDeduped);
      if (!text.trim()) return { success: true, deduped: true };
      text = collapseSentEcho(text);
      if (!text.trim()) return { success: true, collapsed: true };
      text = formatDialogueText(text, !s.tgTopics, s.interfaceLanguage || "ru");
    }
    if (!s.tgTopics) return notifyTelegram(tok, cid, text);
    const topics = topicsFor(await getTgTopics(), cid);
    if (notifyType === "test") return notifyTelegram(tok, cid, text);
    if (notifyType === "digest" || notifyType === "status")
      return notifyTelegram(tok, cid, text, topics.important);
    if (notifyType === "outreach") {
      const kb = handle ? { inline_keyboard: [[{ text: t("bg.btn.invite", lang), callback_data: "inv:" + handle }]] } : null;
      return notifyTelegram(tok, cid, text, topics.important, 0, kb);
    }
    if (notifyType === "variants" && fan && extra && extra.single === true && typeof extra.draft === "string" && extra.draft.trim()) {
      const kb = { inline_keyboard: [[{ text: t("bg.btn.draftSend", lang), callback_data: "gd" }, { text: t("bg.btn.draftAgain", lang), callback_data: "ga" }]] };
      const rv = await sendFanTopic(tok, cid, text, fan, topics, kb);
      await trackLatestBtn(tok, cid, fan, rv);
      const tid = topicsFor(await getTgTopics(), cid).fans?.[fan];
      if (rv?.success && rv.message_id && tid) await pushFanDraft(cid, tid, extra.task, extra.draft, rv.message_id, extra.again === true);
      return rv;
    }
    if (notifyType === "variants") {
      const n = Math.min(Math.max(parseInt(variantCount) || 1, 1), 3);
      const row = [];
      for (let i = 0; i < n; i++) row.push({ text: `${i + 1}`, callback_data: "gs" + i });
      const rv = await sendFanTopic(tok, cid, text, fan, topics, { inline_keyboard: [row] });
      await trackLatestBtn(tok, cid, fan, rv);
      return rv;
    }
    if (notifyType === "dialogue") {
      return sendFanTopic(tok, cid, text, fan, topics, null);
    }
    if (notifyType === "cmd") return fan ? sendFanTopic(tok, cid, text, fan, topics, null) : notifyTelegram(tok, cid, text);
    const r = await sendFanTopic(tok, cid, text, fan, topics, null);
    if (topics.important) await notifyTelegram(tok, cid, text, topics.important);
    return r;
  }
  async function sendFanTopic(tok, cid, text, fan, topics, replyMarkup = null) {
    if (!fan) return notifyTelegram(tok, cid, text);
    const { tid, created } = await getOrCreateFanTopic(tok, cid, fan, topics);
    let r = await notifyTelegram(tok, cid, text, tid, created ? 3 : 0, replyMarkup);
    if (!r.success && !created && /thread not found/i.test(r.error || "")) {
      delete topics.fans[fan];
      const fresh = topicsFor(await getTgTopics(), cid);
      delete fresh.fans[fan];
      await saveTgTopics(fresh);
      const re = await getOrCreateFanTopic(tok, cid, fan, topics);
      r = await notifyTelegram(tok, cid, text, re.tid, 3, replyMarkup);
    }
    return r;
  }
  async function trackLatestBtn(tok, cid, fan, r) {
    if (!r?.success || !r.message_id || !fan) return;
    const fresh = topicsFor(await getTgTopics(), cid);
    const tid = fresh.fans?.[fan];
    if (!tid) return;
    const map = await new Promise((res) => chrome.storage.local.get("fansly_tg_lastbtn", (d) => res(d.fansly_tg_lastbtn || {})));
    const prev = map[tid];
    if (prev && prev !== r.message_id) {
      await tgApi(tok, "editMessageReplyMarkup", { chat_id: cid, message_id: prev, reply_markup: { inline_keyboard: [] } });
    }
    map[tid] = r.message_id;
    await new Promise((res) => chrome.storage.local.set({ fansly_tg_lastbtn: map }, res));
  }
  function getTgTopics() {
    return new Promise((res) => chrome.storage.local.get("fansly_tg_topics", (d) => res(d.fansly_tg_topics || { important: null, posts: null, fans: {} })));
  }
  function saveTgTopics(map) {
    if (map && map.chat) map.chat = chatAlias(map.chat);
    return new Promise((res) => chrome.storage.local.set({ fansly_tg_topics: map }, () => res()));
  }
  const TG_TOPIC_KEYS = { important: "bg.tg.topicName.important", posts: "bg.tg.topicName.posts" };
  async function serviceTopicName(kind) {
    return t(TG_TOPIC_KEYS[kind], (await getSettings()).interfaceLanguage || "ru");
  }
  function topicsFor(map, chatId) {
    const cid = chatAlias(chatId);
    if (map && map.chat && chatAlias(map.chat) !== cid) return { important: null, posts: null, fans: {}, chat: cid };
    if (map && cid && String(map.chat || "") !== cid) map.chat = cid;
    return map;
  }
  const _chatMoved = /* @__PURE__ */ new Map();
  let _announceMove = null;
  const chatAlias = (id) => {
    let cur = String(id || "");
    for (let i = 0; i < 3 && _chatMoved.has(cur); i++) cur = _chatMoved.get(cur);
    return cur;
  };
  async function noteChatMoved(oldId, newId) {
    oldId = String(oldId || "");
    newId = String(newId || "");
    if (!oldId || !newId || oldId === newId || _chatMoved.get(oldId) === newId) return false;
    _chatMoved.set(oldId, newId);
    console.warn("[FanslyAI] \u0422\u0413: \u0433\u0440\u0443\u043F\u043F\u0430 \u0441\u0442\u0430\u043B\u0430 \u0441\u0443\u043F\u0435\u0440\u0433\u0440\u0443\u043F\u043F\u043E\u0439, \u0443 \u043D\u0435\u0451 \u043D\u043E\u0432\u044B\u0439 id:", oldId, "\u2192", newId);
    const s = await getSettings();
    const patch = {};
    for (const k of ["telegramChatId", "tgOwnerChat", "tgMemberCountChat", "tgAdminChat"]) if (String(s[k] || "") === oldId) patch[k] = newId;
    const ours = Object.keys(patch).length > 0 || String(s.telegramChatId || "") === newId;
    if (ours) {
      const prev = Array.isArray(s.tgChatPrev) ? s.tgChatPrev.map(String) : [];
      if (!prev.includes(oldId)) patch.tgChatPrev = [...prev, oldId].slice(-5);
    }
    if (Object.keys(patch).length) await new Promise((r) => saveSettings(patch, r));
    if (patch.telegramChatId) _announceMove = { oldId, newId };
    const map = await getTgTopics();
    if (map && String(map.chat || "") === oldId) {
      map.chat = newId;
      await saveTgTopics(map);
    }
    if (ours) {
      const seen = await new Promise((r) => chrome.storage.local.get("fansly_tg_seen_chats", (d) => r(d.fansly_tg_seen_chats || [])));
      if (seen.some((x) => String(x.id) === oldId)) await new Promise((r) => chrome.storage.local.set({ fansly_tg_seen_chats: seen.filter((x) => String(x.id) !== oldId) }, r));
    }
    return true;
  }
  async function noteMovesIn(updates) {
    let moved = false;
    for (const u of updates) {
      const m = u.message;
      if (!m || m.chat?.id == null) continue;
      if (m.migrate_to_chat_id != null) moved = await noteChatMoved(m.chat.id, m.migrate_to_chat_id) || moved;
      if (m.migrate_from_chat_id != null) moved = await noteChatMoved(m.migrate_from_chat_id, m.chat.id) || moved;
    }
    return moved;
  }
  function topicKeyOf(map, tid) {
    if (!tid) return null;
    if (map.important === tid) return ["important"];
    if (map.posts === tid) return ["posts"];
    for (const f in map.fans || {}) if (map.fans[f] === tid) return ["fans", f];
    return null;
  }
  const _healedTopics = /* @__PURE__ */ new Map();
  async function healTopic(token, chatId, deadTid) {
    if (_healedTopics.has(deadTid)) return _healedTopics.get(deadTid);
    const map = topicsFor(await getTgTopics(), chatId);
    const key = topicKeyOf(map, deadTid);
    if (!key) return null;
    const name = key[0] === "fans" ? key[1] : await serviceTopicName(key[0]);
    const tid = await createForumTopic(token, chatId, name);
    if (!tid) return null;
    if (key[0] === "fans") map.fans[key[1]] = tid;
    else map[key[0]] = tid;
    await saveTgTopics(map);
    _healedTopics.set(deadTid, tid);
    console.warn("[FanslyAI] \u0422\u0413: \u0432\u0435\u0442\u043A\u0430", JSON.stringify(name), "\u043F\u0440\u043E\u043F\u0430\u043B\u0430 (" + deadTid + ") \u2192 \u0441\u043E\u0437\u0434\u0430\u043D\u0430 \u0437\u0430\u043D\u043E\u0432\u043E:", tid);
    return tid;
  }
  const TG_ALLOWED_UPDATES = ["callback_query", "message", "my_chat_member", "chat_member"];
  const TG_SETUP_ACTIVE_MS = 15 * 60 * 1e3;
  const TG_COUNT_EVERY_MS = 60 * 60 * 1e3;
  const TG_DAILY_MS = 24 * 60 * 60 * 1e3;
  const TG_SERVICE_IDS = /* @__PURE__ */ new Set(["1087968824", "777000", "136817688"]);
  let _tgCountAt = 0;
  let _tgDailyAt = 0;
  let _tgMarksLoaded = false;
  const tgSession = () => chrome.storage && chrome.storage.session || null;
  async function loadTgMarks() {
    if (_tgMarksLoaded) return;
    _tgMarksLoaded = true;
    const sess = tgSession();
    if (!sess) return;
    const d = await new Promise((r) => sess.get("fansly_tg_marks", (x) => r(x && x.fansly_tg_marks || {})));
    _tgCountAt = Number(d.countAt) || 0;
    _tgDailyAt = Number(d.dailyAt) || 0;
    _topicsFailAt = Number(d.topicsFailAt) || 0;
  }
  function saveTgMarks() {
    const sess = tgSession();
    if (sess) sess.set({ fansly_tg_marks: { countAt: _tgCountAt, dailyAt: _tgDailyAt, topicsFailAt: _topicsFailAt } }, () => void chrome.runtime.lastError);
  }
  const TG_TOPICS_RETRY_MS = 60 * 60 * 1e3;
  let _topicsFailAt = 0;
  let _topicsChain = Promise.resolve();
  function ensureServiceTopics(token, chatId, onError = null) {
    const run = _topicsChain.then(async () => {
      const map = topicsFor(await getTgTopics(), chatId);
      const made = { important: false, posts: false };
      if (!map.important) {
        const tid = await createForumTopic(token, chatId, await serviceTopicName("important"), onError);
        if (!tid) return { map, made, missing: true };
        map.important = tid;
        made.important = true;
        await saveTgTopics(map);
      }
      if (!map.posts) {
        const pid = await createForumTopic(token, chatId, await serviceTopicName("posts"));
        if (pid) {
          map.posts = pid;
          made.posts = true;
          await saveTgTopics(map);
        }
      }
      return { map, made, missing: !map.important || !map.posts };
    });
    _topicsChain = run.catch(() => {
    });
    return run;
  }
  const TG_INTRO_KEY = "fansly_tg_intro";
  let _introChat = null;
  async function sendTgIntro(token, chatId, topics, caps, lang, postsMade) {
    const chat = chatAlias(chatId);
    if (_introChat === null) _introChat = await new Promise((r) => chrome.storage.local.get(TG_INTRO_KEY, (d) => r(d && d[TG_INTRO_KEY] && d[TG_INTRO_KEY].chat || "")));
    const fresh = chatAlias(_introChat) !== chat;
    if (!fresh && !postsMade) return;
    const names = { important: t(TG_TOPIC_KEYS.important, lang), posts: t(TG_TOPIC_KEYS.posts, lang) };
    await notifyTelegram(token, chatId, t("bg.tg.intro.posts", lang, names), topics.posts, 3);
    if (!fresh) return;
    await notifyTelegram(token, chatId, t("bg.tg.intro.general", lang, names) + "\n\n" + tgHelpText("general", caps, lang), null, 0);
    _introChat = chat;
    await new Promise((r) => chrome.storage.local.set({ [TG_INTRO_KEY]: { chat, at: Date.now() } }, r));
  }
  let _modeSwitching = null;
  function switchToSingle(token, chatId, why) {
    if (_modeSwitching) return _modeSwitching;
    _modeSwitching = (async () => {
      const s = await getSettings();
      if (!s.tgTopics || chatAlias(s.telegramChatId) !== chatAlias(chatId)) return false;
      await new Promise((r) => saveSettings({ tgTopics: false }, r));
      await new Promise((r) => chrome.storage.local.set({ fansly_tg_mode: { switched: "single", at: Date.now() } }, r));
      console.warn("[FanslyAI] \u0422\u0413: \u0432 \u0433\u0440\u0443\u043F\u043F\u0435 \u043D\u0435\u0442 \u0422\u0435\u043C (" + why + ") \u2192 \u0440\u0435\u0436\u0438\u043C \u043E\u0434\u043D\u043E\u0433\u043E \u0447\u0430\u0442\u0430; \u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u043E\u0431\u0449\u0438\u0439 \u0447\u0430\u0442, \u043F\u043B\u0430\u0448\u043A\u0430 \u0432 \u043F\u0430\u043D\u0435\u043B\u0438");
      await notifyTelegram(token, chatId, t("bg.tg.modeSingle", s.interfaceLanguage || "ru"), null, 0);
      return true;
    })().finally(() => {
      _modeSwitching = null;
    });
    return _modeSwitching;
  }
  function clearTgMode() {
    return new Promise((r) => chrome.storage.local.remove("fansly_tg_mode", () => {
      void chrome.runtime.lastError;
      r();
    }));
  }
  function getTgAlert() {
    return new Promise((r) => chrome.storage.local.get("fansly_tg_alert", (d) => r(d.fansly_tg_alert || null)));
  }
  function setTgAlert(a) {
    return new Promise((r) => chrome.storage.local.set({ fansly_tg_alert: a }, r));
  }
  function clearTgAlert() {
    return new Promise((r) => chrome.storage.local.remove("fansly_tg_alert", r));
  }
  function getTgHold() {
    return new Promise((r) => chrome.storage.local.get("fansly_tg_hold", (d) => r(d.fansly_tg_hold || null)));
  }
  function getTgGroupAlert() {
    return new Promise((r) => chrome.storage.local.get("fansly_tg_group", (d) => r(d.fansly_tg_group || null)));
  }
  function setTgGroupAlert(g) {
    return new Promise((r) => chrome.storage.local.set({ fansly_tg_group: g }, r));
  }
  function clearTgGroupAlert() {
    return new Promise((r) => chrome.storage.local.remove("fansly_tg_group", r));
  }
  function setTgHold(h) {
    return new Promise((r) => chrome.storage.local.set({ fansly_tg_hold: h }, r));
  }
  function clearTgHold() {
    return new Promise((r) => chrome.storage.local.remove("fansly_tg_hold", r));
  }
  function tgPausedState(al, hold, grp) {
    return !!(hold && hold.list && hold.list.length) || !!(al && al.kind === "bot_no_rights") || !!(grp && grp.public);
  }
  function tgUserLabel(f) {
    return f ? [f.first_name, f.last_name].filter(Boolean).join(" ") + (f.username ? " (@" + f.username + ")" : "") : "";
  }
  async function stopCarouselFor(s) {
    if (s.carouselEnabled === false) return;
    await new Promise((r) => saveSettings({ carouselEnabled: false }, r));
    s.carouselEnabled = false;
  }
  let _botIdCache = "";
  async function ensureBotId(token, s) {
    if (s.tgBotId) return String(s.tgBotId);
    if (_botIdCache) return _botIdCache;
    const me = await tgApi(token, "getMe", {});
    if (!me?.ok || me.result?.id == null) return "";
    _botIdCache = String(me.result.id);
    s.tgBotId = _botIdCache;
    await new Promise((r) => saveSettings({ tgBotId: _botIdCache }, r));
    return _botIdCache;
  }
  async function resolveTgOwnerId(token, chatId, s) {
    if (s.tgOwnerId && s.tgOwnerChat === chatId) return String(s.tgOwnerId);
    const r = await tgApi(token, "getChatAdministrators", { chat_id: chatId });
    if (!r?.ok) return null;
    const creator = (r.result || []).find((m) => m.status === "creator");
    if (!creator?.user?.id) return "";
    const id = String(creator.user.id);
    await new Promise((res) => saveSettings({ tgOwnerId: id, tgOwnerChat: chatId }, res));
    s.tgOwnerId = id;
    s.tgOwnerChat = chatId;
    return id;
  }
  async function refreshTgBaseline(token, chatId, s) {
    const r = await tgApi(token, "getChatMemberCount", { chat_id: chatId });
    if (!r?.ok) return;
    const n = Number(r.result) || 0;
    await new Promise((res) => saveSettings({ tgMemberCount: n, tgMemberCountChat: chatId }, res));
    s.tgMemberCount = n;
    s.tgMemberCountChat = chatId;
  }
  async function checkTgMemberCount(token, chatId, s, lang, topics, hold, reason) {
    const r = await tgApi(token, "getChatMemberCount", { chat_id: chatId });
    if (!r?.ok) return hold;
    _tgCountAt = Date.now();
    saveTgMarks();
    const n = Number(r.result) || 0;
    const known = s.tgMemberCountChat === chatId && typeof s.tgMemberCount === "number";
    if (!known) {
      await refreshTgBaseline(token, chatId, s);
      console.log("[FanslyAI] \u0422\u0413: \u0431\u0430\u0437\u0430 \u0441\u043E\u0441\u0442\u0430\u0432\u0430 \u0433\u0440\u0443\u043F\u043F\u044B \u043F\u0440\u0438\u043D\u044F\u0442\u0430:", n, "\u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432 (" + reason + ")");
      await notifyTelegram(token, chatId, t("bg.tg.baselineSeeded", lang, { n }), topics.important, 0);
      return hold;
    }
    const base = s.tgMemberCount;
    const named = hold ? hold.list.filter((e) => e.id !== "unknown").length : 0;
    const delta = n - base - named;
    if (delta <= 0) {
      if (n < base && !(hold && hold.list.length)) await refreshTgBaseline(token, chatId, s);
      return hold;
    }
    const who = t("bg.tg.unknownWho", lang, { n: delta });
    hold = hold || { list: [], resume: s.carouselEnabled === true, at: Date.now() };
    const ex = hold.list.find((e) => e.id === "unknown");
    if (ex) ex.who = who;
    else hold.list.push({ id: "unknown", who, at: Date.now(), provisional: false });
    await setTgHold(hold);
    await stopCarouselFor(s);
    console.warn("[FanslyAI] \u0422\u0413: \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432 \u0432 \u0433\u0440\u0443\u043F\u043F\u0435", n, "\u043F\u0440\u0438 \u0431\u0430\u0437\u0435", base, "(" + reason + ") \u2192 \u043F\u0443\u043B\u044C\u0442 \u043D\u0430 \u043F\u0430\u0443\u0437\u0435, \u0441\u043E\u0441\u0442\u0430\u0432 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446");
    await notifyTelegram(token, chatId, t("bg.tg.unknownMembers", lang, { n, base }), topics.important, 0);
    return hold;
  }
  async function resumeCarouselIfClear(hold, why) {
    if (!hold || !hold.resume) return;
    const al = await getTgAlert(), grp = await getTgGroupAlert();
    if (al && (al.kind === "bot_removed" || al.kind === "bot_no_rights")) {
      console.log("[FanslyAI] \u0422\u0413: \u043F\u0430\u0443\u0437\u0430 \u0441\u043D\u044F\u0442\u0430 (" + why + "), \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u043D\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0430: \u0441\u0442\u043E\u0438\u0442 \u043F\u043B\u0430\u0448\u043A\u0430 \u0431\u043E\u0442\u0430 \xAB" + al.kind + "\xBB");
      return;
    }
    if (grp && grp.public) {
      console.log("[FanslyAI] \u0422\u0413: \u043F\u0430\u0443\u0437\u0430 \u0441\u043D\u044F\u0442\u0430 (" + why + "), \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u043D\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0430: \u0433\u0440\u0443\u043F\u043F\u0430 \u043F\u0443\u0431\u043B\u0438\u0447\u043D\u0430\u044F");
      return;
    }
    await new Promise((r) => saveSettings({ carouselEnabled: true }, r));
  }
  async function confirmTgHold(ids) {
    const s = await getSettings();
    const hold = await getTgHold();
    if (!hold) return { success: true, left: 0 };
    const drop = new Set((ids || []).map(String));
    hold.list = (hold.list || []).filter((e) => !drop.has(String(e.id)));
    if (hold.list.length) {
      await setTgHold(hold);
      return { success: true, left: hold.list.length };
    }
    await clearTgHold();
    if (s.telegramBotToken && s.telegramChatId) {
      await refreshTgBaseline(s.telegramBotToken, s.telegramChatId, s);
      await refreshTgAdmins(s.telegramBotToken, s.telegramChatId, s);
    }
    console.log("[FanslyAI] \u0422\u0413: \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u0441\u043E\u0441\u0442\u0430\u0432 \u0433\u0440\u0443\u043F\u043F\u044B \u2192 \u043F\u0430\u0443\u0437\u0430 \u0441\u043D\u044F\u0442\u0430");
    await resumeCarouselIfClear(hold, "\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430");
    return { success: true, left: 0 };
  }
  function tgCarouselBlocked(al, hold, grp) {
    return tgPausedState(al, hold, grp) || !!(al && al.kind === "bot_removed");
  }
  async function refreshTgAdmins(token, chatId, s) {
    const r = await tgApi(token, "getChatAdministrators", { chat_id: chatId });
    if (!r?.ok) return null;
    const admins = (r.result || []).map((m) => m.user).filter((u) => u && u.id != null);
    const ids = admins.map((u) => String(u.id));
    await new Promise((res) => saveSettings({ tgAdminIds: ids, tgAdminChat: chatId }, res));
    s.tgAdminIds = ids;
    s.tgAdminChat = chatId;
    return admins;
  }
  async function dailyTgAudit(token, chatId, s, lang, topics, hold) {
    const last = await new Promise((r) => chrome.storage.local.get("fansly_tg_daily_at", (d) => r(d.fansly_tg_daily_at || 0)));
    if (_tgDailyAt && last && Date.now() - last < TG_DAILY_MS) return hold;
    _tgDailyAt = Date.now();
    saveTgMarks();
    const ar = await tgApi(token, "getChatAdministrators", { chat_id: chatId });
    if (ar?.ok) {
      const admins = (ar.result || []).map((m) => m.user).filter((u) => u && u.id != null);
      const ids = admins.map((u) => String(u.id));
      const known = s.tgAdminChat === chatId && Array.isArray(s.tgAdminIds);
      if (!known) {
        await new Promise((res) => saveSettings({ tgAdminIds: ids, tgAdminChat: chatId }, res));
        s.tgAdminIds = ids;
        s.tgAdminChat = chatId;
        console.log("[FanslyAI] \u0422\u0413: \u0441\u043F\u0438\u0441\u043E\u043A \u0430\u0434\u043C\u0438\u043D\u043E\u0432 \u043F\u0440\u0438\u043D\u044F\u0442:", ids.length);
        await notifyTelegram(token, chatId, t("bg.tg.adminsSeeded", lang, { who: admins.map((u) => tgUserLabel(u) || String(u.id)).join(", ") }), topics.important, 0);
      } else {
        const ownerId = s.tgOwnerId && s.tgOwnerChat === chatId ? String(s.tgOwnerId) : "";
        const fresh = admins.filter((u) => !s.tgAdminIds.includes(String(u.id)) && !u.is_bot && String(u.id) !== String(s.tgBotId || "") && String(u.id) !== ownerId);
        if (fresh.length) {
          hold = hold || { list: [], resume: s.carouselEnabled === true, at: Date.now() };
          const names = [];
          for (const u of fresh) {
            const who = (tgUserLabel(u) || String(u.id)) + t("bg.tg.nowAdminSuffix", lang);
            names.push(who);
            if (!hold.list.some((e) => e.id === String(u.id))) hold.list.push({ id: String(u.id), who, at: Date.now(), provisional: false });
          }
          await setTgHold(hold);
          await stopCarouselFor(s);
          console.warn("[FanslyAI] \u0422\u0413: \u043D\u043E\u0432\u044B\u0435 \u0430\u0434\u043C\u0438\u043D\u044B \u0432 \u0433\u0440\u0443\u043F\u043F\u0435:", names.join(", "), "\u2192 \u043F\u0443\u043B\u044C\u0442 \u043D\u0430 \u043F\u0430\u0443\u0437\u0435 \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0432 \u043F\u0430\u043D\u0435\u043B\u0438");
          await notifyTelegram(token, chatId, t("bg.tg.newAdmin", lang, { who: names.join(", ") }), topics.important, 0);
        }
        if (ids.join(",") !== s.tgAdminIds.join(",")) {
          await new Promise((res) => saveSettings({ tgAdminIds: ids }, res));
          s.tgAdminIds = ids;
        }
      }
    }
    const needTopics = !!s.tgTopics;
    const botId = await ensureBotId(token, s);
    const mr = botId ? await tgApi(token, "getChatMember", { chat_id: chatId, user_id: botId }) : null;
    if (mr?.ok && tgMemberIn(mr.result)) {
      const al = await getTgAlert();
      if (!botHasRights(mr.result, needTopics) && !(al && (al.kind === "bot_removed" || al.kind === "bot_no_rights"))) {
        await setTgAlert({ kind: "bot_no_rights", at: Date.now(), checkedAt: Date.now(), single: !needTopics });
        await stopCarouselFor(s);
        console.warn("[FanslyAI] \u0422\u0413: \u0441\u0443\u0442\u043E\u0447\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u2014 \u0431\u043E\u0442 \u0432 \u0433\u0440\u0443\u043F\u043F\u0435 \u0431\u0435\u0437 \u043D\u0443\u0436\u043D\u044B\u0445 \u043F\u0440\u0430\u0432 (" + (needTopics ? "\u043D\u0443\u0436\u0435\u043D \u0430\u0434\u043C\u0438\u043D \u0441 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C \u0442\u0435\u043C\u0430\u043C\u0438" : "\u043D\u0443\u0436\u0435\u043D \u0430\u0434\u043C\u0438\u043D") + ") \u2192 \u043F\u043B\u0430\u0448\u043A\u0430 \xAB\u0431\u0435\u0437 \u043F\u0440\u0430\u0432\xBB, \u043F\u0443\u043B\u044C\u0442 \u043D\u0430 \u043F\u0430\u0443\u0437\u0435");
        await notifyTelegram(token, chatId, t(needTopics ? "bg.tg.botNoRights" : "bg.tg.botNoRightsSingle", lang), topics.important, 0);
      } else if (botHasRights(mr.result, needTopics) && al && al.kind === "bot_no_rights") {
        await clearTgAlert();
        console.log("[FanslyAI] \u0422\u0413: \u0441\u0443\u0442\u043E\u0447\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u2014 \u0443 \u0431\u043E\u0442\u0430 \u043D\u0443\u0436\u043D\u044B\u0435 \u043F\u0440\u0430\u0432\u0430 \u2192 \u043F\u043B\u0430\u0448\u043A\u0430 \u0441\u043D\u044F\u0442\u0430");
        await notifyTelegram(token, chatId, t("bg.tg.botRestored", lang), topics.important, 0);
      }
    }
    const cr = await tgApi(token, "getChat", { chat_id: chatId });
    if (cr?.ok) {
      if (s.tgTopics && cr.result?.is_forum !== true) {
        if (await switchToSingle(token, chatId, "\u0441\u0443\u0442\u043E\u0447\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430")) s.tgTopics = false;
      }
      const isPublic = !!cr.result?.username;
      const grp = await getTgGroupAlert();
      if (isPublic && !(grp && grp.public)) {
        await setTgGroupAlert({ public: true, at: Date.now() });
        await stopCarouselFor(s);
        console.warn("[FanslyAI] \u0422\u0413: \u0433\u0440\u0443\u043F\u043F\u0430 \u0441\u0442\u0430\u043B\u0430 \u043F\u0443\u0431\u043B\u0438\u0447\u043D\u043E\u0439 (@" + cr.result.username + ") \u2192 \u043F\u0443\u043B\u044C\u0442 \u043D\u0430 \u043F\u0430\u0443\u0437\u0435 \u0434\u043E \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u0430 \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u043E\u0441\u0442\u0438");
        await notifyTelegram(token, chatId, t("bg.tg.groupPublic", lang), topics.important, 0);
      } else if (!isPublic && grp && grp.public) {
        await clearTgGroupAlert();
        console.log("[FanslyAI] \u0422\u0413: \u0433\u0440\u0443\u043F\u043F\u0430 \u0441\u043D\u043E\u0432\u0430 \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u0430\u044F \u2192 \u043F\u043B\u0430\u0448\u043A\u0430 \u0441\u043D\u044F\u0442\u0430");
        await notifyTelegram(token, chatId, t("bg.tg.groupPrivateAgain", lang), topics.important, 0);
      }
    }
    await new Promise((r) => chrome.storage.local.set({ fansly_tg_daily_at: Date.now() }, r));
    const noticed = await new Promise((r) => chrome.storage.local.get("fansly_tg_guard_notice", (d) => r(!!d.fansly_tg_guard_notice)));
    if (!noticed) {
      await new Promise((r) => chrome.storage.local.set({ fansly_tg_guard_notice: Date.now() }, r));
      await notifyTelegram(token, chatId, t("bg.tg.guardIntro", lang), topics.important, 0);
    }
    return hold;
  }
  function tgMemberIn(m) {
    const st = m?.status || "";
    return st === "member" || st === "administrator" || st === "creator" || st === "restricted" && m.is_member !== false;
  }
  function tgMemberOut(m) {
    const st = m?.status || "";
    return !m || st === "left" || st === "kicked" || st === "" || st === "restricted" && m.is_member === false;
  }
  function botHasRights(m, needTopics = true) {
    return m?.status === "administrator" && (!needTopics || m.can_manage_topics === true);
  }
  function parseTgMembership(updates, chatId, needTopics = true) {
    const out = { handled: /* @__PURE__ */ new Set(), foreignJoins: /* @__PURE__ */ new Map(), botRemoved: null, botBack: null, joined: [], left: [], passed: [], promoted: [] };
    const trans = /* @__PURE__ */ new Map();
    const foreignLast = /* @__PURE__ */ new Map();
    for (const u of updates) {
      const mc = u.my_chat_member;
      if (mc) {
        out.handled.add(u.update_id);
        const ch = mc.chat || {}, nm = mc.new_chat_member || {}, st = nm.status || "";
        const ours = String(ch.id) === String(chatId);
        const groupish = ch.type === "group" || ch.type === "supergroup" || ch.type === "channel";
        const inside = st === "member" || st === "administrator" || st === "restricted";
        if (!ours) {
          if (groupish) {
            const prev = foreignLast.get(String(ch.id));
            foreignLast.set(String(ch.id), { chat: ch, inside, by: inside ? mc.from || null : prev ? prev.by : null });
          }
          continue;
        }
        if (st === "left" || st === "kicked") {
          out.botRemoved = { by: mc.from || null };
          out.botBack = null;
        } else if (inside) {
          out.botBack = { withRights: botHasRights(nm, needTopics) };
          out.botRemoved = null;
        }
        continue;
      }
      const cm = u.chat_member;
      if (cm && String(cm.chat?.id) === String(chatId)) {
        out.handled.add(u.update_id);
        const usr = cm.new_chat_member?.user || {}, uid = String(usr.id || "");
        if (!uid) continue;
        const rec = trans.get(uid) || { firstOld: cm.old_chat_member || null, user: usr, by: cm.from || null, everIn: !tgMemberOut(cm.old_chat_member), everOut: tgMemberOut(cm.old_chat_member) };
        rec.lastNew = cm.new_chat_member || null;
        rec.by = cm.from || rec.by;
        if (tgMemberIn(rec.lastNew)) rec.everIn = true;
        else rec.everOut = true;
        trans.set(uid, rec);
      }
    }
    for (const [fid, f] of foreignLast) if (f.inside) out.foreignJoins.set(fid, { chat: f.chat, by: f.by });
    for (const [uid, rec] of trans) {
      const wasIn = !tgMemberOut(rec.firstOld), inNow = tgMemberIn(rec.lastNew);
      const ev = { id: uid, user: rec.user, by: rec.by };
      if (inNow && (!wasIn || rec.everOut)) out.joined.push(ev);
      else if (!inNow && wasIn) out.left.push(ev);
      else if (!inNow && !wasIn && rec.everIn) out.passed.push(ev);
      else if (inNow && wasIn && rec.lastNew?.status === "administrator" && rec.firstOld?.status !== "administrator" && rec.firstOld?.status !== "creator") out.promoted.push(ev);
    }
    return out;
  }
  async function holdProvisional(mem, chatId, s, hold0) {
    const ownerKnown = s.tgOwnerId && s.tgOwnerChat === chatId ? String(s.tgOwnerId) : "";
    const own = (j) => s.tgBotId && j.id === String(s.tgBotId) || ownerKnown && j.id === ownerKnown;
    const cands = [...mem.joined.filter((j) => !own(j)).map((j) => ({ ...j, suffix: "" })), ...mem.promoted.filter((j) => !own(j)).map((j) => ({ ...j, suffix: t("bg.tg.nowAdminSuffix", s.interfaceLanguage || "ru") }))];
    if (!cands.length) return hold0;
    const hold = hold0 || { list: [], resume: s.carouselEnabled === true, at: Date.now() };
    let added = 0;
    for (const j of cands) {
      if (hold.list.some((e) => e.id === j.id)) continue;
      hold.list.push({ id: j.id, who: (tgUserLabel(j.user) || j.id) + j.suffix, at: Date.now(), provisional: true });
      added++;
    }
    if (added) await setTgHold(hold);
    await stopCarouselFor(s);
    return hold;
  }
  async function applyTgMembership(mem, ctx) {
    const { token, chatId, s, lang, topics, reason } = ctx;
    let hold = ctx.hold;
    if (mem.foreignJoins.size) {
      const ownerId = await resolveTgOwnerId(token, chatId, s);
      const al = await getTgAlert();
      const groupDown = !!(al && (al.kind === "bot_removed" || al.kind === "bot_no_rights"));
      const seen = await new Promise((r) => chrome.storage.local.get("fansly_tg_seen_chats", (d) => r(d.fansly_tg_seen_chats || [])));
      for (const [fid, fj] of mem.foreignJoins) {
        const b = fj.by || {};
        const rec = { id: fid, title: fj.chat.title || "", type: fj.chat.type || "", at: Date.now(), bot: await ensureBotId(token, s), by: { id: b.id, is_bot: !!b.is_bot, first_name: b.first_name || "", last_name: b.last_name || "", username: b.username || "" } };
        const rest = seen.filter((x) => String(x.id) !== fid);
        seen.length = 0;
        seen.push(rec, ...rest.slice(0, 4));
      }
      await new Promise((r) => chrome.storage.local.set({ fansly_tg_seen_chats: seen }, r));
      for (const [fid, fj] of mem.foreignJoins) {
        const byId = String(fj.by?.id || "");
        const ownerAdded = !!(ownerId && byId === ownerId);
        const who = tgUserLabel(fj.by) || "?";
        if (ownerAdded || !ownerId || groupDown) {
          const why = ownerAdded ? "(\u0434\u043E\u0431\u0430\u0432\u0438\u043B \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446)" : !ownerId ? "(\u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D)" : "(\u0440\u0430\u0431\u043E\u0447\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430)";
          console.warn("[FanslyAI] \u0422\u0413: \u0431\u043E\u0442\u0430 \u0434\u043E\u0431\u0430\u0432\u0438\u043B\u0438 \u0432 \u0434\u0440\u0443\u0433\u043E\u0439 \u0447\u0430\u0442", fid, JSON.stringify(fj.chat.title || ""), "\u043A\u0442\u043E:", who, why, "\u2192 \u043D\u0435 \u0432\u044B\u0445\u043E\u0434\u0438\u043C");
          await notifyTelegram(token, chatId, t("bg.tg.addedElsewhereKept", lang, { title: fj.chat.title || "", id: fid, who }), topics.important, 0);
          continue;
        }
        const lr = await tgApi(token, "leaveChat", { chat_id: fj.chat.id });
        console.warn("[FanslyAI] \u0422\u0413: \u0431\u043E\u0442\u0430 \u0434\u043E\u0431\u0430\u0432\u0438\u043B\u0438 \u0432 \u0447\u0443\u0436\u043E\u0439 \u0447\u0430\u0442", fid, JSON.stringify(fj.chat.title || ""), "\u043A\u0442\u043E:", who, "\u2192 leaveChat:", lr?.ok ? "ok" : lr?.description || "fail");
        await notifyTelegram(token, chatId, t("bg.tg.leftForeignChat", lang, { title: fj.chat.title || "", id: fid, who }), topics.important, 0);
      }
    }
    let forceCount = false;
    if (mem.botRemoved) {
      console.warn("[FanslyAI] \u0422\u0413: \u0431\u043E\u0442\u0430 \u0443\u0434\u0430\u043B\u0438\u043B\u0438 \u0438\u0437 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u044B", chatId, "\u043A\u0442\u043E:", tgUserLabel(mem.botRemoved.by) || "?", "\u2192 \u043F\u0443\u043B\u044C\u0442 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D (\u043F\u043B\u0430\u0448\u043A\u0430 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430 \u0434\u043E \u0441\u0434\u0432\u0438\u0433\u0430 offset)");
    } else if (mem.botBack) {
      const al = await getTgAlert();
      if (mem.botBack.withRights) {
        if (al && (al.kind === "bot_removed" || al.kind === "bot_no_rights")) {
          forceCount = true;
          await clearTgAlert();
          console.log("[FanslyAI] \u0422\u0413: \u0431\u043E\u0442 \u0441\u043D\u043E\u0432\u0430 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u0435 \u0441 \u043F\u0440\u0430\u0432\u0430\u043C\u0438 \u2192 \u043F\u043B\u0430\u0448\u043A\u0430 \u0441\u043D\u044F\u0442\u0430, \u043F\u0443\u043B\u044C\u0442 \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 \u0432\u043A\u043B\u044E\u0447\u0430\u0435\u0442 \u0441\u0430\u043C");
          await notifyTelegram(token, chatId, t("bg.tg.botRestored", lang), topics.important, 0);
        }
      } else if (!al || al.kind !== "bot_no_rights") {
        console.warn("[FanslyAI] \u0422\u0413: \u0431\u043E\u0442 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u0435 \u0431\u0435\u0437 \u043D\u0443\u0436\u043D\u044B\u0445 \u043F\u0440\u0430\u0432 \u2192 \u043F\u043B\u0430\u0448\u043A\u0430 \xAB\u0431\u0435\u0437 \u043F\u0440\u0430\u0432\xBB, \u043F\u0443\u043B\u044C\u0442 \u043D\u0430 \u043F\u0430\u0443\u0437\u0435");
        await setTgAlert({ kind: "bot_no_rights", at: Date.now(), single: !!ctx.single });
        await stopCarouselFor(s);
        await notifyTelegram(token, chatId, t(ctx.single ? "bg.tg.botNoRightsSingle" : "bg.tg.botNoRights", lang), topics.important, 0);
      }
    }
    const ownerId3 = hold && hold.list.some((e) => e.provisional) ? await resolveTgOwnerId(token, chatId, s) : "";
    if (ownerId3 === null) console.warn("[FanslyAI] \u0422\u0413: \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u0441\u043E\u0437\u0434\u0430\u0442\u0435\u043B\u044F \u0433\u0440\u0443\u043F\u043F\u044B, \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0430\u0443\u0437\u044B \u0436\u0434\u0443\u0442 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0433\u043E \u0442\u0430\u043A\u0442\u0430");
    if (hold && ownerId3 !== null && hold.list.some((e) => e.provisional)) {
      const ownerId = ownerId3;
      const keep = [];
      let changed = false, dropped = 0;
      for (const e of hold.list) {
        if (!e.provisional) {
          keep.push(e);
          continue;
        }
        changed = true;
        if (ownerId && e.id === ownerId || s.tgBotId && e.id === String(s.tgBotId)) {
          dropped++;
          continue;
        }
        e.provisional = false;
        keep.push(e);
        console.warn("[FanslyAI] \u0422\u0413: \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u0435 \u043D\u043E\u0432\u044B\u0439 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A", e.id, e.who, "\u2192 \u043F\u0443\u043B\u044C\u0442 \u043D\u0430 \u043F\u0430\u0443\u0437\u0435 \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0432 \u043F\u0430\u043D\u0435\u043B\u0438");
        await notifyTelegram(token, chatId, t("bg.tg.newMember", lang, { who: e.who }), topics.important, 0);
      }
      if (changed) {
        hold.list = keep;
        if (hold.list.length) {
          await setTgHold(hold);
          if (dropped && s.tgMemberCountChat === chatId && typeof s.tgMemberCount === "number") {
            s.tgMemberCount += dropped;
            await new Promise((r) => saveSettings({ tgMemberCount: s.tgMemberCount }, r));
          }
        } else {
          await clearTgHold();
          await refreshTgBaseline(token, chatId, s);
          await resumeCarouselIfClear(hold, "\u0432\u043E\u0448\u0451\u043B \u0441\u0432\u043E\u0439");
          hold = null;
        }
      }
    }
    for (const l of mem.left) await notifyTelegram(token, chatId, t("bg.tg.memberLeft", lang, { who: tgUserLabel(l.user) || l.id }), topics.important, 0);
    for (const l of mem.passed) await notifyTelegram(token, chatId, t("bg.tg.memberPassed", lang, { who: tgUserLabel(l.user) || l.id }), topics.important, 0);
    let baselineDone = false;
    const gone = [...mem.left, ...mem.passed];
    if (hold && gone.length) {
      const before = hold.list.length;
      hold.list = hold.list.filter((e) => !gone.some((g) => g.id === e.id));
      if (hold.list.some((e) => e.id === "unknown")) {
        const r = await tgApi(token, "getChatMemberCount", { chat_id: chatId });
        const known = s.tgMemberCountChat === chatId && typeof s.tgMemberCount === "number";
        if (r?.ok && known) {
          const named = hold.list.filter((e) => e.id !== "unknown").length;
          if ((Number(r.result) || 0) - s.tgMemberCount - named <= 0) hold.list = hold.list.filter((e) => e.id !== "unknown");
        }
      }
      if (hold.list.length !== before) {
        console.log("[FanslyAI] \u0422\u0413: \u043F\u043E\u043C\u0435\u0447\u0435\u043D\u043D\u044B\u0435 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u0438 \u0432\u044B\u0448\u043B\u0438 \u2192 \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u043F\u0430\u0443\u0437\u044B \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C", hold.list.length);
        if (hold.list.length) await setTgHold(hold);
        else {
          await clearTgHold();
          await refreshTgBaseline(token, chatId, s);
          baselineDone = true;
          await resumeCarouselIfClear(hold, "\u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A \u0432\u044B\u0448\u0435\u043B");
          hold = null;
        }
      }
    }
    if (mem.left.length && !baselineDone && !(hold && hold.list.length)) await refreshTgBaseline(token, chatId, s);
    if (!mem.botBack && !mem.botRemoved) {
      const alNow = await getTgAlert();
      if (alNow && (alNow.kind === "bot_removed" || alNow.kind === "bot_no_rights") && Date.now() - (alNow.checkedAt || alNow.at || 0) > TG_COUNT_EVERY_MS) {
        const botId = s.tgBotId || (await tgApi(token, "getMe", {}))?.result?.id;
        const mr = botId ? await tgApi(token, "getChatMember", { chat_id: chatId, user_id: botId }) : null;
        if (mr?.ok) {
          const st = mr.result?.status || "";
          if (botHasRights(mr.result, !ctx.single)) {
            await clearTgAlert();
            forceCount = true;
            console.log("[FanslyAI] \u0422\u0413: \u0441\u0430\u043C\u043E\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u2014 \u0443 \u0431\u043E\u0442\u0430 \u0441\u043D\u043E\u0432\u0430 \u043D\u0443\u0436\u043D\u044B\u0435 \u043F\u0440\u0430\u0432\u0430 \u2192 \u043F\u043B\u0430\u0448\u043A\u0430 \u0441\u043D\u044F\u0442\u0430");
            await notifyTelegram(token, chatId, t("bg.tg.botRestored", lang), topics.important, 0);
          } else if (st === "member" || st === "restricted" || st === "administrator") {
            if (alNow.kind !== "bot_no_rights") {
              await setTgAlert({ kind: "bot_no_rights", at: Date.now(), checkedAt: Date.now(), single: !!ctx.single });
              await notifyTelegram(token, chatId, t(ctx.single ? "bg.tg.botNoRightsSingle" : "bg.tg.botNoRights", lang), topics.important, 0);
            } else await setTgAlert({ ...alNow, checkedAt: Date.now(), single: !!ctx.single });
          } else await setTgAlert({ ...alNow, checkedAt: Date.now() });
        }
      }
    }
    const due = forceCount || reason === "drop" || !_tgCountAt || Date.now() - _tgCountAt > TG_COUNT_EVERY_MS;
    if (due && hold && hold.list.some((e) => e.id !== "unknown")) {
      const before = hold.list.length;
      for (const e of hold.list.filter((e2) => e2.id !== "unknown")) {
        const mr = await tgApi(token, "getChatMember", { chat_id: chatId, user_id: Number(e.id) || e.id });
        if (mr?.ok && tgMemberOut(mr.result)) hold.list = hold.list.filter((x) => x.id !== e.id);
      }
      if (hold.list.length !== before) {
        console.log("[FanslyAI] \u0422\u0413: \u0441\u0432\u0435\u0440\u043A\u0430 \u043F\u043E\u043C\u0435\u0447\u0435\u043D\u043D\u044B\u0445 \u2014 \u0432\u044B\u0448\u0435\u0434\u0448\u0438\u0445 \u0441\u043D\u044F\u043B, \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u043F\u0430\u0443\u0437\u044B \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C", hold.list.length);
        if (hold.list.length) await setTgHold(hold);
        else {
          await clearTgHold();
          await refreshTgBaseline(token, chatId, s);
          await resumeCarouselIfClear(hold, "\u0441\u0432\u0435\u0440\u043A\u0430 \u043F\u043E\u043C\u0435\u0447\u0435\u043D\u043D\u044B\u0445");
          hold = null;
        }
      }
    }
    const hasUnknown = !!(hold && hold.list.some((e) => e.id === "unknown"));
    if (!hasUnknown && due) {
      hold = await checkTgMemberCount(token, chatId, s, lang, topics, hold, forceCount ? "botBack" : reason);
    }
    if (!mem.botRemoved) hold = await dailyTgAudit(token, chatId, s, lang, topics, hold);
    return hold;
  }
  function findContactsByName(name) {
    return new Promise((res) => chrome.storage.local.get(null, (all) => {
      const out = [];
      for (const [k, v] of Object.entries(all)) {
        if (k.startsWith("fai_contact_") && v && v.name === name) out.push({ key: k, data: v });
      }
      res(out);
    }));
  }
  function getTgOffset() {
    return new Promise((res) => chrome.storage.local.get("fansly_tg_offset", (d) => res(d.fansly_tg_offset || 0)));
  }
  function setTgOffset(o) {
    return new Promise((res) => chrome.storage.local.set({ fansly_tg_offset: o }, () => {
      if (chrome.runtime.lastError) console.error("[FanslyAI] \u0422\u0413: offset \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D:", chrome.runtime.lastError.message, "\u2014 \u0431\u0435\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F Telegram \u043E\u0442\u0434\u0430\u0441\u0442 \u0442\u0443 \u0436\u0435 \u043F\u0430\u0447\u043A\u0443 \u0441\u043D\u043E\u0432\u0430");
      res();
    }));
  }
  const TG_SEEN_MAX = 2e3;
  const _seenUpdates = /* @__PURE__ */ new Set();
  function rememberSeen(updates) {
    for (const u of updates) _seenUpdates.add(u.update_id);
    if (_seenUpdates.size > TG_SEEN_MAX) {
      let drop = _seenUpdates.size - TG_SEEN_MAX;
      for (const v of _seenUpdates) {
        if (drop-- <= 0) break;
        _seenUpdates.delete(v);
      }
    }
  }
  const TG_RETRY_MAX_MS = 3e4;
  async function tgApi(token, method, params) {
    const call = async (p) => {
      const resp = await fetchWithTimeout(`https://api.telegram.org/bot${token}/${method}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(p || {})
      }, 15e3);
      return resp.json();
    };
    try {
      let p = params || {};
      if (p.chat_id != null && _chatMoved.size) {
        const a = chatAlias(p.chat_id);
        if (a !== String(p.chat_id)) p = { ...p, chat_id: a };
      }
      let data = await call(p);
      const wait = !data.ok && data.error_code === 429 ? Math.min(TG_RETRY_MAX_MS, Math.max(1e3, 1e3 * (Number(data.parameters?.retry_after) || 1))) : 0;
      if (wait) {
        console.warn("[FanslyAI] \u0422\u0413: \u043B\u0438\u043C\u0438\u0442 Telegram (429) \u043D\u0430", method, "\u2192 \u043F\u0430\u0443\u0437\u0430", wait / 1e3, "\u0441 \u0438 \u043E\u0434\u0438\u043D \u043F\u043E\u0432\u0442\u043E\u0440");
        await new Promise((r) => setTimeout(r, wait));
        data = await call(p);
      }
      const moved = !data.ok && p.chat_id != null && data.parameters?.migrate_to_chat_id != null ? String(data.parameters.migrate_to_chat_id) : "";
      if (moved && moved !== String(p.chat_id)) {
        await noteChatMoved(p.chat_id, moved);
        data = await call({ ...p, chat_id: moved });
      }
      return data;
    } catch (e) {
      return { ok: false, description: e.message };
    }
  }
  async function resolveCallbackMsg(token, cq, clean) {
    const p = { chat_id: cq.message.chat.id, message_id: cq.message.message_id };
    if (clean) await tgApi(token, "deleteMessage", p);
    else await tgApi(token, "editMessageReplyMarkup", { ...p, reply_markup: { inline_keyboard: [] } });
  }
  let _tgPollBusy = false;
  let _tgMasterOffSeen = false;
  function emptyPoll(extra) {
    return { success: true, relays: [], genVars: [], sendVars: [], cmds: [], ...extra || {} };
  }
  const PENDING_STALE_MS = 3e5;
  const PENDING_WARN_MAX = 5;
  const TG_STALE_MS = 2 * 60 * 1e3;
  let _pendingSeq = 0;
  function newPendingId() {
    return Date.now().toString(36) + "-" + (++_pendingSeq).toString(36);
  }
  function readPending() {
    return new Promise((r) => chrome.storage.local.get("fansly_tg_pending", (d) => r(Array.isArray(d.fansly_tg_pending) ? d.fansly_tg_pending : [])));
  }
  function writePending(list) {
    return new Promise((r) => chrome.storage.local.set({ fansly_tg_pending: list }, () => r()));
  }
  async function ackTgTask(pid, ok = false) {
    if (!pid) return;
    const list = await readPending();
    const hit = list.find((p) => p.pid === pid);
    const keep = list.filter((p) => p.pid !== pid);
    if (keep.length !== list.length) await writePending(keep);
    if (ok === true && hit && hit.draft) await markFanDraftSent((await getSettings()).telegramChatId, hit.draft);
  }
  async function sweepStalePending(token, chatId, topics, lang) {
    const list = await readPending();
    if (!list.length) return;
    const now = Date.now();
    const keep = [], stale = [];
    for (const p of list) (now - (p.at || 0) > PENDING_STALE_MS ? stale : keep).push(p);
    if (!stale.length) return;
    await writePending(keep);
    for (const p of stale.slice(0, PENDING_WARN_MAX)) {
      if (p.kind === "cmd") await notifyTelegram(token, chatId, t("bg.tg.cmdNotDone", lang, { cmd: "/" + (p.name || "?") }), p.fan ? topics.fans?.[p.fan] : null, 0);
      else await notifyTelegram(token, chatId, t("bg.tg.taskNotDone", lang, { fan: p.fan }), topics.fans?.[p.fan], 0);
    }
    if (stale.length > PENDING_WARN_MAX) console.warn("[FanslyAI] \u0422\u0413: \u043F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043E \u0437\u0430\u0434\u0430\u0447 \u0431\u0435\u0437 \u043E\u0442\u0447\u0451\u0442\u0430:", stale.length);
  }
  async function pollTelegram(tabId = null, caps = null) {
    if (_tgPollBusy) return emptyPoll({ busy: true });
    _tgPollBusy = true;
    try {
      const s = await getSettings();
      if (s.masterEnabled === false) {
        if (!_tgMasterOffSeen) {
          _tgMasterOffSeen = true;
          chrome.storage.local.set({ fansly_tg_drop_backlog: true });
        }
        return emptyPoll({ masterOff: true });
      }
      _tgMasterOffSeen = false;
      return await _pollTelegramOnce(tabId, caps);
    } finally {
      _tgPollBusy = false;
    }
  }
  async function _pollTelegramOnce(tabId, caps = null) {
    const s = await getSettings();
    const lang = s.interfaceLanguage || "ru";
    const capSet = new Set(Array.isArray(caps) ? caps.filter((x) => typeof x === "string").slice(0, 32) : []);
    if (!s.telegramEnabled || !s.telegramBotToken) return { success: false, error: "tg off" };
    if (!s.telegramChatId) return { success: false, error: "no chat" };
    const token = s.telegramBotToken;
    await loadTgMarks();
    const setupTs = await new Promise((r) => chrome.storage.local.get("fansly_tg_setup_active", (d) => r(d.fansly_tg_setup_active || 0)));
    if (setupTs && Date.now() - setupTs < TG_SETUP_ACTIVE_MS) return emptyPoll({ setup: true });
    const off = await getTgOffset();
    const data = await tgApi(token, "getUpdates", { offset: off, timeout: 0, allowed_updates: TG_ALLOWED_UPDATES });
    if (!data.ok) return { success: false, error: data.description };
    const updates = data.result || [];
    let maxId = -1;
    for (const u of updates) if (u.update_id > maxId) maxId = u.update_id;
    const nextOff = updates.length ? maxId + 1 : null;
    if (nextOff != null && off > maxId) console.warn("[FanslyAI] \u0422\u0413: \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0439 offset", off, "\u0432\u043F\u0435\u0440\u0435\u0434\u0438 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 \u0431\u043E\u0442\u0430 (\u043C\u0430\u043A\u0441. update_id " + maxId + ") \u2014 \u0441\u043C\u0435\u043D\u0430 \u0431\u043E\u0442\u0430? Telegram \u0442\u0430\u043A\u043E\u0439 offset \u0438\u0433\u043D\u043E\u0440\u0438\u0440\u0443\u0435\u0442 \u0438 \u043E\u0442\u0434\u0430\u0451\u0442 \u0432\u0441\u0451 \u0437\u0430\u043D\u043E\u0432\u043E; \u0441\u0442\u0430\u0432\u043B\u044E", nextOff);
    const fresh = _seenUpdates.size ? updates.filter((u) => !_seenUpdates.has(u.update_id)) : updates;
    if (fresh.length !== updates.length) console.warn("[FanslyAI] \u0422\u0413: Telegram \u0432\u044B\u0434\u0430\u043B \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E", updates.length - fresh.length, "\u0430\u043F\u0434\u0435\u0439\u0442(\u043E\u0432), \u0443\u0436\u0435 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043D\u044B\u0445 \u044D\u0442\u0438\u043C \u0432\u043E\u0440\u043A\u0435\u0440\u043E\u043C \u2014 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430\u044E");
    if (await noteMovesIn(fresh)) Object.assign(s, await getSettings());
    const chatId = chatAlias(s.telegramChatId);
    const prevIds = /* @__PURE__ */ new Set([...Array.isArray(s.tgChatPrev) ? s.tgChatPrev.map(String) : [], ...[..._chatMoved.keys()].filter((k) => chatAlias(k) === chatId)]);
    const own = prevIds.size ? fresh.filter((u) => {
      const c = _chatFromUpdate(u);
      return !(c && prevIds.has(String(c.id)));
    }) : fresh;
    if (own.length !== fresh.length) console.log("[FanslyAI] \u0422\u0413: \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E \u0430\u043F\u0434\u0435\u0439\u0442\u043E\u0432 \u0438\u0437 \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E id \u0441\u0432\u043E\u0435\u0439 \u0433\u0440\u0443\u043F\u043F\u044B:", fresh.length - own.length);
    const single = !s.tgTopics;
    const emptyMap = () => ({ important: null, posts: null, fans: {}, chat: chatId });
    const mem = parseTgMembership(own, chatId, !single);
    const al0 = await getTgAlert(), grp0 = await getTgGroupAlert();
    let hold = await holdProvisional(mem, chatId, s, await getTgHold());
    if (mem.botRemoved) {
      await setTgAlert({ kind: "bot_removed", at: Date.now(), by: tgUserLabel(mem.botRemoved.by) });
      await stopCarouselFor(s);
    }
    const _drop = await new Promise((r) => chrome.storage.local.get("fansly_tg_drop_backlog", (d) => r(!!d.fansly_tg_drop_backlog)));
    if (_drop) {
      if (nextOff != null) {
        await setTgOffset(nextOff);
        rememberSeen(updates);
      }
      await new Promise((r) => chrome.storage.local.remove("fansly_tg_drop_backlog", r));
      await applyTgMembership(mem, { token, chatId, s, lang, topics: single ? emptyMap() : topicsFor(await getTgTopics(), chatId), hold, reason: "drop", single });
      return emptyPoll({ droppedBacklog: updates.length });
    }
    if (mem.botRemoved) {
      if (nextOff != null) {
        await setTgOffset(nextOff);
        rememberSeen(updates);
      }
      await applyTgMembership(mem, { token, chatId, s, lang, topics: single ? emptyMap() : topicsFor(await getTgTopics(), chatId), hold, reason: "removed", single });
      return emptyPoll({ botRemoved: true });
    }
    const topics = single ? emptyMap() : topicsFor(await getTgTopics(), chatId);
    if (_announceMove) {
      const mv = _announceMove;
      _announceMove = null;
      await notifyTelegram(token, chatId, t("bg.tg.chatMoved", lang, { id: mv.newId }), topics.important, 0);
    }
    const pausedNow = tgPausedState(al0, hold, grp0);
    const mirrorOff = s.carouselEnabled === false && !pausedNow;
    let postsMade = false;
    if (!single && chatId && (!topics.important || !topics.posts) && !pausedNow && !mirrorOff && Date.now() - _topicsFailAt > TG_TOPICS_RETRY_MS) {
      const r = await ensureServiceTopics(token, chatId);
      Object.assign(topics, r.map);
      if (r.missing) {
        _topicsFailAt = Date.now();
        saveTgMarks();
        console.warn("[FanslyAI] \u0422\u0413: \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0435 \u0432\u0435\u0442\u043A\u0438 \u0441\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C, \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u0447\u0435\u0440\u0435\u0437 \u0447\u0430\u0441");
      }
      if (r.made.important) await notifyTelegram(token, chatId, t("bg.tg.topicsCreated", lang), topics.important, 3);
      postsMade = r.made.posts;
    }
    if (!single && chatId && topics.important && topics.posts && !pausedNow && !mirrorOff) await sendTgIntro(token, chatId, topics, capSet, lang, postsMade);
    if (!pausedNow && !mirrorOff && !single) await sweepStalePending(token, chatId, topics, lang);
    const staleNow = !pausedNow && !mirrorOff;
    const { acts, postBriefs, stale, orphanThreads, foreign } = parseTgUpdates(own, { chatId, topics, handled: mem.handled, staleNow, now: Date.now(), caps: capSet, single });
    if (nextOff != null) {
      await setTgOffset(nextOff);
      rememberSeen(updates);
    }
    for (const [k, n] of foreign) console.warn("[FanslyAI] \u0422\u0413: \u043E\u0442\u0431\u0440\u043E\u0448\u0435\u043D\u043E \u0430\u043F\u0434\u0435\u0439\u0442\u043E\u0432 \u0438\u0437 \u0447\u0443\u0436\u043E\u0433\u043E \u0447\u0430\u0442\u0430", k, "\u2192", n, "(\u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D", chatId + ")");
    const early = acts.filter((a) => a.pid).map((a) => ({ pid: a.pid, kind: a.kind, fan: a.fan, ...a.kind === "cmd" ? { name: a.name } : {}, tabId, at: Date.now() }));
    if (early.length) await writePending([...await readPending(), ...early].slice(-200));
    if (stale.length) {
      const byThread = /* @__PURE__ */ new Map();
      for (const x of stale) {
        const e = byThread.get(x.thread) || { n: 0, newest: 0 };
        e.n++;
        e.newest = Math.max(e.newest, x.date || 0);
        byThread.set(x.thread, e);
      }
      for (const [th, e] of byThread) {
        const mins = Math.max(1, Math.round((Date.now() / 1e3 - e.newest) / 60));
        await notifyTelegram(token, chatId, t("bg.tg.staleNotSent", lang, { n: e.n, mins }), th, 0);
      }
      console.warn("[FanslyAI] \u0422\u0413: \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E \u043F\u043E \u0434\u0430\u0432\u043D\u043E\u0441\u0442\u0438:", stale.length, "(\u043F\u043E\u0440\u043E\u0433", TG_STALE_MS / 6e4, "\u043C\u0438\u043D), \u0432\u0435\u0442\u043E\u043A", byThread.size);
    }
    if (orphanThreads.size && staleNow && !single) {
      for (const th of orphanThreads) await notifyTelegram(token, chatId, t("bg.tg.threadUnbound", lang), th, 0);
      console.warn("[FanslyAI] \u0422\u0413: \u0442\u0435\u043A\u0441\u0442 \u0432 \u043D\u0435\u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0445 \u0432\u0435\u0442\u043A\u0430\u0445:", [...orphanThreads].join(", "));
    }
    const relays = [];
    const genVars = [];
    const sendVars = [];
    const cmds = [];
    const draftTids = /* @__PURE__ */ new Map();
    const cmdNames = /* @__PURE__ */ new Map();
    const fanIds = /* @__PURE__ */ new Map();
    const ambiguous = /* @__PURE__ */ new Set();
    const resolveFanId = async (fan) => {
      if (ambiguous.has(fan)) return void 0;
      if (fanIds.has(fan)) return fanIds.get(fan);
      const list = await findContactsByName(fan);
      if (list.length > 1) {
        ambiguous.add(fan);
        await notifyTelegram(token, chatId, t("bg.tg.ambiguousFan", lang, { fan, n: list.length }), topics.fans?.[fan], 0);
        return void 0;
      }
      const id = list.length ? list[0].key.replace("fai_contact_", "") : null;
      fanIds.set(fan, id);
      return id;
    };
    hold = await applyTgMembership(mem, { token, chatId, s, lang, topics, hold, reason: "poll", single });
    const paused = tgPausedState(await getTgAlert(), hold, await getTgGroupAlert());
    const mirrorBlocked = mirrorOff && !paused;
    const pausedThreads = /* @__PURE__ */ new Set(), offThreads = /* @__PURE__ */ new Set();
    for (const a of acts) {
      if (single && a.cq) {
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id });
        continue;
      }
      const pressed = a.kind === "inv" || a.kind === "sendvar" || a.kind === "senddraft" || a.kind === "again" || a.kind === "confirm";
      if (paused && pressed) {
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.pausedNewMember", lang), show_alert: true });
        continue;
      }
      const typed = a.kind === "relay" || a.kind === "genvar" || a.kind === "cmd" || a.kind === "say" || a.kind === "ask";
      if (paused && typed) {
        pausedThreads.add(a.thread || null);
        continue;
      }
      if (mirrorBlocked && pressed) {
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.mirrorOff", lang), show_alert: true });
        continue;
      }
      if (mirrorBlocked && typed) {
        offThreads.add(a.thread || null);
        continue;
      }
      if (a.kind === "inv") {
        await startInviteFlow(a.handle);
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.openingProfile", lang, { handle: a.handle }) });
        await tgApi(token, "editMessageReplyMarkup", { chat_id: a.cq.message.chat.id, message_id: a.cq.message.message_id, reply_markup: { inline_keyboard: [] } });
      } else if (a.kind === "sendvar") {
        const id = await resolveFanId(a.fan);
        if (id === void 0) {
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.ambiguousFan", lang, { fan: a.fan }) });
          continue;
        }
        sendVars.push({ fan: a.fan, id, idx: a.idx, pid: a.pid });
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.sendingVariant", lang, { fan: a.fan, n: a.idx + 1 }) });
        await resolveCallbackMsg(token, a.cq, s.tgCleanProcessed);
      } else if (a.kind === "noop") {
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id });
      } else if (a.kind === "relay" || a.kind === "genvar") {
        const id = await resolveFanId(a.fan);
        if (id === void 0) continue;
        if (a.kind === "relay") relays.push({ fan: a.fan, text: a.text, id, pid: a.pid });
        else genVars.push({ fan: a.fan, id, hint: a.hint, proactive: true, forceOR: a.forceOR, pid: a.pid, ...a.draft ? { single: true, turns: (await readFanCtx(chatId, a.thread)).items } : {} });
      } else if (a.kind === "senddraft" || a.kind === "again") {
        const c = capSet.has("draft") ? await readFanCtx(chatId, a.thread) : { items: [], msg: null };
        const lastOf = (role) => {
          for (let i = c.items.length - 1; i >= 0; i--) if (c.items[i].role === role) return c.items[i];
          return null;
        };
        const draft = lastOf("draft");
        if (!draft || !c.msg || c.msg !== a.cq.message.message_id) {
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.draftStale", lang), show_alert: true });
          continue;
        }
        const id = await resolveFanId(a.fan);
        if (id === void 0) {
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.ambiguousFan", lang, { fan: a.fan }) });
          continue;
        }
        await spendFanDraftMsg(chatId, a.thread);
        if (a.kind === "senddraft") {
          sendVars.push({ fan: a.fan, id, idx: 0, pid: a.pid, text: draft.text });
          draftTids.set(a.pid, a.thread);
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.sendingDraft", lang, { fan: a.fan }) });
          await resolveCallbackMsg(token, a.cq, s.tgCleanProcessed);
        } else {
          const task = lastOf("task");
          genVars.push({ fan: a.fan, id, hint: task ? task.text : "", proactive: true, forceOR: false, pid: a.pid, single: true, turns: c.items, again: true });
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.draftAgain", lang) });
          await tgApi(token, "editMessageReplyMarkup", { chat_id: a.cq.message.chat.id, message_id: a.cq.message.message_id, reply_markup: { inline_keyboard: [] } });
        }
      } else if (a.kind === "say") {
        if (a.local === "postsClear") await clearPostsCtx();
        if (a.local === "fanClear") {
          const c = await readFanCtx(chatId, a.thread);
          await clearFanCtx(chatId, a.thread);
          if (c.msg) await tgApi(token, "editMessageReplyMarkup", { chat_id: chatId, message_id: c.msg, reply_markup: { inline_keyboard: [] } });
        }
        const vars = a.key === "bg.tg.cmd.onlyPosts" || a.key === "bg.tg.cmd.onlyFanPosts" ? { ...a.vars, posts: t(TG_TOPIC_KEYS.posts, lang) } : a.vars;
        const say = a.help ? tgHelpText(a.help, capSet, lang) : t(a.key, lang, vars);
        await notifyTelegram(token, chatId, say, a.thread || null, 0);
      } else if (a.kind === "cmd") {
        const id = a.fan ? await resolveFanId(a.fan) : null;
        if (id === void 0) continue;
        cmds.push({ cmd: a.cmd, fan: a.fan || null, id, pid: a.pid, arg: a.arg });
        cmdNames.set(a.pid, a.name);
      } else if (a.kind === "ask") {
        if (await resolveFanId(a.fan) === void 0) continue;
        const kb = { inline_keyboard: [[{ text: t("bg.btn.confirmYes", lang), callback_data: "cby" }, { text: t("bg.btn.confirmNo", lang), callback_data: "cbn" }]] };
        const q = await notifyTelegram(token, chatId, t("bg.tg.cmd.banAsk", lang, { fan: a.fan }), a.thread, 0, kb);
        if (q.success && q.message_id) {
          const prev = await putTgConfirm(chatId, { msg: q.message_id, tid: a.thread, fan: a.fan, cmd: a.cmd, name: a.name });
          if (prev) await tgApi(token, "editMessageReplyMarkup", { chat_id: chatId, message_id: prev, reply_markup: { inline_keyboard: [] } });
        }
      } else if (a.kind === "confirm") {
        const rec = await takeTgConfirm(chatId, a.thread, a.cq.message.message_id);
        if (!rec || a.yes && !capSet.has(rec.cmd)) {
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.confirmStale", lang), show_alert: true });
          await tgApi(token, "editMessageReplyMarkup", { chat_id: a.cq.message.chat.id, message_id: a.cq.message.message_id, reply_markup: { inline_keyboard: [] } });
          continue;
        }
        if (!a.yes) {
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.confirmNo", lang) });
          await resolveCallbackMsg(token, a.cq, s.tgCleanProcessed);
          continue;
        }
        const id = await resolveFanId(rec.fan);
        if (id === void 0) {
          await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.ambiguousFan", lang, { fan: rec.fan }) });
          await tgApi(token, "editMessageReplyMarkup", { chat_id: a.cq.message.chat.id, message_id: a.cq.message.message_id, reply_markup: { inline_keyboard: [] } });
          continue;
        }
        cmds.push({ cmd: rec.cmd, fan: rec.fan, id, pid: a.pid, arg: null });
        cmdNames.set(a.pid, rec.name);
        await tgApi(token, "answerCallbackQuery", { callback_query_id: a.cq.id, text: t("bg.toast.banYes", lang, { fan: rec.fan }) });
        await resolveCallbackMsg(token, a.cq, s.tgCleanProcessed);
      }
    }
    if (paused) {
      for (const th of pausedThreads) await notifyTelegram(token, chatId, t("bg.toast.pausedNewMember", lang), th, 0);
      if (postBriefs.length && topics.posts && !pausedThreads.has(topics.posts)) await notifyTelegram(token, chatId, t("bg.toast.pausedNewMember", lang), topics.posts, 0);
    }
    if (mirrorBlocked) {
      for (const th of offThreads) await notifyTelegram(token, chatId, t("bg.toast.mirrorOff", lang), th, 0);
      if (postBriefs.length && topics.posts && !offThreads.has(topics.posts)) await notifyTelegram(token, chatId, t("bg.toast.mirrorOff", lang), topics.posts, 0);
    }
    for (const brief of paused || mirrorBlocked ? [] : postBriefs) {
      await notifyTelegram(token, chatId, t("bg.post.writing", lang), topics.posts, 3);
      const hist = await readPostsCtx(chatId);
      const pr = await generatePost(brief, s, hist.length ? hist : null);
      if (pr.success) {
        await pushPostsCtx(chatId, brief, pr.text);
        await notifyTelegram(token, chatId, pr.text + (pr.usedOpenRouter ? "\n\n" + t("bg.post.viaOpenRouter", lang) : ""), topics.posts, 3);
      } else {
        const msg = pr.noOpenRouter ? t("bg.post.noOpenRouter", lang) : pr.blocked ? t("bg.post.blocked", lang) : t("bg.post.failed", lang);
        await notifyTelegram(token, chatId, msg, topics.posts, 3);
      }
    }
    let outRelays = relays, outGenVars = genVars, outSendVars = sendVars;
    let routed = [], routedTab = null;
    const claim = await new Promise((r) => chrome.storage.local.get("fansly_invite_claim", (d) => r(d.fansly_invite_claim)));
    if (claim?.tabId && claim?.fan && Date.now() - (claim.ts || 0) < 18e5) {
      const mine = (x) => x.fan === claim.fan;
      const r2 = relays.filter(mine), g2 = genVars.filter(mine), s2 = sendVars.filter(mine);
      if (r2.length || g2.length || s2.length) {
        try {
          chrome.tabs.sendMessage(claim.tabId, { type: "TG_ROUTED", relays: r2, genVars: g2, sendVars: s2 }, () => {
            void chrome.runtime.lastError;
          });
        } catch (e) {
        }
        outRelays = relays.filter((x) => !mine(x));
        outGenVars = genVars.filter((x) => !mine(x));
        outSendVars = sendVars.filter((x) => !mine(x));
        routedTab = claim.tabId;
        routed = [...r2, ...g2, ...s2];
      }
    }
    const handed = [
      ...outRelays.map((x) => ({ pid: x.pid, kind: "relay", fan: x.fan, tabId })),
      ...outGenVars.map((x) => ({ pid: x.pid, kind: "genvar", fan: x.fan, tabId })),
      ...outSendVars.map((x) => ({ pid: x.pid, kind: "sendvar", fan: x.fan, tabId })),
      ...cmds.map((x) => ({ pid: x.pid, kind: "cmd", fan: x.fan, name: cmdNames.get(x.pid), tabId })),
      ...routed.map((x) => ({ pid: x.pid, kind: "routed", fan: x.fan, tabId: routedTab }))
    ].filter((x) => x.pid).map((x) => draftTids.has(x.pid) ? { ...x, draft: draftTids.get(x.pid) } : x);
    const earlyIds = new Set(early.map((x) => x.pid));
    if (handed.length || earlyIds.size) {
      const at = Date.now();
      const list = (await readPending()).filter((p) => !earlyIds.has(p.pid));
      await writePending([...list, ...handed.map((x) => ({ ...x, at }))].slice(-200));
    }
    return { success: true, relays: outRelays, genVars: outGenVars, sendVars: outSendVars, cmds };
  }
  const TG_POSTS_CTX_PAIRS = 3, TG_POSTS_CTX_MS = 60 * 60 * 1e3, TG_POSTS_CTX_CHARS = 1200;
  async function readPostsCtx(chatId) {
    const c = await new Promise((r) => chrome.storage.local.get("fansly_tg_posts_ctx", (d) => r(d.fansly_tg_posts_ctx || null)));
    if (!c || !Array.isArray(c.items) || chatAlias(c.chat) !== chatAlias(chatId) || Date.now() - (c.at || 0) > TG_POSTS_CTX_MS) return [];
    return c.items.filter((x) => x && (x.role === "brief" || x.role === "post") && typeof x.text === "string");
  }
  async function pushPostsCtx(chatId, brief, post) {
    const cut = (x) => String(x || "").slice(0, TG_POSTS_CTX_CHARS);
    const pair = [{ role: "brief", text: cut(String(brief || "").replace(/^\s*!\s*/, "")) }, { role: "post", text: cut(post) }];
    const items = [...await readPostsCtx(chatId), ...pair].slice(-2 * TG_POSTS_CTX_PAIRS);
    await new Promise((r) => chrome.storage.local.set({ fansly_tg_posts_ctx: { chat: chatAlias(chatId), at: Date.now(), items } }, r));
  }
  function clearPostsCtx() {
    return new Promise((r) => chrome.storage.local.remove("fansly_tg_posts_ctx", () => {
      void chrome.runtime.lastError;
      r();
    }));
  }
  const TG_FAN_CTX_PAIRS = 3, TG_FAN_CTX_THREADS = 200, TG_FAN_CTX_CHARS = 800;
  let _fanCtxChain = Promise.resolve();
  async function readFanCtxAll(chatId) {
    const c = await new Promise((r) => chrome.storage.local.get("fansly_tg_fan_ctx", (d) => r(d.fansly_tg_fan_ctx || null)));
    const cid = chatAlias(chatId);
    return c && c.threads && typeof c.threads === "object" && chatAlias(c.chat) === cid ? c : { chat: cid, threads: {} };
  }
  async function readFanCtx(chatId, tid) {
    const e = (await readFanCtxAll(chatId)).threads[tid];
    const items = (e && Array.isArray(e.items) ? e.items : []).filter((x) => x && (x.role === "task" || x.role === "draft") && typeof x.text === "string");
    return { items, msg: e && e.msg || null };
  }
  function editFanCtx(chatId, tid, fn) {
    const run = _fanCtxChain.then(async () => {
      const all = await readFanCtxAll(chatId);
      const cur = all.threads[tid] || { at: 0, msg: null, items: [] };
      const next = fn({ ...cur, items: Array.isArray(cur.items) ? cur.items.slice() : [] });
      if (next) all.threads[tid] = { ...next, at: Date.now() };
      else delete all.threads[tid];
      const ids = Object.keys(all.threads);
      if (ids.length > TG_FAN_CTX_THREADS) for (const k of ids.sort((a, b) => (all.threads[a].at || 0) - (all.threads[b].at || 0)).slice(0, ids.length - TG_FAN_CTX_THREADS)) delete all.threads[k];
      await new Promise((r) => chrome.storage.local.set({ fansly_tg_fan_ctx: all }, r));
    });
    _fanCtxChain = run.catch(() => {
    });
    return run;
  }
  function pushFanDraft(chatId, tid, task, draft, msgId, again = false) {
    const cut = (x) => String(x || "").slice(0, TG_FAN_CTX_CHARS);
    return editFanCtx(chatId, tid, (e) => ({ ...e, msg: msgId, items: [...e.items, { role: "task", text: cut(task), ...again ? { again: true } : {} }, { role: "draft", text: cut(draft) }].slice(-2 * TG_FAN_CTX_PAIRS) }));
  }
  function markFanDraftSent(chatId, tid) {
    return editFanCtx(chatId, tid, (e) => {
      for (let i = e.items.length - 1; i >= 0; i--) if (e.items[i] && e.items[i].role === "draft") {
        e.items[i] = { ...e.items[i], sent: true };
        break;
      }
      return e.items.length ? e : null;
    });
  }
  const spendFanDraftMsg = (chatId, tid) => editFanCtx(chatId, tid, (e) => e.items.length ? { ...e, msg: null } : null);
  const clearFanCtx = (chatId, tid) => editFanCtx(chatId, tid, () => null);
  const TG_CONFIRM_MS = 5 * 60 * 1e3, TG_CONFIRM_MAX = 20;
  let _confirmChain = Promise.resolve();
  function editTgConfirm(chatId, fn) {
    const run = _confirmChain.then(async () => {
      const cid = chatAlias(chatId);
      const all = await new Promise((r) => chrome.storage.local.get("fansly_tg_confirm", (d) => r(Array.isArray(d.fansly_tg_confirm) ? d.fansly_tg_confirm : [])));
      const live = all.filter((x) => x && chatAlias(x.chat) === cid && Date.now() - (x.at || 0) <= TG_CONFIRM_MS);
      const { list, out } = fn(live);
      await new Promise((r) => chrome.storage.local.set({ fansly_tg_confirm: list.slice(-TG_CONFIRM_MAX) }, r));
      return out;
    });
    _confirmChain = run.catch(() => {
    });
    return run;
  }
  const putTgConfirm = (chatId, rec) => editTgConfirm(chatId, (live) => {
    const prev = live.find((x) => x.tid === rec.tid);
    return { list: [...live.filter((x) => x.tid !== rec.tid), { ...rec, chat: chatAlias(chatId), at: Date.now() }], out: prev ? prev.msg : null };
  });
  const takeTgConfirm = (chatId, tid, msgId) => editTgConfirm(chatId, (live) => {
    const rec = live.find((x) => x.tid === tid && x.msg === msgId) || null;
    return { list: rec ? live.filter((x) => x !== rec) : live, out: rec };
  });
  const TG_CMDS = [
    { name: "h", place: "fan", cmd: "hist", line: "bg.tg.cmd.line.h" },
    { name: "i", place: "fan", cmd: "info", line: "bg.tg.cmd.line.i" },
    { name: "ur", place: "fan", cmd: "unread", line: "bg.tg.cmd.line.urFan" },
    { name: "b", place: "fan", cmd: "ban", line: "bg.tg.cmd.line.b", confirm: true },
    { name: "ub", place: "fan", cmd: "unban", line: "bg.tg.cmd.line.ub" },
    { name: "d", place: "fan", cmd: "del", line: "bg.tg.cmd.line.d" },
    { name: "lang", place: "fan", cmd: "lang", line: "bg.tg.cmd.line.lang", tail: true },
    // язык фана (Алекс 13.10): код языка проверяет вкладка — список языков её
    { name: "o", place: "general", cmd: "status", arg: "online", line: "bg.tg.cmd.line.o" },
    { name: "off", place: "general", cmd: "status", arg: "away", line: "bg.tg.cmd.line.off" },
    { name: "hide", place: "general", cmd: "status", arg: "hidden", line: "bg.tg.cmd.line.hide" },
    { name: "ur", place: "general", cmd: "unread", cap: "unread_all", line: "bg.tg.cmd.line.urAll" },
    { name: "c", place: "posts", local: "postsClear", done: "bg.tg.cmd.postsCleared", line: "bg.tg.cmd.line.c" },
    { name: "c", place: "fan", local: "fanClear", done: "bg.tg.cmd.fanCleared", line: "bg.tg.cmd.line.cFan", cap: "draft" }
    // память черновиков есть только у вкладки с одним черновиком
  ];
  const tgCmdReady = (c, caps) => c.local ? !c.cap || caps.has(c.cap) : caps.has(c.cap || c.cmd);
  const tgCmdTail = (text) => parseTgCommand(text).rest.toLowerCase().replace(/\s+/g, " ").slice(0, 32).trim();
  function parseTgCommand(text) {
    const m = /^\/([A-Za-zА-Яа-яЁё]+)(!?)(?:@[A-Za-z0-9_]{1,64})?(?:\s+([\s\S]*))?$/.exec(String(text || "").trim());
    return m ? { name: m[1].toLowerCase(), bang: m[2] === "!", rest: (m[3] || "").trim() } : { name: "", bang: false, rest: "" };
  }
  function resolveTgCommand(text, place, caps) {
    const p = parseTgCommand(text);
    const cmd = p.name ? "/" + p.name : String(text || "").trim().split(/\s/)[0].slice(0, 24);
    if (p.name === "help") return { kind: "help" };
    if (p.name === "g" || p.name === "\u0433") return { kind: "say", key: place === "fan" ? "bg.tg.cmd.gUsage" : "bg.tg.cmd.onlyFan", vars: { cmd } };
    const here = TG_CMDS.find((c) => c.name === p.name && c.place === place);
    if (here) return !tgCmdReady(here, caps) ? { kind: "say", key: "bg.tg.cmd.notReady", vars: { cmd } } : here.local ? { kind: "local", c: here } : here.confirm ? { kind: "confirm", c: here } : { kind: "cmd", c: here };
    const where = new Set(TG_CMDS.filter((c) => c.name === p.name).map((c) => c.place));
    const key = !where.size ? "bg.tg.cmd.unknown" : where.has("fan") && where.has("posts") ? "bg.tg.cmd.onlyFanPosts" : where.has("fan") && where.has("general") ? "bg.tg.cmd.onlyFanGeneral" : where.has("fan") ? "bg.tg.cmd.onlyFan" : where.has("posts") ? "bg.tg.cmd.onlyPosts" : "bg.tg.cmd.onlyGeneral";
    return { kind: "say", key, vars: { cmd } };
  }
  function tgHelpText(place, caps, lang) {
    const ready = (pl) => TG_CMDS.filter((c) => c.place === pl && tgCmdReady(c, caps)).map((c) => t(c.line, lang));
    if (place === "posts") return [t("bg.tg.cmd.help.posts", lang), t("bg.tg.cmd.help.postsCtx", lang), ...ready("posts"), t("bg.tg.cmd.line.help", lang)].join("\n");
    const fan = [t(caps.has("draft") ? "bg.tg.cmd.line.gDraft" : "bg.tg.cmd.line.g", lang), ...ready("fan")];
    if (place === "fan") return [t("bg.tg.cmd.help.fanTitle", lang), ...fan, t("bg.tg.cmd.line.help", lang), "", t("bg.tg.cmd.help.fanPlain", lang)].join("\n");
    return [
      t("bg.tg.cmd.help.generalTitle", lang),
      ...ready("general"),
      t("bg.tg.cmd.line.help", lang),
      "",
      t("bg.tg.cmd.help.fanOnlyTitle", lang),
      ...fan,
      t("bg.tg.cmd.help.fanPlain", lang),
      "",
      t("bg.tg.cmd.help.postsLine", lang, { posts: t(TG_TOPIC_KEYS.posts, lang) }),
      ...ready("posts")
    ].join("\n");
  }
  function parseTgUpdates(updates, { chatId, topics, handled, staleNow, now, caps = /* @__PURE__ */ new Set(), single = false }) {
    const acts = [];
    const postBriefs = [];
    const stale = [];
    const orphanThreads = /* @__PURE__ */ new Set();
    const foreign = /* @__PURE__ */ new Map();
    const fanByThread = (tid) => tid ? Object.keys(topics.fans).find((f) => topics.fans[f] === tid) : null;
    const pushCommand = (m, place, fan) => {
      const thread = m.message_thread_id || null;
      if (staleNow && !!m.date && now - m.date * 1e3 > TG_STALE_MS) {
        stale.push({ thread, date: m.date });
        return;
      }
      const r = resolveTgCommand(m.text, place, caps);
      if (r.kind === "cmd") acts.push({ kind: "cmd", cmd: r.c.cmd, name: r.c.name, arg: r.c.tail ? tgCmdTail(m.text) : r.c.arg || null, fan, thread, pid: newPendingId() });
      else if (r.kind === "help") acts.push({ kind: "say", help: place, thread });
      else if (r.kind === "local") acts.push({ kind: "say", local: r.c.local, key: r.c.done, vars: {}, thread });
      else if (r.kind === "confirm") acts.push({ kind: "ask", cmd: r.c.cmd, name: r.c.name, fan, thread });
      else acts.push({ kind: "say", key: r.key, vars: r.vars, thread });
    };
    for (const u of updates) {
      if (handled.has(u.update_id)) continue;
      const uc = _chatFromUpdate(u);
      if (!uc || String(uc.id) !== String(chatId)) {
        const k = uc ? String(uc.id) : "?";
        foreign.set(k, (foreign.get(k) || 0) + 1);
        continue;
      }
      const cq = u.callback_query;
      if (cq) {
        const action = cq.data || "";
        if (action.startsWith("inv:")) {
          const h = action.slice(4);
          if (/^[A-Za-z0-9_.-]{1,64}$/.test(h)) acts.push({ kind: "inv", cq, handle: h });
          else acts.push({ kind: "noop", cq });
        } else {
          const fan = fanByThread(cq.message?.message_thread_id);
          if (fan && /^gs[0-9]$/.test(action)) acts.push({ kind: "sendvar", cq, fan, idx: parseInt(action.slice(2)), pid: newPendingId() });
          else if (fan && (action === "gd" || action === "ga")) acts.push({ kind: action === "gd" ? "senddraft" : "again", cq, fan, thread: cq.message.message_thread_id, pid: newPendingId() });
          else if (fan && (action === "cby" || action === "cbn")) acts.push({ kind: "confirm", yes: action === "cby", cq, fan, thread: cq.message.message_thread_id, ...action === "cby" ? { pid: newPendingId() } : {} });
          else acts.push({ kind: "noop", cq });
        }
        continue;
      }
      const m = u.message;
      if (m && m.text && !m.message_thread_id) {
        if (!single && m.text.startsWith("/") && !m.from?.is_bot) pushCommand(m, "general", null);
        continue;
      }
      if (m && m.text && m.message_thread_id) {
        const old = staleNow && !!m.date && now - m.date * 1e3 > TG_STALE_MS;
        if (topics.posts && m.message_thread_id === topics.posts) {
          if (m.text.startsWith("/") && !/^(?:g|г|p|п|post|пост)$/.test(parseTgCommand(m.text).name)) {
            pushCommand(m, "posts", null);
            continue;
          }
          const brief = m.text.replace(/^\/(?:g|г|p|п|post|пост)(?:@[A-Za-z0-9_]{1,64})?(?=\s|$)\s*/i, "").trim();
          if (brief) {
            if (old) stale.push({ thread: m.message_thread_id, date: m.date });
            else postBriefs.push(brief);
          }
          continue;
        }
        const fan = fanByThread(m.message_thread_id);
        if (fan) {
          const draftMode = caps.has("draft");
          const gm = m.text.match(/^\/(?:g|г)(!?)(?:@[A-Za-z0-9_]{1,64})?\s+([\s\S]+)/i) || (draftMode ? m.text.match(/^\/(?:g|г)(!?)(?:@[A-Za-z0-9_]{1,64})?\s*()$/i) : null);
          if (gm) {
            if (old) stale.push({ thread: m.message_thread_id, date: m.date });
            else acts.push({ kind: "genvar", fan, hint: gm[2].trim(), forceOR: gm[1] === "!", draft: draftMode, thread: m.message_thread_id, pid: newPendingId() });
          } else if (!m.text.startsWith("/")) {
            if (old) stale.push({ thread: m.message_thread_id, date: m.date });
            else acts.push({ kind: "relay", fan, text: m.text, thread: m.message_thread_id, pid: newPendingId() });
          } else pushCommand(m, "fan", fan);
        } else if (m.message_thread_id !== topics.important) orphanThreads.add(m.message_thread_id);
      }
    }
    return { acts, postBriefs, stale, orphanThreads, foreign };
  }
  async function createForumTopic(token, chatId, name, onError = null) {
    const data = await tgApi(token, "createForumTopic", { chat_id: chatId, name: String(name || "fan").slice(0, 128) });
    if (!data.ok) {
      console.warn("[FanslyAI] createForumTopic:", data.description);
      if (onError) onError(data.description || "");
      if (/not a forum/i.test(data.description || "")) await switchToSingle(token, chatId, "\u0432\u0435\u0442\u043A\u0430 \xAB" + name + "\xBB \u043D\u0435 \u0441\u043E\u0437\u0434\u0430\u043B\u0430\u0441\u044C");
      return null;
    }
    return data.result.message_thread_id;
  }
  const _topicLocks = {};
  async function getOrCreateFanTopic(token, chatId, fan, topics) {
    if (topics.fans[fan]) return { tid: topics.fans[fan], created: false };
    if (!_topicLocks[fan]) {
      _topicLocks[fan] = (async () => {
        const fresh = topicsFor(await getTgTopics(), chatId);
        if (fresh.fans[fan]) return { tid: fresh.fans[fan], created: false };
        const tid = await createForumTopic(token, chatId, fan);
        if (tid) {
          fresh.fans[fan] = tid;
          await saveTgTopics(fresh);
        }
        return { tid: tid || void 0, created: !!tid };
      })().finally(() => {
        delete _topicLocks[fan];
      });
    }
    const res = await _topicLocks[fan];
    if (res.tid) topics.fans[fan] = res.tid;
    return res;
  }
  async function setupTgTopics(token, chatId, opts = {}) {
    const lang = (await getSettings()).interfaceLanguage || "ru";
    if (!token || !chatId) return { success: false, error: t("bg.err.needTokenChatId", lang) };
    let why = "";
    const { map: topics } = await ensureServiceTopics(token, chatId, (d) => {
      why = d;
    });
    if (!topics.important) return { success: false, error: /not a forum/i.test(why) ? t("setup.blocker.noForum", lang) : t("bg.err.topicCreateFailed", lang) };
    await clearTgMode();
    const al = await getTgAlert();
    if (al && (al.kind === "bot_removed" || al.kind === "bot_no_rights")) {
      const me = await tgApi(token, "getMe", {});
      const mem = me?.ok ? await tgApi(token, "getChatMember", { chat_id: chatId, user_id: me.result.id }) : null;
      if (mem?.ok && mem.result?.status === "administrator" && mem.result?.can_manage_topics === true) await clearTgAlert();
    }
    if (opts.wizard) {
      const tail = await tgApi(token, "getUpdates", { offset: -1, timeout: 0 });
      const lastId = tail?.ok && tail.result?.length ? tail.result[tail.result.length - 1].update_id : null;
      if (lastId != null) await setTgOffset(lastId + 1);
      const st = await getSettings();
      await refreshTgBaseline(token, chatId, st);
      await refreshTgAdmins(token, chatId, st);
      await clearTgGroupAlert();
      await new Promise((r) => chrome.storage.local.set({ fansly_tg_guard_notice: Date.now() }, r));
      await new Promise((r) => chrome.storage.local.remove("fansly_tg_setup_active", r));
    }
    return { success: true, importantId: topics.important };
  }
  function _chatFromUpdate(u) {
    return u.message?.chat || u.callback_query?.message?.chat || u.channel_post?.chat || u.my_chat_member?.chat || u.chat_member?.chat || u.chat_join_request?.chat || null;
  }
  async function detectTelegramChat(token, botId = null, wantForum = true) {
    const lang = (await getSettings()).interfaceLanguage || "ru";
    if (!token) return { success: false, error: t("bg.err.needToken", lang) };
    try {
      if (botId == null) {
        const me = await tgApi(token, "getMe", {});
        if (me?.ok && me.result?.id != null) botId = me.result.id;
      }
      const data = await tgApi(token, "getUpdates", {});
      if (!data.ok) return { success: false, error: data.description || "getUpdates failed" };
      const updates = (data.result || []).reverse();
      await noteMovesIn(updates);
      const asNow = (ch) => {
        const a = chatAlias(ch.id);
        return a === String(ch.id) ? ch : { ...ch, id: a, type: "supergroup" };
      };
      const isService = (f) => !f || f.is_bot || TG_SERVICE_IDS.has(String(f.id));
      const cands = [];
      for (const u of updates) {
        const mc = u.my_chat_member;
        if (mc) {
          const st = mc.new_chat_member?.status || "";
          if (st === "left" || st === "kicked") continue;
          const adder = botId != null && String(mc.new_chat_member?.user?.id) === String(botId) && !isService(mc.from) ? String(mc.from.id) : "";
          if (mc.chat && mc.chat.id != null) cands.push({ chat: asNow(mc.chat), owner: adder });
          continue;
        }
        const chat = _chatFromUpdate(u);
        if (chat && chat.id != null) cands.push({ chat: asNow(chat), owner: "" });
      }
      const prevSaved = (await getSettings()).tgChatPrev;
      const prevIds = /* @__PURE__ */ new Set([...Array.isArray(prevSaved) ? prevSaved.map(String) : [], ..._chatMoved.keys()]);
      let pick = cands.find((c) => c.chat.type === "supergroup") || cands.find((c) => c.chat.type === "group");
      if (!pick) {
        const seen = await new Promise((r) => chrome.storage.local.get("fansly_tg_seen_chats", (d) => r(d.fansly_tg_seen_chats || [])));
        const sc = seen.find((x) => (x.type === "supergroup" || x.type === "group") && !prevIds.has(String(x.id)) && (botId == null || String(x.bot || "") === String(botId)));
        if (sc) pick = { chat: asNow({ id: sc.id, type: sc.type, title: sc.title }), owner: sc.by && sc.by.id != null && !isService(sc.by) ? String(sc.by.id) : "" };
      }
      if (!pick) return { success: false, error: t("bg.err.noMessagesToBot", lang) };
      const owner = pick.owner || (cands.find((c) => c.owner && String(c.chat.id) === String(pick.chat.id)) || {}).owner || "";
      const out = { success: true, chatId: String(pick.chat.id), ownerId: owner };
      if (wantForum) {
        const gc = await tgApi(token, "getChat", { chat_id: pick.chat.id });
        if (gc?.ok) out.isForum = gc.result?.is_forum === true;
      }
      return out;
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  async function validateTgBot(token) {
    if (!token) return { success: false, error: "no token" };
    const me = await tgApi(token, "getMe", {});
    if (!me?.ok) return { success: false, error: me?.description || "getMe failed" };
    return { success: true, username: me.result.username, botId: me.result.id };
  }
  async function verifyTgSetup(token) {
    if (!token) return { success: false, error: "no token" };
    const me = await tgApi(token, "getMe", {});
    if (!me?.ok) return { success: false, error: me?.description || "getMe failed" };
    const botId = me.result.id;
    const username = me.result.username;
    const det = await detectTelegramChat(token, botId, false);
    if (!det.success) return { success: false, needChat: true, botUsername: username, error: det.error };
    const chatId = det.chatId;
    const chatResp = await tgApi(token, "getChat", { chat_id: chatId });
    if (!chatResp?.ok) return { success: false, botUsername: username, chatId, error: chatResp?.description || "getChat failed" };
    const cur = await getSettings();
    const patch = { tgBotId: String(botId) };
    if (cur.tgOwnerChat !== chatId) {
      patch.tgOwnerChat = chatId;
      patch.tgOwnerId = det.ownerId || "";
      patch.tgMemberCount = null;
      patch.tgMemberCountChat = "";
      patch.tgAdminIds = null;
      patch.tgAdminChat = "";
      await clearTgHold();
      await clearTgGroupAlert();
      await saveTgTopics({ important: null, posts: null, fans: {}, chat: chatId });
    } else if (!cur.tgOwnerId && det.ownerId) patch.tgOwnerId = det.ownerId;
    await new Promise((r) => saveSettings(patch, r));
    const c = chatResp.result;
    const isPublic = !!c.username;
    const isForum = c.is_forum === true;
    const memResp = await tgApi(token, "getChatMember", { chat_id: chatId, user_id: botId });
    const m = memResp?.ok ? memResp.result : null;
    const isAdmin = m?.status === "administrator";
    const canManageTopics = isAdmin && m?.can_manage_topics === true;
    const canInviteUsers = isAdmin && m?.can_invite_users === true;
    const problems = [];
    if (isPublic) problems.push("public");
    if (!isForum) problems.push("no_forum");
    if (!isAdmin) problems.push("not_admin");
    else if (!canManageTopics) problems.push("no_manage_topics");
    const warnings = [];
    if (isAdmin && !canInviteUsers) warnings.push("no_invite");
    return { success: true, chatId, botUsername: username, isPublic, isForum, isAdmin, canManageTopics, canInviteUsers, problems, warnings };
  }
  function claimInvite(fan, tabId) {
    chrome.storage.local.set({ fansly_invite_claim: { fan, tabId, ts: Date.now() } });
  }
  function unclaimInvite() {
    chrome.storage.local.remove("fansly_invite_claim");
  }
  function setSetupActive(on) {
    return new Promise((r) => chrome.storage.local.set({ fansly_tg_setup_active: on ? Date.now() : 0 }, r));
  }
  function init(deps) {
    ({ getSettings, saveSettings, fetchWithTimeout, generatePost, startInviteFlow } = deps);
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== "local" || !ch.fansly_ai_settings) return;
      const nv = ch.fansly_ai_settings.newValue || {}, ov = ch.fansly_ai_settings.oldValue || {};
      if (nv.telegramBotToken && nv.telegramBotToken !== (ov.telegramBotToken || "")) {
        console.warn("[FanslyAI] \u0422\u0413: \u0442\u043E\u043A\u0435\u043D \u0431\u043E\u0442\u0430 \u0441\u043C\u0435\u043D\u0438\u043B\u0441\u044F \u2192 offset \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E \u0431\u043E\u0442\u0430 \u0441\u043D\u044F\u0442, \u0431\u044D\u043A\u043B\u043E\u0433 \u043D\u043E\u0432\u043E\u0433\u043E \u0431\u043E\u0442\u0430 \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F");
        chrome.storage.local.remove("fansly_tg_offset", () => {
          void chrome.runtime.lastError;
        });
        chrome.storage.local.remove("fansly_tg_seen_chats", () => {
          void chrome.runtime.lastError;
        });
        chrome.storage.local.set({ fansly_tg_drop_backlog: true }, () => {
          void chrome.runtime.lastError;
        });
      }
      const newChat = String(nv.telegramChatId || ""), token = nv.telegramBotToken;
      if (newChat && newChat !== String(ov.telegramChatId || "") && token) {
        (async () => {
          const gc = await tgApi(token, "getChat", { chat_id: newChat });
          if (!gc?.ok) return;
          const forum = gc.result?.is_forum === true;
          const cur = await getSettings();
          if (chatAlias(cur.telegramChatId) !== chatAlias(newChat)) return;
          if (cur.tgTopics !== forum) {
            console.log("[FanslyAI] \u0422\u0413: \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u0434\u0440\u0443\u0433\u043E\u0439 \u0447\u0430\u0442 \u2192 \u0440\u0435\u0436\u0438\u043C \u043F\u043E \xAB\u0422\u0435\u043C\u0430\u043C\xBB:", forum ? "\u0442\u043E\u043F\u0438\u043A\u0438" : "\u043E\u0434\u0438\u043D \u0447\u0430\u0442");
            await new Promise((r) => saveSettings({ tgTopics: forum }, r));
          }
          if (forum) await clearTgMode();
        })();
      }
      if (nv.tgTopics === true && ov.tgTopics !== true) clearTgMode();
      if (nv.carouselEnabled !== true || ov.carouselEnabled === true) return;
      (async () => {
        if (!tgCarouselBlocked(await getTgAlert(), await getTgHold(), await getTgGroupAlert())) return;
        console.warn("[FanslyAI] \u0422\u0413: \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0432\u043A\u043B\u044E\u0447\u0438\u043B\u0438 \u043F\u0440\u0438 \u043F\u0430\u0443\u0437\u0435 \u0422\u0413-\u043E\u0445\u0440\u0430\u043D\u044B \u2192 \u0432\u044B\u043A\u043B\u044E\u0447\u0430\u044E \u043E\u0431\u0440\u0430\u0442\u043D\u043E (\u0441\u043D\u0438\u043C\u0438 \u043F\u0430\u0443\u0437\u0443 \u0432 \u043F\u0430\u043D\u0435\u043B\u0438 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439)");
        await new Promise((r) => saveSettings({ carouselEnabled: false }, r));
      })();
    });
  }
  self.TgCore = { init, notify: handleTelegramNotify, poll: pollTelegram, ack: ackTgTask, confirmHold: confirmTgHold, detectChat: detectTelegramChat, setupTopics: setupTgTopics, validateBot: validateTgBot, verifySetup: verifyTgSetup, claimInvite, unclaimInvite, setSetupActive };
})();
