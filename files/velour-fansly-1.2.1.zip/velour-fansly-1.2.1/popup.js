const BUILD = true ? "full" : "full";
const PLATFORM = true ? "fansly" : "fansly";
const SUPPORT_URL = "https://t.me/velourapp";
const SITE_URL = "https://velourff.com";
function $(id) {
  return document.getElementById(id);
}
function saveOne(key, val) {
  chrome.storage.local.get("fansly_ai_settings", (d) => {
    const s = d.fansly_ai_settings || {};
    s[key] = val;
    chrome.storage.local.set({ fansly_ai_settings: s });
  });
}
let uiLang = "ru";
let _settings = {};
const BUILD_STAMP = true ? "2e0e758@20261107.1705" : "dev";
function pultActive() {
  return new Promise((r) => chrome.storage.local.get("fansly_ai_carousel_leader", (d) => {
    const l = d.fansly_ai_carousel_leader;
    const gone = !!(l && (l.unloading || l.stamp !== BUILD_STAMP));
    r(!!(l && Date.now() - (l.ts || 0) < (gone ? 6e4 : 18e4)));
  }));
}
async function refreshMain() {
  const b = $("btn-main");
  if (!b) return;
  const off = !$("t-master").checked;
  b.classList.toggle("dim", off);
  const mt = b.querySelector(".mt"), ms = b.querySelector(".ms");
  if (off) {
    mt.textContent = t("popup.main.title", uiLang);
    ms.textContent = t("popup.main.sub.off", uiLang);
    return;
  }
  if (await pultActive()) {
    mt.textContent = t("popup.main.title.second", uiLang);
    ms.textContent = t("popup.main.sub", uiLang);
  } else {
    mt.textContent = t("popup.main.title", uiLang);
    ms.textContent = t("popup.main.sub", uiLang);
  }
}
function renderTgRow(s) {
  const row = $("row-tg");
  if (!row) return;
  const sub = $("tg-sub"), sw = $("tg-sw"), go = $("tg-go");
  const connected = s.telegramEnabled === true;
  sw.style.display = connected ? "" : "none";
  go.style.display = connected ? "none" : "";
  row.style.cursor = connected ? "" : "pointer";
  if (!connected) sub.textContent = t("popup.tg.notConnected", uiLang);
  else sub.textContent = s.carouselEnabled === true ? t("popup.tg.active", uiLang) : t("popup.tg.off", uiLang);
  if (connected) chrome.storage.local.get(["fansly_tg_hold", "fansly_tg_alert", "fansly_tg_group"], (d) => {
    const hold = d.fansly_tg_hold, al = d.fansly_tg_alert, grp = d.fansly_tg_group;
    if (hold && hold.list && hold.list.length) sub.textContent = t("popup.tg.pausedHold", uiLang);
    else if (al && (al.kind === "bot_no_rights" || al.kind === "bot_removed")) sub.textContent = t("popup.tg.pausedBot", uiLang);
    else if (grp && grp.public) sub.textContent = t("popup.tg.pausedPublic", uiLang);
  });
}
function renderProv(s) {
  const el = $("prov");
  if (!el) return;
  const proxy = s.useProxy === true && !!s.licenseKey;
  const tr = proxy || s.deepLApiKey ? "DeepL" : "Google";
  if (BUILD === "store") {
    el.classList.add("ok");
    el.classList.remove("warn");
    el.textContent = t("popup.prov.trOnly", uiLang, { tr });
    el.title = tr;
    return;
  }
  const ai = proxy ? "Velour cloud" : s.aiProvider && s.aiProvider !== "mock" ? s.aiProvider : null;
  el.classList.toggle("ok", !!ai);
  el.classList.toggle("warn", !ai);
  el.textContent = ai ? t("popup.prov.ok", uiLang) : t("popup.prov.noAi", uiLang);
  el.title = `${ai || "\u2014"} \xB7 ${t("popup.prov.translate", uiLang)} ${tr}`;
}
const QUOTA_NEAR = 0.8;
const QUOTA_FRESH_MS = 5 * 60 * 1e3;
function quotaOut(q) {
  if (!q || !(q.limit > 0) || !(q.used >= q.limit)) return false;
  if (q.prepaid && q.prepaid.count > 0) return false;
  return !(Date.parse(q.periodEnd) <= Date.now());
}
function quotaDate(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  try {
    return d.toLocaleDateString(uiLang, { day: "numeric", month: "long" });
  } catch (e) {
    return d.toISOString().slice(0, 10);
  }
}
function prepaidText(q) {
  const p = q.prepaid;
  if (!p || !(p.count > 0)) return "";
  if (p.count > 1) return t("popup.quota.prepaidN", uiLang, { n: p.count });
  return p.tier && p.tier !== q.tier ? t("popup.quota.prepaid1Tier", uiLang, { tier: p.tier.toUpperCase() }) : t("popup.quota.prepaid1", uiLang);
}
function renderQuota(s, again) {
  const box = $("quota");
  if (!box) return;
  if (!(s.useProxy === true && !!s.licenseKey)) {
    box.style.display = "none";
    return;
  }
  chrome.runtime.sendMessage({ type: "GET_QUOTA", force: again === true }, (r) => {
    void chrome.runtime.lastError;
    const q = r && r.result;
    const roll = q && q.limit > 0 && q.used >= q.limit && q.prepaid && q.prepaid.count > 0;
    if (q && again !== true && (roll || Date.now() - (q.at || 0) > QUOTA_FRESH_MS)) renderQuota(s, true);
    if (!q || !(q.limit > 0)) {
      box.style.display = "none";
      return;
    }
    const part = Math.min(1, Math.max(0, (q.used || 0) / q.limit));
    const out = quotaOut(q);
    const near = !out && part >= QUOTA_NEAR;
    box.style.display = "";
    box.classList.toggle("near", near);
    box.classList.toggle("out", out);
    $("quota-fill").style.width = Math.round(part * 100) + "%";
    const pre = prepaidText(q);
    $("quota-pct").textContent = out ? t("popup.quota.empty", uiLang) : (pre ? "\u23ED " : "") + t("popup.quota.left", uiLang, { pct: Math.round((1 - part) * 100) });
    const hint = q.tier === "lite" ? "popup.quota.hintTrial" : pre ? "popup.quota.hintMonth" : "popup.quota.hintPaid";
    box.title = t(hint, uiLang, { used: Math.min(q.used || 0, q.limit), limit: q.limit, date: quotaDate(q.periodEnd) }) + (pre ? "\n" + pre : "");
    const cta = $("quota-cta");
    const show = out || near && !pre;
    cta.style.display = show ? "block" : "none";
    if (!show) return;
    if (out) {
      cta.classList.toggle("nolink", false);
      cta.dataset.tier = "";
      cta.textContent = t(q.tier === "lite" ? "popup.quota.outLite" : "popup.quota.out", uiLang);
      return;
    }
    const pro = q.tier === "pro";
    cta.classList.toggle("nolink", pro);
    cta.dataset.tier = pro || q.tier === "lite" ? "" : "pro";
    cta.textContent = pro ? t("popup.quota.nearProRenew", uiLang) : q.tier === "lite" ? t("popup.quota.nearLite", uiLang) : t("popup.quota.near", uiLang);
  });
}
function applyMaster() {
  const on = $("t-master").checked;
  $("body").classList.toggle("off", !on);
  refreshMain();
}
function setChk(id, val) {
  const e = $(id);
  if (e) e.checked = val;
}
function load() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (r) => {
    const s = r && r.result || {};
    _settings = s;
    uiLang = s.interfaceLanguage || "ru";
    applyI18n(document, uiLang);
    $("master-title").textContent = t("popup.master.title", uiLang, { platform: (
      /*@of-start@*/
      PLATFORM === "onlyfans" ? "OnlyFans" : (
        /*@of-end@*/
        "Fansly"
      )
    ) });
    if (BUILD === "store") {
      const _ms = document.querySelector(".master .sub");
      if (_ms) _ms.textContent = t("popup.master.sub.store", uiLang);
    }
    const setupDone = s.setupCompleted === true || !!(s.licenseKey || s.geminiApiKey || s.openrouterApiKey || s.groqApiKey || s.claudeApiKey || s.deepLApiKey || s.telegramBotToken || (s.creatorName || "").trim());
    const first = $("btn-first-setup");
    if (first) first.style.display = BUILD === "full" && !setupDone ? "block" : "none";
    if (!window._tourInit && typeof initPageTour === "function") {
      window._tourInit = true;
      initPageTour({ flag: "tourPopup2", btn: "btn-tour", lang: uiLang, delay: 600, steps: [
        { sel: "#t-master", up: 2, key: BUILD === "store" ? "tour.popup.s1.store" : "tour.popup.s1" },
        { sel: "#btn-main", key: BUILD === "store" ? "tour.popup.s2.store" : "tour.popup.s2" },
        { sel: "#row-tg", key: "tour.popup.s3" },
        { sel: "#row-pages", key: "tour.popup.s4" }
      ] });
    }
    setChk("t-master", s.masterEnabled !== false);
    setChk("t-carousel", s.carouselEnabled === true);
    renderTgRow(s);
    renderProv(s);
    renderQuota(s);
    const keyBtn = $("btn-copy-key");
    if (keyBtn) keyBtn.style.display = String(s.licenseKey || "").trim() ? "" : "none";
    const crmBtn = $("btn-crm");
    if (crmBtn) crmBtn.style.display = s.crmEnabled === false ? "none" : "";
    applyMaster();
  });
}
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && (ch.fansly_ai_settings || ch.fansly_tg_hold || ch.fansly_tg_alert || ch.fansly_tg_group)) load();
});
function bind(id, key, invert) {
  const el = $(id);
  if (!el) return;
  el.addEventListener("change", (e) => {
    saveOne(key, invert ? !e.target.checked : e.target.checked);
    if (id === "t-master") applyMaster();
  });
}
bind("t-master", "masterEnabled");
bind("t-carousel", "carouselEnabled");
$("btn-options").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("options.html") }));
$("btn-about").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("options.html#about") }));
$("about-ver").textContent = "Velour " + chrome.runtime.getManifest().version + " \xB7 " + (/^[0-9a-f]{7,40}\+?@/.test(BUILD_STAMP) ? BUILD_STAMP.split("@")[0].slice(0, 8) : "dev");
$("btn-support").addEventListener("click", () => chrome.tabs.create({ url: SUPPORT_URL }));
$("btn-site").addEventListener("click", () => chrome.tabs.create({ url: SITE_URL }));
$("prov").addEventListener("click", () => {
  if ($("prov").classList.contains("warn")) chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
});
async function copyKey() {
  const key = String(_settings.licenseKey || "").trim();
  if (!key) return false;
  try {
    await navigator.clipboard.writeText(key);
    return true;
  } catch (e) {
    return false;
  }
}
$("btn-copy-key")?.addEventListener("click", async () => {
  const btn = $("btn-copy-key"), was = btn.textContent;
  btn.textContent = t(await copyKey() ? "popup.key.copied" : "popup.key.copyFail", uiLang);
  setTimeout(() => {
    btn.textContent = was;
  }, 1200);
});
$("quota-cta")?.addEventListener("click", async () => {
  const cta = $("quota-cta");
  if (cta.classList.contains("nolink")) return;
  if (await copyKey()) {
    cta.textContent = t("popup.key.copiedHint", uiLang);
    await new Promise((r) => setTimeout(r, 900));
  }
  chrome.runtime.sendMessage({ type: "OPEN_PRICING", tier: cta.dataset.tier });
});
$("btn-main").addEventListener("click", () => {
  if ($("btn-main").classList.contains("dim")) return;
  saveOne("panelHidden", false);
  chrome.runtime.sendMessage({ type: "OPEN_WORK_TAB" }, () => {
    void chrome.runtime.lastError;
    window.close();
  });
});
$("row-tg")?.addEventListener("click", () => {
  if (_settings.telegramEnabled !== true) chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
});
$("btn-first-setup")?.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("setup.html") }));
$("btn-setup")?.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("setup.html") }));
$("btn-catalog")?.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("catalog.html") }));
$("btn-crm")?.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("crm.html") }));
$("btn-diag")?.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("diag.html") }));
if (BUILD === "store") document.querySelectorAll(".full-only").forEach((e) => {
  e.style.display = "none";
});
try {
  if (chrome.action) {
    chrome.action.setBadgeText({ text: "" });
    const mt = chrome.runtime.getManifest();
    chrome.action.setTitle({ title: mt.action && mt.action.default_title || mt.name || "Velour" });
  }
} catch (e) {
}
load();
try {
  FaiConsent.ask((lang) => {
    uiLang = lang;
    applyI18n(document, uiLang);
    load();
  });
} catch (e) {
}
