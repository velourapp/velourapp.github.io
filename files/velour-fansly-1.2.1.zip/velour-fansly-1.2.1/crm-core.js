(function() {
  "use strict";
  const RECENT_BUY_DAYS_DEF = 60;
  const MONTHS = Object.freeze({ Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 });
  const MONTHS_LC = Object.fromEntries(Object.entries(MONTHS).map(([k, v]) => [k.toLowerCase(), v]));
  function monthIndex(s) {
    return MONTHS_LC[String(s || "").slice(0, 3).toLowerCase()];
  }
  function subEndAt(sub) {
    if (!sub) return null;
    const m = (sub.endDate || "").match(/([A-Z][a-z]{2})\s+(\d{1,2}),\s*(\d{4})/);
    return m && MONTHS[m[1]] != null ? new Date(+m[3], MONTHS[m[1]], +m[2]).getTime() : null;
  }
  function subBillingDays(cycle) {
    const c = (cycle || "").toLowerCase();
    if (/year|annual|год/.test(c)) return 365;
    if (/week|недел/.test(c)) return 7;
    return 31;
  }
  function subEffective(sub, latestRenewAt, latestExpireAt) {
    const now = Date.now();
    const subsEndAt = subEndAt(sub);
    const renewEndAt = latestRenewAt != null ? latestRenewAt + subBillingDays(sub && sub.billingCycle) * 864e5 : null;
    let effEndAt = Math.max(subsEndAt || 0, renewEndAt || 0) || null;
    const autoRenew = sub && sub.renewOn === true;
    const cancelledAtEnd = latestExpireAt != null && subsEndAt != null && latestExpireAt >= subsEndAt - 864e5;
    if (autoRenew && subsEndAt && !cancelledAtEnd) effEndAt = Math.max(effEndAt || 0, subsEndAt + subBillingDays(sub.billingCycle) * 864e5);
    let active;
    if (effEndAt != null) active = effEndAt > now;
    else active = !!(sub && sub.status !== "expired" && latestExpireAt == null);
    const nextAt = autoRenew && subsEndAt && subsEndAt > now ? subsEndAt : effEndAt;
    const daysLeft = active && nextAt ? Math.ceil((nextAt - now) / 864e5) : null;
    const everSubbed = !!sub || latestRenewAt != null || latestExpireAt != null;
    return { active, expired: everSubbed && !active, daysLeft, effEndAt };
  }
  function earnBuyerMap(earnings, ledger) {
    if (!earnings || !Object.keys(earnings).length) return null;
    const att = attributeOrphans(earnings, ledger);
    const m = {};
    for (const e of Object.values(earnings)) {
      if (e.refunded || !(e.net >= 0)) continue;
      const inf = !e.buyer ? att[e.orderId] : null;
      if (!e.buyer && !inf) continue;
      const h = (e.buyer || inf.buyer).toLowerCase(), g = e.net / 0.8;
      const o = m[h] || (m[h] = { spent: 0, subSpent: 0, buySpent: 0, tipSpent: 0, lastBuyAt: null, buyCount: 0, firstSubAt: null, lastSubAt: null, subPayCount: 0, media: [], inferredSpent: 0, inferredN: 0, inferredLastAt: 0, namedLastAt: 0, unknownN: 0, unknownLastAt: 0 });
      if (inf) {
        o.inferredSpent += g;
        o.inferredN++;
        if (e.at > o.inferredLastAt) o.inferredLastAt = e.at;
      } else if (e.unknownAt) {
        o.unknownN++;
        if (e.at > o.unknownLastAt) o.unknownLastAt = e.at;
      } else if (e.at > o.namedLastAt) o.namedLastAt = e.at;
      o.spent += g;
      if (e.type === "subscription") {
        o.subSpent += g;
        o.subPayCount++;
        if (e.at && (o.firstSubAt == null || e.at < o.firstSubAt)) o.firstSubAt = e.at;
        if (e.at && (o.lastSubAt == null || e.at > o.lastSubAt)) o.lastSubAt = e.at;
      } else if (e.type === "media" || e.type === "media_bundle") {
        o.buySpent += g;
        o.buyCount++;
        if (e.at && (o.lastBuyAt == null || e.at > o.lastBuyAt)) o.lastBuyAt = e.at;
        const ids = e.mediaIds || [];
        if (ids.length) {
          const per = +(g / (e.bundleSize || ids.length)).toFixed(2);
          for (const id of ids) o.media.push({ mediaId: id, amount: per, at: e.at || null });
        }
      } else if (e.type === "tip") o.tipSpent += g;
    }
    return m;
  }
  const DAY_MS = 864e5;
  function dayOf(at) {
    if (!at) return null;
    const d = new Date(at);
    return Math.round(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DAY_MS);
  }
  function payKind(t) {
    return t === "media" || t === "media_bundle" ? "media" : t === "subscription" || t === "sub_new" || t === "sub_renew" ? "sub" : t === "tip" ? "tip" : null;
  }
  function attributeOrphans(earnings, ledger) {
    const out = {};
    const rows = Object.values(earnings || {}).filter((e) => e && !e.refunded && e.net >= 0);
    const orphans = rows.filter((e) => !e.buyer && payKind(e.type));
    if (!orphans.length || !ledger) return out;
    const coveredMedia = /* @__PURE__ */ new Set(), coveredAmount = /* @__PURE__ */ new Set();
    for (const e of rows) {
      if (!e.buyer) continue;
      const h = e.buyer.toLowerCase(), k = payKind(e.type), d = dayOf(e.at), amt = Math.round(e.net / 0.8);
      if (k === "media") for (const id of e.mediaIds || []) coveredMedia.add(h + "|" + id);
      if (k && d != null) for (const dd of [d - 1, d, d + 1]) coveredAmount.add(h + "|" + k + "|" + dd + "|" + amt);
    }
    const evs = [];
    for (const [key, arr] of Object.entries(ledger)) {
      const h = key.toLowerCase();
      for (const e of arr || []) {
        const k = payKind(e && e.type);
        if (!k) continue;
        const d = dayOf(e.at), amt = e.amount > 0 ? Math.round(e.amount) : null;
        if (k === "media" && e.mediaId && coveredMedia.has(h + "|" + e.mediaId)) continue;
        if (amt != null && d != null && coveredAmount.has(h + "|" + k + "|" + d + "|" + amt)) continue;
        evs.push({ h, k, d, amount: e.amount > 0 ? e.amount : null, mediaId: e.mediaId || null, used: false });
      }
    }
    for (const r of orphans) {
      const k = payKind(r.type), d = dayOf(r.at), gross = r.net / 0.8, ids = new Set(r.mediaIds || []);
      let cands = [], how = "media";
      if (k === "media" && ids.size) cands = evs.filter((v) => !v.used && v.k === "media" && v.mediaId && ids.has(v.mediaId) && (v.d == null || d == null || Math.abs(v.d - d) <= 1));
      if (!cands.length) {
        how = "amount";
        cands = evs.filter((v) => !v.used && v.k === k && v.amount != null && Math.abs(v.amount - gross) <= 0.5 && v.d != null && d != null && Math.abs(v.d - d) <= 1);
      }
      const hs = [...new Set(cands.map((v) => v.h))];
      if (hs.length !== 1) continue;
      cands.sort((a, b) => Math.abs((a.d ?? d) - d) - Math.abs((b.d ?? d) - d))[0].used = true;
      out[r.orderId] = { buyer: hs[0], how };
    }
    return out;
  }
  function pickCI(store, handle, lower) {
    if (store[handle] != null) return store[handle];
    if (store[lower] != null) return store[lower];
    for (const k in store) if (k.toLowerCase() === lower) return store[k];
    return null;
  }
  function evKey(e) {
    if (!e) return "";
    if (e.type === "media" && e.mediaId) return "media|" + e.mediaId;
    const day = e.at ? new Date(e.at).toISOString().slice(0, 10) : "";
    return (e.type || "") + "|" + day + "|" + (e.amount || "") + "|" + (e.mediaId || "");
  }
  function collectCI(store, handle, lower) {
    const seen = /* @__PURE__ */ new Set(), out = [];
    for (const k in store) {
      if (k.toLowerCase() !== lower) continue;
      for (const e of store[k] || []) {
        const key = evKey(e);
        if (key && seen.has(key)) continue;
        if (key) seen.add(key);
        out.push(e);
      }
    }
    return out;
  }
  function freshestCI(store, handle, lower) {
    let best = null;
    for (const k in store) {
      if (k.toLowerCase() !== lower) continue;
      const v = store[k];
      if (!v) continue;
      if (!best || (v.syncedAt || 0) > (best.syncedAt || 0)) best = v;
    }
    return best;
  }
  function hasCrmData(handle, stores) {
    const l = (handle || "").toLowerCase();
    if (freshestCI(stores.fansly_subs || {}, handle, l)) return true;
    if (collectCI(stores.fansly_ledger || {}, handle, l).length) return true;
    if (collectCI(stores.fansly_purchases || {}, handle, l).length) return true;
    if (stores._earnMap === void 0) stores._earnMap = earnBuyerMap(stores.fansly_earnings, stores.fansly_ledger);
    return !!(stores._earnMap && stores._earnMap[l]);
  }
  function openBrief(f) {
    const b = f.contact && f.contact.brief;
    return b && (b.wants || b.details && b.details.length) ? b : null;
  }
  function fanStage(f, opts) {
    const recentBuyDays = opts && opts.recentBuyDays || RECENT_BUY_DAYS_DEF;
    if (f.sub || f.expired || f.spent > 0 || f.activeSub || f.buyCount > 0 || f.subCount > 0) {
      const recentBuy = f.lastBuyAt != null && Date.now() - f.lastBuyAt < recentBuyDays * 864e5;
      const customerNow = f.activeSub || recentBuy;
      const subHistory = !!(f.sub || f.expired || (f.subCount || 0) > 0);
      if (!customerNow) return subHistory ? "lost" : "cold";
      const retained = (f.renewCount || 0) > 0 || (f.months || 0) > 1 || (f.subCount || 0) > 1 || (f.buyCount || 0) > 1;
      return retained ? "repeat" : "paid";
    }
    if (openBrief(f)) return "brief";
    const cl = f.contact && f.contact.dossier && f.contact.dossier.closeness;
    if (cl && cl !== "new") return "interest";
    if (f.contact) return "acquaint";
    return "lead";
  }
  function fanStuck(f, opts) {
    const briefStaleHours = (opts && opts.briefStaleHours) ?? 48;
    const b = openBrief(f);
    if (b && b.collectedAt) {
      const h = Math.floor((Date.now() - b.collectedAt) / 36e5);
      if (h > briefStaleHours) return { key: "briefStale", n: Math.max(1, Math.round(h / 24)) };
    }
    if (f.stage === "interest") {
      const lm = f.contact && f.contact.dossier && f.contact.dossier.lastMessageAt;
      if (lm && Date.now() - lm > 7 * 864e5) return { key: "silent", n: Math.floor((Date.now() - lm) / 864e5) };
    }
    return null;
  }
  function computeSegments(f) {
    const s = /* @__PURE__ */ new Set();
    if (f.paid) s.add("paid");
    if (f.activeSub && f.sub && f.sub.renewOn === false) s.add("churn");
    if (f.activeSub && f.daysLeft != null && f.daysLeft <= 7) s.add("expiring");
    if (f.expired) s.add("expired");
    if (f.hasBought && !f.activeSub) s.add("buyersNoSub");
    if ((f.likes || 0) > 0) s.add(f.hasCard ? "likersCard" : "likersNoCard");
    if (f.followAt && !f.sub && !f.activeSub && !(f.subCount > 0)) s.add("free");
    return s;
  }
  const SPEND_FULL = 1e3;
  function spendW(spent) {
    return Math.min(1, Math.log1p(Math.max(0, spent || 0) / 50) / Math.log1p(SPEND_FULL / 50));
  }
  function leadScore(f) {
    let sc = 0;
    sc += spendW(f.spent) * 45;
    if (f.activeSub) {
      sc += 15;
      sc += Math.min(f.months || 0, 12) / 12 * 15;
      if (f.sub && f.sub.renewOn === false) sc -= 5;
    } else if (f.expired) {
      sc += Math.min(f.months || 0, 12) / 12 * 8;
    }
    const likes = f.likes || 0;
    const lastLike = f.lastLikeAt || 0;
    const likeW = lastLike ? Math.max(0, Math.min(1, (90 - (Date.now() - lastLike) / 864e5) / 60)) : 0.5;
    sc += Math.min(likes, 10) / 10 * 10 * likeW;
    if (f.expired && lastLike && Date.now() - lastLike < 30 * 864e5) sc += 8;
    const lm = f.contact && f.contact.dossier && f.contact.dossier.lastMessageAt;
    if (lm && Date.now() - lm < 14 * 864e5) sc += 10;
    return Math.max(0, Math.min(100, Math.round(sc)));
  }
  const LIKES_CAP = 50;
  const LIKES_IDX = /* @__PURE__ */ new WeakMap();
  function likesKey(store, handle) {
    if (store[handle]) return handle;
    const l = handle.toLowerCase();
    let m = LIKES_IDX.get(store);
    const k0 = m && m.get(l);
    if (k0 != null && store[k0]) return k0;
    if (m && k0 == null) return null;
    m = /* @__PURE__ */ new Map();
    for (const k in store) m.set(k.toLowerCase(), k);
    LIKES_IDX.set(store, m);
    const k1 = m.get(l);
    return k1 != null ? k1 : null;
  }
  function likesRec(store, handle, create) {
    const k = likesKey(store, handle);
    if (k != null) return store[k];
    if (!create) return null;
    store[handle] = { name: "", n: 0, firstLikeAt: 0, lastLikeAt: 0, media: {} };
    const m = LIKES_IDX.get(store);
    if (m) m.set(handle.toLowerCase(), handle);
    return store[handle];
  }
  function likesMerge(store, events, now) {
    if (!store || !Array.isArray(events)) return false;
    now = now || Date.now();
    let changed = false;
    for (const e of events) {
      const h = String(e && e.handle || "").trim();
      if (!h) continue;
      let r = null;
      if (e.kind === "like") {
        if (!e.mediaId) continue;
        const id = String(e.mediaId), at = e.at > 0 ? +e.at : 0;
        r = likesRec(store, h, false);
        const media = r && (r.media || (r.media = {}));
        if (!(media && media[id] != null)) {
          const ids = media ? Object.keys(media) : [];
          let skip = false;
          if (ids.length >= LIKES_CAP) {
            let oldId = null, oldAt = Infinity;
            for (const x of ids) {
              const t = +media[x] || 0;
              if (t < oldAt) {
                oldAt = t;
                oldId = x;
              }
            }
            if (!at || at <= oldAt) skip = true;
            else delete media[oldId];
          }
          if (!skip) {
            if (!r) r = likesRec(store, h, true);
            r.media[id] = at;
            r.n = (r.n || 0) + 1;
            if (at > (r.lastLikeAt || 0)) r.lastLikeAt = at;
            if (at && (!r.firstLikeAt || at < r.firstLikeAt)) r.firstLikeAt = at;
            changed = true;
          }
        }
      } else if (e.kind === "follow") {
        r = likesRec(store, h, false);
        if (!(r && r.followAt)) {
          if (!r) r = likesRec(store, h, true);
          r.followAt = e.at > 0 ? +e.at : now;
          changed = true;
        }
      } else continue;
      if (r && e.name && r.name !== e.name) {
        r.name = e.name;
        changed = true;
      }
    }
    return changed;
  }
  function likesSeed(store, outreach) {
    let changed = false;
    for (const [h, o] of Object.entries(outreach || {})) {
      if (!o || !h) continue;
      const likes = +o.likes || 0, at = +o.lastLikeAt || 0, follow = o.follower === true;
      if (!likes && !at && !follow) continue;
      let r = likesRec(store, h, false);
      if (!r) {
        r = likesRec(store, h, true);
        changed = true;
      }
      if (likes > (r.seed || 0)) {
        r.seed = likes;
        changed = true;
      }
      if (at > (r.lastLikeAt || 0)) {
        r.lastLikeAt = at;
        changed = true;
      }
      if (at && (!r.firstLikeAt || at < r.firstLikeAt)) {
        r.firstLikeAt = at;
        changed = true;
      }
      if (follow && !r.followAt) {
        r.followAt = +o.flaggedAt || +o.lastAt || Date.now();
        changed = true;
      }
      if (!r.name && o.name) {
        r.name = o.name;
        changed = true;
      }
    }
    return changed;
  }
  const STORE_KEYS = Object.freeze(["fansly_subs", "fansly_ledger", "fansly_purchases", "fansly_earnings", "fansly_earnings_lastsync", "fansly_outreach", "fansly_likes"]);
  function computeFan(handle, name, stores, contact, opts) {
    opts = opts || {};
    const l = (handle || "").toLowerCase();
    const subs = stores.fansly_subs || {}, purchases = stores.fansly_purchases || {}, outreach = stores.fansly_outreach || {}, ledger = stores.fansly_ledger || {};
    if (stores._earnMap === void 0) stores._earnMap = earnBuyerMap(stores.fansly_earnings, stores.fansly_ledger);
    const earnMap = stores._earnMap;
    const sub = freshestCI(subs, handle, l);
    const parr = collectCI(purchases, handle, l);
    const purchasesAgg = { count: parr.length, sum: parr.reduce((a2, p) => a2 + (p.amount || 0), 0) };
    const out = pickCI(outreach, handle, l);
    const lk = pickCI(stores.fansly_likes || {}, handle, l);
    const evs = collectCI(ledger, handle, l);
    let ledgerSpent = 0, subCount = 0, firstSubAt = null, mediaBuys = 0, latestRenewAt = null, latestExpireAt = null, renewsAfterSync = 0, renewCount = 0;
    let subSpent = 0, buySpent = 0, tipSpent = 0, buysNoAmount = 0;
    const earnSyncAt = stores.fansly_earnings_lastsync && stores.fansly_earnings_lastsync.at || 0;
    const freshCut = earnSyncAt ? earnSyncAt + 45 * 6e4 : Infinity;
    let freshSpent = 0, freshSub = 0, freshBuy = 0, freshTip = 0, freshN = 0;
    const ledgerMediaIds = /* @__PURE__ */ new Set();
    let ledgerBuyAt = null;
    const purchasedMedia = [], pmSeen = /* @__PURE__ */ new Set();
    for (const e of evs) {
      if (e.amount) ledgerSpent += e.amount;
      if (e.type === "media") {
        if (e.amount) buySpent += e.amount;
        else buysNoAmount++;
      }
      if ((e.type === "sub_new" || e.type === "sub_renew") && e.amount) subSpent += e.amount;
      if (e.type === "tip" && e.amount) tipSpent += e.amount;
      if (e.at && e.at > freshCut && payKind(e.type)) freshN++;
      if (e.amount && e.at && e.at > freshCut) {
        freshSpent += e.amount;
        if (e.type === "media") freshBuy += e.amount;
        else if (e.type === "sub_new" || e.type === "sub_renew") freshSub += e.amount;
        else if (e.type === "tip") freshTip += e.amount;
      }
      if (e.type === "media") {
        mediaBuys++;
        if (e.at && (ledgerBuyAt == null || e.at > ledgerBuyAt)) ledgerBuyAt = e.at;
        if (e.mediaId) {
          ledgerMediaIds.add(e.mediaId);
          if (!pmSeen.has(e.mediaId)) {
            pmSeen.add(e.mediaId);
            purchasedMedia.push({ mediaId: e.mediaId, amount: e.amount || null, at: e.at || null });
          }
        }
      }
      if (e.type === "sub_new") subCount++;
      if (e.type === "sub_new" || e.type === "sub_renew") {
        if (e.at && (firstSubAt == null || e.at < firstSubAt)) firstSubAt = e.at;
        if (e.at && (latestRenewAt == null || e.at > latestRenewAt)) latestRenewAt = e.at;
      }
      if (e.type === "sub_expire" && e.at && (latestExpireAt == null || e.at > latestExpireAt)) latestExpireAt = e.at;
      if (e.type === "sub_renew") renewCount++;
      if (e.type === "sub_renew" && e.at && sub && sub.syncedAt && e.at > sub.syncedAt) renewsAfterSync++;
    }
    let liveExtra = 0, liveBuys = 0;
    for (const p of parr) {
      if (p.mediaId && ledgerMediaIds.has(p.mediaId)) continue;
      if (p.amount) {
        liveExtra += p.amount;
        buySpent += p.amount;
      } else buysNoAmount++;
      liveBuys++;
      if (p.mediaId && !pmSeen.has(p.mediaId)) {
        pmSeen.add(p.mediaId);
        purchasedMedia.push({ mediaId: p.mediaId, amount: p.amount || null, at: p.at || null });
      }
    }
    const a = earnMap ? earnMap[l] || { spent: 0, subSpent: 0, buySpent: 0, tipSpent: 0, lastBuyAt: null, buyCount: 0, firstSubAt: null, lastSubAt: null, subPayCount: 0, media: [] } : null;
    if (a) {
      if (a.lastSubAt != null && (latestRenewAt == null || a.lastSubAt > latestRenewAt)) latestRenewAt = a.lastSubAt;
      if (a.firstSubAt != null && (firstSubAt == null || a.firstSubAt < firstSubAt)) firstSubAt = a.firstSubAt;
      for (const pm of a.media) {
        if (!pm.mediaId) continue;
        if (!pmSeen.has(pm.mediaId)) {
          pmSeen.add(pm.mediaId);
          purchasedMedia.push(pm);
          continue;
        }
        const ex = purchasedMedia.find((x) => x.mediaId === pm.mediaId);
        if (ex) {
          if (ex.amount == null && pm.amount != null) ex.amount = pm.amount;
          if (ex.at == null && pm.at != null) ex.at = pm.at;
        }
      }
    }
    const lastBuyAt = Math.max(
      purchasedMedia.reduce((m, p) => p.at && (m == null || p.at > m) ? p.at : m, null) || 0,
      ledgerBuyAt || 0
    ) || null;
    const eff = subEffective(sub, latestRenewAt, latestExpireAt);
    const activeSub = eff.active;
    const paid = activeSub && sub && (sub.price || 0) > 0;
    const hasBought = purchasesAgg.count > 0 || mediaBuys > 0 || !!(a && a.buyCount > 0);
    const hasCard = !!(contact && contact.hasCard) || paid;
    const f = { handle, name: contact && contact.name || name || handle, sub, purchases: purchasesAgg, outreach: out, contact, activeSub, paid, hasCard, hasBought, daysLeft: eff.daysLeft, expired: eff.expired, months: (sub && sub.totalMonths || 0) + renewsAfterSync, renewCount, lastBuyAt, subSpent, buySpent, tipSpent, buysNoAmount };
    f.likes = lk ? Math.max(lk.n || 0, lk.seed || 0) : 0;
    f.lastLikeAt = lk && lk.lastLikeAt || 0;
    f.followAt = lk && lk.followAt || 0;
    const tiers = sub && sub.tierName ? [sub.tierName] : [];
    for (const e of evs) if (e.tier && /^sub_/.test(e.type || "") && !tiers.includes(e.tier)) tiers.push(e.tier);
    f.tiers = tiers;
    f.spent = ledgerSpent + liveExtra;
    f.subCount = subCount;
    f.buyCount = mediaBuys + liveBuys;
    if (a) {
      f.spent = a.spent + freshSpent;
      f.subSpent = a.subSpent + freshSub;
      f.buySpent = a.buySpent + freshBuy;
      f.tipSpent = a.tipSpent + freshTip;
      f.buysNoAmount = 0;
      if (a.lastBuyAt && (f.lastBuyAt == null || a.lastBuyAt > f.lastBuyAt)) f.lastBuyAt = a.lastBuyAt;
      f.buyCount = Math.max(f.buyCount, a.buyCount);
      f.months = Math.max(f.months, a.subPayCount);
      const goneN = (a.inferredN || 0) + (a.unknownN || 0), goneAt = Math.max(a.inferredLastAt || 0, a.unknownLastAt || 0);
      const back = (a.namedLastAt || 0) > goneAt + DAY_MS || freshN > 0;
      f.deleted = goneN > 0 && !back;
      f.inferredSpent = a.inferredSpent || 0;
    }
    f.purchasedMedia = purchasedMedia;
    f.firstSubAt = firstSubAt;
    f.segments = computeSegments(f);
    f.score = leadScore(f);
    f.stage = fanStage(f, opts);
    f.stuck = fanStuck(f, opts);
    return f;
  }
  function allFans(stores, contacts, opts) {
    const subs = stores.fansly_subs || {}, purchases = stores.fansly_purchases || {}, outreach = stores.fansly_outreach || {}, ledger = stores.fansly_ledger || {};
    const byHandle = {};
    for (const c of Object.values(contacts || {})) if (c && c.handle) byHandle[c.handle.toLowerCase()] = c;
    const keys = /* @__PURE__ */ new Set(), disp = {};
    const reg = (h, name) => {
      if (!h) return;
      const l = h.toLowerCase();
      keys.add(l);
      if (!disp[l]) disp[l] = { handle: h, name: name || h };
      else if (name && disp[l].name === disp[l].handle) disp[l].name = name;
    };
    for (const h of Object.keys(subs)) reg(h, subs[h] && subs[h].name);
    for (const h of Object.keys(purchases)) reg(h);
    for (const h of Object.keys(outreach)) reg(h, outreach[h] && outreach[h].name);
    for (const h of Object.keys(ledger)) reg(h, ledger[h] && ledger[h][0] && ledger[h][0].name);
    for (const c of Object.values(contacts || {})) if (c && c.handle) reg(c.handle, c.name);
    for (const e of Object.values(stores.fansly_earnings || {})) if (e && e.buyer && !e.refunded) reg(e.buyer);
    return [...keys].map((l) => computeFan(disp[l].handle, disp[l].name, stores, byHandle[l] || null, opts));
  }
  function businessReport(fans, earnings, now, ledger) {
    now = now || Date.now();
    const D = 864e5, sum = (a, g2) => a.reduce((s, x) => s + (g2(x) || 0), 0);
    const med = (a) => {
      const s = a.filter((v) => v != null).sort((x, y) => x - y);
      return s.length ? s[Math.floor(s.length / 2)] : null;
    };
    const ago = (at) => at ? (now - at) / D : Infinity;
    const W = Object.values(earnings || {}).filter((e) => e && !e.refunded && e.net >= 0), g = (e) => e.net / 0.8;
    const ats = W.map((e) => e.at).filter(Boolean);
    const att = attributeOrphans(earnings, ledger), buyerOf = (e) => e.buyer || att[e.orderId] && att[e.orderId].buyer || "";
    const orphans = W.filter((e) => !buyerOf(e)), inferred = W.filter((e) => !e.buyer && buyerOf(e));
    const money = {
      total: sum(W, g),
      sub: sum(W.filter((e) => e.type === "subscription"), g),
      buy: sum(W.filter((e) => e.type === "media" || e.type === "media_bundle"), g),
      tip: sum(W.filter((e) => e.type === "tip"), g),
      orphan: sum(orphans, g),
      orphanN: orphans.length,
      inferred: sum(inferred, g),
      inferredN: inferred.length,
      inferredFans: new Set(inferred.map(buyerOf)).size,
      n: W.length,
      first: ats.length ? Math.min(...ats) : null,
      last: ats.length ? Math.max(...ats) : null
    };
    const subbed = fans.filter((f) => f.activeSub || f.expired);
    const overview = {
      fans: fans.length,
      subbed: subbed.length,
      active: fans.filter((f) => f.activeSub).length,
      gone: fans.filter((f) => f.expired).length,
      payers: fans.filter((f) => f.spent > 0).length,
      deleted: fans.filter((f) => f.deleted).length
    };
    const groups = {};
    for (const f of fans) {
      const k = f.sub && f.sub.tierName || (f.activeSub || f.expired ? "" : null);
      if (k != null) (groups[k] = groups[k] || []).push(f);
    }
    const tiers = Object.entries(groups).map(([name, a]) => {
      const act = a.filter((f) => f.activeSub).length, gone = a.filter((f) => f.expired).length, sp = sum(a, (f) => f.spent);
      return {
        name,
        fans: a.length,
        active: act,
        gone,
        churn: act + gone ? gone / (act + gone) : null,
        months: med(a.map((f) => f.months)),
        renewOff: act ? a.filter((f) => f.activeSub && f.sub && f.sub.renewOn === false).length / act : null,
        spent: sp,
        perFan: sp / a.length,
        median: med(a.map((f) => f.spent)),
        sub: sum(a, (f) => f.subSpent),
        buy: sum(a, (f) => f.buySpent),
        tip: sum(a, (f) => f.tipSpent),
        buyers: a.filter((f) => f.buyCount > 0).length / a.length,
        likers: a.filter((f) => f.likes > 0).length / a.length
      };
    }).sort((x, y) => y.fans - x.fans || x.name.localeCompare(y.name));
    const paying = fans.filter((f) => f.spent > 0).sort((a, b) => b.spent - a.spent), payTotal = sum(paying, (f) => f.spent);
    const share = (p) => payTotal ? sum(paying.slice(0, Math.max(1, Math.round(paying.length * p))), (f) => f.spent) / payTotal : 0;
    let acc = 0, n80 = 0;
    for (const f of paying) {
      acc += f.spent;
      n80++;
      if (acc >= payTotal * 0.8) break;
    }
    const brief = (f) => ({ handle: f.handle, name: f.name, spent: f.spent, tier: f.sub && f.sub.tierName || "", active: !!f.activeSub, expired: !!f.expired, deleted: !!f.deleted, likedAgo: f.lastLikeAt ? Math.floor(ago(f.lastLikeAt)) : null });
    const concentration = { payers: paying.length, top5: share(0.05), top20: share(0.2), n80: payTotal ? n80 : 0, top: paying.slice(0, 10).map(brief) };
    const off = fans.filter((f) => f.activeSub && f.sub && f.sub.renewOn === false);
    const winback = fans.filter((f) => f.expired && ago(f.lastLikeAt) <= 30).sort((a, b) => b.spent - a.spent);
    const gonePaid = fans.filter((f) => f.expired && f.spent > 0);
    const risk = {
      renewOff: off.length,
      renewOffPrice: sum(off, (f) => f.sub && f.sub.price),
      renewOffSpent: sum(off, (f) => f.spent),
      winback: winback.map(brief),
      gonePaid: gonePaid.length,
      gonePaidSpent: sum(gonePaid, (f) => f.spent),
      gonePaidMedian: med(gonePaid.map((f) => f.spent))
    };
    const briefs = fans.filter((f) => openBrief(f));
    const orders = { briefs: briefs.length, briefsPaid: briefs.filter((f) => f.spent > 0).length, briefsStale: briefs.filter((f) => ago(f.contact.brief.collectedAt) > 7).length };
    const firstSub = {};
    for (const e of W) if (e.type === "subscription" && buyerOf(e) && e.at) {
      const l = buyerOf(e).toLowerCase();
      if (!firstSub[l] || e.at < firstSub[l]) firstSub[l] = e.at;
    }
    const byL = {};
    for (const f of fans) byL[(f.handle || "").toLowerCase()] = f;
    const coh = {};
    for (const [l, at] of Object.entries(firstSub)) {
      const d = new Date(at), k = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"), f = byL[l];
      const c = coh[k] || (coh[k] = { month: k, came: 0, active: 0, spent: 0 });
      c.came++;
      if (f && f.activeSub) c.active++;
      if (f) c.spent += f.spent || 0;
    }
    return { now, money, overview, tiers, concentration, risk, orders, cohorts: Object.values(coh).sort((a, b) => a.month.localeCompare(b.month)) };
  }
  function reportForAI(rep, labelOf) {
    if (!rep || !rep.money) return "";
    const usd = (n) => "$" + Math.round(n || 0), pc = (x) => x == null ? "n/a" : Math.round(x * 100) + "%";
    const day = (at) => at ? new Date(at).toISOString().slice(0, 10) : "n/a";
    const m = rep.money, o = rep.overview || {}, c = rep.concentration || {}, r = rep.risk || {}, od = rep.orders || {};
    const share = (x) => pc(m.total ? x / m.total : null), lab = typeof labelOf === "function" ? labelOf : (f, i) => "\u2116" + (i + 1);
    const st = (f) => f.deleted ? "Unknown User" : f.active ? "active" : f.expired ? "left" : "no subscription";
    const out = [`Money (gross, ${day(m.first)} to ${day(m.last)}, transactions ${m.n}): total ${usd(m.total)}; subscription ${share(m.sub)}, paid content ${share(m.buy)}, tips ${share(m.tip)}.`];
    if (m.orphanN || m.inferredN) out.push(`From "Unknown User" (deleted their account or blocked her): attached to no one ${usd(m.orphan)} (${share(m.orphan)} of the money, transactions ${m.orphanN}); attributed to fans from notification history ${usd(m.inferred)} (transactions ${m.inferredN}, fans ${m.inferredFans || 0}).`);
    out.push(`Fans in the base ${o.fans}: subscribed at some point ${o.subbed}, active now ${o.active}, left ${o.gone}, paid ${o.payers}, marked Unknown User ${o.deleted || 0}.`);
    if ((rep.tiers || []).length) {
      out.push("Tiers (last tier seen by the subscriber scan):");
      for (const x of rep.tiers) out.push(`- ${x.name || "(tier unknown)"}: fans ${x.fans}, active ${x.active}, left ${x.gone} (churn ${pc(x.churn)}), median tenure ${x.months ?? "n/a"} mo, renewal off ${pc(x.renewOff)} of active, money ${usd(x.spent)}, per fan ${usd(x.perFan)}, median ${usd(x.median)}, content share ${pc(x.spent ? x.buy / x.spent : null)}, bought content ${pc(x.buyers)}, like posts ${pc(x.likers)}.`);
    }
    if (c.payers) {
      out.push(`Concentration: 80% of the money comes from ${c.n80} of ${c.payers} payers; the top 5% of payers give ${pc(c.top5)} of the money, the top 20% give ${pc(c.top20)}.`);
      out.push("Top 10 by money (anonymized): " + (c.top || []).map((f, i) => `${lab(f, i)} ${usd(f.spent)}, tier ${f.tier || "n/a"}, ${st(f)}${f.likedAgo != null ? ", liked " + f.likedAgo + " days ago" : ""}`).join("; ") + ".");
    }
    const wb = r.winback || [];
    out.push(`Retention: active with renewal off ${r.renewOff || 0} (their subscription ${usd(r.renewOffPrice)} a month, spent ${usd(r.renewOffSpent)} in total); left but liked within 30 days ${wb.length} (spent ${usd(wb.reduce((s, f) => s + (f.spent || 0), 0))} before); left after paying ${r.gonePaid || 0} (${usd(r.gonePaidSpent)} in total, median ${usd(r.gonePaidMedian)}).`);
    out.push(`Content orders: open ${od.briefs || 0}, from payers ${od.briefsPaid || 0}, waiting over a week ${od.briefsStale || 0}.`);
    if ((rep.cohorts || []).length) out.push("Who stays, by month of the first subscription payment (came \u2192 still subscribed now, spent): " + rep.cohorts.map((k) => `${k.month}: ${k.came} \u2192 ${k.active}, ${usd(k.spent)}`).join("; ") + ".");
    return out.join("\n").slice(0, 8e3);
  }
  const FANSLY_EPOCH = 1561418851940;
  function dateWithYear(s, id) {
    if (!s) return "";
    if (/\b\d{4}\b/.test(s)) return s;
    const m = s.match(/(\d{1,2})\s+([A-Za-z]{3,})/);
    if (!m) return s;
    const mo = monthIndex(m[2]);
    if (mo == null) return s;
    let year;
    try {
      const d = new Date(Number(BigInt(id) >> 22n) + FANSLY_EPOCH);
      year = d.getUTCFullYear();
      const dm = d.getUTCMonth();
      if (dm === 0 && mo === 11) year -= 1;
      else if (dm === 11 && mo === 0) year += 1;
    } catch (e) {
      const now = /* @__PURE__ */ new Date();
      year = now.getFullYear();
      if (new Date(year, mo, parseInt(m[1], 10)).getTime() > now.getTime() + 864e5) year -= 1;
    }
    return s + " " + year;
  }
  function postPubAt(p) {
    const m = (p && p.date || "").match(/([A-Za-z]{3,})\s+(\d{1,2})(?:,\s*(\d{4}))?/);
    if (!m) return null;
    const mo = monthIndex(m[1]);
    if (mo == null) return null;
    const day = parseInt(m[2], 10);
    if (m[3]) return new Date(parseInt(m[3], 10), mo, day).getTime();
    const ref = p.lastSeen || p.firstSeen || Date.now();
    let y = new Date(ref).getFullYear();
    if (new Date(y, mo, day).getTime() > ref + 864e5) y -= 1;
    return new Date(y, mo, day).getTime();
  }
  function pluralRu(n, formsRu) {
    const a = Math.abs(Math.trunc(n)) % 100, b = a % 10;
    if (a > 10 && a < 20) return formsRu[2];
    if (b > 1 && b < 5) return formsRu[1];
    if (b === 1) return formsRu[0];
    return formsRu[2];
  }
  function plural(n, formsRu) {
    return n + " " + pluralRu(n, formsRu);
  }
  self.CRM = { subEndAt, subBillingDays, subEffective, earnBuyerMap, pickCI, collectCI, freshestCI, hasCrmData, openBrief, fanStage, fanStuck, computeSegments, spendW, leadScore, computeFan, dateWithYear, pluralRu, plural, MONTHS, monthIndex, postPubAt, FANSLY_EPOCH, STORE_KEYS, likesMerge, likesSeed, allFans, businessReport, reportForAI, attributeOrphans };
})();
