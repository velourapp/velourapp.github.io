"use strict";
let session = null, names = null, cats = null, backend = null, inputSize = 448;
const CAT_GENERAL = 0, CAT_CHARACTER = 4, CAT_RATING = 9;
const CHARACTER_THRESHOLD = 0.85;
let canvas = null, ctx = null;
function parseTagsCsv(csv) {
  const lines = csv.trim().split("\n");
  const head = lines[0].split(",");
  const iName = head.indexOf("name"), iCat = head.indexOf("category");
  const n = [], c = [];
  for (let i = 1; i < lines.length; i++) {
    const p = lines[i].split(",");
    n.push(p[iName]);
    c.push(+p[iCat]);
  }
  return { names: n, cats: c };
}
async function init({ ortUrl, wasmPath, modelBuf, csv, threads, prefer }) {
  self.importScripts(ortUrl);
  ort.env.wasm.wasmPaths = wasmPath;
  const isolated = !!self.crossOriginIsolated, sab = typeof SharedArrayBuffer !== "undefined";
  ort.env.wasm.numThreads = isolated && sab ? threads : 1;
  ort.env.wasm.simd = true;
  ort.env.logLevel = "error";
  try {
    ort.env.webgpu.powerPreference = void 0;
    if (self.navigator && navigator.gpu && navigator.gpu.requestAdapter) {
      const orig = navigator.gpu.requestAdapter.bind(navigator.gpu);
      navigator.gpu.requestAdapter = (opts) => {
        if (opts && "powerPreference" in opts) {
          const o = Object.assign({}, opts);
          delete o.powerPreference;
          return orig(o);
        }
        return orig(opts);
      };
    }
  } catch (e) {
  }
  console.log(
    "[FanslyAI] \u{1F3F7} \u0432\u043E\u0440\u043A\u0435\u0440: \u0438\u0437\u043E\u043B\u044F\u0446\u0438\u044F",
    isolated,
    "| SharedArrayBuffer",
    sab,
    "| \u043F\u043E\u0442\u043E\u043A\u043E\u0432",
    ort.env.wasm.numThreads,
    "(\u0437\u0430\u043F\u0440\u043E\u0448\u0435\u043D\u043E",
    threads + ")"
  );
  const parsed = parseTagsCsv(csv);
  names = parsed.names;
  cats = parsed.cats;
  const bytes = new Uint8Array(modelBuf);
  const GOOD_ENOUGH_MS = 2500;
  const SESS = { logSeverityLevel: 3 };
  async function probe(ep) {
    const s = await ort.InferenceSession.create(bytes, Object.assign({ executionProviders: [ep] }, SESS));
    const dummy = new ort.Tensor("float32", new Float32Array(inputSize * inputSize * 3), [1, inputSize, inputSize, 3]);
    await s.run({ [s.inputNames[0]]: dummy });
    const t = performance.now();
    await s.run({ [s.inputNames[0]]: dummy });
    return { s, ms: Math.round(performance.now() - t) };
  }
  const free = (s) => {
    try {
      s && s.release && s.release();
    } catch (e) {
    }
  };
  const cpuLabel = `CPU \xD7${threads > 1 ? threads : 1}`;
  let gpu = null, gpuMs = null, cpuMs = null, chosen = null;
  if (prefer === "wasm" || prefer === "webgpu") {
    try {
      session = await ort.InferenceSession.create(bytes, Object.assign({ executionProviders: [prefer] }, SESS));
      backend = prefer === "webgpu" ? "GPU" : cpuLabel;
      chosen = prefer;
      canvas = new OffscreenCanvas(inputSize, inputSize);
      ctx = canvas.getContext("2d", { willReadFrequently: true });
      return { backend, vocab: names.length, threads, gpuMs, cpuMs, ep: chosen, cached: true };
    } catch (e) {
      session = null;
    }
  }
  try {
    gpu = await probe("webgpu");
    gpuMs = gpu.ms;
  } catch (e) {
    gpu = null;
  }
  if (gpu && gpu.ms <= GOOD_ENOUGH_MS) {
    session = gpu.s;
    backend = "GPU";
    chosen = "webgpu";
  } else if (threads > 1 || !gpu) {
    free(gpu && gpu.s);
    let cpu = null;
    try {
      cpu = await probe("wasm");
      cpuMs = cpu.ms;
    } catch (e) {
      cpu = null;
    }
    if (cpu && (!gpu || cpu.ms <= gpu.ms)) {
      session = cpu.s;
      backend = cpuLabel;
      chosen = "wasm";
    } else {
      free(cpu && cpu.s);
      const g2 = await probe("webgpu");
      session = g2.s;
      backend = "GPU";
      chosen = "webgpu";
    }
  } else {
    session = gpu.s;
    backend = "GPU";
    chosen = "webgpu";
  }
  canvas = new OffscreenCanvas(inputSize, inputSize);
  ctx = canvas.getContext("2d", { willReadFrequently: true });
  return { backend, vocab: names.length, threads, gpuMs, cpuMs, ep: chosen };
}
async function preprocess(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  const bmp = await createImageBitmap(blob);
  const w = bmp.width, h = bmp.height, side = Math.max(w, h);
  const sq = new OffscreenCanvas(side, side);
  const sctx = sq.getContext("2d");
  sctx.fillStyle = "#fff";
  sctx.fillRect(0, 0, side, side);
  sctx.drawImage(bmp, side - w >> 1, side - h >> 1);
  bmp.close();
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, inputSize, inputSize);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(sq, 0, 0, inputSize, inputSize);
  const px = ctx.getImageData(0, 0, inputSize, inputSize).data;
  const data = new Float32Array(inputSize * inputSize * 3);
  for (let p = 0, q = 0; p < px.length; p += 4) {
    data[q++] = px[p + 2];
    data[q++] = px[p + 1];
    data[q++] = px[p];
  }
  return new ort.Tensor("float32", data, [1, inputSize, inputSize, 3]);
}
function decode(probs, th) {
  const rating = {};
  const gen = [];
  const chars = [];
  for (let i = 0; i < names.length; i++) {
    const p = probs[i];
    if (cats[i] === CAT_RATING) rating[names[i]] = Math.round(p * 1e4) / 1e4;
    else if (cats[i] === CAT_GENERAL && p >= th) gen.push([names[i], Math.round(p * 1e4) / 1e4]);
    else if (cats[i] === CAT_CHARACTER && p >= CHARACTER_THRESHOLD) chars.push(names[i]);
  }
  gen.sort((a, b) => b[1] - a[1]);
  let best = null, bv = -1;
  for (const k in rating) if (rating[k] > bv) {
    bv = rating[k];
    best = k;
  }
  return { tags: gen.map((g) => g[0]), scores: Object.fromEntries(gen), rating: best, ratingScores: rating, character: chars };
}
async function tag({ dataUrl, threshold }) {
  const tensor = await preprocess(dataUrl);
  const out = await session.run({ [session.inputNames[0]]: tensor });
  return decode(out[session.outputNames[0]].data, threshold);
}
async function tagBatch({ dataUrls, threshold }) {
  const tensors = [];
  for (const u of dataUrls) tensors.push(await preprocess(u));
  const n = tensors.length;
  if (n === 1) {
    const out2 = await session.run({ [session.inputNames[0]]: tensors[0] });
    return [decode(out2[session.outputNames[0]].data, threshold)];
  }
  const per = inputSize * inputSize * 3;
  const merged = new Float32Array(per * n);
  for (let i = 0; i < n; i++) merged.set(tensors[i].data, i * per);
  const batch = new ort.Tensor("float32", merged, [n, inputSize, inputSize, 3]);
  const out = await session.run({ [session.inputNames[0]]: batch });
  const data = out[session.outputNames[0]].data;
  const stride = data.length / n;
  const res = [];
  for (let i = 0; i < n; i++) res.push(decode(data.subarray(i * stride, (i + 1) * stride), threshold));
  return res;
}
self.onmessage = async (ev) => {
  const { id, cmd, payload } = ev.data || {};
  try {
    let result = null;
    if (cmd === "init") result = await init(payload);
    else if (cmd === "tag") result = await tag(payload);
    else if (cmd === "tagBatch") result = await tagBatch(payload);
    else if (cmd === "release") {
      try {
        session && session.release && session.release();
      } catch (e) {
      }
      session = null;
      result = true;
    } else throw new Error("unknown command " + cmd);
    self.postMessage({ id, ok: true, result });
  } catch (e) {
    self.postMessage({ id, ok: false, error: e && e.message || String(e) });
  }
};
