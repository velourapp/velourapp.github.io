console.log("[FanslyAI] *** CONTENT SCRIPT LOADED v0.3 ***");
(function() {
  "use strict";
  const BUILD = true ? "full" : "full";
  const _bugCrumbs = [];
  function bugCrumb(code) {
    if (code) {
      _bugCrumbs.push(code);
      if (_bugCrumbs.length > 8) _bugCrumbs.shift();
    }
  }
  function bugStackFrames(err) {
    const out = { name: err && err.name || "Error" };
    const stack = err && err.stack || "";
    const re = /(?:chrome-extension:\/\/[a-z]+\/)?([\w.-]+\.js):(\d+):(\d+)/g;
    const frames = [];
    let m;
    while ((m = re.exec(stack)) && frames.length < 2) frames.push(`${m[1]}:${m[2]}:${m[3]}`);
    if (frames[0]) out.frame = frames[0];
    if (frames[1]) out.frame2 = frames[1];
    return out;
  }
  function reportBug(code, fields, k) {
    try {
      sendSafe({ type: "REPORT_BUG", code, fields: fields || {}, bc: _bugCrumbs.slice(), k });
    } catch (e) {
    }
  }
  window.addEventListener("unhandledrejection", (e) => {
    const m = (e.reason && (e.reason.message || e.reason)) + "";
    if (/context invalidated/i.test(m)) {
      e.preventDefault();
      return;
    }
    if (e.reason && e.reason._faiReported) {
      e.preventDefault();
      return;
    }
    reportBug("exception", { src: "content", ...bugStackFrames(e.reason) });
  });
  window.addEventListener("error", (e) => {
    if (/context invalidated/i.test(e.message || "")) {
      e.preventDefault();
      return;
    }
    const f = e.filename ? { frame: `${e.filename.split("/").pop()}:${e.lineno}:${e.colno}` } : {};
    reportBug("exception", { src: "content", ...bugStackFrames(e.error), ...f });
  });
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type !== "PULT_STATE") return;
    sendResponse({ pult: !!state._pultActive });
  });
  const PLATFORM = true ? "fansly" : "fansly";
  const FANSLY = {
    key: "fansly",
    SEL: {
      messageContent: ".message-content-list",
      messageText: ".message-text",
      textarea: "textarea.message-input",
      contactHeader: ".message-content-header-contact",
      headerWrap: ".message-content-header",
      quote: ".message-reply, .message-quote",
      media: ".message-attachment, .image-placeholder-wrapper",
      displayName: ".display-name",
      contactList: ".message-list.noselect",
      contactLink: '.message-list.noselect a[href*="messages"]',
      search: ".search-input-container input",
      listUnread: '[class~="badge"], [class*="badge-container"]',
      messageTime: ".message-time",
      // время последнего сообщения в строке списка (now/2m/8h/Jul 20, 15:22)
      rowPreview: ".font-size-xs.dark-blue-1.eclipse",
      // превью строки списка = ПОЛНЫЙ текст последнего сообщения (eclipse — только CSS-обрезка); у медиа без текста пусто
      rowPaid: ".fa-badge-dollar",
      // платное вложение в непрочитанном
      rowMedia: ".fa-image, .fa-images, .fa-video, .fa-photo-video, .fa-file-image, .fa-paperclip, .fa-microphone, .fa-camera",
      // признак вложения в строке (best-effort: ⏳ живой замер на фото с подписью)
      navEnvelope: '[data-menu-item="message"] .notification-badge',
      navNotif: '[routerlink="/notifications"] .notification-badge',
      sendBtn: 'button[class*="send"], .send-btn',
      messageNode: "app-group-message.message",
      // один узел сообщения (для observer/скролл-догрузки)
      messageTimestamp: ".timestamp",
      // разделитель даты в ленте — соседний div ВНЕ узла сообщения (пункт 4, 20.10: в реестр)
      usernameLink: ".username-wrapper",
      // ссылка на ник фана в шапке чата (href «/ник») — якорь имени, когда шапка показывает «Unknown User»
      // ── Корневые якоря сканеров (Fansly, full-only использование; ТОЛЬКО через q()/qa()/selStr()) ──
      // Значение — массив кандидатов (fallback-цепочка): первый живой побеждает. Ломкие места редизайна
      // площадки (app-*-компоненты); удалённый оверрайд (selectors.json) чинит их без перевыпуска.
      subCard: ["app-creator-dashboard-subscription"],
      earnRoot: ["app-creator-wallet-transaction-history", "app-wallet-transaction-history"],
      // кошелёк после редизайна 19.10; прежняя таблица — запасом
      earnRow: ["app-creator-wallet-transaction-history .tx-row", "app-wallet-transaction-history table tbody tr, app-wallet-transaction-history table tr"],
      broadcastCard: ["app-broadcast-message-history-item"],
      // Вкладка и внутренности карточки рассылки (6а, 23.10: из кода в реестр — редизайн чинится selectors.json, без релиза).
      // Метрика — по ИКОНКЕ внутри блока метрики (язык-независимо): охват, открытия, продажи; число — текст рядом с иконкой.
      broadcastTab: [".tab-nav-items .tab-nav-item, .tab-nav-item"],
      // ОДНОЙ строкой: нужны все вкладки разом (какая из них «Broadcast Message Stats» — по тексту)
      broadcastStat: [".stat-item"],
      // блок метрики
      broadcastReach: ["i.fa-telegram"],
      // иконка охвата (сколько получили)
      broadcastOpen: ["i.fa-eye"],
      // иконка открытий
      broadcastSale: ["i.fa-tally"],
      // иконка продаж
      broadcastTooltip: [".tooltiptext"],
      // подсказка: вырезаем, иначе число тонет в её тексте
      broadcastAmount: [".stat-item-dollar app-balance-display"],
      // сумма продаж — сам элемент суммы
      broadcastAmountBox: [".stat-item-dollar"],
      // блок суммы — запасной путь, подсказка вырезается
      broadcastTime: [".timestamp"],
      // «Sunday, Jul 26, 2026 at 18:38»
      broadcastText: [".message-content"],
      // превью текста рассылки
      postCard: ["app-post.feed-item", "app-post"],
      // Внутренности поста, бандл «+N», стена профиля и тарифы (6б, 23.10: из кода в реестр — редизайн чинится selectors.json,
      // без релиза). Признаки (postAvatar, postWallActive) проверяются на самом элементе (qm), остальное — поиск внутри.
      postMedia: ["app-post-attachment app-media[data-media-id]"],
      // медиа-вложения поста (не аватар, не превью)
      postMediaNest: ["app-media"],
      // тег медиа: медиа внутри другого медиа — служебное превью, не считаем
      postAvatar: [".avatar"],
      // аватар автора — не медиа поста
      postMediaBox: ["app-account-media"],
      // обёртка медиа со своими счётчиками
      postMediaLike: [".stats-overlay .feed-item-stat.likes"],
      // лайки отдельного медиа (в его обёртке)
      postStatsBox: [".feed-item-stats"],
      // блок счётчиков поста (не тот, что в обёртке медиа)
      postLikes: [".feed-item-stat.likes"],
      // лайки поста — в блоке счётчиков
      postComments: [".feed-item-stat.comments"],
      // комментарии поста — в блоке счётчиков
      postBundleMore: [".more-media-available"],
      // плитка «ещё N медиа» (бандл)
      postBundleOverlay: [".image-overlay"],
      // её оверлей — по нему кликаем
      postGalleryItem: [".media-gallery-item"],
      // плитка галереи в окне бандла
      postGalleryMedia: ["app-media[data-media-id]"],
      // медиа в плитке галереи
      postProfileGallery: [".profile-media-gallery"],
      // профильная карусель в том же окне — её плитки не наши
      postModalClose: [".modal-close-button"],
      // крестик окна: есть он — окно открыто
      postWallBubble: [".bubble"],
      // пузыри стен профиля («Posts», «Live», …)
      postWallActive: [".active"],
      // признак открытой стены
      postTime: [".feed-item-timestamp"],
      // дата поста
      postText: [".feed-item-description"],
      // текст поста
      postTag: ['a[href^="/explore/tag/"]'],
      // ссылки-теги поста
      tierBox: [".subscription-plans"],
      // блок тарифа на профиле
      tierName: [".subscription-tier-title"],
      // название тарифа
      tierPlan: [".subscription-plan[style]"],
      // плашка тарифа — цвет из background в style
      tierPrice: [".subscription-price app-balance-display"],
      // цена тарифа
      notifRow: [".notifications-list .notification", ".notification"],
      vaultTile: [".vault-content app-media[data-media-id]"],
      // Картинка для тумбы/блюр-метрик ВНУТРИ тайла. У видео их ДВЕ (Alex 2026-08-15): `.preview.overflow-hidden`
      // → `img.image.cover` (обрезанная, размытая) и `.preview` → `img.image.contain` (чёткий постер). Первый
      // кандидат цепочки = contain: q() отдаёт первый живой, у фото contain нет → падаем на обычный img.image.
      vaultThumbImg: ["img.image.contain", "img.image"],
      vaultReady: [".vault-album, .quick-menu .bubble, .vault-content app-media[data-media-id]"],
      // Съёмка кадров из видео. ⚠️ Кликать МОЖНО только по кнопке плеера: клик по `.image-overlay`
      // или по самой картинке открывает модалку просмотра и ломает ленту (проверено живьём 2026-08-19).
      vaultPlayBtn: [".video-controls .play-button"],
      vaultVideoEl: ["app-video-element-wrapper video", "video"],
      // Всё остальное хранилища (6в, 23.10: из кода в реестр — редизайн чинится selectors.json, без релиза). Признаки
      // (vaultCoverMedia, vaultAvatar, vaultItemActive) проверяются на самом элементе (qm), остальное — поиск внутри.
      // Альбомы на Overview (их же читает vault-counts.js: реестр ему передаёт сбор хранилища).
      vaultAlbum: [".vault-album"],
      // плитка альбома
      vaultAlbumName: [".vault-album-footer .semi-bold"],
      // имя альбома — единственный ключ папки
      vaultAlbumCount: [".vault-album-footer .dark-blue-1"],
      // счётчик медиа альбома («3,141»)
      vaultAlbumMedia: [".vault-album-media"],
      // обложка альбома — по ней кликаем, чтобы войти
      // Навигация папок: меню пузырей и выпадающий «More» с остальными папками.
      vaultMenu: [".quick-menu"],
      // меню пузырей (у Fansly есть и чужие — наше узнаём по All/Overview/Posts)
      vaultBubble: [".bubble"],
      // пузырь папки (любой глубины в меню)
      vaultBubbleTop: [":scope > .bubble"],
      // прямой пузырь меню — относительно меню (More вложен глубже и сюда не попадает)
      vaultBubbleActive: [".bubble.active"],
      // пузырь открытой папки
      vaultMore: [".transparent-dropdown"],
      // выпадающий «More» в меню
      vaultMoreToggle: [":scope > .bubble"],
      // кнопка «More» — собственный пузырь выпадающего (относительно него)
      vaultMoreItem: [".dropdown-list .dropdown-item"],
      // пункт «More» — папка (в DOM и закрытым)
      vaultItemActive: [".active"],
      // признак открытой папки на пункте «More»
      vaultFolderName: [".eclipse"],
      // имя папки в пункте — по нему кликаем (не по ✏️/✖: ✖ удаляет папку!)
      // Плитка медиа: длительность, имя и дата файла, признаки аудио и видео, служебные превью.
      vaultPlayTime: [".play-time"],
      // длительность видео «0:07»
      vaultProgress: [".progressed-time"],
      // прогресс внутри длительности — вырезаем
      vaultFileName: [".image-filename"],
      // имя файла в ячейке грида
      vaultFileDate: [".image-date"],
      // дата файла в ячейке грида
      vaultAudioMark: [".contains-audio, audio.audio, .audio-wrapper"],
      // ОДНОЙ строкой: любой из признаков аудио
      vaultVideoMark: ["app-video-element-wrapper, video, .play-time"],
      // ОДНОЙ строкой: любой из признаков видео (запас, когда имени нет)
      vaultMediaNest: ["app-media"],
      // тег медиа: медиа внутри другого медиа — служебное превью
      vaultCoverMedia: [".album-cover-media"],
      // обложка альбома — не медиа сетки
      vaultAvatar: [".avatar"],
      // аватар — не медиа сетки
      vaultPreviewPoster: ["app-media.preview"],
      // превью-постер: кнопка плеера в нём — не та
      vaultModalClose: [".modal-close-button"],
      // крестик окна просмотра (клик открыл его — закрыть)
      vaultScroller: [".vault-wrapper"],
      // прокрутка хранилища (запас, если по плитке не нашлась)
      vaultSearchIcon: ["i.fa-search"],
      // лупа в пузыре поиска
      vaultSearchInput: ['.material-input input[type="text"]'],
      // поле «Search Album»
      // Пикер «Из хранилища» (чат, окно загрузки медиа; 24.10): альбомы в окне — те же vaultAlbum / vaultAlbumName / vaultAlbumMedia.
      vaultPickerModal: ["app-media-vault-picker-modal.active-modal"],
      // окно выбора медиа из хранилища
      vaultPickerSearch: [".vault-search .bubble"],
      // лупа поиска файла в окне (внутри папки)
      vaultPickerInput: [".material-input input"],
      // поле поиска файла в окне
      vaultPickMenuItem: [".dropdown-item"],
      // пункт меню, по клику на который проверяем «это хранилище?»
      vaultPickIcon: [".fa-photo-film"],
      // значок «Из хранилища» (меню вложений чата, «добавить ещё»)
      vaultPickUploadIcon: [".fa-upload"],
      // значок загрузки — у «From Vault» блока превью он же
      vaultPickUploadNew: ['[data-menu-item="upload-new"]'],
      // признак соседа «Загрузить новое»: у пункта хранилища его нет
      // Тайл статы в шапке (Лайки / Бесплатные / Платные подписчики → дневной срез + график «Динамики»).
      // Деградирует МОЛЧА (график просто перестаёт пополняться) → корень и внутренности в реестре с оверрайдом.
      creatorStat: [".creator-stats .creator-stat"],
      creatorStatTitle: [".creator-stat-title"],
      creatorStatValue: [".creator-stat-value"],
      // Типы нотификаций — СТРУКТУРНО по тегу компонента (текст локализуется Fansly и ломается молча:
      // «Приобрели ваш медиа-контент» уже не матчился /Purchased your Media/). Теги сняты с живой ленты
      // (Alex 2026-08-13; чаевые и набор — дампы 2026-09-26, #132). Ключи-ПРЕДИКАТЫ (qm). Текстовые регэкспы остаются
      // фолбэком в notifParse — только английским: в русском интерфейсе без тега терялись все чаевые и наборы.
      notifMediaOrder: ["app-account-media-order-notification", "app-account-media-bundle-order-notification"],
      // одиночная покупка и набор: текст у них один
      notifSubPay: ["app-subscription-history-renew-notification"],
      // ОБЩИЙ тег покупки И продления подписки — new/renew различаем по тексту
      notifSubExpire: ["app-subscription-expire-notification"],
      notifTipRow: ["app-tip-received-notification"],
      notifTime: [".notification-timestamp"],
      // штамп времени строки («47m» / «Aug 12»)
      // Внутренности строки уведомления (пункт 5, 20.10: из кода в реестр — редизайн строки чинится без перевыпуска).
      // Без ника строка пропускается целиком; сумма — деньги в ledger; медиа — какое купили или лайкнули.
      notifUser: ["a.username-wrapper[href]"],
      // ссылка на ник фана (href «/ник»)
      notifAmount: ["app-balance-display"],
      // сумма в строке (чаевые, покупка, подписка)
      notifMedia: ["app-media[data-media-id]"],
      // медиа в строке; у видео первым — само медиа, следом превью
      // Лайк / подписка-фоллоу — по имени тега («…like…» / «…follow…», так в коде). Эти ключи по умолчанию пусты и только
      // ДОБАВЛЯЮТ признак: переименовал Fansly тег без этих слов — дописываем его сюда удалённо.
      notifLikeRow: [],
      notifFollowRow: [],
      // Фильтр типов на странице истории уведомлений (глубокий скан). Пункты без иконок, текст локализован — выбираем по
      // НОМЕРУ (одинаков во всех языках): notifFilterWant — какие включить (чаевые, покупки медиа, платные подписчики,
      // истёкшие), notifFilterCount — сколько пунктов ждём: галки ставятся лишь при ровно таком списке (см. scans.js).
      // 12 — живая проверка Алекса 20.10: Fansly Alerts · Likes · Post Replies · Post Quotes · Tips · Followers · Media Purchases ·
      // Subscribers · Expired Subscriptions · Promotions · Locked Text Purchases · Stream Ticket Purchases (три последних Fansly
      // дописал в конец, 4/6/7/8 не сдвинулись). Вставит пункт в середину — галки не тронем, нам отчёт.
      // ⚠️ Две последние записи — числа строкой, не селекторы: у реестра одна схема, и так их тоже чинит selectors.json.
      notifFilterBox: ["[appxddropdown].dropdown, .dropdown"],
      // ОДНОЙ строкой: нужны все дропдауны разом (какой из них фильтр — по пунктам с галкой), а не первый непустой кандидат
      notifFilterItem: [".dropdown-item"],
      notifFilterCheck: [".checkbox"],
      notifFilterOn: [".checkbox.selected"],
      notifFilterTitle: [".dropdown-title"],
      notifFilterWant: ["4", "6", "7", "8"],
      notifFilterCount: ["12"],
      // Разбор строки кошелька: от этих зависит, ЧТО и ПО КАКОЙ цене мы засчитали за проданное.
      // Деградируют молча (ноль ошибок в консоли, просто неверные цифры) → держим в реестре с оверрайдом.
      earnMedia: ["app-media[data-media-id]"],
      // медиа-плитка внутри строки заказа
      moreOverlay: [".more-media-available-overlay span"],
      // «+N» скрытых в пакете (кошелёк и посты)
      // Всё остальное в строке кошелька и общий пагинатор (7а, 24.10: из кода в реестр — редизайн чинится selectors.json, без релиза).
      // Новая вёрстка кошелька (19.10): строка — div.tx-row без ячеек. Признак строки (earnTxRow) проверяется на ней самой (qm).
      earnTxRow: [".tx-row"],
      // строка новой вёрстки → разбор по блокам, а не по ячейкам
      earnTxBuyer: [".tx-main app-account-username, .tx-main a.username-wrapper[href]"],
      // покупатель есть — продажа (у выплаты его нет)
      earnTxOut: [".tx-thumb.out"],
      // исходящая (деньги ушли) — не продажа
      earnTxSign: [".tx-sign"],
      // знак суммы («−» — деньги ушли)
      earnTxId: [".tx-id"],
      // номер заказа «#966…»
      earnTxAmount: [".tx-amount app-balance-display"],
      // сумма продажи
      earnTxStatus: [".fansly-status-pill"],
      // плашка статуса: возврат, отклонено
      earnTxBuyerLink: [".tx-main a.username-wrapper[href]", '.tx-main app-account-username a[href^="/"]'],
      // ссылка покупателя → хэндл
      earnTxDate: [".tx-meta > span:not(.tx-id):not(.fansly-status-pill)"],
      // дата «Oct 12, 2026, 15:11»
      // Прежняя таблица кошелька (до 19.10) — запасной разбор.
      earnCell: [":scope > td"],
      // ячейки строки (относительно строки)
      earnCellBuyer: ["app-account-username, a.username-wrapper[href]"],
      // ячейка с покупателем
      earnCellBuyerLink: ["a.username-wrapper[href]", 'a[href^="/"]'],
      // ссылка покупателя в ячейке (запас — любая ссылка на профиль)
      earnAmount: ["app-balance-display"],
      // сумма в строке таблицы
      // Ожидание ников покупателей: ник дорисовывается лениво — сначала «Unknown user» без ссылки, потом хэндл.
      earnBuyerLink: ["a.username-wrapper[href]"],
      // ссылка на профиль покупателя в строке
      earnBuyerName: [".display-name"],
      // имя покупателя («Unknown…» — ещё не дорисован)
      // Пагинатор Fansly — общий для доходов и подписчиков. Прежняя разметка (app-xd-pagination): .nav-item, выбранный .selected,
      // погашенный .disabled; новая кошелька (app-cursor-pager): .pager-btn, номер .pager-num.active, пропуск .pager-gap, погашенная — disabled.
      pagerItem: [".nav-item, .pager-btn, .pager-gap"],
      // ОДНОЙ строкой: кнопки, номера и пропуски — в порядке документа
      pagerNextIcon: ["i.fa-chevron-right"],
      // стрелка «вперёд» внутри кнопки
      pagerSelected: [".nav-item.selected, .pager-num.active"],
      // выбранный номер (и признак на самом элементе)
      pagerOff: [".disabled"],
      // погашенная кнопка прежней разметки (у новой — свойство disabled)
      earnPager: ["app-creator-wallet-transaction-history app-cursor-pager, app-wallet-transaction-history app-xd-pagination, app-wallet-transaction-history .table-nav"],
      // пагинатор ИСТОРИИ, не выплат
      subsPager: ["app-xd-pagination, .table-nav"],
      // пагинаторы страницы подписчиков (свой — первый после списка карточек)
      // Подписчики (7б, 25.10): вкладки, фан в карточке и карточка новой вёрстки (с 14.10). Карточка — subCard; прежняя вёрстка
      // карточки (строки с иконками, до 14.10) — запасная ветка разбора, в реестр не вынесена. Признаки (subsTabOn, subPriceRow,
      // subStatusOk) проверяются на самом элементе (qm).
      subsSearch: [".subscriber-search"],
      // поиск подписчика — рядом с ним СВОЯ полоса вкладок
      subsTabsWrap: [".tab-nav-wrapper"],
      // блок вкладок вокруг поиска (closest)
      subsTab: [".tab-nav-items .tab-nav-item"],
      // вкладка «Активно / Истёк / Все (N)»
      subsTabOn: [".selected"],
      // признак выбранной вкладки
      subUserLink: ["a.username-wrapper[href]", 'a[href^="/"]'],
      // ссылка на профиль фана в карточке (запас — любая ссылка на профиль)
      subUserName: [".display-name"],
      // имя фана («Unknown…» — ещё не дорисован или удалён)
      subStarIcon: [".user-icon"],
      // значки у ника (галочка верификации и звезда тира)
      subStar: [".icon-stack .fa-star"],
      // звезда тира внутри значка — значок со звездой и есть тир (цвет — в style)
      subStarOverlay: [".overlay"],
      // значок поверх звезды (продление / пауза) — подтверждение статуса
      subDetails: ["dl.subscription-details"],
      // детали подписки новой вёрстки: dt — название, dd — значение
      subTier: [".subscriber-tier"],
      // название тира в шапке карточки
      subDetailValue: ["dd"],
      // значение строки деталей
      subPriceRow: [".subscriber-price"],
      // признак строки цены среди деталей
      subDateBox: [".subscriber-date"],
      // блок даты продления / окончания
      subDateValue: [".subscriber-date-value"],
      // сама дата в блоке
      subStatus: [".fansly-status-pill"],
      // плашка статуса подписки
      subStatusOk: [".ok"],
      // признак действующей подписки на плашке
      subPrice: ["app-balance-display"],
      // цена подписки
      // ⚠️ ПРЕДИКАТ (qm/matches), не поиск. Служебный превью-вариант закрытого видео: рядом с настоящим медиа
      // Fansly рисует его же превью — это не покупка, не файл каталога и не вложение поста. Один ключ на все
      // четыре места (кошелёк, vault, посты, бандл). Замерено на живом DOM: 71 плитка, 16 превью — класс всегда
      // самостоятельный токен `preview`, иногда с довеском (`preview overflow-hidden`), поэтому именно `.preview`,
      // а не равенство класса. Подстроку (`[class*="preview" i]`) намеренно НЕ берём: она поймала бы и будущий
      // `preview-enabled` у настоящего медиа, а потерять реальный файл хуже, чем посчитать лишний. Переименование
      // класса площадкой чинится добавлением кандидата в selectors.json — без перевыпуска.
      mediaPreview: [".preview"],
      // Оплачено ли СВОЁ платное медиа. Лочка тут ни при чём — она только прикрывает контент от посторонних
      // (Alex 2026-08-21), а ценника в СВОЁМ узле нет вовсе: «Unlock for $X» видит фан, а не криейтер, поэтому
      // detectMediaLocked на своих сообщениях всегда false. Настоящий признак — значок «$» в стеке покупателей:
      // с модификатором dark-blue-1 = ещё не куплено, без него = куплено, а если значка нет совсем — медиа
      // доступно фану бесплатно (входит в подписку). Оба ключа чинятся через selectors.json без перевыпуска.
      paidBadge: [".purchased-icon"],
      // значок «$» в стеке покупателей
      paidUnbought: [".purchased-icon.dark-blue-1, .purchased-avatar.not-purchased"],
      // маркер «ещё не куплено»: висит то на значке, то на аватаре
      // Пейвол — СТРУКТУРНО: платное Fansly оборачивает в .locked-image и рисует .locked-icon/.locked-text
      // («Unlock Video» у чужого, «Show Video» у своего). Фильтр чувствительного контента — это ДРУГОЙ узел
      // (.blur-overlay + «View Content / Disable Filter»), .locked-* там нет вовсе (unlocked_content.txt).
      // Признак язык-независимый, в отличие от прежней ловли по тексту/ценнику.
      lockedGate: [".locked-image", ".locked-icon", ".locked-text-container"],
      // Тарифы на /posts: карточка тарифа кликабельна → открывается модалка подписчика с условиями.
      // ⚠️ purchaseBtn здесь ТОЛЬКО чтобы обходить его стороной — кликать по нему нельзя никогда.
      subPlanCard: [".subscription-plans .subscription-plan"],
      subModal: [".active-modal .modal-content", ".modal.v2 .modal-content"],
      subBenefits: [".subscription-benefits"],
      subModalClose: [".active-modal i.fa-xmark.pointer", ".modal.v2 i.fa-xmark.pointer"],
      subModalTier: [".tier-title-header .bold"]
    },
    // Своё исходящее сообщение (входящее — без my-message). Медиа: класс my-message иногда навешивается
    // ПОЗЖЕ рендера вложения (гонка при live-отправке) → узел ловился как чужой (слева, как фан) и ломал
    // коучинг. Страховка — структурный признак «моё медиа»: .purchased-content (стек «кто купил», есть
    // ТОЛЬКО на своём медиа). ⚠️ .unlocked-content для этого больше НЕ годится — теперь она есть и у медиа
    // ФАНА (урезанное меню Toggle Preview/Add to Collection) → метила входящее фана своим. Дампы 2026-08.
    isOwn(node) {
      if (node.classList.contains("my-message")) return true;
      const own = node.querySelector(".purchased-content");
      return !!own && !own.closest(".message-reply");
    },
    // числовой id контакта: из URL и из href строки списка (стабильнее имени)
    contactId() {
      return (location.href.match(/\/messages\/(\d+)/) || [])[1] || null;
    },
    contactIdFromHref(h) {
      return ((h || "").match(/\/messages\/(\d+)/) || [])[1] || null;
    },
    // раздел сообщений (гейт загрузки панели/ретрая/ре-инита при SPA-навигации)
    isMessagesPage(url = location.href) {
      return /messaging|messages/.test(url);
    },
    // добавленный узел = сообщение (для MutationObserver-фильтра живых входящих/исходящих)
    isMessageNode(node) {
      return node.tagName === "APP-GROUP-MESSAGE" || qm("messageNode", node);
    },
    // + реестр (пункт 4): переопределённый узел сообщения тоже узнаётся
    // href строки списка + навигабельный клик-элемент (на Fansly el = сам <a>, так что оба — тождество)
    hrefOf(el) {
      return el.getAttribute("href");
    },
    clickTarget(el) {
      return el;
    },
    // Открыть строку списка чатов БЕЗ «активности». Слушатель активности Fansly висит на document в фазе всплытия
    // (click/keydown/touch*): обычный el.click() всплывает до него → через 90–120 с POST /status → криейтер числится
    // «онлайн», пока пульт открывает чаты (замер Алекса 2026-09-06, только в режиме Online). RouterLink слушает на
    // самой <a>, поэтому клик без всплытия чат открывает, а до document не доходит (три клика за 5,5 мин — ноль
    // /status). Диспатч обязан идти на саму <a>: у внутреннего узла RouterLink нет.
    openRow(el) {
      const a = el && el.matches && el.matches("a[href]") ? el : el?.closest?.("a[href]") || el?.querySelector?.("a[href]") || el;
      if (!a) return;
      a.dispatchEvent(new MouseEvent("click", { bubbles: false, cancelable: true, composed: true, view: window }));
    },
    profileUrl(handle) {
      return handle ? "https://fansly.com/" + encodeURIComponent(handle) : null;
    },
    // Время сообщения: в самом узле даты нет — `.timestamp` лежит соседним div ВНЕ app-group-message.
    // Идём вверх от узла, на каждом уровне ищем прямого ребёнка `.timestamp` (не внутри сообщения) → parseFanslyTs.
    // null — если не нашли (сгруппированные сообщения без своей метки → carry-forward выше по стеку).
    timeOf(node) {
      let el = node;
      for (let i = 0; i < 4 && el; i++) {
        el = el.parentElement;
        if (!el) break;
        for (const c of el.children) {
          if (c.nodeType === 1 && qm("messageTimestamp", c) && !c.closest(selStr("messageNode"))) {
            const t2 = parseFanslyTs(c.textContent);
            if (t2) return t2;
          }
        }
      }
      return null;
    }
  };
  const ONLYFANS = {
    key: "onlyfans",
    SEL: {
      messageContent: ".b-chat__messages-wrapper",
      // контейнер истории
      messageText: ".b-chat__message__text-holder",
      textarea: '.b-text-editor[contenteditable="true"], .tiptap.ProseMirror[contenteditable="true"]',
      contactHeader: ".b-chat__header__wrapper",
      headerWrap: ".b-chat__header__wrapper",
      quote: ".b-chat__replied-message",
      // цитата (reply) — подтверждено на живом OF-DOM
      media: ".b-chat__message__media-wrapper, .b-purchase__list",
      displayName: ".g-user-name",
      contactList: ".b-chats__list",
      /* TODO(sonnet): подтвердить контейнер скролла */
      contactLink: ".b-chats__item",
      // строка списка (внутри: chatLink)
      chatLink: 'a[href^="/my/chats/chat/"]',
      // ссылка чата внутри строки
      search: ".b-chat__search-form .b-search-form__input",
      // поле поиска чатов (подтв. на живом DOM)
      listUnread: ".m-unread",
      // OF: непрочит = класс на .b-chats__item
      navEnvelope: 'a[data-name="Chats"] .l-header__menu__item__count',
      navNotif: 'a[data-name="Notifications"] .l-header__menu__item__count',
      sendBtn: 'button[at-attr="send_btn"]',
      messageNode: '.b-chat__message[at-attr="chat_message"]'
      // один узел сообщения
    },
    isOwn(node) {
      return node.classList.contains("m-from-me");
    },
    contactId() {
      return (location.pathname.match(/\/my\/chats\/chat\/(\d+)/) || [])[1] || null;
    },
    contactIdFromHref(h) {
      return ((h || "").match(/chat\/(\d+)/) || [])[1] || null;
    },
    isMessagesPage(url = location.href) {
      return /\/my\/chats/.test(url);
    },
    isMessageNode(node) {
      return !!node.matches && node.matches(ONLYFANS.SEL.messageNode);
    },
    // href лежит на внутренней ссылке <a>, а НЕ на контейнере .b-chats__item; клик — по навигабельной ссылке
    hrefOf(el) {
      return (el.querySelector(ONLYFANS.SEL.chatLink) || el).getAttribute("href");
    },
    clickTarget(el) {
      return el.querySelector(ONLYFANS.SEL.chatLink) || el.querySelector(".b-chats__item__link") || el;
    },
    openRow(el) {
      el.click();
    },
    // на OF ровно как раньше (обычный клик по переданному элементу): без своей живой проверки не меняем
    profileUrl(handle) {
      return handle ? "https://onlyfans.com/" + encodeURIComponent(handle) : null;
    },
    timeOf(node) {
      return null;
    },
    // TODO(OF-порт): извлечение времени сообщения из OF-DOM не портировано
    // ── Whole-function OF-варианты (стубы — заполняет Sonnet) ──
    // Контракт = поведение одноимённой FANSLY-функции, но по OF-DOM. Пока возвращают безопасные
    // пустышки: OF-сборка не падает, просто пусто, до заливки.
    findUnreadContacts() {
      const out = [];
      document.querySelectorAll(ONLYFANS.SEL.contactLink + ONLYFANS.SEL.listUnread).forEach((el) => {
        const link = el.querySelector(ONLYFANS.SEL.chatLink);
        const href = link ? link.getAttribute("href") : "";
        const id = this.contactIdFromHref(href);
        const nameEl = el.querySelector(ONLYFANS.SEL.displayName);
        const name = nameEl ? cleanContactName(nameEl.innerText) : "(?)";
        out.push({ el: ONLYFANS.clickTarget(el), id, name, count: 1 });
      });
      return out;
    },
    detectContact() {
      state.currentContactId = this.contactId();
      const header = document.querySelector(ONLYFANS.SEL.contactHeader);
      if (header) {
        const nameEl = header.querySelector(ONLYFANS.SEL.displayName);
        state.currentContact = cleanContactName(nameEl ? nameEl.innerText : header.innerText);
      }
    },
    loadHistory() {
      state.chatHistory = [];
      state._histFor = state.currentContactId;
      state.processedNodes = /* @__PURE__ */ new WeakSet();
      state._mirrorLiveCount = 0;
      state._mirrorLiveAt = 0;
      const historyEl = document.getElementById("fai-chat-history");
      if (historyEl) historyEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.loading">${t("panel.history.loading", state.uiLang)}</div>`;
      document.querySelectorAll(ONLYFANS.SEL.messageNode).forEach((node) => {
        const role = this.isOwn(node) ? "model" : "subscriber";
        const text = getMessageText(node);
        const hasMedia = node.querySelector(ONLYFANS.SEL.media);
        if (!text && !hasMedia) return;
        state.processedNodes.add(node);
        const entry = {
          role,
          text: text || "",
          isMedia: !!hasMedia && !text,
          mediaType: null,
          mediaLocked: false,
          timestamp: this.timeOf(node) || Date.now(),
          // OF timeOf пока стаб(null)→now; заполнит OF-порт — подхватится
          ts: null,
          reply: null
        };
        state.chatHistory.push(entry);
        const msgEl = appendMessageToHistory(entry);
        if (text && msgEl) translateMsgForDisplay(text, msgEl, role === "model" ? outGenders() : inGenders());
      });
      const lastSub = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
      state.lastIncomingText = lastSub ? lastSub.text : null;
      if (state._ofGenContact !== state.currentContactId) {
        state._ofGenContact = state.currentContactId;
        state._ofLastGen = lastSub ? lastSub.text : null;
      } else if (lastSub && state.active && lastSub.text !== state._ofLastGen && Date.now() >= state.suppressUntil) {
        state._ofLastGen = lastSub.text;
        scheduleIncomingGen(lastSub.text);
      }
      updateStats();
      scrollHistoryToBottom();
    },
    applyFanStatus() {
      return;
    },
    // ── Отправка ──
    // Ввод в ProseMirror недоступен из isolated world → делаем через main-world мост (of-bridge.js):
    // postMessage 'setText' → мост зовёт el.editor…insertContent → отвечает 'setText:done'. Затем клик
    // send (DOM-действие доступно из isolated) и ждём своё .m-from-me (OF шлёт с задержкой ~5с).
    _bridgeSetText(text) {
      return new Promise((resolve) => {
        const onMsg = (e) => {
          if (e.source === window && e.data && e.data.source === "fai-of-bridge" && e.data.action === "setText:done") {
            window.removeEventListener("message", onMsg);
            resolve(e.data);
          }
        };
        window.addEventListener("message", onMsg);
        window.postMessage({ source: "fai-of", action: "setText", text: String(text || "") }, "*");
        setTimeout(() => {
          window.removeEventListener("message", onMsg);
          resolve({ ok: false, err: "timeout" });
        }, 3e3);
      });
    },
    // Возвращает тот же статус-контракт, что humanTypeAndSend: 'sent' | 'unconfirmed' | 'no-field'
    // (вызывающий по нему решает, писать ли в ТГ «✅ отправлено»).
    async setAndSend(text) {
      state.suppressUntil = Date.now() + 2500;
      const r = await ONLYFANS._bridgeSetText(text);
      if (!r.ok) {
        setStatus(t("panel.status.noInputField", state.uiLang));
        console.warn("[FanslyAI] OF: \u0432\u0432\u043E\u0434 \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F:", r.err);
        return "no-field";
      }
      const btn = document.querySelector(ONLYFANS.SEL.sendBtn);
      if (!btn || btn.disabled) {
        setStatus(t("panel.status.noInputField", state.uiLang));
        return "no-field";
      }
      const own = () => document.querySelectorAll(".b-chat__message.m-from-me").length;
      const before = own();
      btn.click();
      clearSuggestions();
      const appeared = await new Promise((res) => {
        let n = 0;
        const iv = setInterval(() => {
          if (own() > before) {
            clearInterval(iv);
            res(true);
          } else if (++n > 24) {
            clearInterval(iv);
            res(false);
          }
        }, 500);
      });
      if (!appeared) console.warn("[FanslyAI] OF: \u0441\u0432\u043E\u0451 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B\u043E\u0441\u044C \u0437\u0430 12\u0441 (\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E, \u0432\u0441\u0451 \u0436\u0435 \u0443\u0448\u043B\u043E)");
      setStatus(t("panel.status.sent", state.uiLang));
      setTimeout(() => setStatus(""), 2e3);
      return appeared ? "sent" : "unconfirmed";
    }
  };
  const PLAT = (
    /*@of-start@*/
    PLATFORM === "onlyfans" ? ONLYFANS : (
      /*@of-end@*/
      FANSLY
    )
  );
  const { hashString, parseFanslyTs, bodyMediaEl, bodyMediaId, detectMediaType, detectMediaLocked, detectPaidState, cleanContactName } = Parsers;
  Parsers.init({ sel: { q, qa, qm, selStr }, plat: PLAT });
  const { keyOfCurrent, contactDataIsCurrent, defaultContact, loadContact, saveContact, pinnedOf, isPinned, applyScanMarks, keepPinnedOnly } = ContactStore;
  const { collapseKey, getUnreadCount, parseMsgTime, rowActivityTs, rowActivityFull, rowSnapshot, readEnvelopeUnread, subText, subCardParse, parseEarningsRow, broadcastParseCard, notifParse, parseMoney, scrapeCreatorStats, scrapeTiers } = ScanParsers;
  ScanParsers.init({ sel: { q, qa, qm, selStr }, plat: PLAT, cleanContactName });
  const { applyDossierUpdate, savePatchTo, applyBrief, mergeAnalysisIntoContact, readContactRecord, loadExcludedIds, loadExcludedContacts, setContactExcludedById } = ContactStore;
  const CONFIG = {
    SELECTORS: PLAT.SEL,
    // источник истины — адаптер (ключи messageContent/messageText/textarea/contactHeader сохранены)
    POS_KEY: "fansly_ai_panel_pos",
    CONTACT_DELAY: 800,
    MAX_TRANSLATE: 3
  };
  let _initialized = false;
  const state = {
    currentContact: null,
    // display name (для UI)
    currentContactId: null,
    // числовой ID из URL — стабильный ключ хранилища
    fanGender: "male",
    contactData: null,
    lastIncomingText: null,
    chatHistory: [],
    observer: null,
    active: false,
    processedNodes: /* @__PURE__ */ new WeakSet(),
    translateQueue: [],
    translateRunning: 0,
    contactTimer: null,
    suppressUntil: 0,
    uiLang: "ru",
    // язык UI расширения (interfaceLanguage) — НЕ путать с nativeLang ниже
    nativeLang: "ru",
    maxWords: 0,
    customIntents: [],
    // пользовательские интенты из настроек
    briefShowOriginal: false,
    // бриф: false = перевод на язык настроек, true = оригинал
    briefCollapsed: true,
    // бриф свёрнут по умолчанию (не забивает обзор)
    typingNow: false,
    // идёт человекоподобная печать (защита от обрезков)
    lastIncomingReply: null,
    // {text, author, isMine} — цитата последнего входящего (#2)
    forceProvider: "auto",
    // ручной override провайдера генерации: auto (каскад) | openrouter | gemini | groq | claude
    _incomingDebounce: null,
    // дебаунс генерации на входящее (защита от лавины)
    activatedAt: 0,
    // момент активации
    historyScrolling: false,
    // true пока пользователь скроллит историю вверх
    _scrollTimer: null,
    transCache: /* @__PURE__ */ new Map(),
    // text → перевод (в памяти сессии): без мигания и повторных запросов
    tiers: [],
    // тарифы {name, price, color}, снятые со страницы /posts (fansly_tiers) — замена ручного маппинга
    selOverrides: null
    // удалённый оверрайд селекторов (fansly_sel_overrides[PLATFORM]) — приоритет над PLAT.SEL
  };
  ContactStore.init({ state, hashString, send: sendSafe, renderDossier });
  ContactStore.initFull({ renderBrief });
  function waitForElement(selector, timeout = 3e4) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      const obs = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) {
          obs.disconnect();
          resolve(found);
        }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => {
        obs.disconnect();
        reject(new Error(`Timeout: ${selector}`));
      }, timeout);
    });
  }
  function selList(key) {
    const ov = state.selOverrides && state.selOverrides[key];
    const v = ov != null ? ov : PLAT.SEL[key];
    return Array.isArray(v) ? v.filter(Boolean) : v ? [v] : [];
  }
  function selStr(key) {
    return selList(key).join(", ");
  }
  function selJoin(...keys) {
    return keys.map(selStr).filter(Boolean).join(", ");
  }
  function q(key, root) {
    for (const s of selList(key)) {
      try {
        const el = (root || document).querySelector(s);
        if (el) return el;
      } catch (e) {
      }
    }
    return null;
  }
  function qa(key, root) {
    for (const s of selList(key)) {
      try {
        const els = (root || document).querySelectorAll(s);
        if (els.length) return els;
      } catch (e) {
      }
    }
    return document.querySelectorAll("[data-fai-never]");
  }
  function qm(key, el) {
    if (!el) return false;
    for (const s of selList(key)) {
      try {
        if (el.matches(s)) return true;
      } catch (e) {
      }
    }
    return false;
  }
  function sanitizeSelOverrides(raw) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    const out = {};
    let n = 0;
    for (const key of Object.keys(raw)) {
      if (!Object.prototype.hasOwnProperty.call(PLAT.SEL, key)) continue;
      const list = (Array.isArray(raw[key]) ? raw[key] : [raw[key]]).filter((s) => typeof s === "string" && s.trim() && s.length <= 200).slice(0, 8);
      if (!list.length) continue;
      out[key] = list;
      n++;
    }
    return n ? out : null;
  }
  function loadSelOverrides() {
    try {
      chrome.storage.local.get("fansly_sel_overrides", (d) => {
        const o = d && d.fansly_sel_overrides;
        state.selOverrides = sanitizeSelOverrides(o && o[PLATFORM]);
      });
    } catch (e) {
    }
  }
  loadSelOverrides();
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "local" && ch.fansly_sel_overrides) loadSelOverrides();
    });
  } catch (e) {
  }
  window.__faiSel = function() {
    const SCAN = /* @__PURE__ */ new Set([
      "subCard",
      "earnRoot",
      "earnRow",
      "broadcastCard",
      "postCard",
      "notifRow",
      "vaultTile",
      "vaultReady",
      "earnMedia",
      "moreOverlay",
      "notifTime",
      "notifUser",
      "notifAmount",
      "notifMedia",
      "notifFilterBox",
      "notifFilterItem",
      "notifFilterCheck",
      "notifFilterOn",
      "notifFilterTitle",
      "broadcastTab",
      "broadcastStat",
      "broadcastReach",
      "broadcastOpen",
      "broadcastSale",
      "broadcastTooltip",
      "broadcastAmount",
      "broadcastAmountBox",
      "broadcastTime",
      "broadcastText",
      "postMedia",
      "postMediaNest",
      "postMediaBox",
      "postMediaLike",
      "postStatsBox",
      "postLikes",
      "postComments",
      "postBundleMore",
      "postBundleOverlay",
      "postGalleryItem",
      "postGalleryMedia",
      "postProfileGallery",
      "postModalClose",
      "postWallBubble",
      "postTime",
      "postText",
      "postTag",
      "tierBox",
      "tierName",
      "tierPlan",
      "tierPrice",
      "vaultThumbImg",
      "vaultPlayBtn",
      "vaultVideoEl",
      "vaultAlbum",
      "vaultAlbumName",
      "vaultAlbumCount",
      "vaultAlbumMedia",
      "vaultMenu",
      "vaultBubble",
      "vaultBubbleTop",
      "vaultBubbleActive",
      "vaultMore",
      "vaultMoreToggle",
      "vaultMoreItem",
      "vaultFolderName",
      "vaultPlayTime",
      "vaultProgress",
      "vaultFileName",
      "vaultFileDate",
      "vaultAudioMark",
      "vaultVideoMark",
      "vaultMediaNest",
      "vaultPreviewPoster",
      "vaultModalClose",
      "vaultScroller",
      "vaultSearchIcon",
      "vaultSearchInput",
      "vaultPickerModal",
      "vaultPickerSearch",
      "vaultPickerInput",
      "vaultPickMenuItem",
      "vaultPickIcon",
      "vaultPickUploadIcon",
      "earnTxBuyer",
      "earnTxOut",
      "earnTxSign",
      "earnTxId",
      "earnTxAmount",
      "earnTxStatus",
      "earnTxBuyerLink",
      "earnTxDate",
      "earnCell",
      "earnCellBuyer",
      "earnCellBuyerLink",
      "earnAmount",
      "earnBuyerLink",
      "earnBuyerName",
      "pagerItem",
      "pagerNextIcon",
      "pagerSelected",
      "earnPager",
      "subsPager",
      "subsSearch",
      "subsTabsWrap",
      "subsTab",
      "subUserLink",
      "subUserName",
      "subStarIcon",
      "subStar",
      "subStarOverlay",
      "subDetails",
      "subTier",
      "subDetailValue",
      "subDateBox",
      "subDateValue",
      "subStatus",
      "subPrice"
    ]);
    const PRED = /* @__PURE__ */ new Set([
      "mediaPreview",
      "notifMediaOrder",
      "notifSubPay",
      "notifSubExpire",
      "notifTipRow",
      "notifLikeRow",
      "notifFollowRow",
      "postAvatar",
      "postWallActive",
      "vaultCoverMedia",
      "vaultAvatar",
      "vaultItemActive",
      "vaultPickUploadNew",
      "earnTxRow",
      "pagerOff",
      "subsTabOn",
      "subPriceRow",
      "subStatusOk"
    ]);
    const NUM = /* @__PURE__ */ new Set(["notifFilterWant", "notifFilterCount"]);
    const REL = { vaultBubbleTop: "vaultMenu", vaultMoreToggle: "vaultMore", earnCell: "earnRow" };
    const rows = Object.keys(PLAT.SEL).map((k) => {
      if (NUM.has(k)) return { \u043A\u043B\u044E\u0447: k, \u0442\u0438\u043F: "\u0447\u0438\u0441\u043B\u043E", \u043D\u0430\u0439\u0434\u0435\u043D\u043E: "\u2014", \u0441\u0440\u0430\u0431\u043E\u0442\u0430\u043B_\u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442: selStr(k) || "\u2014", \u043E\u0432\u0435\u0440\u0440\u0430\u0439\u0434: !!(state.selOverrides && state.selOverrides[k] != null) };
      let used = "\u2014", n = 0;
      const roots = REL[k] ? [...qa(REL[k])] : [document];
      for (const s of selList(k)) {
        try {
          const c = roots.reduce((m, r) => m + r.querySelectorAll(s).length, 0);
          if (c) {
            used = s;
            n = c;
            break;
          }
        } catch (e) {
          used = "\u041E\u0428\u0418\u0411\u041A\u0410: " + s;
        }
      }
      return { \u043A\u043B\u044E\u0447: k, \u0442\u0438\u043F: PRED.has(k) ? "\u043F\u0440\u0438\u0437\u043D\u0430\u043A" : REL[k] ? "\u0441\u043A\u0430\u043D \u0432 " + REL[k] : SCAN.has(k) ? "\u0441\u043A\u0430\u043D" : "\u0447\u0430\u0442", \u043D\u0430\u0439\u0434\u0435\u043D\u043E: n, \u0441\u0440\u0430\u0431\u043E\u0442\u0430\u043B_\u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442: used, \u043E\u0432\u0435\u0440\u0440\u0430\u0439\u0434: !!(state.selOverrides && state.selOverrides[k] != null) };
    });
    console.table(rows);
    console.log(
      "[FanslyAI] \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440\u044B | \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430:",
      location.pathname,
      "| \u0443\u0434\u0430\u043B\u0451\u043D\u043D\u044B\u0439 \u043E\u0432\u0435\u0440\u0440\u0430\u0439\u0434 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D:",
      !!(state.selOverrides && Object.keys(state.selOverrides).length),
      "| \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430: \u044F\u043A\u043E\u0440\u044F \xAB\u0441\u043A\u0430\u043D\xBB \u043D\u0435\u043D\u0443\u043B\u0435\u0432\u044B\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u0441\u0432\u043E\u0435\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0441\u043A\u0430\u043D\u0435\u0440\u0430"
    );
    return rows;
  };
  function timeStr(ts) {
    const d = new Date(ts), now = /* @__PURE__ */ new Date();
    const lang = state.uiLang || "ru";
    const time = d.toLocaleTimeString(lang, { hour: "2-digit", minute: "2-digit" });
    if (d.toDateString() === now.toDateString()) return time;
    const opts = { day: "2-digit", month: "short" };
    if (d.getFullYear() !== now.getFullYear()) opts.year = "numeric";
    return `${d.toLocaleDateString(lang, opts)}, ${time}`;
  }
  function getMessageText(node) {
    const allTexts = qa("messageText", node);
    for (const el of allTexts) {
      if (!el.closest(selStr("quote"))) {
        return el.innerText?.trim() || "";
      }
    }
    return "";
  }
  function extractReply(node) {
    const replyEl = q("quote", node);
    if (!replyEl) return null;
    const qText = q("messageText", replyEl)?.innerText?.trim() || "";
    const qHasMedia = [...qa("media", replyEl)].some((el) => !el.closest("app-account-avatar"));
    const mediaType = qHasMedia ? detectMediaType(replyEl, { includeReply: true }) : null;
    if (!qText && !mediaType) return null;
    const author = q("displayName", replyEl)?.innerText?.trim() || "";
    const isMine = PLAT.isOwn(replyEl);
    return { text: qText, author, isMine, mediaType };
  }
  function extractContactIdFromUrl() {
    return PLAT.contactId();
  }
  const FANSLY_SYSTEM_PATHS = /* @__PURE__ */ new Set([
    "messages",
    "home",
    "explore",
    "search",
    "notifications",
    "settings",
    "live",
    "lists",
    "wallet",
    "help",
    "account",
    "post",
    "posts",
    "media",
    "suggestions",
    "subscriptions",
    "collections",
    "following",
    "followers",
    "chat",
    "feed",
    "timeline"
  ]);
  function extractProfileHandle() {
    const candidates = [];
    const header = q("contactHeader")?.closest("*");
    const scopes = [
      q("headerWrap"),
      q("contactHeader")?.parentElement,
      header
    ].filter(Boolean);
    for (const scope of scopes) {
      scope.querySelectorAll('a[href^="/"]').forEach((a) => {
        const href = a.getAttribute("href") || "";
        const seg = href.replace(/^\/+/, "").split(/[/?#]/)[0].toLowerCase();
        if (seg && !FANSLY_SYSTEM_PATHS.has(seg) && /^[a-z0-9_.]+$/.test(seg)) {
          candidates.push(seg);
        }
      });
    }
    const handle = candidates[0] || null;
    console.log("[FanslyAI] Profile handle candidates:", candidates, "\u2192 picked:", handle);
    return handle;
  }
  function chatNameFrom(scope) {
    const nameEl = scope ? q("displayName", scope) : null;
    let name = cleanContactName(nameEl ? nameEl.textContent : scope && scope.innerText || "");
    const unresolved = /^unknown/i.test(name);
    if (/…|\.\.\./.test(name) || unresolved) {
      const handle = (q("usernameLink", scope)?.getAttribute("href") || "").replace(/^\//, "").trim();
      if (handle) name = handle;
    }
    return { name: name || null, unresolved };
  }
  function healthyName(n) {
    return !!n && !/^unknown/i.test(n) && !/…|\.\.\./.test(n);
  }
  function headerIdentity(id) {
    if (PLATFORM === "onlyfans") return { handle: extractProfileHandle(), name: null, trusted: true };
    const linkHandle = (a) => (a && a.getAttribute("href") || "").replace(/^\/+/, "").split(/[/?#]/)[0].trim().toLowerCase() || null;
    let row = null;
    if (id) {
      for (const a of qa("contactLink")) if (PLAT.contactIdFromHref(a.getAttribute("href")) === String(id)) {
        row = a;
        break;
      }
    }
    const rowHandle = row ? linkHandle(q("usernameLink", row)) : null;
    const rowName = row ? chatNameFrom(row).name : null;
    const heads = document.querySelectorAll(selStr("contactHeader"));
    const head = heads.length === 1 ? heads[0] : null;
    const headHandle = head ? linkHandle(q("usernameLink", head)) : null;
    const headName = head ? chatNameFrom(head).name : null;
    if (rowHandle) {
      const agree = headHandle === rowHandle;
      if (heads.length && !agree) console.log("[FanslyAI] \u0448\u0430\u043F\u043A\u0430 \u0447\u0430\u0442\u0430 \u043D\u0435 \u043E\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430 (" + (headHandle || heads.length + " \u0448\u0430\u043F\u043A\u0438") + " \u2260 " + rowHandle + ") \u2014 \u043D\u0438\u043A \u0438 \u0438\u043C\u044F \u0431\u0435\u0440\u0443 \u0438\u0437 \u0441\u0442\u0440\u043E\u043A\u0438 \u0441\u043F\u0438\u0441\u043A\u0430 (#180)");
      return { handle: rowHandle, name: agree && headName ? headName : rowName, trusted: true };
    }
    if (head && headHandle && (!rowName || headName === rowName)) return { handle: headHandle, name: headName, trusted: true };
    if (heads.length > 1) console.log("[FanslyAI] \u0432 DOM " + heads.length + " \u0448\u0430\u043F\u043A\u0438 \u0447\u0430\u0442\u0430, \u0441\u0442\u0440\u043E\u043A\u0438 \u0441 id " + id + " \u043D\u0435\u0442 \u2014 \u043D\u0438\u043A \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u044E (#180)");
    return { handle: null, name: null, trusted: false };
  }
  function getRecentOwnReplies(n = 3) {
    return state.chatHistory.filter((m) => m.role === "model" && !m.isMedia && m.text).slice(-n).map((m) => m.text);
  }
  function computeGap(lastTs) {
    if (!lastTs) return null;
    const hours = (Date.now() - lastTs) / 36e5;
    if (hours < 5) return null;
    const isNewDay = new Date(lastTs).toDateString() !== (/* @__PURE__ */ new Date()).toDateString();
    return `${Math.round(hours)}h${isNewDay ? ", new day" : ""}`;
  }
  const PINNED_MAX = 15;
  function clearBrief() {
    if (!state.contactData) return;
    state.contactData.brief = null;
    saveContact(state.currentContact, { brief: null });
    renderBrief();
  }
  function renderBrief() {
    const wrap = document.getElementById("fai-brief");
    if (!wrap) return;
    const b = state.contactData?.brief;
    if (!b || state.contactData?.unknownConfirmed || !(b.wants || b.details?.length || b.mood || b.refs?.length)) {
      wrap.style.display = "none";
      return;
    }
    wrap.style.display = "block";
    const body = document.getElementById("fai-brief-body");
    if (!body) return;
    body.innerHTML = "";
    const showOriginal = state.briefShowOriginal;
    const rows = [
      [t("common.brief.wants", state.uiLang), b.wants],
      [t("common.brief.mood", state.uiLang), b.mood],
      [t("common.brief.details", state.uiLang), b.details?.length ? b.details.join(", ") : ""],
      [t("common.brief.refs", state.uiLang), b.refs?.length ? b.refs.join(", ") : ""]
    ];
    rows.forEach(([label, value]) => {
      if (!value) return;
      const row = document.createElement("div");
      row.className = "fai-brief-row";
      row.innerHTML = `<b>${label}:</b> <span class="bv">${escapeHtmlC(value)}</span>`;
      body.appendChild(row);
      if (!showOriginal) {
        const span = row.querySelector(".bv");
        span.textContent = "\u23F3";
        enqueueTranslate(value, state.nativeLang, (res) => {
          span.textContent = res || value;
        }, inGenders());
      }
    });
    applyBriefCollapsed();
    updateAboutSummary();
  }
  function applyBriefCollapsed() {
    const body = document.getElementById("fai-brief-body");
    const tog = document.getElementById("fai-brief-toggle");
    if (body) body.style.display = state.briefCollapsed ? "none" : "block";
    if (tog) tog.textContent = state.briefCollapsed ? "\u25BE" : "\u25B4";
  }
  function collectHistoryFromDom() {
    const out = [];
    let curTs = null;
    const roots = qa("messageContent");
    if (roots.length !== 1) {
      if (roots.length > 1) console.log("[FanslyAI] \u{1F9EC} collectHistoryFromDom: \u043B\u0435\u043D\u0442 \u0432 DOM " + roots.length + " (\u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u043C\u0435\u0436\u0434\u0443 \u0447\u0430\u0442\u0430\u043C\u0438) \u2014 \u0441\u0431\u043E\u0440 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D");
      return out;
    }
    const sel = selJoin("messageNode", "messageTimestamp");
    if (!sel) return out;
    roots[0].querySelectorAll(sel).forEach((el) => {
      if (qm("messageTimestamp", el)) {
        if (!el.closest(selStr("messageNode"))) {
          const t2 = parseFanslyTs(el.textContent);
          if (t2) curTs = t2;
        }
        return;
      }
      const isOwn = PLAT.isOwn(el);
      const hasMedia = bodyMediaEl(el);
      const text = getMessageText(el);
      if (!text && !hasMedia) return;
      out.push({
        role: isOwn ? "model" : "subscriber",
        text: text || "",
        isMedia: !!hasMedia && !text,
        ts: curTs
        // реальная дата сообщения (carry-forward по .timestamp)
      });
    });
    return out;
  }
  const DELTA_MIN_MSGS = 1;
  const DELTA_CONTEXT = 8;
  function humanError(err) {
    const raw = String(err || "").trim();
    const l = raw.toLowerCase();
    const k = (key, hintKey) => ({ text: t(key, state.uiLang), hint: hintKey ? t(hintKey, state.uiLang) : "" });
    if (!raw) return k("panel.err.h.unknown");
    if (/no provider|no llm provider|нет провайдера|no api key|missing key/.test(l)) return k("panel.err.h.noProvider", "panel.err.h.openSettings");
    if (/unauthorized|forbidden|\b401\b|\b403\b|invalid api key|api key not valid|licen/.test(l)) return k("panel.err.h.badKey", "panel.err.h.openSettings");
    if (/\bbusy\b|upstream_busy|занят|перегруж/.test(l)) return k("panel.err.h.busy");
    if (/quota|\b429\b|too many requests|rate limit|исчерпан/.test(l)) return k("panel.err.h.quota");
    if (/timeout|timed out|abort|network|failed to fetch|\b50[234]\b|нет ответа/.test(l)) return k("panel.err.h.network");
    if (/block|safety|content_filter|refus|censor|отказал/.test(l)) return k("panel.err.h.blocked", "panel.err.h.rephrase");
    if (/ничего не извлечено|nothing extracted|nichts extrahiert|no se extrajo|rien n/.test(l)) return k("panel.err.h.nothingExtracted");
    return { text: t("panel.err.h.generic", state.uiLang, { err: raw.slice(0, 60) }), hint: "" };
  }
  function humanErrorLine(err) {
    const h = humanError(err);
    return h.text + (h.hint ? " \xB7 " + h.hint : "");
  }
  function aiStopLine(r) {
    if (r?.subscriptionExpired) return t("panel.status.subscriptionExpired", state.uiLang);
    if (r?.quotaExhausted) return t("panel.status.quotaExhausted", state.uiLang);
    return "";
  }
  function markNeedsFullScan(on) {
    const btn = document.getElementById("fai-analyze-btn");
    if (!btn || btn.disabled) return;
    btn.textContent = on ? "\u{1F50D}\u2757" : "\u{1F50D}";
    btn.title = t(on ? "panel.dossier.needFull.title" : "panel.dossier.analyze.title", state.uiLang);
    if (!on) {
      state._needFullFor = null;
      return;
    }
    if (state._needFullFor === state.currentContact) return;
    state._needFullFor = state.currentContact;
    setStatus(t("panel.status.needFull", state.uiLang));
    setTimeout(() => setStatus(""), 9e3);
  }
  function triggerHistoryAnalysis(manual = false) {
    if (!state.active || !state.currentContact) return;
    if (!manual && state.collectDossier === false) return;
    if (!manual && state.suppressUntil && Date.now() < state.suppressUntil) {
      clearTimeout(state._dossierDeltaTimer);
      state._dossierDeltaTimer = setTimeout(() => {
        if (state.active && state.currentContact) triggerHistoryAnalysis(false);
      }, state.suppressUntil - Date.now() + 800);
      return;
    }
    const liveId = extractContactIdFromUrl();
    if (liveId && state.currentContactId && liveId !== state.currentContactId) {
      console.log("[FanslyAI] \u{1F9EC} \u0430\u043D\u0430\u043B\u0438\u0437 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D: URL \u0443\u0436\u0435 " + liveId + ", state \u0435\u0449\u0451 " + state.currentContactId + " (\u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0447\u0430\u0442\u0430; \u0434\u0435\u043B\u044C\u0442\u0430 \u043D\u0435 \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u0430 \u2014 \u043F\u043E\u0434\u0445\u0432\u0430\u0442\u0438\u0442\u0441\u044F \u043F\u0440\u0438 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u043C \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0438)");
      return;
    }
    markNeedsFullScan(false);
    const history = collectHistoryFromDom();
    const textMsgs = history.filter((m) => m.text && !m.isMedia);
    if (!manual && textMsgs.length < 5) return;
    const d0 = state.contactData?.dossier;
    const upTo = manual ? null : d0?.analyzedUpTo || null;
    if (!manual && !upTo && d0?.facts?.length && !d0?.partialScan) {
      const maxTs = history.reduce((mx, m) => m.ts && m.ts > mx ? m.ts : mx, 0);
      if (maxTs) applyDossierUpdate({ analyzedUpTo: maxTs });
      return;
    }
    let sendHistory = history, contextTail = [], mode = "full";
    if (upTo) {
      const oldestTs = history.reduce((mn, m) => m.ts && (mn == null || m.ts < mn) ? m.ts : mn, null);
      if (oldestTs != null && oldestTs > upTo) {
        markNeedsFullScan(true);
        return;
      }
      const fresh = history.filter((m) => m.ts && m.ts > upTo);
      const freshText = fresh.filter((m) => m.text && !m.isMedia && m.role === "subscriber");
      if (freshText.length < (state.dossierDeltaMin || DELTA_MIN_MSGS)) return;
      const idx = history.findIndex((m) => m.ts && m.ts > upTo);
      contextTail = idx > 0 ? history.slice(Math.max(0, idx - DELTA_CONTEXT), idx) : [];
      sendHistory = fresh;
      mode = "delta";
    }
    const targetName = state.currentContact;
    const targetId = state.currentContactId;
    const btn = document.getElementById("fai-analyze-btn");
    if (btn) {
      btn.textContent = "\u23F3";
      btn.disabled = true;
    }
    setStatus(t("panel.status.analyzing", state.uiLang, { name: targetName }));
    sendSafe({
      type: "ANALYZE_HISTORY",
      history: sendHistory,
      fanName: targetName,
      mode,
      manual,
      // 🔍 = человек ждёт (прокси даёт такому вызову место в очереди), авто-дельта = фон
      contextTail,
      // Дельта — все известные факты: она ДОПИСЫВАЕТ, так что «не повторяй» безопасно.
      // Полная пересборка ЗАМЕНЯЕТ досье, поэтому просить пропустить всё известное и потом это известное
      // затереть — значит терять факты на каждом нажатии 🔍 (Alex 2026-09-01: было 11 → стало 18, прежние
      // 11 исчезли). Но ЗАКРЕПЛЁННЫЕ пересборку переживают — их слать и можно, и нужно, иначе модель
      // вернёт «его зовут Марк» своими словами рядом с закреплённым «зовут Марк», и в списке будут оба.
      // Шлём ровно то, что заведомо выживет.
      knownFacts: (mode === "delta" ? d0?.facts || [] : pinnedOf(d0)).slice(0, 60)
    }).then(async (r) => {
      if (btn) {
        btn.textContent = "\u{1F50D}";
        btn.disabled = false;
      }
      const sameContact = targetId != null ? state.currentContactId === targetId : state.currentContact === targetName;
      if (!(r?.success && r.result)) {
        if (r?.analyzedUpTo && state.collectDossier !== false) {
          if (sameContact) applyDossierUpdate({ analyzedUpTo: r.analyzedUpTo });
          else mergeAnalysisIntoContact(targetName, targetId, { analyzedUpTo: r.analyzedUpTo }, false);
        }
        if (sameContact) setStatus(
          aiStopLine(r) || (manual ? humanErrorLine(r?.error) : "")
        );
        setTimeout(() => setStatus(""), 6e3);
        return;
      }
      const n = r.result.facts?.length || 0;
      const hasBrief = r.result.brief && (r.result.brief.wants || r.result.brief.details?.length);
      if (sameContact) {
        if (state.collectDossier === false) {
          setStatus(t("panel.status.dossierOff", state.uiLang));
        } else {
          applyDossierUpdate(r.result, mode === "full" && !r.result.partial);
          if (r.result.brief) applyBrief(r.result.brief, null, manual);
          setStatus(t("panel.status.factsResult", state.uiLang, { n }) + (hasBrief ? t("panel.status.briefSuffix", state.uiLang) : ""));
        }
      } else {
        await mergeAnalysisIntoContact(targetName, targetId, r.result, mode === "full" && !r.result.partial);
        setStatus(t("panel.status.factsResultBg", state.uiLang, { name: targetName, n }));
      }
      setTimeout(() => setStatus(""), 4e3);
    });
  }
  function togglePin(fact) {
    const d = state.contactData?.dossier;
    if (!d || !fact) return;
    if (!d.manualFacts) d.manualFacts = [];
    const i = d.manualFacts.indexOf(fact);
    if (i >= 0) d.manualFacts.splice(i, 1);
    else {
      if (d.manualFacts.length >= PINNED_MAX) {
        setStatus(t("panel.dossier.pin.limit", state.uiLang, { n: PINNED_MAX }));
        setTimeout(() => setStatus(""), 5e3);
        return;
      }
      d.manualFacts.push(fact);
    }
    saveContact(state.currentContact, { dossier: d });
    renderDossier();
  }
  function deleteFact(idx) {
    if (!state.contactData?.dossier) return;
    const d = state.contactData.dossier;
    const removed = d.facts[idx];
    d.facts.splice(idx, 1);
    if (removed) {
      if (d.factDates) delete d.factDates[removed];
      if (d.manualFacts) d.manualFacts = d.manualFacts.filter((f) => f !== removed);
    }
    saveContact(state.currentContact, { dossier: d });
    renderDossier();
  }
  function relTime(ts) {
    if (!ts) return "";
    const diff = Date.now() - ts;
    if (diff < 0) return "";
    const day = 864e5;
    if (diff < day) return t("common.relTime.today", state.uiLang);
    const days = Math.floor(diff / day);
    if (days < 7) return t("common.relTime.days", state.uiLang, { n: days });
    if (days < 30) return t("common.relTime.weeks", state.uiLang, { n: Math.floor(days / 7) });
    if (days < 365) return t("common.relTime.months", state.uiLang, { n: Math.floor(days / 30) });
    return t("common.relTime.years", state.uiLang, { n: Math.floor(days / 365) });
  }
  function updateGenderBtn() {
    const b = document.getElementById("fai-fan-gender");
    if (!b) return;
    const female = (state.fanGender || "male") === "female";
    b.textContent = female ? "\u{1F469}" : "\u{1F468}";
    b.title = t("panel.btn.fanGender.state", state.uiLang, {
      gender: t(female ? "common.gender.female" : "common.gender.male", state.uiLang)
    });
  }
  function factsCountText(n) {
    if (state.uiLang === "ru" && typeof CRM !== "undefined" && CRM.plural) return CRM.plural(n, ["\u0444\u0430\u043A\u0442", "\u0444\u0430\u043A\u0442\u0430", "\u0444\u0430\u043A\u0442\u043E\u0432"]);
    return t("panel.dossier.factsCount", state.uiLang, { n });
  }
  function crmCurrent() {
    const h = state.contactData && state.contactData.handle;
    return h && state._crmHandle === h ? state._crm || null : null;
  }
  function aboutSummaryText() {
    const parts = [];
    const s = crmCurrent();
    const money = (n) => (+(+n).toFixed(2)).toString();
    if (s && s.spent > 0) parts.push("$" + money(s.spent));
    if (s && s.buyCount > 0) parts.push(t("crm.card.buys", state.uiLang, { n: s.buyCount }));
    if (s && s.activeSub && s.daysLeft != null) parts.push(t("crm.card.renews", state.uiLang, { n: s.daysLeft }));
    else if (s && s.expired) parts.push(t("crm.card.expired", state.uiLang));
    const b = state.contactData?.brief;
    if (b && b.collectedAt && (b.wants || b.details?.length)) {
      const days = Math.max(0, Math.floor((Date.now() - b.collectedAt) / 864e5));
      parts.push(t("panel.about.brief", state.uiLang, { n: days }));
    }
    const facts = state.contactData?.dossier?.facts?.length || 0;
    if (facts) parts.push(factsCountText(facts));
    return parts.join(" \xB7 ");
  }
  function updateAboutSummary() {
    const el = document.getElementById("fai-about-sum");
    if (!el) return;
    const txt = aboutSummaryText();
    el.textContent = txt;
    const head = document.getElementById("fai-about-head");
    if (head) head.title = txt ? "" : t("panel.about.empty", state.uiLang);
    applyAboutOpen();
  }
  function aboutIsOpen() {
    return !!(state._panelUi && state._panelUi.aboutOpen);
  }
  function applyAboutOpen() {
    const body = document.getElementById("fai-about-body");
    const caret = document.getElementById("fai-about-caret");
    if (body) body.style.display = aboutIsOpen() ? "block" : "none";
    if (caret) caret.textContent = aboutIsOpen() ? "\u25BE" : "\u25B8";
  }
  function aboutToggle() {
    const nv = !aboutIsOpen();
    state._panelUi = Object.assign({}, state._panelUi, { aboutOpen: nv });
    if (typeof panelUiSet === "function") panelUiSet({ aboutOpen: nv });
    applyAboutOpen();
  }
  function renderDossier() {
    const d = state.contactData?.dossier;
    const badgeEl = document.getElementById("fai-closeness-badge");
    const countEl = document.getElementById("fai-facts-count");
    const listEl = document.getElementById("fai-facts-list");
    if (!badgeEl) return;
    const closenessMap = {
      new: { icon: "\u{1F331}", key: "common.closeness.new" },
      interested: { icon: "\u{1F4AC}", key: "common.closeness.interested" },
      regular: { icon: "\u{1F525}", key: "common.closeness.regular" },
      supporter: { icon: "\u{1F48E}", key: "common.closeness.supporter" }
    };
    const cl = closenessMap[d?.closeness] || closenessMap.new;
    badgeEl.textContent = cl.icon;
    badgeEl.title = t(cl.key, state.uiLang);
    const facts = d?.facts || [];
    if (countEl) countEl.textContent = facts.length ? factsCountText(facts.length) : "";
    updateAboutSummary();
    if (listEl) {
      listEl.innerHTML = "";
      const fd = d.factDates || {};
      const ordered = facts.map((fact, idx) => ({ fact, idx, ts: fd[fact] || 0, pin: isPinned(d, fact) })).sort((a, b) => b.pin - a.pin || b.ts - a.ts);
      ordered.forEach(({ fact, idx, pin }) => {
        const item = document.createElement("div");
        item.className = "fai-fact-item" + (pin ? " fai-fact-pinned" : "");
        const pinBtn = document.createElement("button");
        pinBtn.className = "fai-fact-pin" + (pin ? " on" : "");
        pinBtn.textContent = "\u{1F4CC}";
        pinBtn.title = t(pin ? "panel.dossier.unpin.title" : "panel.dossier.pin.title", state.uiLang);
        pinBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          togglePin(fact);
        });
        const del = document.createElement("button");
        del.className = "fai-fact-delete";
        del.textContent = "\xD7";
        del.title = t("common.btn.delete", state.uiLang);
        del.addEventListener("click", (e) => {
          e.stopPropagation();
          deleteFact(idx);
        });
        const txt = document.createElement("span");
        txt.className = "fai-fact-text";
        txt.textContent = fact;
        txt.title = fact;
        const fg = inGenders();
        const cf = state.transCache.get(tcKey(fact, fg)) ?? state.transCache.get(tcKey(fact, null));
        if (cf != null) txt.textContent = cf;
        else enqueueTranslate(fact, state.nativeLang, (res, meta) => {
          if (res) {
            state.transCache.set(tcKey(fact, meta?.genderSafe !== false ? fg : null), res);
            txt.textContent = res;
          }
        }, fg);
        item.appendChild(pinBtn);
        item.appendChild(del);
        item.appendChild(txt);
        const ts = fd[fact];
        if (ts) {
          const age = document.createElement("span");
          age.className = "fai-fact-age";
          age.textContent = relTime(ts);
          age.title = new Date(ts).toLocaleString();
          age.style.cssText = "font-size:10px;color:#888;margin-left:6px;white-space:nowrap;flex-shrink:0";
          item.appendChild(age);
        }
        listEl.appendChild(item);
      });
    }
    renderCrm();
  }
  const CRM_EVT_MS = 7 * 864e5, CRM_EVT_MAX = 5;
  function recentLedgerEvents(handle, stores) {
    const evs = CRM.collectCI(stores.fansly_ledger || {}, handle, (handle || "").toLowerCase());
    const out = [];
    for (const e of evs) {
      if (!e.at || Date.now() - e.at >= CRM_EVT_MS) continue;
      const tags = (e.mediaId && stores.fansly_catalog && stores.fansly_catalog[e.mediaId] && stores.fansly_catalog[e.mediaId].autoTags || []).slice(0, 6);
      out.push({ type: e.type, amount: e.amount || null, tier: e.tier || "", mediaId: e.mediaId || null, tags, agoMs: Date.now() - e.at });
    }
    out.sort((x, y) => x.agoMs - y.agoMs);
    return out.slice(0, CRM_EVT_MAX);
  }
  function crmSummary(handle, stores, contact) {
    if (!CRM.hasCrmData(handle, stores)) return null;
    const f = CRM.computeFan(handle, contact && contact.name || handle, stores, contact || null, {});
    return {
      sub: f.sub,
      activeSub: f.activeSub,
      expired: f.expired,
      daysLeft: f.daysLeft,
      months: f.months,
      spent: f.spent,
      buyCount: f.buyCount,
      subCount: f.subCount,
      firstSubAt: f.firstSubAt,
      subSpent: f.subSpent,
      buySpent: f.buySpent,
      tipSpent: f.tipSpent,
      buysNoAmount: f.buysNoAmount,
      lastBuyAt: f.lastBuyAt,
      // Промпт совета читает crm.likes/crm.lastLikeAt плоскими; ядро берёт их из fansly_likes (todo #53).
      likes: f.likes || 0,
      lastLikeAt: f.lastLikeAt || 0,
      stage: f.stage,
      segments: [...f.segments || []],
      // ядро отдаёт Set (CRM-страница на этом фильтрует), наружу — массив
      recentEvents: recentLedgerEvents(handle, stores)
    };
  }
  async function crmSummaryFresh(contact) {
    const handle = contact && contact.handle;
    if (!handle) return null;
    const stores = await new Promise((r) => chrome.storage.local.get(CRM.STORE_KEYS, (d) => r(d || {})));
    stores.fansly_catalog = await recentMediaMeta(handle, stores.fansly_ledger || {});
    try {
      return crmSummary(handle, stores, contact);
    } catch (e) {
      console.warn("[FanslyAI] CRM: \u0440\u0430\u0441\u0447\u0451\u0442 \u0434\u043B\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430 \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F \u2014", e);
      return null;
    }
  }
  function crmChip(box, text, bg, tip) {
    const c = document.createElement("span");
    c.textContent = text;
    if (tip) c.title = tip;
    c.style.cssText = "font-size:10px;border-radius:10px;padding:2px 7px;background:" + (bg || "#23233c") + ";color:#d5d5e6;white-space:nowrap";
    box.appendChild(c);
  }
  function startPanelTour() {
    if (document.getElementById("fai-tour-dim")) return;
    if (state._pultActive) return;
    if (document.getElementById("fai-consent")) {
      state._tourTried = false;
      return;
    }
    const steps = [
      { sel: "#fai-header", key: "panel.tour.s1" },
      { sel: "#fai-coach-btn", key: "panel.tour.s3" },
      // ⚠️ Досье и CRM-портрет теперь внутри свёрнутой «справки о фане»: их узлы невидимы (offsetParent
      // === null) и шаг молча выпадал бы из тура. Подсвечиваем саму полосу справки.
      { sel: "#fai-about", key: "panel.tour.s4" },
      { sel: "#fai-about", key: "panel.tour.s5" },
      { sel: null, key: "panel.tour.s6" }
      // финал — по центру, без выреза
    ].filter((s) => !s.sel || (() => {
      const el = document.querySelector(s.sel);
      return el && el.offsetParent !== null;
    })());
    if (!steps.length) return;
    let i = 0;
    const dim = document.createElement("div");
    dim.id = "fai-tour-dim";
    dim.style.cssText = "position:fixed;inset:0;z-index:2147483645";
    const hole = document.createElement("div");
    hole.style.cssText = "position:absolute;border:2px solid #e91e8c;border-radius:10px;box-shadow:0 0 0 99999px rgba(8,8,16,.6);transition:all .25s";
    const bubble = document.createElement("div");
    bubble.style.cssText = 'position:absolute;width:min(300px,86vw);background:#12121f;border:1px solid #e91e8c;border-radius:12px;padding:12px 14px;color:#f0f0f0;font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.5)';
    const txt = document.createElement("div");
    txt.style.marginBottom = "10px";
    const rowB = document.createElement("div");
    rowB.style.cssText = "display:flex;align-items:center;gap:8px";
    const cnt = document.createElement("span");
    cnt.style.cssText = "font-size:11px;color:#8a8aa5;flex:1";
    const mkBtn = (css, txt2) => {
      const b = document.createElement("button");
      b.style.cssText = css;
      b.textContent = txt2;
      return b;
    };
    const bSkip = mkBtn("background:#1a1a2e;color:#9a9ab0;border:1px solid #2e2e50;border-radius:8px;padding:5px 10px;font-size:11px;cursor:pointer", t("panel.tour.skip", state.uiLang));
    const bNext = mkBtn("background:#e91e8c;color:#fff;border:none;border-radius:8px;padding:5px 14px;font-size:12px;font-weight:600;cursor:pointer", "");
    rowB.append(cnt, bSkip, bNext);
    bubble.append(txt, rowB);
    dim.append(hole, bubble);
    document.body.appendChild(dim);
    const finish = () => {
      dim.remove();
      panelUiSet({ tourDone: true });
    };
    bSkip.addEventListener("click", finish);
    bNext.addEventListener("click", () => {
      i++;
      if (i >= steps.length) finish();
      else show();
    });
    const show = () => {
      const s = steps[i];
      cnt.textContent = i + 1 + "/" + steps.length;
      txt.textContent = t(s.key, state.uiLang);
      bNext.textContent = t(i === steps.length - 1 ? "panel.tour.done" : "panel.tour.next", state.uiLang);
      const el = s.sel && document.querySelector(s.sel);
      if (el) {
        try {
          el.scrollIntoView({ block: "nearest" });
        } catch (e) {
        }
        const r = el.getBoundingClientRect();
        dim.style.background = "";
        hole.style.display = "";
        hole.style.left = r.left - 4 + "px";
        hole.style.top = r.top - 4 + "px";
        hole.style.width = r.width + 8 + "px";
        hole.style.height = r.height + 8 + "px";
        bubble.style.transform = "";
        const bw = Math.min(300, innerWidth * 0.86);
        bubble.style.left = Math.min(Math.max(8, r.left), innerWidth - bw - 8) + "px";
        bubble.style.top = r.bottom + 10 + "px";
        requestAnimationFrame(() => {
          const bh = bubble.offsetHeight;
          if (r.bottom + 10 + bh > innerHeight - 8) bubble.style.top = Math.max(8, r.top - bh - 10) + "px";
        });
      } else {
        hole.style.display = "none";
        dim.style.background = "rgba(8,8,16,.6)";
        bubble.style.left = "50%";
        bubble.style.top = "50%";
        bubble.style.transform = "translate(-50%,-50%)";
      }
    };
    show();
  }
  function showAnalyzeHint(onGo) {
    if (document.getElementById("fai-analyze-hint")) return;
    const dim = document.createElement("div");
    dim.id = "fai-analyze-hint";
    dim.style.cssText = "position:fixed;inset:0;background:rgba(8,8,16,.55);z-index:2147483645;display:flex;align-items:center;justify-content:center";
    const card = document.createElement("div");
    card.style.cssText = 'width:min(380px,90vw);background:#12121f;border:2px solid #e91e8c;border-radius:14px;padding:18px 20px;color:#f0f0f0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:13px;line-height:1.55';
    const mk = (tag, css, txt) => {
      const el = document.createElement(tag);
      el.style.cssText = css;
      if (txt != null) el.textContent = txt;
      return el;
    };
    card.appendChild(mk("div", "font-weight:700;font-size:14px;margin-bottom:8px", t("panel.hint.analyze.title", state.uiLang)));
    card.appendChild(mk("div", "color:#d6d6e6;margin-bottom:12px", t("panel.hint.analyze.text", state.uiLang)));
    const lbl = mk("label", "display:flex;align-items:center;gap:7px;font-size:12px;color:#9a9ab0;cursor:pointer;margin-bottom:14px");
    const cb = document.createElement("input");
    cb.type = "checkbox";
    lbl.append(cb, document.createTextNode(t("panel.hint.analyze.dontShow", state.uiLang)));
    card.appendChild(lbl);
    const rowB = mk("div", "display:flex;gap:8px;justify-content:flex-end");
    const bCancel = mk("button", "background:#1a1a2e;color:#cfcfe0;border:1px solid #2e2e50;border-radius:8px;padding:7px 14px;font-size:12px;cursor:pointer", t("panel.hint.analyze.cancel", state.uiLang));
    const bGo = mk("button", "background:#e91e8c;color:#fff;border:none;border-radius:8px;padding:7px 16px;font-size:12px;font-weight:600;cursor:pointer", t("panel.hint.analyze.go", state.uiLang));
    const close = () => {
      if (cb.checked) panelUiSet({ analyzeHintHidden: true });
      dim.remove();
    };
    bCancel.addEventListener("click", close);
    bGo.addEventListener("click", () => {
      close();
      onGo();
    });
    rowB.append(bCancel, bGo);
    card.appendChild(rowB);
    dim.appendChild(card);
    document.body.appendChild(dim);
  }
  function paintCrm(box, s) {
    const hasCard = !!state.contactData?.hasCard;
    if (!s && !hasCard) {
      box.style.display = "none";
      box.innerHTML = "";
      return;
    }
    box.style.display = "";
    box.innerHTML = "";
    const crmCollapsed = () => !!(state._panelUi && state._panelUi.crmCollapsed);
    const head = document.createElement("div");
    const paintHead = () => {
      head.textContent = t("panel.crm.label", state.uiLang) + " " + (crmCollapsed() ? "\u25B8" : "\u25BE");
    };
    paintHead();
    head.style.cssText = "font-size:10px;color:#8a8aa5;margin-bottom:4px;cursor:pointer;user-select:none";
    box.appendChild(head);
    const row = document.createElement("div");
    row.style.cssText = "display:flex;gap:5px;flex-wrap:wrap";
    if (crmCollapsed()) row.style.display = "none";
    head.addEventListener("click", () => {
      panelUiSet({ crmCollapsed: !crmCollapsed() });
      row.style.display = crmCollapsed() ? "none" : "flex";
      paintHead();
    });
    const money = (n) => (+(+n).toFixed(2)).toString();
    if (s) {
      if (s.spent > 0) {
        const tl = [t("crm.tip.spent", state.uiLang)];
        if (s.subSpent > 0) tl.push(t("crm.tip.spent.subs", state.uiLang, { n: money(s.subSpent) }));
        if (s.buySpent > 0) tl.push(t("crm.tip.spent.buys", state.uiLang, { n: money(s.buySpent) }));
        if (s.tipSpent > 0) tl.push(t("crm.tip.spent.tips", state.uiLang, { n: money(s.tipSpent) }));
        if (s.buysNoAmount > 0) tl.push(t("crm.tip.spent.unknown", state.uiLang, { n: s.buysNoAmount }));
        crmChip(row, t("crm.card.spent", state.uiLang, { n: money(s.spent) }), "rgba(76,175,80,.22)", tl.join("\n"));
      }
      if (s.buyCount > 0) crmChip(row, t("crm.card.buys", state.uiLang, { n: s.buyCount }), null, t("crm.tip.buys", state.uiLang));
      if (s.sub && s.sub.tierName) crmChip(row, "\u2B50 " + s.sub.tierName, "#2a2340", t("crm.tip.tier", state.uiLang));
      if (s.activeSub && s.sub && s.sub.price) crmChip(row, t("crm.card.perMonth", state.uiLang, { n: money(s.sub.price) }), null, t("crm.tip.perMonth", state.uiLang));
      if (s.activeSub && s.sub && s.sub.billingCycle) crmChip(row, t("crm.card.cycle", state.uiLang, { v: s.sub.billingCycle }), null, t("crm.tip.cycle", state.uiLang));
      if (s.activeSub && s.sub && s.sub.renewOn === true) crmChip(row, t("crm.card.renewOn", state.uiLang), "rgba(76,175,80,.14)", t("crm.tip.renewOn", state.uiLang));
      if (s.activeSub && s.sub && s.sub.renewOn === false) crmChip(row, t("crm.card.renewOff", state.uiLang), "rgba(233,30,140,.22)", t("crm.tip.renewOff", state.uiLang));
      if (s.activeSub && s.daysLeft != null) crmChip(row, t("crm.card.renews", state.uiLang, { n: s.daysLeft }), "rgba(255,152,0,.2)", t("crm.tip.renews", state.uiLang));
      if (s.expired) {
        const dt = (s.sub && s.sub.endDate || "").replace(/^[A-Za-z]+,\s*/, "");
        crmChip(row, t("crm.card.expired", state.uiLang) + (dt ? " " + dt : ""), "rgba(120,120,140,.2)", t("crm.tip.expired", state.uiLang));
      }
      if (s.months) crmChip(row, t("crm.card.months", state.uiLang, { n: s.months }), null, t("crm.tip.months", state.uiLang));
      if (s.firstSubAt) crmChip(row, t("crm.card.since", state.uiLang, { d: new Date(s.firstSubAt).toLocaleDateString(state.uiLang, { month: "short", year: "numeric" }) }), null, t("crm.tip.since", state.uiLang));
      if (s.subCount > 1) crmChip(row, t("crm.card.subcount", state.uiLang, { n: s.subCount }), null, t("crm.tip.subcount", state.uiLang));
      if (s.lastLikeAt) {
        const days = Math.floor((Date.now() - s.lastLikeAt) / 864e5);
        const txt = days <= 0 ? t("crm.card.lastLikeToday", state.uiLang) : t("crm.card.lastLike", state.uiLang, { n: days });
        crmChip(row, txt, days <= 30 && s.expired ? "rgba(255,152,0,.2)" : null, t("crm.tip.lastLike", state.uiLang));
      }
    }
    if (hasCard) crmChip(row, "\u{1F4B3}", "rgba(76,175,80,.14)", t("crm.tip.card", state.uiLang));
    box.appendChild(row);
    updateAboutSummary();
  }
  const CRM_RECENT_MS = 7 * 864e5, CRM_RECENT_MAX = 30;
  async function recentMediaMeta(handle, ledger) {
    const l = (handle || "").toLowerCase();
    let evs = ledger[handle] || ledger[l];
    if (!evs) {
      for (const k in ledger) if (k.toLowerCase() === l) {
        evs = ledger[k];
        break;
      }
    }
    const ids = [];
    for (const e of evs || []) {
      if (!e || !e.mediaId || !e.at || Date.now() - e.at >= CRM_RECENT_MS) continue;
      if (!ids.includes(e.mediaId)) ids.push(e.mediaId);
      if (ids.length >= CRM_RECENT_MAX) break;
    }
    if (!ids.length) return {};
    const r = await sendSafe({ type: "CATALOG_META_GET", ids });
    return r && r.success && r.items ? r.items : {};
  }
  async function renderCrm() {
    const box = document.getElementById("fai-crm");
    if (!box) return;
    const handle = state.contactData && state.contactData.handle;
    if (!handle) {
      box.style.display = "none";
      box.innerHTML = "";
      return;
    }
    if (state._crmHandle !== handle) {
      const stores = await new Promise((r) => chrome.storage.local.get(CRM.STORE_KEYS, (d) => r(d)));
      if (state.contactData?.handle !== handle) return;
      stores.fansly_catalog = await recentMediaMeta(handle, stores.fansly_ledger || {});
      if (state.contactData?.handle !== handle) return;
      try {
        state._crm = crmSummary(handle, stores, state.contactData || null);
      } catch (e) {
        state._crm = null;
        console.warn("[FanslyAI] CRM: \u0440\u0430\u0441\u0447\u0451\u0442 \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F \u2014", e);
      }
      state._crmSubsKnown = Object.keys(stores.fansly_subs || {}).length > 0;
      state._crmHandle = handle;
    }
    if (state._crm && state._crm.activeSub) {
      const _sb = document.getElementById("fai-subscribed");
      if (_sb) _sb.textContent = "\u2B50";
      if (state.contactData && !state.contactData.isSubscribed) {
        state.contactData.isSubscribed = true;
        if (state.currentContact) saveContact(state.currentContact, { isSubscribed: true });
      }
    } else if (state._crm && state._crm.sub && state._crm.sub.status === "expired" && state.contactData?.isSubscribed) {
      state.contactData.isSubscribed = false;
      if (state.currentContact) saveContact(state.currentContact, { isSubscribed: false });
      const _sb = document.getElementById("fai-subscribed");
      if (_sb) _sb.textContent = "\u2606";
    }
    clearFollowerStar();
    paintCrm(box, state._crm);
  }
  function clearFollowerStar() {
    const cd = state.contactData;
    if (!cd || !cd.isSubscribed || !cd.handle || !contactDataIsCurrent()) return;
    if (state._crmHandle !== cd.handle || !state._crmSubsKnown) return;
    const c = state._crm;
    if (c && (c.activeSub || c.sub || c.subCount || c.subSpent || c.firstSubAt)) return;
    const head = q("contactHeader");
    const ready = !!(head && (q("displayName", head)?.textContent || "").trim());
    if (!ready || head.querySelector("i.fa-star")) return;
    cd.isSubscribed = false;
    saveContact(state.currentContact, { isSubscribed: false });
    const sb = document.getElementById("fai-subscribed");
    if (sb) {
      sb.textContent = "\u2606";
      sb.title = t(subTitleKey(false), state.uiLang);
    }
    console.log("[FanslyAI] \u0437\u0432\u0435\u0437\u0434\u0430 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438 \u0441\u043D\u044F\u0442\u0430: \u0444\u043E\u043B\u043B\u043E\u0432\u0435\u0440 \u2014 \u0432 \u0441\u043A\u0430\u043D\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u043E\u0432 \u043D\u0435\u0442, \u043E\u043F\u043B\u0430\u0442 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438 \u043D\u0435\u0442 (#156)");
  }
  async function maybeSendCrmReminders() {
    const s = await getSettingsAsync();
    if (!s.telegramEnabled || !s.crmRemindersEnabled) return;
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const last = await new Promise((r) => chrome.storage.local.get("fansly_crm_reminder_day", (d) => r(d.fansly_crm_reminder_day)));
    if (last === today) return;
    await new Promise((r) => chrome.storage.local.set({ fansly_crm_reminder_day: today }, r));
    const items = (await sendSafe({ type: "TODAY_LIST", limit: 8 }))?.items || [];
    if (!items.length) return;
    const body = t("crm.remind.header", state.uiLang) + "\n" + items.map((x) => "\u2022 " + x.name + " \u2014 " + t("todo.reason." + x.kind, state.uiLang, x.data || {})).join("\n");
    sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "digest", text: body });
  }
  const ANALYSIS_WAIT_MIN_MS = 8e3, ANALYSIS_WAIT_MAX_MS = 9e4, ANALYSIS_POLL_MS = 2500;
  function scheduleAnalysisAfterTranslations() {
    clearTimeout(state._analysisWaitTimer);
    const startedAt = Date.now();
    const tick = () => {
      if (!state.active || !state.currentContact) return;
      const busy = state.translateRunning > 0 || state.translateQueue.length > 0;
      if (busy && Date.now() - startedAt < ANALYSIS_WAIT_MAX_MS) {
        state._analysisWaitTimer = setTimeout(tick, ANALYSIS_POLL_MS);
        return;
      }
      triggerHistoryAnalysis(false);
    };
    state._analysisWaitTimer = setTimeout(tick, ANALYSIS_WAIT_MIN_MS);
  }
  function enqueueTranslate(text, targetLang, onResult, g = null, ctx = null, fanLang = null) {
    if (!/[\p{L}\p{N}]/u.test(text || "")) {
      onResult(null, { genderSafe: true, retryAfterMs: 0 });
      return;
    }
    state.translateQueue.push({ text, targetLang, onResult, g, ctx, fanLang });
    if (!state._trFlushTimer) state._trFlushTimer = setTimeout(() => {
      state._trFlushTimer = null;
      processTranslateQueue();
    }, 60);
  }
  const _transPending = /* @__PURE__ */ new Map();
  function outGenders() {
    return { genderHint: state.creatorGender || "female", toGender: state.fanGender || "male" };
  }
  function inGenders() {
    return { genderHint: state.fanGender || "male", toGender: state.creatorGender || "female" };
  }
  function tcKey(text, g) {
    return `${g?.genderHint || ""}|${g?.toGender || ""}|${text}`;
  }
  const TR_CTX_MAX = 3, TR_CTX_LINE = 200, TR_CTX_CHARS = 600;
  function trContextLines(prev, role) {
    const lines = prev.filter((e) => e.text && !e.isMedia && e.text.trim()).slice(-TR_CTX_MAX).map((e) => ({ who: e.role === role ? "speaker" : "addressee", t: e.text.trim().slice(0, TR_CTX_LINE) }));
    while (lines.length && lines.reduce((n, l) => n + l.t.length, 0) > TR_CTX_CHARS) lines.shift();
    return lines.length ? lines : null;
  }
  function trContextFor(entry) {
    if (state.translateContext === false || !entry) return null;
    const idx = state.chatHistory.lastIndexOf(entry);
    return idx < 0 ? null : trContextLines(state.chatHistory.slice(0, idx), entry.role);
  }
  function trContextOut(chatId = null) {
    if (state.translateContext === false) return null;
    if (chatId && state.currentContactId !== chatId) return null;
    ensureHistoryForCurrent();
    return trContextLines(state.chatHistory || [], "model");
  }
  function trEntryOf(text, isOwn) {
    const role = isOwn ? "model" : "subscriber";
    for (let i = state.chatHistory.length - 1; i >= 0; i--) {
      const e = state.chatHistory[i];
      if (e.role === role && e.text === text) return e;
    }
    return null;
  }
  const TR_CTX_NOCACHE = 20;
  const _trCtxShort = /* @__PURE__ */ new Set();
  let _trCtxChat = "";
  function trChatNow() {
    return String(state.currentContactId || state.currentContact || "");
  }
  function trCtxShort(text, ctx) {
    return !!ctx && String(text).trim().length < TR_CTX_NOCACHE;
  }
  function trCtxChatSync() {
    const chat = trChatNow();
    if (chat === _trCtxChat) return;
    for (const k of _trCtxShort) state.transCache.delete(k);
    _trCtxShort.clear();
    _trCtxChat = chat;
  }
  function translateForOwner(text, g = null, ctx = null) {
    if (!text) return Promise.resolve(null);
    if (state.translatorEnabled === false) return Promise.resolve(null);
    trCtxChatSync();
    const short = trCtxShort(text, ctx), chat = trChatNow();
    const ck = tcKey(text, g);
    const ckPlain = tcKey(text, null);
    const pk = short ? ck + "ctx" : ck;
    const cached = state.transCache.get(ck);
    if (cached != null && (!short || _trCtxShort.has(ck))) return Promise.resolve(cached);
    const plain = state.transCache.get(ckPlain);
    if (plain != null && Date.now() < (state._genderlessUntil || 0)) return Promise.resolve(plain);
    if (_transPending.has(pk)) return _transPending.get(pk);
    const fanLang = contactDataIsCurrent() && state.contactData ? state.contactData.lang || "en" : null;
    const p = new Promise((resolve) => {
      enqueueTranslate(text, state.nativeLang, (result, meta) => {
        if (result) {
          const key = meta?.genderSafe !== false ? ck : ckPlain;
          if (!short) {
            state.transCache.set(key, result);
            _trCtxShort.delete(key);
          } else if (trChatNow() === chat) {
            state.transCache.set(key, result);
            _trCtxShort.add(key);
          }
          if (meta?.genderSafe === false) state._genderlessUntil = Date.now() + (meta?.retryAfterMs || 6e4);
        }
        _transPending.delete(pk);
        resolve(result || (plain != null ? plain : null));
      }, g, ctx, fanLang);
    });
    _transPending.set(pk, p);
    return p;
  }
  function translateMsgForDisplay(text, msgEl, g = null, ctx = null) {
    if (!text || !msgEl) return;
    const div = msgEl.querySelector(".fai-msg-text");
    if (!div) return;
    div.dataset.orig = text;
    const mark = div.dataset.mediaMark ? div.dataset.mediaMark + " " : "";
    trCtxChatSync();
    const ck = tcKey(text, g);
    const cached = state.transCache.get(ck);
    if (cached != null && (!trCtxShort(text, ctx) || _trCtxShort.has(ck))) {
      div.textContent = mark + cached;
      return;
    }
    translateForOwner(text, g, ctx).then((r) => {
      if (r) div.textContent = mark + r;
    });
  }
  function retranslateHistory() {
    document.querySelectorAll("#fansly-ai-panel .fai-msg-text[data-orig]").forEach((div) => {
      const mark = div.dataset.mediaMark ? div.dataset.mediaMark + " " : "";
      const g = div.closest(".fai-msg")?.classList.contains("model") ? outGenders() : inGenders();
      translateForOwner(div.dataset.orig, g).then((r) => {
        if (r) div.textContent = mark + r;
      });
    });
  }
  const TR_BATCH_MAX = 12, TR_BATCH_CHARS = 6e3;
  function processTranslateQueue() {
    while (state.translateRunning < CONFIG.MAX_TRANSLATE && state.translateQueue.length > 0) {
      const head = state.translateQueue.find((it) => it.ctx) || state.translateQueue[0];
      const sameGroup = (it) => !!it.ctx === !!head.ctx && it.targetLang === head.targetLang && (it.g?.genderHint || "") === (head.g?.genderHint || "") && (it.g?.toGender || "") === (head.g?.toGender || "") && (it.fanLang || "") === (head.fanLang || "");
      const group = [];
      let chars = 0;
      for (let i = 0; i < state.translateQueue.length && group.length < TR_BATCH_MAX; ) {
        const it = state.translateQueue[i];
        if (!sameGroup(it) || group.length && chars + it.text.length > TR_BATCH_CHARS) {
          i++;
          continue;
        }
        chars += it.text.length;
        group.push(state.translateQueue.splice(i, 1)[0]);
      }
      if (!group.length) break;
      state.translateRunning++;
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        state.translateRunning--;
        processTranslateQueue();
      };
      const deliver = (item, one) => {
        try {
          item.onResult(one?.result ?? null, { genderSafe: one?.genderSafe !== false, retryAfterMs: one?.retryAfterMs || 0 });
        } catch (e) {
        }
      };
      const ask = (texts, cheapOnly) => sendSafe({
        type: "TRANSLATE_BATCH",
        texts,
        cheapOnly,
        targetLang: head.targetLang,
        genderHint: head.g?.genderHint || null,
        toGender: head.g?.toGender || null,
        ...head.ctx ? { ctx: head.ctx } : {},
        // в ОБОИХ заходах: с контекстом фон и дешёвый заход мимо постоянного кеша ведёт сам
        ...head.fanLang ? { fanLang: head.fanLang } : {}
      }).then((r) => r?.success && Array.isArray(r.results) ? r.results : null).catch(() => null);
      ask(group.map((x) => x.text), true).then((cheap) => {
        const rest = [];
        group.forEach((item, i) => {
          const one = cheap ? cheap[i] : null;
          if (one) deliver(item, one);
          else rest.push(item);
        });
        if (!rest.length) {
          finish();
          return;
        }
        return ask(rest.map((x) => x.text), false).then((out) => {
          rest.forEach((item, k) => deliver(item, out ? out[k] : null));
          finish();
        });
      }).catch(() => finish());
    }
  }
  function _tabId() {
    return state._tabId || (state._tabId = Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
  }
  let _hbPrevLabel = null;
  function faiHeartbeat() {
    if (!isExtensionAlive()) return;
    let label = "", navType = "";
    try {
      const row = q("contactLink");
      label = ((row && q("messageTime", row))?.textContent || "").trim();
    } catch (e) {
    }
    try {
      navType = performance.getEntriesByType("navigation")[0]?.type || "";
    } catch (e) {
    }
    const labelMoved = _hbPrevLabel != null && label !== _hbPrevLabel;
    _hbPrevLabel = label;
    const entry = {
      ts: Date.now(),
      carousel: !!carousel.running,
      poll: !!state._tgPollTimer,
      vis: document.visibilityState,
      focus: document.hasFocus(),
      ka: typeof _keepAliveCtx !== "undefined" && _keepAliveCtx ? _keepAliveCtx.state : "off",
      url: location.pathname,
      stepAgo: carousel._lastStepAt ? Math.round((Date.now() - carousel._lastStepAt) / 6e4) : null,
      navBusy: !!carousel.navBusy,
      label,
      labelMoved,
      wasDisc: document.wasDiscarded === true,
      navType,
      tab: _tabId()
    };
    hbTelemetry(entry);
    chrome.storage.local.get("fansly_ai_health", (d) => {
      const log = d.fansly_ai_health || [];
      log.push(entry);
      if (log.length > 200) log.splice(0, log.length - 200);
      chrome.storage.local.set({ fansly_ai_health: log });
    });
  }
  let _hbLastAt = 0, _hbStallSent = false, _hbDiscSent = false, _hbNoRedraw = 0;
  const HB_GAP_MS = 15 * 6e4;
  const HB_STALL_MS = 15 * 6e4;
  function hbTelemetry(e) {
    const now = e.ts, role = e.carousel ? "pult" : "tab";
    if (_hbLastAt && now - _hbLastAt > HB_GAP_MS) reportBug("pult_health", { code: "gap", ageMs: now - _hbLastAt, name: e.ka, src: role }, "note");
    _hbLastAt = now;
    _hbNoRedraw = e.labelMoved ? 0 : _hbNoRedraw + 1;
    const stallMs = e.carousel && carousel._lastStepAt ? now - carousel._lastStepAt : 0;
    if (stallMs > HB_STALL_MS) {
      if (!_hbStallSent) {
        _hbStallSent = true;
        reportBug("pult_health", { code: "stall", ageMs: stallMs, n: _hbNoRedraw }, "bug");
      }
    } else _hbStallSent = false;
    if (e.wasDisc && !_hbDiscSent && (e.carousel || state._carouselWanted)) {
      _hbDiscSent = true;
      reportBug("pult_health", { code: "discard", src: role }, "bug");
    }
  }
  window.__faiHealth = function() {
    chrome.storage.local.get("fansly_ai_health", (d) => {
      const log = d.fansly_ai_health || [];
      const prevBy = {}, short = (t2) => (t2 || "\u2014").slice(-4);
      const rows = log.map((e) => {
        const k = e.tab || "\u2014";
        const gap = prevBy[k] ? Math.round((e.ts - prevBy[k]) / 6e4) : 0;
        prevBy[k] = e.ts;
        return { \u0432\u0440\u0435\u043C\u044F: new Date(e.ts).toLocaleString(), \u043E\u043A\u043D\u043E: short(e.tab), \u043F\u0430\u0443\u0437\u0430_\u043C\u0438\u043D: gap, \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C: e.carousel, \u043E\u043F\u0440\u043E\u0441: e.poll, \u0432\u043A\u043B\u0430\u0434\u043A\u0430: e.vis, \u0444\u043E\u043A\u0443\u0441: e.focus, keepalive: e.ka, \u0448\u0430\u0433_\u043C\u0438\u043D: e.stepAgo, \u043C\u044C\u044E\u0442\u0435\u043A\u0441: e.navBusy, \u043C\u0435\u0442\u043A\u0430: e.label, \u043C\u0435\u0442\u043A\u0430_\u0448\u043B\u0430: e.labelMoved, \u0432\u044B\u0433\u0440\u0443\u0436\u0430\u043B\u0438: e.wasDisc, \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0430: e.navType };
      });
      console.table(rows);
      const tabs = [...new Set(log.map((e) => e.tab || "\u2014"))];
      const gaps = rows.filter((r) => r.\u043F\u0430\u0443\u0437\u0430_\u043C\u0438\u043D > 7);
      console.log(`[FanslyAI] \u0432\u043A\u043B\u0430\u0434\u043E\u043A \u0432 \u043A\u043E\u043B\u044C\u0446\u0435: ${tabs.length} (${tabs.map(short).join(", ")}) \u2014 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0435\u0440\u0435\u043C\u0435\u0448\u0430\u043D\u044B, \u043F\u0430\u0443\u0437\u044B \u0441\u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F \u043F\u043E \u0441\u0432\u043E\u0435\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435`);
      console.warn(gaps.length ? `[FanslyAI] \u0440\u0430\u0437\u0440\u044B\u0432\u043E\u0432 >7\u043C\u0438\u043D: ${gaps.length} (\u0437\u0430\u043C\u043E\u0440\u043E\u0437\u043A\u0438)` : "[FanslyAI] \u0440\u0430\u0437\u0440\u044B\u0432\u043E\u0432 \u043D\u0435\u0442 \u2014 \u043F\u0438\u043D\u0433 \u0440\u043E\u0432\u043D\u044B\u0439", gaps);
    });
  };
  window.__faiReport = function() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["fansly_ai_health", "fansly_bugbuf", "fansly_ai_settings"], (d) => {
        const log = d.fansly_ai_health || [], buf = d.fansly_bugbuf || [], st = d.fansly_ai_settings || {};
        if (!log.length) {
          console.log("[FanslyAI] \u0441\u0432\u043E\u0434\u043A\u0430: \u043A\u043E\u043B\u044C\u0446\u043E \u043F\u0438\u043D\u0433\u043E\u0432 \u043F\u0443\u0441\u0442\u043E\u0435");
          resolve("");
          return;
        }
        const fmt = (ts) => new Date(ts).toLocaleString();
        const by = {};
        log.forEach((e) => {
          const k = e.tab || "\u2014";
          (by[k] = by[k] || []).push(e);
        });
        const L = [
          "Velour \xB7 \u0441\u0432\u043E\u0434\u043A\u0430 \u0436\u0438\u0432\u0443\u0447\u0435\u0441\u0442\u0438",
          "\u043F\u0435\u0440\u0438\u043E\u0434: " + fmt(log[0].ts) + " \u2014 " + fmt(log[log.length - 1].ts) + " (\u0437\u0430\u043F\u0438\u0441\u0435\u0439 " + log.length + ", \u0432\u043A\u043B\u0430\u0434\u043E\u043A " + Object.keys(by).length + ")"
        ];
        for (const [tab, arr] of Object.entries(by)) {
          let gaps = 0, maxGap = 0, gapAt = 0;
          for (let i = 1; i < arr.length; i++) {
            const g = arr[i].ts - arr[i - 1].ts;
            if (g > 7 * 6e4) {
              gaps++;
              if (g > maxGap) {
                maxGap = g;
                gapAt = arr[i].ts;
              }
            }
          }
          const ka = arr.reduce((a, e) => {
            const k = e.ka || "?";
            a[k] = (a[k] || 0) + 1;
            return a;
          }, {});
          const steps = arr.filter((e) => e.carousel && e.stepAgo != null);
          const busy = arr.filter((e) => e.navBusy).length, moved = arr.filter((e) => e.labelMoved).length;
          const reloads = arr.filter((e) => e.navType === "reload").length, disc = arr.filter((e) => e.wasDisc).length;
          L.push("\u0432\u043A\u043B\u0430\u0434\u043A\u0430 " + tab.slice(-4) + (arr.some((e) => e.carousel) ? " (\u043F\u0443\u043B\u044C\u0442)" : "") + ": \u043F\u0438\u043D\u0433\u043E\u0432 " + arr.length + ", \u043F\u0440\u043E\u0432\u0430\u043B\u043E\u0432>7\u043C\u0438\u043D " + gaps + (maxGap ? " (\u043C\u0430\u043A\u0441 " + Math.round(maxGap / 6e4) + " \u043C\u0438\u043D, " + fmt(gapAt) + ")" : ""));
          L.push("   keepalive: " + Object.entries(ka).map(([k, v]) => k + "\xD7" + v).join(", ") + " | reload " + reloads + " | \u0432\u044B\u0433\u0440\u0443\u0436\u0430\u043B\u0438 " + disc);
          if (steps.length) L.push("   \u0448\u0430\u0433 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u0438: \u043C\u0430\u043A\u0441 " + steps.reduce((m, e) => Math.max(m, e.stepAgo), 0) + " \u043C\u0438\u043D, \u043F\u0438\u043D\u0433\u043E\u0432 \u0441\u043E \u0441\u0442\u043E\u044F\u0449\u0438\u043C \u0448\u0430\u0433\u043E\u043C " + steps.filter((e) => e.stepAgo > 5).length + " \u0438\u0437 " + steps.length);
          L.push("   \u043C\u044C\u044E\u0442\u0435\u043A\u0441 \u0437\u0430\u043D\u044F\u0442: " + busy + " | \u0441\u0442\u0440\u043E\u043A\u0443 \u043F\u0435\u0440\u0435\u0440\u0438\u0441\u043E\u0432\u044B\u0432\u0430\u043B\u0438: " + Math.round(moved / arr.length * 100) + "% \u043F\u0438\u043D\u0433\u043E\u0432");
        }
        const codes = buf.reduce((a, e) => {
          const k = e.c + (e.code ? "/" + e.code : "");
          a[k] = (a[k] || 0) + (e.n || 1);
          return a;
        }, {});
        L.push("\u0431\u0430\u0433\u0440\u0435\u043F\u043E\u0440\u0442\u044B \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u0438: " + (Object.keys(codes).length ? Object.entries(codes).map(([k, v]) => k + "\xD7" + v).join(", ") : "\u043F\u0443\u0441\u0442\u043E") + " (\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 " + (st.bugReportEnabled === true ? "\u0432\u043A\u043B\u044E\u0447\u0435\u043D\u0430" : "\u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D\u0430") + ")");
        const text = L.join("\n");
        console.log(text);
        resolve(text);
      });
    });
  };
  let _healthWatchTimer = null, _healthWatchUntil = 0, _healthWatchLast = 0;
  const HEALTH_WATCH_MS = 15e3;
  window.__faiHealthWatch = function(min) {
    if (min == null) {
      chrome.storage.local.get("fansly_ai_health_watch", (d) => {
        const log = d.fansly_ai_health_watch || [];
        console.table(log.map((e) => ({ \u0432\u0440\u0435\u043C\u044F: new Date(e.ts).toLocaleTimeString(), \u0444\u0430\u043A\u0442_\u0441: Math.round(e.actual / 1e3), \u0434\u0440\u0435\u0439\u0444_\u0441: Math.round(e.drift / 1e3), \u0432\u043A\u043B\u0430\u0434\u043A\u0430: e.vis, \u0444\u043E\u043A\u0443\u0441: e.focus, keepalive: e.ka })));
        const frozen = log.filter((e) => e.drift > 5e3);
        console.warn(frozen.length ? `[FanslyAI] \u0442\u0438\u043A\u043E\u0432 \u0441 \u0434\u0440\u0435\u0439\u0444\u043E\u043C >5\u0441: ${frozen.length} \u0438\u0437 ${log.length} \u2014 \u0442\u0430\u0439\u043C\u0435\u0440\u044B \u0442\u0440\u043E\u0442\u0442\u043B\u0438\u043B\u0438\u0441\u044C/\u0437\u0430\u043C\u0438\u0440\u0430\u043B\u0438` : `[FanslyAI] \u0434\u0440\u0435\u0439\u0444 \u0440\u043E\u0432\u043D\u044B\u0439 (${log.length} \u0442\u0438\u043A\u043E\u0432) \u2014 \u0442\u0430\u0439\u043C\u0435\u0440\u044B \u043D\u0435 \u0442\u0440\u043E\u0442\u0442\u043B\u0438\u043B\u0438\u0441\u044C`);
      });
      return;
    }
    clearInterval(_healthWatchTimer);
    _healthWatchUntil = Date.now() + min * 6e4;
    _healthWatchLast = Date.now();
    chrome.storage.local.set({ fansly_ai_health_watch: [] });
    console.log(`[FanslyAI] \u{1FA7A} \u0437\u0430\u043C\u0435\u0440 \u043D\u0430 ${min} \u043C\u0438\u043D \u043F\u043E\u0448\u0451\u043B. \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u0443\u0439 \u044D\u043A\u0440\u0430\u043D / \u0441\u0432\u0435\u0440\u043D\u0438 / \u043E\u0442\u043A\u043B\u044E\u0447\u0438 RDP, \u043F\u043E\u0442\u043E\u043C \u0432\u0435\u0440\u043D\u0438\u0441\u044C \u0438 \u0432\u044B\u0437\u043E\u0432\u0438 __faiHealthWatch()`);
    _healthWatchTimer = setInterval(() => {
      const now = Date.now();
      const actual = now - _healthWatchLast;
      _healthWatchLast = now;
      const entry = { ts: now, actual, drift: actual - HEALTH_WATCH_MS, vis: document.visibilityState, focus: document.hasFocus(), ka: typeof _keepAliveCtx !== "undefined" && _keepAliveCtx ? _keepAliveCtx.state : "off" };
      chrome.storage.local.get("fansly_ai_health_watch", (d) => {
        const log = d.fansly_ai_health_watch || [];
        log.push(entry);
        if (log.length > 600) log.splice(0, log.length - 600);
        chrome.storage.local.set({ fansly_ai_health_watch: log });
      });
      if (now >= _healthWatchUntil) {
        clearInterval(_healthWatchTimer);
        _healthWatchTimer = null;
        console.log("[FanslyAI] \u{1FA7A} \u0437\u0430\u043C\u0435\u0440 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D \u2014 __faiHealthWatch() \u043F\u043E\u043A\u0430\u0436\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
      }
    }, HEALTH_WATCH_MS);
  };
  const MIRROR_ANCHOR_K = 3;
  const MIRROR_ANCHOR_TOL_MS = 6e5;
  function scheduleMirrorScan(live = false) {
    if (!state.tgDialogue) return;
    if (live) state._mirrorLive = true;
    clearTimeout(state._mirrorTimer);
    state._mirrorTimer = setTimeout(mirrorNewIncoming, 1500);
  }
  function readIncomingFeed() {
    const feed = [];
    let curTs = null;
    const sel = selJoin("messageNode", "messageTimestamp");
    if (!sel) return feed;
    document.querySelectorAll(sel).forEach((node) => {
      if (qm("messageTimestamp", node)) {
        if (!node.closest(selStr("messageNode"))) {
          const p = parseFanslyTs(node.textContent);
          if (p) curTs = p;
        }
        return;
      }
      const isOwn = PLAT.isOwn(node);
      const hasMedia = bodyMediaEl(node);
      const text = getMessageText(node);
      if (!text && !hasMedia) return;
      const isMedia = !!hasMedia && !text;
      const mediaType = hasMedia ? detectMediaType(node) : null;
      const mediaId = hasMedia ? bodyMediaId(node) : null;
      const reply = extractReply(node);
      feed.push({
        text,
        isMedia,
        mediaType,
        isOwn,
        reply,
        mediaLocked: hasMedia ? detectMediaLocked(node) : false,
        ts: PLAT.timeOf(node) || curTs || null,
        // НЕ Date.now(): при отсутствии надёжного времени → null → матч якоря
        // деградирует к key-only (a.ts&&f.ts пропускает ts-проверку). Иначе ts=now
        // расходился с сохранённым (реальным) ts якоря >10мин → ложный засев → переотправка старого при рестарте.
        // Направление в ключе → якорь не путает own/incoming с одинаковым текстом. У медиа без подписи в ключ
        // идёт ещё и id файла: без него все ролики подряд имели ОДИН ключ и дедуп глотал всё, кроме первого.
        key: (isOwn ? ">" : "<") + (text || "[m:" + (mediaType || "media") + (mediaId ? "#" + mediaId : "") + "]")
      });
    });
    return feed;
  }
  function findAfterAnchor(feed, anchor) {
    if (!anchor || !anchor.length) return -1;
    const K = anchor.length;
    let fallback = -1;
    for (let i = feed.length - K; i >= 0; i--) {
      let keysOk = true;
      for (let j = 0; j < K; j++) {
        if (feed[i + j].key !== anchor[j].key) {
          keysOk = false;
          break;
        }
      }
      if (!keysOk) continue;
      let tsOk = true;
      for (let j = 0; j < K; j++) {
        const f = feed[i + j], a = anchor[j];
        if (a.ts && f.ts && Math.abs(f.ts - a.ts) > MIRROR_ANCHOR_TOL_MS) {
          tsOk = false;
          break;
        }
      }
      if (tsOk) return i + K;
      if (fallback < 0) fallback = i + K;
    }
    return fallback;
  }
  const MIRROR_KEYS_TTL = 48 * 36e5, MIRROR_KEYS_CAP = 120;
  const DEDUP_RECENT_MS = 12e4;
  const ARRIVAL_TOL_MS = 5e3;
  function mirrorKeySeen(key, since = 0) {
    const m = state.contactData?.mirroredKeys;
    if (!m) return false;
    const at = m[key] != null ? m[key] : m[collapseKey(key)];
    return at != null && Date.now() - at < MIRROR_KEYS_TTL && at >= since;
  }
  function markMirroredKeys(keys, tgt) {
    const d = tgt && tgt.data || state.contactData;
    if (!d || !keys || !keys.length) return;
    const now = Date.now();
    const m = d.mirroredKeys || {};
    for (const k of keys) m[k] = now;
    state._mirrorLastMarkAt = now;
    const kept = {};
    for (const [k, at] of Object.entries(m).filter(([, at2]) => now - at2 < MIRROR_KEYS_TTL).sort((a, b) => b[1] - a[1]).slice(0, MIRROR_KEYS_CAP)) kept[k] = at;
    d.mirroredKeys = kept;
    if (tgt) savePatchTo(tgt, tgt.name, { mirroredKeys: kept });
    else saveContact(state.currentContact, { mirroredKeys: kept });
  }
  function domContactName() {
    if (PLATFORM === "onlyfans") return state.currentContact;
    const header = q("contactHeader");
    if (!header) return null;
    const nameEl = q("displayName", header);
    let name = cleanContactName(nameEl ? nameEl.textContent : header.innerText);
    if (/…|\.\.\./.test(name)) {
      const handle = (q("usernameLink", header)?.getAttribute("href") || "").replace(/^\//, "").trim();
      if (handle) name = handle;
    }
    return name || null;
  }
  const MIRROR_LOG_KEY = "fansly_mirror_log", MIRROR_LOG_CAP = 60;
  function mirrorLogNote(e) {
    try {
      chrome.storage.local.get(MIRROR_LOG_KEY, (d) => {
        const log = d && d[MIRROR_LOG_KEY] || [];
        log.push(Object.assign({ at: Date.now(), tab: String(_tabId()).slice(-4), pageS: Math.round(performance.now() / 1e3) }, e));
        chrome.storage.local.set({ [MIRROR_LOG_KEY]: log.slice(-MIRROR_LOG_CAP) });
      });
    } catch (err) {
    }
  }
  window.__faiMirrorLog = function(n = 30) {
    if (n === "clear") {
      chrome.storage.local.remove(MIRROR_LOG_KEY);
      console.log("[FanslyAI] \u0436\u0443\u0440\u043D\u0430\u043B \u0437\u0435\u0440\u043A\u0430\u043B\u0430 \u043E\u0447\u0438\u0449\u0435\u043D");
      return;
    }
    chrome.storage.local.get(MIRROR_LOG_KEY, (d) => {
      const log = (d[MIRROR_LOG_KEY] || []).slice(-n);
      console.table(log.map((e) => ({
        \u0432\u0440\u0435\u043C\u044F: new Date(e.at).toLocaleString(),
        \u0432\u043A\u043B\u0430\u0434\u043A\u0430: e.tab,
        \u0441\u0442\u0440_\u0441\u0435\u043A: e.pageS,
        \u0444\u0430\u043D: e.fan,
        \u043B\u0435\u043D\u0442\u0430: e.feed,
        \u044F\u043A\u043E\u0440\u044C: e.anchor,
        \u043F\u0443\u0442\u044C: e.path,
        \u0436\u0438\u0432\u044B\u0445: e.live,
        \u043E\u0442\u0441\u0447\u0451\u0442_\u043C\u0438\u043D: e.sinceMin,
        \u0434\u043E_\u0434\u0435\u0434\u0443\u043F\u0430: e.before,
        \u0443\u0448\u043B\u043E: e.sent,
        \u0441\u0432\u043E\u0438\u0445: e.own,
        \u0441_\u043F\u043E\u043C\u0435\u0442\u043A\u043E\u0439: e.marked,
        \u043A\u043B\u044E\u0447\u0435\u0439: e.mk,
        \u0441\u0442\u0440\u043E\u043A\u0438: e.keys
      })));
      console.log("[FanslyAI] \u0436\u0443\u0440\u043D\u0430\u043B \u0437\u0435\u0440\u043A\u0430\u043B\u0430: " + log.length + " \u0437\u0430\u043F\u0438\u0441\u0435\u0439. \u041F\u0430\u0447\u043A\u0430 \u0443\u0436\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u2014 \u043C\u0430\u043B\u043E\u0435 \xAB\u0441\u0442\u0440_\u0441\u0435\u043A\xBB, \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \xAB\u0443\u0448\u043B\u043E\xBB; \xAB\u0441_\u043F\u043E\u043C\u0435\u0442\u043A\u043E\u0439\xBB > 0 = \u0441\u0442\u0440\u043E\u043A\u0438, \u043E \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u044C \u0437\u043D\u0430\u043B\u0430, \u043D\u043E \u0434\u0435\u0434\u0443\u043F \u0438\u0445 \u043D\u0435 \u0443\u0437\u043D\u0430\u043B");
    });
  };
  async function mirrorNewIncoming() {
    if (!state.tgDialogue) return;
    if (!carousel.running) {
      console.log("[FanslyAI] \u{1F514} mirror SKIP: \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0430 \u0432 \u044D\u0442\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435 (\u043B\u044C\u0451\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043B\u0438\u0434\u0435\u0440)");
      return;
    }
    if (!state.currentContact) {
      console.log("[FanslyAI] \u{1F514} mirror SKIP: \u0438\u043C\u044F \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430 \u043D\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u043B\u043E\u0441\u044C \u2192 \u041D\u0415 \u043B\u044C\u0451\u043C \u0432 \u0431\u043E\u0433\u0443\u0441-\u0442\u043E\u043F\u0438\u043A \xAB\u0444\u0430\u043D\xBB (\u0447\u0438\u043D\u0438\u043C detectContact)");
      return;
    }
    if (!state.contactData) {
      console.log("[FanslyAI] \u{1F514} mirror: contactData \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D \u2192 \u043F\u0440\u043E\u043F\u0443\u0441\u043A (\u0436\u0434\u0451\u043C \u044F\u043A\u043E\u0440\u044C)");
      return;
    }
    if (!contactDataIsCurrent()) {
      console.log("[FanslyAI] \u{1F514} mirror: contactData \u043E\u0442 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0447\u0430\u0442\u0430 \u2192 \u043F\u0440\u043E\u043F\u0443\u0441\u043A (\u0436\u0434\u0451\u043C \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0443)");
      return;
    }
    if (state._mirrorInFlight) {
      scheduleMirrorScan(false);
      return;
    }
    const cid0 = state.currentContactId;
    const rowKeys = (await rowKeysLoad())[cid0] || null;
    if (state.currentContactId !== cid0 || !state.contactData) {
      console.log("[FanslyAI] \u{1F514} mirror SKIP: \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \u0441\u043C\u0435\u043D\u0438\u043B\u0441\u044F \u0437\u0430 \u0432\u0440\u0435\u043C\u044F \u0447\u0442\u0435\u043D\u0438\u044F \u043A\u043B\u044E\u0447\u0435\u0439 \u0441\u0442\u0440\u043E\u043A");
      return;
    }
    const _urlId = extractContactIdFromUrl();
    const _domName = domContactName();
    if (_urlId && _urlId !== state.currentContactId || _domName && _domName !== state.currentContact) {
      console.log("[FanslyAI] \u{1F514} mirror SKIP: \u0441\u0442\u0435\u0439\u0442 \u043E\u0442\u0441\u0442\u0430\u043B \u043F\u0440\u0438 \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0438 | urlId=" + _urlId + " cid=" + state.currentContactId + " | domName=" + JSON.stringify(_domName) + " cur=" + JSON.stringify(state.currentContact) + " \u2014 \u0436\u0434\u0451\u043C detectContact");
      return;
    }
    const feed = readIncomingFeed();
    if (!feed.length) return;
    const scanAt = Date.now();
    const prevLen = state._mirrorFeedLen || 0;
    state._mirrorFeedLen = feed.length;
    try {
      const _mn = qa("messageNode");
      state._mirrorLastNode = _mn[_mn.length - 1] || null;
    } catch (e) {
    }
    const persistSeen = (k) => mirrorKeySeen(k) || rowKeySeen(rowKeys, k);
    const wasLive = state._mirrorLive;
    state._mirrorLive = false;
    let liveN = state._mirrorLiveFor === state.currentContactId ? state._mirrorLiveCount || 0 : 0;
    liveN = Math.min(liveN, Math.max(0, feed.length - prevLen));
    const liveAt = liveN ? state._mirrorLiveAt || 0 : 0;
    state._mirrorLiveCount = 0;
    state._mirrorLiveAt = 0;
    state._mirrorLiveFor = null;
    const anchor = state.contactData?.mirrorAnchor || null;
    const anchorIdx = findAfterAnchor(feed, anchor);
    const matched = anchorIdx >= 0;
    let fresh = matched ? feed.slice(liveN ? Math.min(anchorIdx, feed.length - liveN) : anchorIdx) : [];
    let mlPath = "\u044F\u043A\u043E\u0440\u044C";
    let since = matched && state.contactData?.mirrorAnchorAt ? state.contactData.mirrorAnchorAt : 0;
    const tgt = { name: state.currentContact, id: state.currentContactId, data: state.contactData };
    const newAnchor = feed.slice(-MIRROR_ANCHOR_K).map((m) => ({ key: m.key, ts: m.ts }));
    const commitAnchor = () => {
      if (tgt.data && (tgt.data.mirrorAnchorScanAt || 0) > scanAt) {
        console.log("[FanslyAI] \u{1F514} mirror: \u044F\u043A\u043E\u0440\u044C \u0443\u0436\u0435 \u043D\u043E\u0432\u0435\u0435, \u043A\u043E\u043C\u043C\u0438\u0442 \u0441\u0442\u0430\u0440\u043E\u0433\u043E \u0441\u043A\u0430\u043D\u0430 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D");
        return;
      }
      const at = Math.max(Date.now(), (state._mirrorLastMarkAt || 0) + 1);
      if (tgt.data) {
        tgt.data.mirrorAnchor = newAnchor;
        tgt.data.mirrorAnchorAt = at;
        tgt.data.mirrorAnchorScanAt = scanAt;
      }
      savePatchTo(tgt, tgt.name, { mirrorAnchor: newAnchor, mirrorAnchorAt: at, mirrorAnchorScanAt: scanAt });
    };
    if (!fresh.length) {
      if (matched) {
        if (wasLive) {
          fresh = feed.slice(-Math.max(1, Math.min(liveN, feed.length)));
          since = 0;
          mlPath = "\u044F\u043A\u043E\u0440\u044C \u043D\u0430 \u0445\u0432\u043E\u0441\u0442\u0435 + \u0436\u0438\u0432\u043E\u0439";
          console.log("[FanslyAI] \u{1F514} mirror: \u044F\u043A\u043E\u0440\u044C \u043D\u0430 \u0445\u0432\u043E\u0441\u0442\u0435, \u0436\u0438\u0432\u043E\u0439 \u0442\u0440\u0438\u0433\u0433\u0435\u0440 \u2192 \u0445\u0432\u043E\u0441\u0442" + (liveN ? " (\u0436\u0438\u0432\u044B\u0445 \u0443\u0437\u043B\u043E\u0432 " + liveN + ")" : "") + " | feed=" + feed.length);
        } else {
          commitAnchor();
          console.log("[FanslyAI] \u{1F514} mirror: \u043D\u043E\u0432\u043E\u0433\u043E \u043D\u0435\u0442 (\u044F\u043A\u043E\u0440\u044C \u0441\u043E\u0432\u043F\u0430\u043B) | feed=" + feed.length);
          return;
        }
      } else {
        let lastMirrored = -1;
        for (let i = feed.length - 1; i >= 0; i--) {
          if (persistSeen(feed[i].key)) {
            lastMirrored = i;
            break;
          }
        }
        let lastOwn = -1;
        for (let i = feed.length - 1; i >= 0; i--) {
          if (feed[i].isOwn) {
            lastOwn = i;
            break;
          }
        }
        if (lastMirrored >= 0 && lastMirrored < feed.length - 1) {
          fresh = feed.slice(lastMirrored + 1);
          mlPath = "\u0437\u0430\u0441\u0435\u0432: \u043F\u043E \u043E\u0442\u0437\u0435\u0440\u043A\u0430\u043B\u0435\u043D\u043D\u043E\u043C\u0443";
          console.log("[FanslyAI] \u{1F514} mirror: \u0437\u0430\u0441\u0435\u0432 \u2192 \u0433\u0440\u0430\u043D\u0438\u0446\u0430 \u043F\u043E \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u043C\u0443 \u043E\u0442\u0437\u0435\u0440\u043A\u0430\u043B\u0435\u043D\u043D\u043E\u043C\u0443, " + fresh.length + " \u043F\u043E\u0441\u043B\u0435 \u2192 \u0431\u043B\u043E\u043A | feed=" + feed.length);
        } else if (lastMirrored < 0 && lastOwn >= 0 && lastOwn < feed.length - 1) {
          fresh = feed.slice(lastOwn + 1);
          mlPath = "\u0437\u0430\u0441\u0435\u0432: \u043F\u043E \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u043C\u0443";
          console.log("[FanslyAI] \u{1F514} mirror: \u0437\u0430\u0441\u0435\u0432 \u2192 \u0433\u0440\u0430\u043D\u0438\u0446\u0430 \u043F\u043E \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u043C\u0443 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u043C\u0443, " + fresh.length + " \u043F\u043E\u0441\u043B\u0435 \u2192 \u0431\u043B\u043E\u043A | feed=" + feed.length);
        } else if (wasLive) {
          fresh = feed.slice(-Math.max(1, Math.min(liveN, feed.length)));
          mlPath = "\u0437\u0430\u0441\u0435\u0432: \u0436\u0438\u0432\u043E\u0439 \u0445\u0432\u043E\u0441\u0442";
          console.log("[FanslyAI] \u{1F514} mirror: \u0437\u0430\u0441\u0435\u0432, \u0436\u0438\u0432\u043E\u0439 \u0442\u0440\u0438\u0433\u0433\u0435\u0440 \u2192 \u0445\u0432\u043E\u0441\u0442" + (liveN ? " (\u0436\u0438\u0432\u044B\u0445 \u0443\u0437\u043B\u043E\u0432 " + liveN + ")" : "") + " | feed=" + feed.length);
        } else {
          commitAnchor();
          console.log("[FanslyAI] \u{1F514} mirror: \u0437\u0430\u0441\u0435\u0432 \u2014 \u0437\u0435\u0440\u043A\u0430\u043B\u0438\u0442\u044C \u043D\u0435\u0447\u0435\u0433\u043E (\u043F\u0435\u0440\u0432\u043E\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435, \u0437\u0430\u0441\u0435\u044F\u043B \u044F\u043A\u043E\u0440\u044C) | feed=" + feed.length);
          return;
        }
      }
    } else {
      console.log("[FanslyAI] \u{1F514} mirror: \u043D\u043E\u0432\u044B\u0445 " + fresh.length + " \u043F\u043E\u0441\u043B\u0435 \u044F\u043A\u043E\u0440\u044F \u2192 \u0431\u043B\u043E\u043A \u0432 \u0422\u0413 | feed=" + feed.length + (liveN ? " | \u0436\u0438\u0432\u044B\u0445 \u0443\u0437\u043B\u043E\u0432 " + liveN : ""));
    }
    const sessKey = (k) => (state.currentContactId || state.currentContact || "?") + "|" + k;
    const _before = fresh.length;
    const liveFrom = liveN ? Math.max(0, fresh.length - liveN) : fresh.length;
    const liveSince = liveAt ? liveAt - 200 : since;
    fresh.forEach((m, i) => {
      m._since = i >= liveFrom ? liveSince : since;
      m._live = i >= liveFrom;
    });
    fresh = fresh.filter((m) => !mirrorKeySeen(m.key, m._since) && !rowKeySeen(rowKeys, m.key, m._since) && !tgSeen(sessKey(m.key), m._since) && !tgSeen(sessKey(collapseKey(m.key)), m._since) && !rowPendingLive(sessKey(collapseKey(m.key))));
    if (fresh.length !== _before) console.log("[FanslyAI] \u{1F514} mirror: \u0434\u0435\u0434\u0443\u043F \u0432\u044B\u0440\u0435\u0437\u0430\u043B " + (_before - fresh.length) + " \u0438\u0437 " + _before + " \u2014 \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0448\u043B\u0451\u043C");
    {
      const mk = tgt.data && tgt.data.mirroredKeys || {};
      mirrorLogNote({
        fan: tgt.name,
        id: String(tgt.id || "").slice(-6),
        feed: feed.length,
        anchor: matched ? "@" + anchorIdx + " \u0438\u0437 " + feed.length : "\u043D\u0435\u0442",
        path: mlPath,
        live: liveN,
        sinceMin: since ? Math.round((Date.now() - since) / 6e4) : "48\u0447",
        before: _before,
        sent: fresh.length,
        own: fresh.filter((m) => m.isOwn).length,
        marked: fresh.filter((m) => mk[m.key] != null || mk[collapseKey(m.key)] != null).length,
        mk: Object.keys(mk).length,
        keys: fresh.slice(0, 12).map((m) => m.key.slice(0, 31)).join(" | ")
      });
    }
    if (!fresh.length) {
      commitAnchor();
      console.log("[FanslyAI] \u{1F514} mirror: \u0432\u0441\u0451 \u0443\u0436\u0435 \u043E\u0442\u0437\u0435\u0440\u043A\u0430\u043B\u0435\u043D\u043E (\u043F\u0435\u0440\u0441\u0438\u0441\u0442-\u0434\u0435\u0434\u0443\u043F) | feed=" + feed.length);
      return;
    }
    state._mirrorInFlight = true;
    try {
      const fan = state.currentContact || t("common.fanFallback", state.uiLang);
      const lines = [];
      for (const m of fresh) {
        let body;
        const ctx = m._live && !m.isOwn && m.text ? trContextFor(trEntryOf(m.text, false)) : null;
        if (m.mediaType) {
          const label = mediaLabel(m.mediaType, m.mediaLocked);
          const cap = m.text ? await translateForOwner(m.text, m.isOwn ? outGenders() : inGenders(), ctx) || m.text : "";
          body = cap ? `${label} ${cap}` : label;
        } else {
          body = await translateForOwner(m.text, m.isOwn ? outGenders() : inGenders(), ctx) || m.text;
        }
        let line = `\u{1F4AC} ${fan} ${m.isOwn ? "\u{1F916}" : "\u{1F464}"} ${body}`;
        if (m.reply) line += `
   \u21B3 ${replyQuoteStr(await replyTranslated(m.reply))}`;
        lines.push(line);
      }
      const msgKeys = fresh.map((m) => m.key);
      const sessKeys = msgKeys.map(sessKey);
      const hasIncoming = fresh.some((m) => !m.isOwn);
      const chunks = chunkTgLines(lines);
      if (chunks.length > 1) console.log("[FanslyAI] \u{1F514} mirror: \u0431\u043B\u043E\u043A \u0440\u0430\u0437\u0440\u0435\u0437\u0430\u043D \u043D\u0430 " + chunks.length + " \u0441\u043E\u043E\u0431\u0449. (\u043B\u0438\u043C\u0438\u0442 \u0422\u0413) | \u0441\u0442\u0440\u043E\u043A=" + lines.length);
      let pending = chunks.length;
      for (const idxs of chunks) {
        const cRaw = idxs.map((i) => msgKeys[i]);
        const cSess = idxs.map((i) => sessKeys[i]);
        const cInc = idxs.some((i) => !fresh[i].isOwn);
        const cSince = Math.min(...idxs.map((i) => fresh[i]._since || 0));
        tgMirrorLine(idxs.map((i) => lines[i]).join("\n"), fan, cInc, cSess, () => {
          markMirroredKeys(cRaw, tgt);
          if (--pending !== 0) return;
          commitAnchor();
          try {
            const lastM = fresh[fresh.length - 1];
            const rowEl = lastM && tgt.id ? rowElFor(tgt.id) : null;
            if (rowEl) {
              const pv = collapseKey(q("rowPreview", rowEl)?.innerText || "");
              const expect = lastM.text ? collapseKey(lastM.text) : "";
              if (pv === expect) {
                carousel.rowMirrored[tgt.id] = { badge: getUnreadCount(rowEl), text: pv };
                carousel.lastRowPreview[tgt.id] = pv;
                rowLastSave(tgt.id);
              }
            }
          } catch (e) {
          }
        }, false, null, cSince);
      }
    } finally {
      state._mirrorInFlight = false;
    }
  }
  const TG_MSG_LIMIT = 4e3;
  function chunkTgLines(lines) {
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].length > TG_MSG_LIMIT) {
        const cut = " " + t("panel.tg.cut", state.uiLang);
        lines[i] = lines[i].slice(0, TG_MSG_LIMIT - cut.length) + cut;
      }
    }
    const chunks = [];
    let cur = [], len = 0;
    for (let i = 0; i < lines.length; i++) {
      const add = (len ? 1 : 0) + lines[i].length;
      if (len && len + add > TG_MSG_LIMIT) {
        chunks.push(cur);
        cur = [];
        len = 0;
      }
      cur.push(i);
      len += (len ? 1 : 0) + lines[i].length;
    }
    if (cur.length) chunks.push(cur);
    return chunks;
  }
  async function mirrorOutgoingToTG() {
  }
  function mediaLabel(type, locked) {
    const key = { audio: "common.media.audio", video: "common.media.video", photo: "common.media.photo", gif: "common.media.gif", blurred: "common.media.blurred", bundle: "common.media.bundle" }[type] || "common.media.attachment";
    return `[${t(key, state.uiLang)}${locked ? t("common.media.lockedSuffix", state.uiLang) : ""}]`;
  }
  const TG_MIRRORED_TTL = 6 * 36e5, TG_MIRRORED_CAP = 300;
  function tgSeen(key, since = 0) {
    const at = state._tgMirrored && state._tgMirrored.get(key);
    return at != null && Date.now() - at < TG_MIRRORED_TTL && at >= since;
  }
  function tgMirrorLine(line, fan, incoming = false, dedupKeys = null, onSent = null, noActivityMark = false, onFail = null, guardSince = null) {
    if (!state._tgMirrored) state._tgMirrored = /* @__PURE__ */ new Map();
    const keys = dedupKeys && dedupKeys.length ? dedupKeys : [line];
    const _gs = guardSince != null ? guardSince : Date.now() - DEDUP_RECENT_MS;
    if (keys.every((k) => tgSeen(k, _gs))) {
      console.log("[FanslyAI] \u{1F514} tgLine DEDUP-SKIP (\u0432\u0435\u0441\u044C \u0431\u043B\u043E\u043A \u0443\u0436\u0435 \u0441\u043B\u0430\u043B\u0438) | " + line.slice(0, 60));
      return;
    }
    const now = Date.now();
    for (const k of keys) {
      state._tgMirrored.set(k, now);
      if (state._tgMirrored.size > TG_MIRRORED_CAP) state._tgMirrored.delete(state._tgMirrored.keys().next().value);
    }
    try {
      if (!noActivityMark) markActivityHandled(state.currentContactId);
    } catch (e) {
    }
    const attempt = (tryN) => {
      console.log("[FanslyAI] \u{1F514} tgLine \u2192 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430" + (tryN ? " (\u0440\u0435\u0442\u0440\u0430\u0439 " + tryN + ")" : "") + " | fan:", fan, "| " + line.slice(0, 50));
      sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "dialogue", fan, text: line, incoming, preDeduped: guardSince != null }).then((r) => {
        if (r?.success) {
          console.log("[FanslyAI] \u{1F514} tgLine \u0420\u0415\u0417\u0423\u041B\u042C\u0422\u0410\u0422: " + (r.deduped ? "\u0424\u041E\u041D \u041E\u0422\u0421\u0401\u041A \u041A\u0410\u041A \u0414\u0423\u0411\u041B\u042C (\u0432 \u0422\u0413 \u043D\u0435 \u0443\u0448\u043B\u043E)" : r.message_id == null ? "OK \u0431\u0435\u0437 msg_id" : "OK msg_id=" + r.message_id) + " | " + line.slice(0, 40));
          try {
            onSent && onSent();
          } catch (e) {
          }
          return;
        }
        if (tryN < 1) {
          console.log("[FanslyAI] \u{1F514} tgLine FAIL: " + (r?.error || r?.result || "\u043D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430") + " \u2192 \u0440\u0435\u0442\u0440\u0430\u0439 4\u0441 | " + line.slice(0, 40));
          setTimeout(() => attempt(tryN + 1), 4e3);
          return;
        }
        for (const k of keys) state._tgMirrored.delete(k);
        try {
          onFail && onFail();
        } catch (e) {
        }
        console.log("[FanslyAI] \u{1F514} tgLine FAIL \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E: " + (r?.error || r?.result || "\u043D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430") + " \u2192 \u043F\u043E\u043C\u0435\u0442\u043A\u0430 \u0441\u043D\u044F\u0442\u0430, \u043F\u0435\u0440\u0435\u0448\u043B\u0451\u043C \u043F\u0440\u0438 redraw | " + line.slice(0, 40));
      }).catch((e) => {
        if (tryN < 1) {
          setTimeout(() => attempt(tryN + 1), 4e3);
          return;
        }
        for (const k of keys) state._tgMirrored.delete(k);
        try {
          onFail && onFail();
        } catch (e2) {
        }
        console.log("[FanslyAI] \u{1F514} tgLine FAIL(exc): " + (e?.message || e) + " \u2192 \u043F\u043E\u043C\u0435\u0442\u043A\u0430 \u0441\u043D\u044F\u0442\u0430 | " + line.slice(0, 40));
      });
    };
    attempt(0);
  }
  function processMessageNode(node) {
    if (state.processedNodes.has(node)) return;
    state.processedNodes.add(node);
    const isOwn = PLAT.isOwn(node);
    const role = isOwn ? "model" : "subscriber";
    const hasMedia = bodyMediaEl(node);
    const text = getMessageText(node);
    if (!text && !hasMedia) return;
    const freshTs = PLAT.timeOf(node);
    if (freshTs) state._lastDomTs = freshTs;
    const timestampReliable = freshTs != null;
    const timestamp = freshTs != null ? freshTs : state._lastDomTs || Date.now();
    const isScrollLoaded = state.historyScrolling || timestampReliable && timestamp < state.activatedAt;
    if (isScrollLoaded) scheduleMirrorScan();
    if (isScrollLoaded) return;
    const entry = {
      role,
      text: text || "",
      isMedia: !!hasMedia && !text,
      mediaType: hasMedia ? detectMediaType(node) : null,
      mediaLocked: hasMedia ? detectMediaLocked(node) : false,
      mediaPaid: hasMedia ? detectPaidState(node) : null,
      // своё платное: выкуплено/нет/бесплатно (см. detectPaidState)
      timestamp,
      ts: Date.now()
      // живое сообщение приходит сейчас → реальная дата = now (для метки разрыва)
    };
    if (role === "subscriber") entry.reply = extractReply(node);
    state.chatHistory.push(entry);
    updateStats();
    const msgEl = appendMessageToHistory(entry);
    {
      const lastN = state._mirrorLastNode;
      if (lastN && !lastN.isConnected) {
        try {
          const _mn = qa("messageNode");
          state._mirrorLastNode = _mn[_mn.length - 1] || node;
        } catch (e) {
          state._mirrorLastNode = node;
        }
      } else if (!lastN || lastN !== node && lastN.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING) {
        state._mirrorLiveCount = (state._mirrorLiveCount || 0) + 1;
        if (!state._mirrorLiveAt) state._mirrorLiveAt = Date.now();
        state._mirrorLiveFor = state.currentContactId;
        state._mirrorLastNode = node;
      }
      scheduleMirrorScan(true);
    }
    if (role === "subscriber" && text && state.active) {
      state.lastIncomingReply = entry.reply || null;
      translateMsgForDisplay(text, msgEl, inGenders(), trContextFor(entry));
      noteFanMessage(timestamp);
      scheduleDossierDelta();
      if (Date.now() < state.suppressUntil) {
        state.lastIncomingText = text;
      } else {
        scheduleIncomingGen(text);
      }
    } else if (role === "subscriber" && entry.isMedia && state.active) {
      console.log("[FanslyAI] \u043C\u0435\u0434\u0438\u0430 \u043E\u0442 \u0444\u0430\u043D\u0430:", entry.mediaType, "| locked:", entry.mediaLocked, "| txt:", (node.textContent || "").slice(0, 60));
      noteFanMessage(timestamp);
    } else if (role === "model" && text) {
      translateMsgForDisplay(text, msgEl, outGenders());
    }
  }
  function scheduleDossierDelta() {
    if (state.collectDossier === false) return;
    clearTimeout(state._dossierDeltaTimer);
    state._dossierDeltaTimer = setTimeout(() => {
      if (state.active && state.currentContact) triggerHistoryAnalysis(false);
    }, 8e3);
  }
  function scheduleIncomingGen(text) {
    state.lastIncomingText = text;
    clearTimeout(state._incomingDebounce);
    state._incomingDebounce = setTimeout(() => {
      if (latestFanMsg()?.isMedia) return;
      const lastIncoming = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
      if (!lastIncoming || lastIncoming.text !== text) return;
      if (carousel.running) autoHandleInActiveChat(text);
    }, 1500);
  }
  function noteFanMessage(timestamp) {
    if (!contactDataIsCurrent() || !state.contactData) return false;
    const cd = state.contactData;
    if (!cd.dossier) cd.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
    cd.dossier.lastMessageAt = timestamp;
    cd.totalMsgs = (cd.totalMsgs || 0) + 1;
    saveContact(state.currentContact, { dossier: cd.dossier, totalMsgs: cd.totalMsgs });
    return true;
  }
  async function autoHandleInActiveChat(text) {
    const id = state.currentContactId;
    if (carousel.navBusy) return;
    const lastIncoming = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
    if (!lastIncoming || lastIncoming.text !== text) return;
    if (state.contactData?.excludeFromAuto || id && carousel.excludedIds.has(id)) return;
    if (id && text === carousel.lastHandledText[id]) return;
    if (id) carousel.lastHandledText[id] = text;
    scheduleMirrorScan(true);
  }
  function latestFanMsg() {
    return [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && (m.text || m.isMedia));
  }
  function ensureHistoryForCurrent() {
    if (state._histFor === state.currentContactId) return;
    loadExistingMessages();
  }
  function loadExistingMessages() {
    state._histFor = state.currentContactId;
    if (PLATFORM === "onlyfans") return ONLYFANS.loadHistory();
    state.translateQueue = [];
    _transPending.clear();
    state.chatHistory = [];
    state.processedNodes = /* @__PURE__ */ new WeakSet();
    state._mirrorLiveCount = 0;
    state._mirrorLiveAt = 0;
    const historyEl = document.getElementById("fai-chat-history");
    if (historyEl) historyEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.loading">${t("panel.history.loading", state.uiLang)}</div>`;
    let curTs = null;
    const sel = selJoin("messageNode", "messageTimestamp");
    if (sel) document.querySelectorAll(sel).forEach((node) => {
      if (qm("messageTimestamp", node)) {
        if (!node.closest(selStr("messageNode"))) {
          const t2 = parseFanslyTs(node.textContent);
          if (t2) curTs = t2;
        }
        return;
      }
      if (state.processedNodes.has(node)) return;
      state.processedNodes.add(node);
      const isOwn = PLAT.isOwn(node);
      const role = isOwn ? "model" : "subscriber";
      const hasMedia = bodyMediaEl(node);
      const text = getMessageText(node);
      if (!text && !hasMedia) return;
      const entry = {
        role,
        text: text || "",
        isMedia: !!hasMedia && !text,
        mediaType: hasMedia ? detectMediaType(node) : null,
        mediaLocked: hasMedia ? detectMediaLocked(node) : false,
        // за пейволом? → для метки в ТГ
        mediaPaid: hasMedia ? detectPaidState(node) : null,
        // своё платное: выкуплено/нет/бесплатно (см. detectPaidState)
        timestamp: PLAT.timeOf(node) || curTs || Date.now(),
        // реальное время сообщения (панель рисует его); timeOf per-узел обходит off-by-one carry-forward
        ts: curTs,
        // реальная дата сообщения → метка разрыва в промпте (NB: при возобновлении после паузы)
        /*@full-start@*/
        reply: role === "subscriber" ? extractReply(node) : null
        /*@full-end@*/
        // #2
      };
      state.chatHistory.push(entry);
      const msgEl = appendMessageToHistory(entry);
      if (text && msgEl) translateMsgForDisplay(text, msgEl, role === "model" ? outGenders() : inGenders());
    });
    updateStats();
    scrollHistoryToBottom();
    console.log(`[FanslyAI] Loaded ${state.chatHistory.length} messages`);
    try {
      const _mn = qa("messageNode");
      state._mirrorLastNode = _mn[_mn.length - 1] || null;
      state._mirrorFeedLen = readIncomingFeed().length;
    } catch (e) {
    }
    scheduleMirrorScan();
    const lastIncoming = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
    if (lastIncoming) {
      state.lastIncomingText = lastIncoming.text;
      state.lastIncomingReply = lastIncoming.reply || null;
      setStatus(t("panel.status.clickGenerate", state.uiLang));
      setTimeout(() => setStatus(""), 3e3);
    }
    const lastFanAny = [...state.chatHistory].reverse().find((m) => m.role === "subscriber");
    if (lastFanAny?.timestamp && state.contactData) {
      if (!state.contactData.dossier) state.contactData.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
      if (state.contactData.dossier.lastMessageAt !== lastFanAny.timestamp) {
        state.contactData.dossier.lastMessageAt = lastFanAny.timestamp;
        saveContact(state.currentContact, { dossier: state.contactData.dossier });
      }
    }
    if (!state._dialogScan) {
      scheduleAnalysisAfterTranslations();
    }
  }
  function ensureDomObserver() {
    if (PLATFORM === "onlyfans") return;
    if (!isExtensionAlive() || !PLAT.isMessagesPage()) return;
    const cur = q("messageContent");
    if (!cur) return;
    const t2 = state._obsTarget;
    if (state.observer && t2 && t2.isConnected && t2 === cur) return;
    console.log("[FanslyAI] \u{1FA9E} observer \u043C\u0451\u0440\u0442\u0432/\u043D\u0430 \u0447\u0443\u0436\u043E\u0439 \u043B\u0435\u043D\u0442\u0435 \u2192 \u043F\u0435\u0440\u0435\u0432\u0435\u0448\u0438\u0432\u0430\u044E | obs=" + !!state.observer + " connected=" + (t2 ? t2.isConnected : "\u2014") + " same=" + (t2 === cur) + " \u043B\u0435\u043D\u0442 \u0432 DOM=" + qa("messageContent").length);
    startDomObserver(cur);
    scheduleMirrorScan();
  }
  function startDomObserver(container) {
    if (state.observer) state.observer.disconnect();
    state._obsTarget = container;
    if (!state._obsWatchTimer) state._obsWatchTimer = setInterval(ensureDomObserver, 25e3);
    if (PLATFORM === "onlyfans") {
      state.observer = new MutationObserver(() => {
        clearTimeout(state._ofSyncTimer);
        state._ofSyncTimer = setTimeout(() => ONLYFANS.loadHistory(), 500);
      });
      state.observer.observe(container, { childList: true, subtree: true });
      return;
    }
    state.observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (PLAT.isMessageNode(node)) processMessageNode(node);
          qa("messageNode", node).forEach((n) => processMessageNode(n));
        });
      });
    });
    state.observer.observe(container, { childList: true, subtree: true });
    if (container._faiScrollBound) return;
    container._faiScrollBound = true;
    container.addEventListener("scroll", () => {
      if (container.scrollTop < 400) {
        state.historyScrolling = true;
        clearTimeout(state._scrollTimer);
        state._scrollTimer = setTimeout(() => {
          state.historyScrolling = false;
          renderWindowFromDom();
        }, 1200);
      }
    }, { passive: true });
  }
  function renderWindowFromDom() {
    const historyEl = document.getElementById("fai-chat-history");
    if (!historyEl) return;
    historyEl.innerHTML = "";
    qa("messageNode").forEach((node) => {
      const isOwn = PLAT.isOwn(node);
      const role = isOwn ? "model" : "subscriber";
      const hasMedia = bodyMediaEl(node);
      const text = getMessageText(node);
      if (!text && !hasMedia) return;
      const entry = {
        role,
        text: text || "",
        isMedia: !!hasMedia && !text,
        mediaType: hasMedia ? detectMediaType(node) : null,
        timestamp: PLAT.timeOf(node) || Date.now()
        // реальное время сообщения (панель рисует его), не время перерисовки
      };
      const msgEl = appendMessageToHistory(entry);
      if (text && msgEl) translateMsgForDisplay(text, msgEl, role === "model" ? outGenders() : inGenders());
    });
  }
  function detectContact() {
    if (PLATFORM === "onlyfans") return ONLYFANS.detectContact();
    state.currentContactId = extractContactIdFromUrl();
    if (state.contactData && state._dataFor && state.currentContactId && state._dataFor !== "fai_contact_" + state.currentContactId) {
      console.log("[FanslyAI] contactData \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u0447\u0430\u0442\u0443 (" + state._dataFor + ") \u2192 \u0441\u0431\u0440\u043E\u0441 \u0434\u043E \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u043D\u043E\u0432\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438");
      state.contactData = null;
      state._dataFor = null;
    }
    const header = q("contactHeader");
    if (header) {
      const { name, unresolved } = chatNameFrom(header);
      state.currentContact = name;
      state._nameUnresolved = unresolved;
    }
  }
  async function resolveNamePoll() {
    if (PLATFORM !== "fansly") return;
    const id0 = state.currentContactId;
    const header = q("contactHeader");
    if (!header) return;
    const readName = () => {
      const el = q("displayName", header);
      return cleanContactName(el ? el.textContent : "");
    };
    let resolved = null;
    for (let i = 0; i < 12; i++) {
      const nm = readName();
      if (nm && !/^unknown/i.test(nm) && !/…|\.\.\./.test(nm)) {
        resolved = nm;
        break;
      }
      if (!state._nameUnresolved) return;
      await sleep(500);
    }
    if (state.currentContactId !== id0) return;
    if (!state.contactData) return;
    if (resolved) {
      state.currentContact = resolved;
      state._nameUnresolved = false;
      const upd = { name: resolved, nameResolved: true };
      if (state.contactData.unknownConfirmed || state.contactData.unknownSeen) {
        upd.unknownConfirmed = false;
        upd.unknownSeen = 0;
      }
      Object.assign(state.contactData, upd);
      saveContact(state.currentContact, upd);
      updatePanelContact();
    } else if (state._nameUnresolved) {
      const seen = (state.contactData.unknownSeen || 0) + 1;
      const upd = { unknownSeen: seen, unknownLast: Date.now() };
      if (seen >= 2) upd.unknownConfirmed = true;
      Object.assign(state.contactData, upd);
      saveContact(state.currentContact, upd);
    }
  }
  function onContactChange() {
    if (state.contactTimer) clearTimeout(state.contactTimer);
    state.contactTimer = setTimeout(() => {
      detectContact();
      clearTimeout(state._dossierDeltaTimer);
      state.historyScrolling = false;
      clearTimeout(state._scrollTimer);
      if (carousel.running) return;
      if (state.observer) {
        state.observer.disconnect();
        state.observer = null;
      }
      const panel = document.getElementById("fansly-ai-panel");
      const panelVisible = panel && panel.style.display !== "none";
      if (panelVisible) {
        clearSuggestions();
        activateForContact();
      } else {
        state.active = false;
        state.contactData = null;
        state._crm = null;
        state._crmHandle = null;
        if (panel) {
          updatePanelContact();
          clearSuggestions();
          const title = document.querySelector(".fai-title");
          if (title) title.textContent = "\u{1F916}";
          const historyEl = document.getElementById("fai-chat-history");
          if (historyEl) historyEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.clickToActivate">${t("panel.history.clickToActivate", state.uiLang)}</div>`;
          state.chatHistory = [];
          state._histFor = null;
          state.translateQueue = [];
          updateStats();
        }
      }
    }, CONFIG.CONTACT_DELAY);
  }
  function normColor(c) {
    if (!c) return "";
    c = c.trim().toLowerCase();
    const hex = c.match(/^#([0-9a-f]{6})$/i);
    if (hex) {
      const n = parseInt(hex[1], 16);
      return `rgb(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255})`;
    }
    return c.replace(/\s+/g, " ").replace(/,(?=\S)/g, ", ");
  }
  function subTitleKey(isSub) {
    if (BUILD === "full") return isSub ? "panel.sub.title.autoOn" : "panel.sub.title.autoOff";
    return isSub ? "panel.sub.title.on" : "panel.sub.title.off";
  }
  function tierNameByColor(color) {
    if (!color || !state.tiers?.length) return null;
    const want = normColor(color);
    const hit = state.tiers.find((t2) => t2.color && normColor(t2.color) === want);
    return hit ? hit.name : null;
  }
  function applyFanStatusFromHeader() {
    if (PLATFORM === "onlyfans") return ONLYFANS.applyFanStatus();
    const head = q("contactHeader");
    if (!head || !state.contactData || !state.currentContact) return;
    const star = head.querySelector("i.fa-star");
    const tierColor = star ? star.closest(".user-icon")?.style?.color || null : null;
    const upd = {};
    if (star) {
      if (!state.contactData.isSubscribed) upd.isSubscribed = true;
      const tn = tierNameByColor(tierColor);
      if (tierColor && tierColor !== state.contactData.tierColor) upd.tierColor = tierColor;
      if (tn && tn !== state.contactData.tierName) upd.tierName = tn;
    }
    const _headerReady = !!(q("displayName", head)?.textContent || "").trim();
    const _cardIcon = !!head.querySelector("i.fa-credit-card");
    if (_cardIcon && !state.contactData.hasCard) upd.hasCard = true;
    else if (!_cardIcon && _headerReady && state.contactData.hasCard) upd.hasCard = false;
    if (head.querySelector("i.fa-arrow-rotate-right") && !state.contactData.autoRenew) upd.autoRenew = true;
    if (head.querySelector("i.fa-badge") && !state.contactData.isCreator) upd.isCreator = true;
    if (Object.keys(upd).length) {
      Object.assign(state.contactData, upd);
      saveContact(state.currentContact, upd);
      console.log("[FanslyAI] \u0421\u0442\u0430\u0442\u0443\u0441\u044B \u0438\u0437 \u0448\u0430\u043F\u043A\u0438:", JSON.stringify(upd));
    }
    const subBtn = document.getElementById("fai-subscribed");
    if (subBtn && state.contactData.isSubscribed) {
      subBtn.textContent = "\u2B50";
      subBtn.title = t(subTitleKey(true), state.uiLang);
    }
    const tierEl = document.getElementById("fai-tier");
    if (tierEl) {
      const tn = state.contactData.tierName;
      tierEl.textContent = tn ? tn.slice(0, 12) : "";
      tierEl.title = tn ? t("panel.tier.title", state.uiLang, { tier: tn }) + (state.contactData.hasCard ? t("panel.tier.cardSuffix", state.uiLang) : "") : "";
    }
    clearFollowerStar();
  }
  const ensureConsent = () => {
    try {
      FaiConsent.ask();
    } catch (e) {
    }
  };
  function activateForContact(nameHint = null, idHint = null) {
    state.active = true;
    ensureConsent();
    if (idHint) state.currentContactId = idHint;
    detectContact();
    if (!state.currentContact && nameHint) {
      state.currentContact = nameHint;
    }
    state.contactData = null;
    state._dataFor = null;
    state.chatHistory = [];
    state._histFor = null;
    const _histEl = document.getElementById("fai-chat-history");
    if (_histEl) _histEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.loading">${t("panel.history.loading", state.uiLang)}</div>`;
    clearTimeout(state._dossierDeltaTimer);
    state.activatedAt = Date.now();
    state._mirrorLiveCount = 0;
    state._mirrorLiveAt = 0;
    state._mirrorLiveFor = null;
    state._mirrorLastNode = null;
    state._mirrorFeedLen = 0;
    state._mirrorLive = false;
    state._mirrorInFlight = false;
    clearTimeout(state._mirrorTimer);
    try {
      if (carousel && carousel.rowResync && state.currentContactId) delete carousel.rowResync[state.currentContactId];
    } catch (e) {
    }
    state.suppressUntil = Date.now() + 4500;
    const ident = headerIdentity(state.currentContactId);
    const handle = ident.handle;
    if (ident.trusted && ident.name) state.currentContact = ident.name;
    else if (!ident.trusted && nameHint) state.currentContact = nameHint;
    if (!ident.trusted) console.log("[FanslyAI] \u043D\u0438\u043A \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D id \u2014 \u0432 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u043D\u0435 \u043F\u0438\u0448\u0443 (#180)");
    createPanel();
    updatePanelContact();
    clearSuggestions();
    clearSendFailed();
    chatLayoutProbe();
    const _idAtLoad = state.currentContactId;
    loadContact(state.currentContact, handle).then((contact) => {
      if (state.currentContactId !== _idAtLoad) {
        console.log("[FanslyAI] \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \u0441\u043C\u0435\u043D\u0438\u043B\u0441\u044F, \u043F\u043E\u043A\u0430 \u0433\u0440\u0443\u0437\u0438\u043B\u0430\u0441\u044C \u0437\u0430\u043F\u0438\u0441\u044C \u2014 \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u044E");
        return;
      }
      if (contact.note && contact.note.trim()) {
        if (!contact.dossier) {
          contact.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
        }
        const note = contact.note.trim();
        if (!contact.dossier.manualFacts) contact.dossier.manualFacts = [];
        if (!contact.dossier.facts.includes(note)) {
          contact.dossier.facts.unshift(note);
          if (contact.dossier.manualFacts.length < PINNED_MAX && !contact.dossier.manualFacts.includes(note)) contact.dossier.manualFacts.push(note);
          contact.note = "";
          saveContact(state.currentContact, { note: "", dossier: contact.dossier });
        }
      }
      const updates = {};
      if (handle && contact.handle !== handle) {
        updates.handle = handle;
      }
      const newName = state.currentContact;
      if (state._nameUnresolved || !ident.trusted || !healthyName(newName)) {
      } else if (contact.name && !healthyName(contact.name) && contact.name !== newName) {
        updates.name = newName;
        if (Array.isArray(contact.nameHistory) && contact.nameHistory.some((h) => !healthyName(h))) updates.nameHistory = contact.nameHistory.filter(healthyName);
        console.log(`[FanslyAI] \u0438\u043C\u044F \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u043E\u0447\u0438\u043D\u0435\u043D\u043E: "${contact.name}" \u2192 "${newName}" (\u043E\u0431\u0440\u0435\u0437\u043A\u0430/Unknown, \u043D\u0435 \u0441\u043C\u0435\u043D\u0430 \u043D\u0438\u043A\u0430)`);
      } else if (newName && contact.name && contact.name !== newName) {
        const history = contact.nameHistory || [];
        if (!history.includes(contact.name)) history.push(contact.name);
        updates.nameHistory = history;
        updates.name = newName;
        const handleStr = handle ? ` (@${handle})` : "";
        setStatus(t("panel.status.nickChanged", state.uiLang, { old: contact.name, new: newName, handle: handleStr }));
        console.log(`[FanslyAI] Nick changed: "${contact.name}" \u2192 "${newName}"${handleStr}`);
      } else if (newName && !contact.name) {
        updates.name = newName;
      }
      if (Object.keys(updates).length) {
        Object.assign(contact, updates);
        saveContact(state.currentContact, updates);
      }
      state.fanGender = contact.gender || "male";
      state.contactData = contact;
      state._dataFor = keyOfCurrent();
      updateGenderBtn();
      const subBtn = document.getElementById("fai-subscribed");
      if (subBtn) subBtn.textContent = contact.isSubscribed ? "\u2B50" : "\u2606";
      if (subBtn) subBtn.title = t(subTitleKey(contact.isSubscribed), state.uiLang);
      const langBtn = document.getElementById("fai-fan-lang");
      if (langBtn) langBtn.textContent = (contact.lang || "en").toUpperCase();
      updatePanelContact();
      updateExcludeBtn();
      renderDossier();
      renderBrief();
      restoreCoach();
      resolveNamePoll();
      setTimeout(applyFanStatusFromHeader, 2500);
    });
    sendSafe({ type: "GET_SETTINGS" }).then((r) => {
      if (r?.result) {
        state.nativeLang = r.result.nativeLanguage || "ru";
        state.maxWords = r.result.maxWords ?? 0;
        state.customIntents = r.result.customIntents || [];
        const mwInput = document.getElementById("fai-maxwords-input");
        if (mwInput) mwInput.value = state.maxWords;
      }
    });
    chrome.storage.local.get("fansly_tiers", (d) => {
      state.tiers = d.fansly_tiers?.list || [];
    });
    const title = document.querySelector(".fai-title");
    if (title) title.textContent = "\u{1F916}\u25CF";
    const _attachFeed = (ms) => waitForElement(selStr("messageContent"), ms).then((container) => {
      startDomObserver(container);
      setTimeout(() => loadExistingMessages(), 1500);
    });
    _attachFeed(8e3).catch(() => _attachFeed(15e3)).catch(() => {
      console.warn("[FanslyAI] \u043B\u0435\u043D\u0442\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043D\u0435 \u043F\u043E\u044F\u0432\u0438\u043B\u0430\u0441\u044C \u2014 \u0438\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0443\u0441\u0442\u0430 (\u0447\u0443\u0436\u0430\u044F \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0430 \u0432 \u0418\u0418 \u043D\u0435 \u0443\u0439\u0434\u0451\u0442)");
      state.chatHistory = [];
      state._histFor = state.currentContactId;
    });
  }
  function watchContactChanges() {
    let lastUrl = location.href;
    new MutationObserver(() => {
      if (location.href === lastUrl) return;
      lastUrl = location.href;
      onContactChange();
    }).observe(document, { subtree: true, childList: true });
  }
  function injectActivationButtons() {
    const contacts = qa("contactLink");
    contacts.forEach((contactEl) => {
      if (contactEl.querySelector(".fai-activate-btn")) return;
      const nameEl = q("displayName", contactEl);
      if (!nameEl) return;
      const btn = document.createElement("span");
      btn.className = "fai-activate-btn";
      btn.textContent = "\u{1F7E3}";
      btn.title = t("panel.activate.title", state.uiLang);
      btn.style.cssText = "pointer-events: auto !important; cursor: pointer !important;";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        state._panelShown = true;
        persistSetting("panelHidden", false);
        const panel = document.getElementById("fansly-ai-panel");
        if (panel) {
          panel.style.display = "";
          panel.classList.remove("collapsed");
          const colBtn = document.getElementById("fai-collapse-btn");
          if (colBtn) colBtn.textContent = "\u25B2";
        }
        let nameFromBtn = chatNameFrom(contactEl).name;
        if (PLATFORM === "onlyfans") nameFromBtn = cleanContactName(nameEl.innerText) || null;
        const idFromHref = PLAT.contactIdFromHref(contactEl.getAttribute("href"));
        contactEl.click();
        setTimeout(() => activateForContact(nameFromBtn, idFromHref), CONFIG.CONTACT_DELAY + 200);
      });
      nameEl.parentNode.insertBefore(btn, nameEl.nextSibling);
    });
  }
  function watchContactList() {
    const tryAttach = () => {
      const listEl = q("contactList");
      if (!listEl) {
        setTimeout(tryAttach, 1e3);
        return;
      }
      injectActivationButtons();
      new MutationObserver(() => injectActivationButtons()).observe(listEl, { childList: true, subtree: true });
    };
    tryAttach();
  }
  try {
    window.__faiScan = scanUnread2;
  } catch (e) {
  }
  window.__faiCrmDump = async function() {
    const c = state.contactData || null;
    console.log("%c=== \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430 ===", "font-weight:bold");
    console.log({
      key: keyOfCurrent(),
      currentContactId: state.currentContactId,
      /* id-guard: отладочный дамп __faiCrmDump, только чтение и вывод в консоль — записи нет */
      name: state.currentContact,
      handle: c && c.handle,
      isSubscribed: c && c.isSubscribed,
      tierName: c && c.tierName,
      hasCard: c && c.hasCard
    });
    console.log("%c=== \u043A\u0435\u0448 CRM (\u0442\u043E, \u0447\u0442\u043E \u043D\u0430\u0440\u0438\u0441\u043E\u0432\u0430\u043D\u043E) ===", "font-weight:bold");
    console.log("_crmHandle:", state._crmHandle, "| _crm:", state._crm);
    if (!c || !c.handle) {
      console.warn("handle \u043F\u0443\u0441\u0442 \u2192 renderCrm \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0441\u0440\u0430\u0437\u0443 \u0438 \u043F\u0440\u044F\u0447\u0435\u0442 \u0431\u043B\u043E\u043A");
      return;
    }
    const stores = await new Promise((r) => chrome.storage.local.get(CRM.STORE_KEYS, (d) => r(d)));
    const fresh = crmSummary(c.handle, stores, c);
    console.log("%c=== \u041F\u0415\u0420\u0415\u0421\u0427\u0401\u0422 \u0441\u0435\u0439\u0447\u0430\u0441 ===", "font-weight:bold");
    console.log(fresh);
    console.log("%c=== \u0412\u042B\u0412\u041E\u0414 ===", "font-weight:bold;color:#e91e8c");
    if (!fresh) console.log("crmSummary \u0432\u0435\u0440\u043D\u0443\u043B null \u2192 \u0432 \u0441\u0442\u043E\u0440\u0430\u0445 \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E handle \u043F\u0443\u0441\u0442\u043E (\u0441\u0432\u0435\u0440\u044C \u0440\u0435\u0433\u0438\u0441\u0442\u0440 \u043A\u043B\u044E\u0447\u0435\u0439)");
    else if (!state._crm) console.log("\u041F\u0415\u0420\u0415\u0421\u0427\u0401\u0422 \u0434\u0430\u0451\u0442 \u0434\u0430\u043D\u043D\u044B\u0435, \u0430 \u0432 \u043A\u0435\u0448\u0435 \u043F\u0443\u0441\u0442\u043E \u2192 \u0431\u043B\u043E\u043A \u043A\u0440\u0430\u0441\u0438\u043B\u0441\u044F \u0414\u041E \u0442\u043E\u0433\u043E, \u043A\u0430\u043A \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u0438\u0435\u0445\u0430\u043B\u0438; \u043A\u0435\u0448 \u043F\u043E handle \u043D\u0435 \u043F\u0435\u0440\u0435\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u0435\u0442\u0441\u044F");
    else console.log("\u043A\u0435\u0448 \u0438 \u043F\u0435\u0440\u0435\u0441\u0447\u0451\u0442 \u043E\u0431\u0430 \u0435\u0441\u0442\u044C \u2014 \u0441\u043C\u043E\u0442\u0440\u0438, \u043A\u0430\u043A\u0438\u0435 \u0447\u0438\u043F\u044B \u043E\u0442\u0444\u0438\u043B\u044C\u0442\u0440\u043E\u0432\u0430\u043B\u0438\u0441\u044C \u0443\u0441\u043B\u043E\u0432\u0438\u044F\u043C\u0438 \u0432 paintCrm");
  };
  window.__faiDumpHistory = function(opts) {
    opts = opts || {};
    const history = collectHistoryFromDom();
    if (!history.length) {
      console.warn("[FanslyAI] \u{1F4E4} \u043B\u0435\u043D\u0442\u0430 \u043F\u0443\u0441\u0442\u0430 \u0438\u043B\u0438 \u0432 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u043D\u043E\u043C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0438 \u2014 \u043E\u0442\u043A\u0440\u043E\u0439 \u0447\u0430\u0442 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438");
      return;
    }
    const msgs = history.filter((m) => m.text && !m.isMedia);
    const fanName = state.currentContact || "Fan";
    const fmt = (arr) => arr.map((m) => `${m.role === "subscriber" ? fanName : "Creator"}: ${m.text}`).join("\n");
    const transcript = fmt(msgs);
    const dump = {
      fanName,
      contactId: state.currentContactId || null,
      dumpedAt: (/* @__PURE__ */ new Date()).toISOString(),
      counts: {
        dom: history.length,
        // всего собрано из ленты
        analyzed: msgs.length,
        // ← это число печатает лог как «msgs:»
        subscriber: msgs.filter((m) => m.role === "subscriber").length,
        creator: msgs.filter((m) => m.role === "model").length,
        mediaSkipped: history.length - msgs.length,
        noTs: msgs.filter((m) => !m.ts).length
        // без даты → дельта их не увидит, дата факта не найдётся
      },
      transcriptChars: transcript.length,
      groupsAtCurrentLimit: Math.max(1, Math.ceil(msgs.reduce((s, m) => s + (m.text || "").length + 24, 0) / 12e4)),
      knownFacts: (state.contactData?.dossier?.facts || []).slice(0, 60),
      // ← ровно то, что уходит как «не повторяй»
      history: msgs,
      // [{role,text,isMedia,ts}] как уходит в ANALYZE_HISTORY
      transcript
      // дословно то, что подставляется в промпт
    };
    const c = dump.counts;
    console.log(`[FanslyAI] \u{1F4E4} \u0438\u0437 \u043B\u0435\u043D\u0442\u044B ${c.dom} \u2192 \u0432 \u0430\u043D\u0430\u043B\u0438\u0437 ${c.analyzed} (\u0444\u0430\u043D ${c.subscriber} \xB7 \u043A\u0440\u0438\u0435\u0439\u0442\u0435\u0440 ${c.creator} \xB7 \u043C\u0435\u0434\u0438\u0430 \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438 ${c.mediaSkipped} \xB7 \u0431\u0435\u0437 \u0434\u0430\u0442\u044B ${c.noTs})`);
    console.log(`[FanslyAI] \u{1F4E4} ${dump.transcriptChars} \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432 \u2192 \u043A\u0443\u0441\u043A\u043E\u0432 \u043F\u0440\u0438 \u043D\u044B\u043D\u0435\u0448\u043D\u0435\u043C \u043F\u0440\u0435\u0434\u0435\u043B\u0435: ${dump.groupsAtCurrentLimit}; \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0445 \u0444\u0430\u043A\u0442\u043E\u0432: ${dump.knownFacts.length}`);
    if (opts.log) console.log(dump);
    try {
      const blob = new Blob([JSON.stringify(dump, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fai-history-${String(fanName).replace(/[^\w\-]+/g, "_")}-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 16).replace(/[:T]/g, "")}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1e4);
      console.log("[FanslyAI] \u{1F4E4} \u0444\u0430\u0439\u043B \u0432\u044B\u0433\u0440\u0443\u0436\u0435\u043D \u0432 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438. \u041D\u0435 \u0441\u043A\u0430\u0447\u0430\u043B\u043E\u0441\u044C \u2014 \u0432\u044B\u0437\u043E\u0432\u0438 __faiDumpHistory({log:true}) \u0438 \u0441\u043A\u043E\u043F\u0438\u0440\u0443\u0439 \u043E\u0431\u044A\u0435\u043A\u0442 \u0438\u0437 \u043A\u043E\u043D\u0441\u043E\u043B\u0438");
    } catch (e) {
      console.warn("[FanslyAI] \u{1F4E4} \u0441\u043A\u0430\u0447\u0430\u0442\u044C \u043D\u0435 \u0432\u044B\u0448\u043B\u043E (" + e.message + ") \u2192 \u043E\u0431\u044A\u0435\u043A\u0442 \u043D\u0438\u0436\u0435, \u043A\u043E\u043F\u0438\u0440\u0443\u0439 \u0438\u0437 \u043A\u043E\u043D\u0441\u043E\u043B\u0438");
      console.log(dump);
    }
    return dump;
  };
  window.__faiDossierAudit = function(opts) {
    opts = opts || {};
    chrome.storage.local.get(null, (all) => {
      const contacts = [];
      for (const k in all) {
        if (!k.startsWith("fai_contact_")) continue;
        const c = all[k];
        if (!c || !c.dossier || !Array.isArray(c.dossier.facts) || !c.dossier.facts.length) continue;
        contacts.push({ key: k, data: c, name: c.name || c.handle || k, handle: c.handle || "", facts: c.dossier.facts });
      }
      const norm = (f) => String(f).trim().replace(/\s+/g, " ").toLowerCase();
      const byFact = /* @__PURE__ */ new Map();
      for (const c of contacts) for (const f of c.facts) {
        const n = norm(f);
        if (!n) continue;
        if (!byFact.has(n)) byFact.set(n, []);
        if (!byFact.get(n).includes(c)) byFact.get(n).push(c);
      }
      const shared = [], pairCount = /* @__PURE__ */ new Map();
      for (const [f, cs] of byFact) {
        if (cs.length < 2) continue;
        shared.push({ "\u0444\u0430\u043A\u0442": f.slice(0, 80), "\u0443 \u043A\u043E\u0433\u043E": cs.map((c) => c.name).join(" | ") });
        for (let i = 0; i < cs.length; i++) for (let j = i + 1; j < cs.length; j++) {
          const pk = [cs[i].name, cs[j].name].sort().join(" \u21C4 ");
          pairCount.set(pk, (pairCount.get(pk) || 0) + 1);
        }
      }
      console.log("[FanslyAI] \u{1F9EC} \u0430\u0443\u0434\u0438\u0442 \u0434\u043E\u0441\u044C\u0435: \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043E\u0432 \u0441 \u0444\u0430\u043A\u0442\u0430\u043C\u0438 " + contacts.length + ", \u043E\u0431\u0449\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0432 " + shared.length);
      if (shared.length) {
        console.table(shared);
        console.table([...pairCount.entries()].sort((a, b) => b[1] - a[1]).map(([p, n]) => ({ "\u043F\u0430\u0440\u0430": p, "\u043E\u0431\u0449\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0432": n })));
        console.log('[FanslyAI] \u{1F9EC} \u0441\u0435\u0440\u0438\u044F \u043E\u0431\u0449\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0432 \u0443 \u043F\u0430\u0440\u044B = \u043F\u043E\u0447\u0442\u0438 \u043D\u0430\u0432\u0435\u0440\u043D\u044F\u043A\u0430 \u0437\u0430\u0440\u0430\u0436\u0435\u043D\u0438\u0435. \u0427\u0438\u0441\u0442\u043A\u0430: __faiDossierAudit({ removeSharedFrom: "\u0438\u043C\u044F \u0438\u043B\u0438 handle" })');
      } else {
        console.log("[FanslyAI] \u{1F9EC} \u0434\u043E\u0441\u043B\u043E\u0432\u043D\u044B\u0445 \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u0439 \u0444\u0430\u043A\u0442\u043E\u0432 \u043C\u0435\u0436\u0434\u0443 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430\u043C\u0438 \u043D\u0435\u0442");
      }
      if (opts.removeSharedFrom) {
        const q2 = String(opts.removeSharedFrom).trim().toLowerCase();
        const target = contacts.find((c) => c.name.toLowerCase() === q2 || c.handle.toLowerCase() === q2);
        if (!target) {
          console.warn("[FanslyAI] \u{1F9EC} \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \xAB" + opts.removeSharedFrom + "\xBB \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D (\u0438\u0449\u0443 \u043F\u043E \u0442\u043E\u0447\u043D\u043E\u043C\u0443 \u0438\u043C\u0435\u043D\u0438 \u0438\u043B\u0438 handle)");
          return;
        }
        const foreign = /* @__PURE__ */ new Set();
        for (const [f, cs] of byFact) if (cs.length > 1 && cs.includes(target)) foreign.add(f);
        const keep = [], removed = [];
        for (const f of target.facts) (foreign.has(norm(f)) ? removed : keep).push(f);
        if (!removed.length) {
          console.log("[FanslyAI] \u{1F9EC} \u0443 \xAB" + target.name + "\xBB \u043D\u0435\u0442 \u0444\u0430\u043A\u0442\u043E\u0432, \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0449\u0438\u0445 \u0441 \u0447\u0443\u0436\u0438\u043C\u0438 \u2014 \u0443\u0434\u0430\u043B\u044F\u0442\u044C \u043D\u0435\u0447\u0435\u0433\u043E");
          return;
        }
        target.data.dossier.facts = keep;
        if (target.data.dossier.factDates) for (const f of removed) delete target.data.dossier.factDates[f];
        if (target.data.dossier.manualFacts) target.data.dossier.manualFacts = target.data.dossier.manualFacts.filter((f) => !removed.includes(f));
        chrome.storage.local.set({ [target.key]: target.data }, () => {
          console.log("[FanslyAI] \u{1F9EC} \u0443 \xAB" + target.name + "\xBB \u0443\u0434\u0430\u043B\u0435\u043D\u043E \u0444\u0430\u043A\u0442\u043E\u0432: " + removed.length + " (\u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C " + keep.length + ")");
          removed.forEach((f) => console.log("   \u2212 " + f));
        });
      }
    });
  };
  window.__faiDiagnose = function() {
    const b = document.getElementById("fai-diagnose-btn");
    if (!b) {
      console.warn("[FanslyAI] \u{1F52C} \u043A\u043D\u043E\u043F\u043A\u0430 \u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0438 \u0435\u0441\u0442\u044C \u0442\u043E\u043B\u044C\u043A\u043E \u0432 full-\u0441\u0431\u043E\u0440\u043A\u0435");
      return;
    }
    console.log("[FanslyAI] \u{1F52C} \u0431\u0438\u0441\u0435\u043A\u0442 \u0446\u0435\u043D\u0437\u0443\u0440\u044B Gemini \u043F\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u043C\u0443 \u0447\u0430\u0442\u0443 \u2014 \u043D\u0443\u0436\u0435\u043D \u0441\u0432\u043E\u0439 Gemini-\u043A\u043B\u044E\u0447 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043D\u0438\u0436\u0435 \u0438 \u0432 \u0441\u0442\u0430\u0442\u0443\u0441\u0435 \u043F\u0430\u043D\u0435\u043B\u0438");
    b.click();
  };
  window.__faiPanelRev = function() {
    const panel = document.getElementById("fansly-ai-panel");
    const onScreen = panel ? panel.dataset.faiRev || "(\u043D\u0435\u0442 \u043C\u0435\u0442\u043A\u0438 \u2014 \u043F\u0430\u043D\u0435\u043B\u044C \u043E\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0431\u043E\u0440\u043A\u0438)" : "(\u043F\u0430\u043D\u0435\u043B\u0438 \u043D\u0435\u0442 \u0432 DOM)";
    console.log("[FanslyAI] \u0440\u0435\u0432\u0438\u0437\u0438\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0438 \u043F\u0430\u043D\u0435\u043B\u0438: \u0432 \u043A\u043E\u0434\u0435 " + PANEL_REV + " | \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 " + onScreen);
    if (panel && panel.dataset.faiRev !== PANEL_REV) console.warn("[FanslyAI] \u26A0\uFE0F \u0440\u0430\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u2014 \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5), \u0438\u043D\u0430\u0447\u0435 \u043F\u0440\u0430\u0432\u043E\u043A \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0438 \u043D\u0435 \u0443\u0432\u0438\u0434\u0438\u0448\u044C");
    else if (panel) console.log("[FanslyAI] \u2705 \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430");
  };
  window.__faiHelp = function() {
    const fns = [
      ["__faiHelp()", "\u044D\u0442\u0430 \u0441\u043F\u0440\u0430\u0432\u043A\u0430"],
      ["__faiPanelRev()", "\u0440\u0435\u0432\u0438\u0437\u0438\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0438 \u043F\u0430\u043D\u0435\u043B\u0438: \u0432 \u043A\u043E\u0434\u0435 vs \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 (\u0440\u0430\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435 = \u043D\u0443\u0436\u0435\u043D F5, \u043F\u0440\u0430\u0432\u043A\u0438 \u043D\u0435 \u0432\u0438\u0434\u043D\u044B)"]
    ];
    fns.push(
      ["__faiSel()", "\u0440\u0435\u0435\u0441\u0442\u0440 DOM-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440\u043E\u0432: \u043A\u0430\u043A\u0438\u0435 \u043A\u043B\u044E\u0447\u0438 \u043D\u0430\u0448\u043B\u0438\u0441\u044C \u043D\u0430 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 (\u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \u0440\u0435\u0434\u0438\u0437\u0430\u0439\u043D\u0430 Fansly)"],
      ["__faiHealth()", "\u0445\u0430\u0440\u0442\u0431\u0438\u0442 \u0432\u043A\u043B\u0430\u0434\u043A\u0438: \u0440\u0430\u0437\u0440\u044B\u0432\u044B = \u0437\u0430\u043C\u043E\u0440\u043E\u0437\u043A\u0438/\u0443\u0441\u044B\u043F\u043B\u0435\u043D\u0438\u0435 (\u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \xAB\u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0432\u0441\u0442\u0430\u043B\u0430\xBB)"],
      ["__faiHealthWatch(\u043C\u0438\u043D)", "\u0438\u043D\u0442\u0435\u043D\u0441\u0438\u0432\u043D\u044B\u0439 \u0437\u0430\u043C\u0435\u0440 \u0442\u0438\u043A\u043E\u0432 ~15\u0441: drift/\u0432\u0438\u0434\u0438\u043C\u043E\u0441\u0442\u044C/\u0444\u043E\u043A\u0443\u0441/keep-alive (\u043B\u043E\u043A \u044D\u043A\u0440\u0430\u043D\u0430, RDP)"],
      ["__faiMirrorLog(n)", '\u0436\u0443\u0440\u043D\u0430\u043B \u0440\u0435\u0448\u0435\u043D\u0438\u0439 \u0437\u0435\u0440\u043A\u0430\u043B\u0430 (\u043F\u0435\u0440\u0435\u0436\u0438\u0432\u0430\u0435\u0442 F5): \u043F\u0443\u0442\u044C \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0431\u043B\u043E\u043A\u0430, \u0441\u0442\u0440\u043E\u043A\u0438 \u0434\u043E \u0438 \u043F\u043E\u0441\u043B\u0435 \u0434\u0435\u0434\u0443\u043F\u0430, \u0447\u044C\u0438, \u0441 \u043F\u043E\u043C\u0435\u0442\u043A\u043E\u0439 \xAB\u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E\xBB (#158); ("clear") \u2014 \u043E\u0447\u0438\u0441\u0442\u0438\u0442\u044C'],
      ["__faiReport()", "\u0442\u043E \u0436\u0435 \u043A\u043E\u043B\u044C\u0446\u043E \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u043C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u0441\u044B\u043B\u043A\u0438: \u043F\u0440\u043E\u0432\u0430\u043B\u044B, \u0441\u0442\u043E\u044F\u0449\u0438\u0439 \u0448\u0430\u0433, \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438, \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u0431\u0430\u0433\u0440\u0435\u043F\u043E\u0440\u0442\u043E\u0432"],
      ["__faiScan()", "\u0434\u0430\u043C\u043F \u0438\u043D\u0434\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043D\u0435\u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u043E \u0441\u0442\u0440\u043E\u043A\u0430\u043C \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u0438\u0430\u043B\u043E\u0433\u043E\u0432 (\u043A\u043E\u0433\u0434\u0430 \u0431\u0435\u0439\u0434\u0436\u0438 \xAB\u043D\u0435 \u0432\u0438\u0434\u044F\u0442\u0441\u044F\xBB)"],
      ["__faiDiagnose()", "\u0431\u0438\u0441\u0435\u043A\u0442 \u0446\u0435\u043D\u0437\u0443\u0440\u044B GEMINI \u043F\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u043C\u0443 \u0447\u0430\u0442\u0443 (\u043D\u0443\u0436\u0435\u043D \u0441\u0432\u043E\u0439 Gemini-\u043A\u043B\u044E\u0447; \u0434\u0440\u0443\u0433\u0438\u043C \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430\u043C \u0442\u0435\u0441\u0442 \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C)"],
      ["__faiDossierAudit()", "\u043F\u043E\u0438\u0441\u043A \u0437\u0430\u0440\u0430\u0436\u0435\u043D\u0438\u044F \u0434\u043E\u0441\u044C\u0435: \u0434\u043E\u0441\u043B\u043E\u0432\u043D\u043E \u043E\u0431\u0449\u0438\u0435 \u0444\u0430\u043A\u0442\u044B \u0443 \u0440\u0430\u0437\u043D\u044B\u0445 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043E\u0432 + \u043F\u0430\u0440\u044B"],
      ['__faiDossierAudit({removeSharedFrom:"\u043D\u0438\u043A"})', "\u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0443 \u0423\u041A\u0410\u0417\u0410\u041D\u041D\u041E\u0413\u041E \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430 \u0444\u0430\u043A\u0442\u044B, \u0434\u043E\u0441\u043B\u043E\u0432\u043D\u043E \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0443 \u0434\u0440\u0443\u0433\u0438\u0445"],
      ["__faiDumpHistory()", "\u0432\u044B\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430 \u0432 JSON \u0440\u043E\u0432\u043D\u043E \u0432 \u0442\u043E\u043C \u0432\u0438\u0434\u0435, \u0432 \u043A\u0430\u043A\u043E\u043C \u043E\u043D\u0430 \u0443\u0445\u043E\u0434\u0438\u0442 \u0432 \u0430\u043D\u0430\u043B\u0438\u0437 \u0434\u043E\u0441\u044C\u0435 (\u0434\u043B\u044F \u0441\u0442\u0435\u043D\u0434\u0430)"],
      ["__faiVaultFailNext()", "\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043E \u0441\u0431\u043E\u0435: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0437\u0430\u043F\u0443\u0441\u043A \u0441\u043A\u0430\u043D\u0430 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430 \u0443\u043F\u0430\u0434\u0451\u0442 \u043E\u0434\u0438\u043D \u0440\u0430\u0437 (\u0432 \u043B\u044E\u0431\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435)"],
      ["__faiTrFailNext()", "\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0431\u043E\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0433\u043E (\u043A\u043D\u043E\u043F\u043A\u0430 \u2191 \u043F\u0430\u043D\u0435\u043B\u0438 \u0438\u043B\u0438 \u043E\u0442\u0432\u0435\u0442 \u0438\u0437 \u0422\u0413) \u043D\u0435 \u0443\u0434\u0430\u0441\u0442\u0441\u044F \u043E\u0434\u0438\u043D \u0440\u0430\u0437"]
    );
    const rows = fns.filter(([sig]) => {
      const name = sig.split("(")[0];
      return typeof window[name] === "function";
    }).map(([sig, desc]) => ({ "\u0444\u0443\u043D\u043A\u0446\u0438\u044F": sig, "\u0447\u0442\u043E \u0434\u0435\u043B\u0430\u0435\u0442": desc }));
    console.log("[FanslyAI] \u043A\u043E\u043D\u0441\u043E\u043B\u044C\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 (DevTools \u2192 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \xABVelour for Fansly\xBB):");
    console.table(rows);
  };
  function scanUnread2() {
    const rows = [];
    qa("contactLink").forEach((el) => {
      const nameEl = q("displayName", el);
      const name = nameEl ? chatNameFrom(el).name : "(?)";
      const markers = [];
      el.querySelectorAll("*").forEach((node) => {
        const c = node.className?.toString?.() || "";
        if (/badge|count|unread|unseen|notif|dot|indicator|new|pill/i.test(c)) {
          markers.push(`${c.trim().slice(0, 40)}="${(node.innerText || "").trim().slice(0, 10)}"`);
        }
      });
      const fw = nameEl ? getComputedStyle(nameEl).fontWeight : "";
      const aria = el.getAttribute("aria-label") || "";
      const ownCls = (el.className + " " + (el.parentElement?.className || "")).trim().slice(0, 100);
      rows.push({ name, fontWeight: fw, aria: aria.slice(0, 40), markers: markers.join(" | ") || "\u2205", ownCls });
    });
    console.log("[FanslyAI] \u2500\u2500 \u0420\u0410\u0417\u0412\u0415\u0414\u041A\u0410 2.0 (" + rows.length + ") \u2500\u2500");
    console.table(rows);
    rows.forEach((r) => console.log(`  ${r.name}: fw=${r.fontWeight} | markers: ${r.markers}`));
    return rows;
  }
  function findUnreadContacts(skipRowMirrored = false) {
    if (PLATFORM === "onlyfans") return ONLYFANS.findUnreadContacts();
    const out = [];
    qa("contactLink").forEach((el) => {
      const count = getUnreadCount(el);
      if (count <= 0) return;
      const nameEl = q("displayName", el);
      const name = nameEl ? chatNameFrom(el).name : "(?)";
      const id = PLAT.contactIdFromHref(el.getAttribute("href"));
      if (skipRowMirrored && id) {
        if (rowMirrorCovers(el, id)) return;
        if (rowPendingFor(id)) return;
        if (carousel.rowMirrored[id]) console.log("[FanslyAI] \u{1F514} rowMirror: \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u041D\u0415 \u043F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u043B\u0430", id, "| \u0431\u0435\u0439\u0434\u0436", count, "\u0443\u0447\u0451\u0442", JSON.stringify(carousel.rowMirrored[id]), "| \u043F\u0440\u0435\u0432\u044C\u044E", JSON.stringify(collapseKey(q("rowPreview", el)?.innerText || "").slice(0, 30)));
      }
      out.push({ el, id, name, count, ts: rowActivityTs(el) });
    });
    return out;
  }
  function markActivityHandled(id, ts) {
    if (!id) return;
    carousel.msgTs[id] = Math.max(carousel.msgTs[id] || 0, ts || Date.now());
    chrome.storage.local.set({ fansly_msg_ts: carousel.msgTs });
  }
  const ACT_TOL = 6e4;
  const ACT_BACKFILL_MAX = 5;
  function rowAlreadyHandled(id, el) {
    const last = carousel.lastRowPreview[id];
    if (last == null) return false;
    return collapseKey(q("rowPreview", el)?.innerText || "") === last;
  }
  function scanRecentActivity() {
    if (PLATFORM === "onlyfans") return [];
    const since = carousel.mirrorSince || 0, seen = carousel.msgTs || {};
    const out = [], noMark = [];
    qa("contactLink").forEach((el) => {
      const id = PLAT.contactIdFromHref(el.getAttribute("href"));
      if (!id) return;
      if (rowAlreadyHandled(id, el)) return;
      const act = rowActivityFull(el);
      if (!act) return;
      const ts = act.ts, mark = seen[id] || 0;
      if (ts <= since) return;
      if (mark && ts <= mark + act.step + ACT_TOL) return;
      if (rowMirrorCovers(el, id) || rowPendingFor(id)) return;
      const nameEl = q("displayName", el);
      const item = { el, id, name: nameEl ? chatNameFrom(el).name : "(?)", ts, fromActivity: true };
      (mark ? out : noMark).push(item);
    });
    if (noMark.length > ACT_BACKFILL_MAX) {
      noMark.sort((a, b) => b.ts - a.ts);
      const drop = noMark.splice(ACT_BACKFILL_MAX);
      drop.forEach((x) => markActivityHandled(x.id, x.ts));
      console.log(
        "[FanslyAI] \u23F3 \u0434\u043E\u0433\u043E\u043D \u0431\u0435\u0437 \u0432\u043E\u0434\u044F\u043D\u043E\u0433\u043E \u0437\u043D\u0430\u043A\u0430: \u0431\u0435\u0440\u0443 " + ACT_BACKFILL_MAX + ", \u043F\u043E\u043C\u0435\u0447\u0430\u044E \u0443\u0447\u0442\u0451\u043D\u043D\u044B\u043C\u0438 " + drop.length + ":",
        // обычный догон, не сбой (todo 46)
        drop.map((x) => x.name + " (" + x.id + ", " + Math.round((Date.now() - x.ts) / 6e4) + "\u043C \u043D\u0430\u0437\u0430\u0434)").join(", ")
      );
    }
    return out.concat(noMark);
  }
  function findContactEl(id, name) {
    const links = [...qa("contactLink")];
    if (id) {
      const byId = links.find((el) => PLAT.contactIdFromHref(PLAT.hrefOf(el)) === id);
      if (byId) return PLAT.clickTarget(byId);
    }
    if (name) {
      if (PLATFORM === "onlyfans") {
        const byName2 = links.find((el) => {
          const nameEl = q("displayName", el);
          return nameEl && cleanContactName(nameEl.innerText) === name;
        });
        return byName2 ? PLAT.clickTarget(byName2) : null;
      }
      const byName = links.find((el) => chatNameFrom(el).name === name);
      if (byName) return PLAT.clickTarget(byName);
    }
    return null;
  }
  async function scrollContactListTop() {
    const list = q("contactList");
    if (!list) return;
    list.scrollTop = 0;
    const feedEl = q("messageContent");
    let el = list.parentElement;
    while (el && el !== document.body) {
      if (el.scrollHeight > el.clientHeight + 20) {
        if (!(feedEl && el.contains(feedEl))) el.scrollTop = 0;
        break;
      }
      el = el.parentElement;
    }
    await sleep(400);
  }
  const ROW_MIRROR_DEBOUNCE_MS = 300;
  const ROW_PENDING_MS = 6e4;
  const ROW_KEYS_STORE = "fansly_row_mirrored";
  const ROW_MIRROR_SKIP_VISIT = true;
  const ROW_REPEAT_MS = 1500;
  const ROW_BROADCAST_MIN = 3;
  const ROW_RESYNC_MS = 18e4;
  const ROW_LAST_STORE = "fansly_row_last";
  function rowElFor(id) {
    if (!id) return null;
    for (const a of qa("contactLink")) if (PLAT.contactIdFromHref(a.getAttribute("href")) === id) return a;
    return null;
  }
  function rowPendingFor(id) {
    for (const [k, at] of carousel.rowPending) if (k.startsWith(id + "|") && Date.now() - at < ROW_PENDING_MS) return true;
    return false;
  }
  function rowPendingLive(k) {
    const at = carousel.rowPending.get(k);
    return at != null && Date.now() - at < ROW_PENDING_MS;
  }
  function rowMirrorCovers(el, id) {
    if (!ROW_MIRROR_SKIP_VISIT || !id) return false;
    const rm = carousel.rowMirrored[id];
    if (!rm || rm.text == null) return false;
    const pv = collapseKey(q("rowPreview", el)?.innerText || "");
    return pv === rm.text && getUnreadCount(el) === rm.badge;
  }
  function ensureRowObserver(baseline = false) {
    if (PLATFORM === "onlyfans") return;
    if (!carousel.running) return;
    if (baseline) {
      carousel.rowSnap = {};
      carousel.rowMirrored = {};
      carousel.rowPending = /* @__PURE__ */ new Map();
      carousel.lastRowPreview = {};
      carousel._rowGrewAt = {};
    }
    const list = q("contactList");
    if (!list) return;
    if (carousel._rowObs && carousel._rowObsTarget === list && list.isConnected) return;
    stopRowObserver();
    carousel._rowObsTarget = list;
    carousel._rowObs = new MutationObserver(() => {
      clearTimeout(carousel._rowObsTimer);
      carousel._rowObsTimer = setTimeout(() => {
        try {
          rowMirrorScan();
        } catch (e) {
          console.warn("[FanslyAI] rowMirror:", e?.message || e);
        }
      }, ROW_MIRROR_DEBOUNCE_MS);
    });
    carousel._rowObs.observe(list, { childList: true, characterData: true, subtree: true });
    rowMirrorScan(true);
  }
  function stopRowObserver() {
    try {
      carousel._rowObs?.disconnect();
    } catch (e) {
    }
    carousel._rowObs = null;
    carousel._rowObsTarget = null;
    clearTimeout(carousel._rowObsTimer);
    carousel._rowObsTimer = null;
    carousel._rowGen = (carousel._rowGen || 0) + 1;
    carousel.rowPending = /* @__PURE__ */ new Map();
    for (const tm of Object.values(carousel._rowRepeat || {})) clearTimeout(tm);
    carousel._rowRepeat = {};
    carousel._rowGrewAt = {};
  }
  function rowKeysLoad() {
    return new Promise((r) => {
      try {
        chrome.storage.local.get(ROW_KEYS_STORE, (d) => r(d[ROW_KEYS_STORE] || {}));
      } catch (e) {
        r({});
      }
    });
  }
  function rowKeySeen(map, key, since = 0) {
    if (!map) return false;
    const at = map[key] != null ? map[key] : map[collapseKey(key)];
    return at != null && Date.now() - at < MIRROR_KEYS_TTL && at >= since;
  }
  let _rowKeysQueue = Promise.resolve();
  function rowLastLoad() {
    return new Promise((r) => {
      try {
        chrome.storage.local.get(ROW_LAST_STORE, (d) => r(d[ROW_LAST_STORE] || {}));
      } catch (e) {
        r({});
      }
    });
  }
  let _rowLastTimer = null, _rowLastDirty = /* @__PURE__ */ new Set();
  function rowLastSave(id) {
    if (!id) return;
    _rowLastDirty.add(id);
    clearTimeout(_rowLastTimer);
    _rowLastTimer = setTimeout(() => {
      const ids = [..._rowLastDirty];
      _rowLastDirty = /* @__PURE__ */ new Set();
      _rowKeysQueue = _rowKeysQueue.then(() => rowLastSaveImpl(ids)).catch(() => {
      });
    }, 1e3);
  }
  async function rowLastSaveImpl(ids) {
    const all = await rowLastLoad(), now = Date.now();
    for (const id of ids) {
      const p = carousel.lastRowPreview[id], rm = carousel.rowMirrored[id];
      if (p == null && !rm) {
        delete all[id];
        continue;
      }
      all[id] = { p: p != null ? p : rm ? rm.text : "", b: rm ? rm.badge : null, at: now };
    }
    const keep = Object.entries(all).filter(([, v]) => v && now - (v.at || 0) < 30 * 864e5).sort((x, y) => (y[1].at || 0) - (x[1].at || 0)).slice(0, 500);
    const out = {};
    for (const [k, v] of keep) out[k] = v;
    try {
      chrome.storage.local.set({ [ROW_LAST_STORE]: out });
    } catch (e) {
    }
  }
  async function rowLastRestore() {
    const all = await rowLastLoad();
    let handled = 0, covered = 0;
    for (const [id, snap] of Object.entries(carousel.rowSnap)) {
      const v = all[id];
      if (!v || v.p == null || v.p !== snap.preview) continue;
      carousel.lastRowPreview[id] = v.p;
      handled++;
      if (v.b != null && v.b === snap.badge && snap.badge > 0) {
        carousel.rowMirrored[id] = { badge: v.b, text: v.p };
        covered++;
      }
    }
    if (handled || covered) console.log("[FanslyAI] \u{1F514} rowMirror: \u0443\u0447\u0451\u0442 \u0441\u0442\u0440\u043E\u043A \u0438\u0437 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430 \u2014 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E " + handled + ", \u043F\u043E\u043A\u0440\u044B\u0442\u043E " + covered);
  }
  function rowKeysMark(id, key) {
    _rowKeysQueue = _rowKeysQueue.then(() => rowKeysMarkImpl(id, key)).catch(() => {
    });
    return _rowKeysQueue;
  }
  async function rowKeysMarkImpl(id, key) {
    const all = await rowKeysLoad(), now = Date.now();
    const m = all[id] || {};
    m[key] = now;
    const kept = {};
    for (const [k, at] of Object.entries(m).filter(([, at2]) => now - at2 < MIRROR_KEYS_TTL).sort((x, y) => y[1] - x[1]).slice(0, MIRROR_KEYS_CAP)) kept[k] = at;
    all[id] = kept;
    for (const [oid, om] of Object.entries(all)) if (!Object.values(om).some((at) => now - at < MIRROR_KEYS_TTL)) delete all[oid];
    try {
      chrome.storage.local.set({ [ROW_KEYS_STORE]: all });
    } catch (e) {
    }
  }
  function rowMirrorScan(baselineOnly = false) {
    if (!carousel.running) return;
    for (const [k, at] of carousel.rowPending) if (Date.now() - at > 2 * ROW_PENDING_MS) carousel.rowPending.delete(k);
    const present = /* @__PURE__ */ new Set(), rows = [], changed = {};
    for (const el of qa("contactLink")) {
      const snap = rowSnapshot(el);
      if (!snap) continue;
      present.add(snap.id);
      const prev = carousel.rowSnap[snap.id];
      rows.push({ snap, prev });
      if (snap.preview && (!prev || snap.preview !== prev.preview)) changed[snap.preview] = (changed[snap.preview] || 0) + 1;
    }
    for (const { snap, prev } of rows) {
      if (snap.id === state.currentContactId) delete carousel.rowResync[snap.id];
      if (prev && !baselineOnly && snap.badge > prev.badge && snap.preview === prev.preview) {
        console.log("[FanslyAI] \u{1F514} rowScan", snap.id, "\u0431\u0435\u0439\u0434\u0436 " + prev.badge + "\u2192" + snap.badge + ", \u043F\u0440\u0435\u0432\u044C\u044E \u043F\u0440\u0435\u0436\u043D\u0435\u0435 \u2192 \u0436\u0434\u0451\u043C \u0442\u0435\u043A\u0441\u0442 " + ROW_REPEAT_MS + " \u043C\u0441");
        if (!carousel._rowGrewAt) carousel._rowGrewAt = {};
        carousel._rowSeenBadge[snap.id] = Math.max(carousel._rowSeenBadge[snap.id] || 0, snap.badge);
        if (!carousel._rowGrewAt[snap.id]) carousel._rowGrewAt[snap.id] = Date.now();
        scheduleRowRepeat(snap.id);
        continue;
      }
      delete carousel._rowSeenBadge[snap.id];
      const grewAt = carousel._rowGrewAt && carousel._rowGrewAt[snap.id];
      if (grewAt) {
        snap.arrivedAt = grewAt;
        delete carousel._rowGrewAt[snap.id];
      }
      carousel.rowSnap[snap.id] = snap;
      if (baselineOnly) continue;
      if (!prev || snap.badge !== prev.badge || snap.preview !== prev.preview) console.log("[FanslyAI] \u{1F514} rowScan", snap.id, prev ? "\u0431\u0435\u0439\u0434\u0436 " + prev.badge + "\u2192" + snap.badge + (snap.preview !== prev.preview ? ", \u043F\u0440\u0435\u0432\u044C\u044E \u0441\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C" : ", \u043F\u0440\u0435\u0432\u044C\u044E \u043F\u0440\u0435\u0436\u043D\u0435\u0435") : "\u0441\u0442\u0440\u043E\u043A\u0430 \u043D\u043E\u0432\u0430\u044F, \u0431\u0435\u0439\u0434\u0436 " + snap.badge, "|", JSON.stringify(snap.preview.slice(0, 30)), snap.media ? "[\u043C\u0435\u0434\u0438\u0430]" : "", snap.paid ? "[$]" : "", rowPendingFor(snap.id) ? "[\u0432 \u043F\u043E\u043B\u0451\u0442\u0435]" : "", snap.id === state.currentContactId ? "[\u043E\u0442\u043A\u0440\u044B\u0442]" : "");
      let dBadge;
      if (!prev) {
        const fresh = snap.ts != null && Date.now() - snap.ts < 3 * 6e4 && snap.ts > (carousel.mirrorSince || 0) && snap.ts > (carousel.msgTs[snap.id] || 0) + ACT_TOL;
        if (snap.badge !== 1 || !fresh) continue;
        dBadge = 1;
      } else {
        if (snap.badge === 0 || snap.badge < prev.badge) {
          if (carousel.rowMirrored[snap.id]) console.log("[FanslyAI] \u{1F514} rowMirror: \u0443\u0447\u0451\u0442 \u0441\u0431\u0440\u043E\u0448\u0435\u043D (\u0441\u043D\u0438\u043C\u043E\u043A " + prev.badge + " \u2192 \u0431\u0435\u0439\u0434\u0436 " + snap.badge + ", \u0443\u0447\u0451\u0442 " + JSON.stringify(carousel.rowMirrored[snap.id]) + ")", snap.id);
          if (snap.badge === 0 && prev.badge > 0 && snap.preview === prev.preview && snap.id !== state.currentContactId && !(carousel._visitId === snap.id && Date.now() - carousel._visitAt < 15e3)) {
            const was = Math.max(prev.badge, carousel._rowSeenBadge[snap.id] || 0);
            carousel.rowResync[snap.id] = { badge: was, at: Date.now() };
            console.log("[FanslyAI] \u{1F514} rowMirror: \u0431\u0435\u0439\u0434\u0436 \u0441\u043D\u044F\u0442 \u0441\u043D\u0430\u0440\u0443\u0436\u0438 (\u0431\u044B\u043B\u043E " + was + ") \u2192 \u043F\u043E\u043C\u043D\u044E 3 \u043C\u0438\u043D", snap.id);
          }
          delete carousel._rowSeenBadge[snap.id];
          if (carousel.rowMirrored[snap.id]) {
            delete carousel.rowMirrored[snap.id];
            rowLastSave(snap.id);
          }
          continue;
        }
        dBadge = snap.badge - prev.badge;
      }
      if (dBadge <= 0) {
        if (snap.preview !== prev.preview) {
          if (carousel.rowMirrored[snap.id]) console.log("[FanslyAI] \u{1F514} rowMirror: \u0443\u0447\u0451\u0442 \u0441\u0431\u0440\u043E\u0448\u0435\u043D (\u043F\u0440\u0435\u0432\u044C\u044E \u0441\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u043F\u0440\u0438 \u0442\u043E\u043C \u0436\u0435 \u0431\u0435\u0439\u0434\u0436\u0435)", snap.id);
          delete carousel.rowMirrored[snap.id];
        }
        continue;
      }
      if (dBadge !== 1 || prev && snap.preview === prev.preview) continue;
      if (changed[snap.preview] >= ROW_BROADCAST_MIN) {
        console.log("[FanslyAI] \u{1F514} rowMirror: \u043E\u0434\u0438\u043D \u0442\u0435\u043A\u0441\u0442 \u043D\u0430 " + changed[snap.preview] + " \u0441\u0442\u0440\u043E\u043A\u0430\u0445 \u2192 \u0441\u0432\u043E\u0451 (\u0440\u0430\u0441\u0441\u044B\u043B\u043A\u0430), \u0441\u0442\u0440\u043E\u043A\u043E\u0439 \u043D\u0435 \u0448\u043B\u0451\u043C", snap.id);
        continue;
      }
      rowTrySend(snap, prev, 0);
    }
    for (const id of Object.keys(carousel.rowSnap)) if (!present.has(id)) delete carousel.rowSnap[id];
  }
  function rowTrySend(snap, prev, repeat, insist = false) {
    if (snap.id === state.currentContactId) return false;
    if (!snap.preview || snap.paid || snap.media) return false;
    if (!state.tgDialogue || carousel.excludedIds.has(snap.id) && state.tgMuteExcluded) return false;
    if (rowPendingFor(snap.id)) {
      if (prev) carousel.rowSnap[snap.id] = prev;
      else delete carousel.rowSnap[snap.id];
      return false;
    }
    if (prev && prev.badge > 0) {
      const rm = carousel.rowMirrored[snap.id];
      if (!rm || rm.badge !== prev.badge || rm.text !== prev.preview) {
        console.log("[FanslyAI] \u{1F514} rowMirror: \u0440\u0430\u0437\u0440\u044B\u0432 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u044F (\u0441\u043D\u0438\u043C\u043E\u043A " + prev.badge + ", \u0443\u0447\u0451\u0442 " + JSON.stringify(rm || null) + ") \u2192 \u0432\u0438\u0437\u0438\u0442", snap.id);
        return false;
      }
    }
    mirrorFromRow(snap, repeat, insist).catch((e) => console.warn("[FanslyAI] rowMirror:", e?.message || e));
    return true;
  }
  function scheduleRowRepeat(id) {
    if (!carousel._rowRepeat) carousel._rowRepeat = {};
    clearTimeout(carousel._rowRepeat[id]);
    carousel._rowRepeat[id] = setTimeout(() => {
      delete carousel._rowRepeat[id];
      try {
        rowRepeatCheck(id);
      } catch (e) {
        console.warn("[FanslyAI] rowMirror:", e?.message || e);
      }
    }, ROW_REPEAT_MS);
  }
  function rowRepeatCheck(id) {
    if (!carousel.running) return;
    const el = rowElFor(id), prev = carousel.rowSnap[id];
    const snap = el && rowSnapshot(el);
    if (!snap || !prev || snap.preview !== prev.preview || snap.badge <= prev.badge) return;
    if (rowPendingFor(id)) {
      scheduleRowRepeat(id);
      return;
    }
    snap.arrivedAt = carousel._rowGrewAt && carousel._rowGrewAt[id] || Date.now() - ROW_REPEAT_MS - ROW_MIRROR_DEBOUNCE_MS;
    if (carousel._rowGrewAt) delete carousel._rowGrewAt[id];
    delete carousel._rowSeenBadge[id];
    const rs = carousel.rowResync[id];
    const restored = rs && Date.now() - rs.at < ROW_RESYNC_MS ? rs.badge : 0;
    const ageOf = (l) => {
      const t2 = parseMsgTime(l);
      return t2 == null ? null : Date.now() - t2;
    };
    const aN = ageOf(snap.tsLabel), aP = ageOf(prev.tsLabel);
    const jumped = snap.tsLabel !== prev.tsLabel && aN != null && aP != null && aN < aP;
    const kNew = jumped ? snap.badge - prev.badge : snap.badge - Math.max(prev.badge, restored);
    const cover = (why) => {
      console.log("[FanslyAI] \u{1F514} rowMirror: \u0431\u0435\u0439\u0434\u0436 \u0432\u0435\u0440\u043D\u0443\u043B\u0441\u044F \u0431\u0435\u0437 \u043D\u043E\u0432\u043E\u0433\u043E \u0442\u0435\u043A\u0441\u0442\u0430 (" + why + ") \u2192 \u043F\u043E\u043A\u0440\u044B\u0442\u043E", id, JSON.stringify(snap.preview.slice(0, 30)), "\u0431\u0435\u0439\u0434\u0436 " + prev.badge + "\u2192" + snap.badge + (restored ? ", \u043F\u043E\u043C\u043D\u044E " + restored : ""));
      carousel.rowMirrored[id] = { badge: snap.badge, text: snap.preview };
      carousel.rowSnap[id] = snap;
      rowLastSave(id);
    };
    if (kNew <= 0) return cover(restored ? "\u043F\u0435\u0440\u0435\u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u043F\u043E\u0441\u043B\u0435 \u0447\u0442\u0435\u043D\u0438\u044F \u0441\u043D\u0430\u0440\u0443\u0436\u0438" : "\u0441\u0447\u0451\u0442\u0447\u0438\u043A \u043D\u0435 \u0432\u044B\u0448\u0435 \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E");
    if (!jumped && prev.badge === 0 && !rs) return cover("0\u21921 \u0431\u0435\u0437 \u043F\u0430\u043C\u044F\u0442\u0438 \u043E \u0441\u0431\u0440\u043E\u0441\u0435, \u043C\u0435\u0442\u043A\u0430 \u043D\u0435 \u043F\u0440\u044B\u0433\u043D\u0443\u043B\u0430");
    const insist = !jumped && (prev.badge > 0 || restored > 0);
    console.log("[FanslyAI] \u{1F514} rowMirror: \u043F\u043E\u0432\u0442\u043E\u0440 \u0442\u043E\u0433\u043E \u0436\u0435 \u0442\u0435\u043A\u0441\u0442\u0430 \xD7" + kNew, id, JSON.stringify(snap.preview.slice(0, 30)), jumped ? "(\u043C\u0435\u0442\u043A\u0430 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043F\u0440\u044B\u0433\u043D\u0443\u043B\u0430)" : "(\u0431\u0435\u0439\u0434\u0436 \u0432\u044B\u0448\u0435 \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E" + (restored ? " \u0438 \u0437\u0430\u043F\u043E\u043C\u043D\u0435\u043D\u043D\u043E\u0433\u043E " + restored : "") + ")");
    if (rowTrySend(snap, prev, kNew, insist)) carousel.rowSnap[id] = snap;
  }
  async function mirrorFromRow(snap, repeat = 0, insist = false) {
    const gen = carousel._rowGen;
    const alive = () => carousel.running && gen === carousel._rowGen;
    const key = "<" + snap.preview + (repeat ? "#" + snap.badge : "");
    const sess = snap.id + "|" + key;
    const recent = (snap.arrivedAt || snap.seenAt || Date.now()) - ARRIVAL_TOL_MS;
    if (tgSeen(sess, recent) || carousel.rowPending.has(sess)) return;
    carousel.rowPending.set(sess, Date.now());
    const done = () => carousel.rowPending.delete(sess);
    const rec = await readContactRecord(snap.id);
    if (!alive()) return done();
    const healthy = (n) => !!n && !/^unknown/i.test(n) && !/…|\.\.\./.test(n);
    const rowName = snap.name, recName = rec && rec.name;
    let fan = "";
    if (healthy(rowName) && (!healthy(recName) || recName === rowName)) fan = rowName;
    else if (!healthy(rowName) && healthy(recName)) fan = recName;
    if (!fan || healthy(recName) && recName !== fan) console.log("[FanslyAI] \u{1F514} rowMirror: \u0438\u043C\u044F \u0441\u0442\u0440\u043E\u043A\u0438", JSON.stringify(rowName), "| \u0437\u0430\u043F\u0438\u0441\u044C", JSON.stringify(recName || ""), "\u2192", fan ? "\u0432\u0435\u0442\u043A\u0430 " + JSON.stringify(fan) : "\u043D\u0435 \u0448\u043B\u0451\u043C, \u0447\u0430\u0442 \u043E\u0442\u043A\u0440\u043E\u0435\u0442 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C");
    if (!fan) return done();
    const at = rec && rec.mirroredKeys && rec.mirroredKeys[key];
    if (at != null && at >= recent) {
      console.log("[FanslyAI] \u{1F514} rowMirror: \u0443\u0436\u0435 \u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E \u0434\u0440\u0443\u0433\u0438\u043C \u043F\u0443\u0442\u0451\u043C (\u0437\u0430\u043F\u0438\u0441\u044C)", snap.id, JSON.stringify(snap.preview.slice(0, 30)));
      return done();
    }
    if (rowKeySeen((await rowKeysLoad())[snap.id], key, recent)) {
      console.log("[FanslyAI] \u{1F514} rowMirror: \u0443\u0436\u0435 \u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E \u0434\u0440\u0443\u0433\u0438\u043C \u043F\u0443\u0442\u0451\u043C (\u043A\u043B\u044E\u0447\u0438 \u0441\u0442\u0440\u043E\u043A)", snap.id);
      return done();
    }
    if (!alive()) return done();
    markActivityHandled(snap.id, Math.max(snap.ts || 0, Date.now()));
    const g = { genderHint: rec && (rec.fanGender || rec.gender) || "male", toGender: state.creatorGender || "female" };
    const tr = state.translatorEnabled === false ? null : await Promise.race([
      sendSafe({ type: "TRANSLATE", text: snap.previewRaw || snap.preview, targetLang: state.nativeLang, kind: "translate", ...g, ...rec ? { fanLang: rec.lang || "en" } : {} }).then((r) => r && r.success && r.result ? r.result : null).catch(() => null),
      sleep(45e3).then(() => null)
    ]);
    const body = tr || snap.previewRaw || snap.preview;
    if (!alive()) return done();
    const line = `\u{1F4AC} ${fan} \u{1F464} ${body}` + (repeat > 1 ? " " + t("panel.tg.repeatN", state.uiLang, { n: repeat }) : insist && repeat ? " " + t("panel.tg.repeat", state.uiLang) : "");
    console.log("[FanslyAI] \u{1F514} rowMirror: \u0432\u0445\u043E\u0434\u044F\u0449\u0435\u0435 \u0438\u0437 \u0441\u0442\u0440\u043E\u043A\u0438 \u0441\u043F\u0438\u0441\u043A\u0430 \u2192", fan, "| \u0431\u0435\u0439\u0434\u0436", snap.badge, repeat ? "| \u043F\u043E\u0432\u0442\u043E\u0440 \xD7" + repeat : "", "|", snap.preview.slice(0, 40));
    tgMirrorLine(line, fan, true, [sess], async () => {
      done();
      const fresh = await readContactRecord(snap.id);
      const keys = repeat ? [key, "<" + snap.preview] : [key];
      if (fresh) markMirroredKeys(keys, { id: snap.id, name: fan, data: fresh });
      for (const k of keys) rowKeysMark(snap.id, k);
      const live = carousel.rowSnap[snap.id];
      if (!live || live.badge < snap.badge) {
        console.log("[FanslyAI] \u{1F514} rowMirror: \u0443\u0447\u0451\u0442 \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D \u2014 \u0441\u043D\u0438\u043C\u043E\u043A", live ? "\u0431\u0435\u0439\u0434\u0436 " + live.badge : "\u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442", "\u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E\u043C", snap.badge, snap.id);
        return;
      }
      carousel.rowMirrored[snap.id] = { badge: snap.badge, text: collapseKey(snap.preview) };
      carousel.lastHandledText[snap.id] = snap.preview;
      carousel.lastRowPreview[snap.id] = snap.preview;
      rowLastSave(snap.id);
    }, true, () => {
      done();
      delete carousel.rowMirrored[snap.id];
    }, recent);
  }
  const carousel = {
    running: false,
    processed: 0,
    settings: null,
    nextTimer: null,
    countdownTimer: null,
    lastHandledText: {},
    // id -> текст последнего обработанного входящего (защита от дубля)
    triedThisRound: /* @__PURE__ */ new Set(),
    // id, попробованные в текущем проходе (сброс при прогрессе/idle)
    excludedIds: /* @__PURE__ */ new Set(),
    // id контактов с пометкой «исключён» (личные диалоги)
    pushStreak: {},
    // id -> серия ходов подряд, где фан настаивал (лестница увода/затухания, Блок 9)
    idleSec: 45,
    // интервал проверки в режиме ожидания
    navBusy: false,
    // мьютекс навигации: шаг карусели ИЛИ доставка ручного ответа из ТГ
    _lastStepAt: 0,
    // когда шаг карусели последний раз дошёл до работы (не просто был вызван) — для heartbeat
    _navTag: "",
    // кто держит мьютекс навигации (для лога сторожа)
    _navAt: 0,
    // когда захвачен
    _navTouch: 0,
    // когда владелец последний раз отчитался о работе (navTouch)
    _navGen: 0,
    // поколение захвата: снятый сторожем владелец своим release уже не сбивает чужой
    navGuardTimer: null,
    // сторож залипшего мьютекса
    relayQueue: [],
    // очередь ручных ответов из ТГ {fan,text,id} — доставляются по одному
    staleTimer: null,
    // сторож рассинхрона списка (конверт>0, а в списке непрочитанных нет → reload)
    staleSince: 0,
    // ts, когда рассинхрон впервые замечен (0 = нет)
    mirrorSince: 0,
    // отсечка «зеркалить активность от»: сдвигается на ts ручного включения пульта
    msgTs: {},
    // id чата -> ts последней УЧТЁННОЙ активности (водяной знак для детекта по message-time)
    _catchupNotified: false,
    // шапка «догоняю N диалогов» уже отправлена в текущем всплеске накопа
    rowSnap: {},
    // id -> последний снимок строки списка {preview,badge,paid,ts,name} (зеркало из превью, только память)
    rowMirrored: {},
    // id -> {badge, text}: бейдж и превью строки на момент последней доставки в ТГ без визита (строка / живое зеркало)
    lastRowPreview: {},
    // id -> превью строки на момент, когда её уже обработали (зеркало из строки, визит, живое зеркало): дрейф метки времени не показатель
    _rowObs: null,
    // MutationObserver списка чатов (лидер-вкладка, пока карусель работает)
    _rowObsTarget: null,
    _rowObsTimer: null,
    rowPending: /* @__PURE__ */ new Map(),
    // id|ключ -> ts: строка летит в ТГ из превью (очередь карусели и скан ленты её ждут)
    _rowGen: 0,
    // поколение наблюдателя: стоп/перевес обесценивает висящие отправки
    _rowRepeat: {},
    // id -> таймер проверки повтора того же текста (бейдж вырос, превью прежнее)
    _rowGrewAt: {},
    // id -> когда впервые увидели рост бейджа без смены текста (приход сообщения для дедупа)
    _rowSeenBadge: {},
    // id -> наибольший бейдж, увиденный при прежнем тексте (снимок в это время заморожен)
    rowResync: {},
    // id -> {badge, at}: бейдж упал до 0 при прежнем тексте снаружи (телефон/другое окно) → счётчик может вернуться по шагам
    _visitId: null,
    // чей чат мы сами сейчас открываем (визит/ответ из ТГ): его сброс бейджа — наш, не внешний
    _visitAt: 0
  };
  const extAlive = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  };
  function persistSetting(key, val) {
    if (!extAlive()) return;
    try {
      chrome.storage.local.get("fansly_ai_settings", (d) => {
        const s = d.fansly_ai_settings || {};
        s[key] = val;
        chrome.storage.local.set({ fansly_ai_settings: s });
      });
    } catch (e) {
    }
  }
  function persistSettings(obj) {
    if (!extAlive()) return;
    try {
      chrome.storage.local.get("fansly_ai_settings", (d) => {
        const s = d.fansly_ai_settings || {};
        Object.assign(s, obj);
        chrome.storage.local.set({ fansly_ai_settings: s });
      });
    } catch (e) {
    }
  }
  const aiWorks = (s) => !!(s.useProxy === true && s.licenseKey || s.geminiApiKey || s.groqApiKey || s.openrouterApiKey || s.claudeApiKey);
  const goodTranslate = (s) => !!(s.useProxy === true && s.licenseKey || s.deepLApiKey);
  const SUB_PAUSE_KEY = "fansly_sub_expired";
  const SUB_RENEW_KEY = "fansly_sub_renew";
  function subKeyFp(k) {
    let h = 5381;
    const s = String(k || "");
    for (let i = 0; i < s.length; i++) h = (h << 5) + h + s.charCodeAt(i) | 0;
    return (h >>> 0).toString(16);
  }
  let _subHintTimer = 0, _renewMark = null, _money = null;
  function refreshSetupHintNow() {
    sendSafe({ type: "GET_SETTINGS" }).then((r) => {
      if (r?.result) refreshSetupHint(r.result);
    });
  }
  const QUOTA_KEY = "fansly_ai_quota";
  const QUOTA_POLL_MS = 5 * 60 * 1e3;
  function quotaOut(q2) {
    if (!q2 || !(q2.limit > 0) || !(q2.used >= q2.limit)) return false;
    if (q2.prepaid && q2.prepaid.count > 0) return false;
    return !(Date.parse(q2.periodEnd) <= Date.now());
  }
  function quotaPollIn(q2) {
    const now = Date.now(), end = Date.parse(q2.periodEnd);
    let ms = (q2.at || 0) + QUOTA_POLL_MS - now;
    if (end > now) ms = Math.min(ms, end - now + 1e3);
    return Math.max(ms, 30 * 1e3);
  }
  function quotaPoll() {
    if (document.hidden) {
      _subHintTimer = setTimeout(quotaPoll, QUOTA_POLL_MS);
      return;
    }
    chrome.storage.local.get(QUOTA_KEY, (d) => {
      const q2 = d && d[QUOTA_KEY];
      const stale = !!q2 && Date.now() - (q2.at || 0) >= QUOTA_POLL_MS - 1e3;
      sendSafe({ type: "GET_QUOTA", force: stale }).then(refreshSetupHintNow);
    });
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && _money?.quota) quotaPoll();
  });
  async function quotaCheck() {
    const at0 = (await new Promise((r) => chrome.storage.local.get(QUOTA_KEY, (d) => r(d && d[QUOTA_KEY]))))?.at || 0;
    moneyNote("panel.quota.checking");
    const q2 = (await sendSafe({ type: "GET_QUOTA", force: true }))?.result;
    if (q2 && !quotaOut(q2)) {
      refreshSetupHintNow();
      return;
    }
    moneyNote(q2 && q2.at !== at0 ? "panel.quota.notyet" : "panel.quota.checkFail");
  }
  function moneyNote(key) {
    if (!_money || _money.action !== "quota-check") return;
    _money.text = t(key, state.uiLang);
    const txt = document.getElementById("fai-setup-hint-text");
    if (txt && document.getElementById("fai-setup-hint-btn")?.dataset.faiAction === "quota-check") txt.textContent = _money.text;
    paintPultMoney();
  }
  function setMoney(m) {
    _money = m;
    paintPultMoney();
  }
  function refreshSetupHint(s) {
    const box = document.getElementById("fai-setup-hint");
    if (!box) return;
    const txt = document.getElementById("fai-setup-hint-text");
    const btn = document.getElementById("fai-setup-hint-btn");
    if (s.privacyDeclinedAt && !s.privacyConsentAt) {
      txt.textContent = t("panel.consent.declined", state.uiLang);
      btn.textContent = t("panel.consent.again", state.uiLang);
      box.style.display = "flex";
      btn.dataset.faiAction = "consent";
      wireHintBtn(btn);
      setMoney(null);
      return;
    }
    const ai = BUILD === "store" ? true : aiWorks(s);
    const tr = goodTranslate(s);
    if (ai && tr) {
      showCodeRow(false);
      const viaProxy = s.useProxy === true && !!s.licenseKey;
      chrome.storage.local.get([SUB_PAUSE_KEY, SUB_RENEW_KEY, QUOTA_KEY], (d0) => {
        const p = d0 && d0[SUB_PAUSE_KEY];
        clearTimeout(_subHintTimer);
        if (viaProxy && p && p.fp === subKeyFp(s.licenseKey) && Date.now() < p.until) {
          const renewed = d0[SUB_RENEW_KEY]?.until === p.until;
          const copied = renewed && d0[SUB_RENEW_KEY].copied === true;
          txt.textContent = t(copied ? "panel.sub.renewed.copied" : renewed ? "panel.sub.renewed" : BUILD === "store" ? "panel.sub.expired.store" : "panel.sub.expired", state.uiLang);
          btn.textContent = t(renewed ? "panel.sub.btn.options" : "panel.sub.btn", state.uiLang);
          box.style.display = "flex";
          btn.dataset.faiAction = renewed ? "options" : "pricing";
          _renewMark = { until: p.until };
          wireHintBtn(btn);
          _subHintTimer = setTimeout(refreshSetupHintNow, p.until - Date.now() + 1e3);
          setMoney({ text: txt.textContent, btn: btn.textContent, action: btn.dataset.faiAction });
          return;
        }
        const q2 = d0 && d0[QUOTA_KEY];
        if (viaProxy && quotaOut(q2)) {
          const renewed = d0[SUB_RENEW_KEY]?.quota === q2.periodEnd;
          const copied = renewed && d0[SUB_RENEW_KEY].copied === true;
          const lite = q2.tier === "lite";
          const out = BUILD === "store" ? lite ? "panel.quota.outLite.store" : "panel.quota.out.store" : lite ? "panel.quota.outLite" : "panel.quota.out";
          txt.textContent = t(copied ? "panel.quota.renewed.copied" : renewed ? "panel.quota.renewed" : out, state.uiLang);
          btn.textContent = t(renewed ? "panel.quota.btn.continue" : lite ? "panel.quota.btn.lite" : "panel.sub.btn", state.uiLang);
          box.style.display = "flex";
          btn.dataset.faiAction = renewed ? "quota-check" : "pricing";
          _renewMark = { quota: q2.periodEnd };
          wireHintBtn(btn);
          _subHintTimer = setTimeout(quotaPoll, quotaPollIn(q2));
          setMoney({ text: txt.textContent, btn: btn.textContent, action: btn.dataset.faiAction, quota: true });
          return;
        }
        setMoney(null);
        chrome.storage.local.get(["fansly_subs", "fansly_catalog_lastfull"], (d) => {
          const collected = !!(d && (d.fansly_subs && Object.keys(d.fansly_subs).length || d.fansly_catalog_lastfull));
          if (collected) {
            box.style.display = "none";
            return;
          }
          txt.textContent = t("panel.setup.collect", state.uiLang);
          btn.textContent = t("panel.setup.collect.btn", state.uiLang);
          box.style.display = "flex";
          btn.dataset.faiAction = "collect";
          wireHintBtn(btn);
        });
        if (BUILD === "store") box.style.display = "none";
      });
      return;
    }
    setMoney(null);
    chrome.storage.local.get("fansly_trial_state", (d) => {
      const ts = d && d.fansly_trial_state;
      if (ts && ts.closed) {
        const tg = ts.closed === "tg";
        txt.textContent = t(tg ? "panel.trial.closed.tg" : "panel.trial.closed.code", state.uiLang);
        btn.textContent = t(tg ? "panel.trial.btn.tg" : "panel.trial.btn.where", state.uiLang);
        box.style.display = "flex";
        btn.dataset.faiAction = "trial";
        wireHintBtn(btn);
        showCodeRow(!tg);
        return;
      }
      showCodeRow(false);
      const key = !ai && !tr ? "panel.setup.both" : !ai ? "panel.setup.ai" : "panel.setup.translate";
      txt.textContent = t(key, state.uiLang);
      btn.textContent = t("panel.setup.btn", state.uiLang);
      box.style.display = "flex";
      btn.dataset.faiAction = "options";
      wireHintBtn(btn);
    });
  }
  function showCodeRow(show) {
    const row = document.getElementById("fai-code-row");
    if (!row) return;
    row.style.display = show ? "flex" : "none";
    if (!show || row.dataset.faiWired) return;
    row.dataset.faiWired = "1";
    const inp = document.getElementById("fai-code-input");
    const btn = document.getElementById("fai-code-btn");
    inp.placeholder = t("panel.trial.code.hint", state.uiLang);
    btn.textContent = t("panel.trial.code.btn", state.uiLang);
    const send = () => {
      const code = (inp.value || "").trim().slice(0, 32);
      if (!code) return;
      btn.disabled = true;
      const say = (key) => {
        const t2 = document.getElementById("fai-setup-hint-text");
        if (t2) t2.textContent = t(key, state.uiLang);
      };
      say("panel.trial.code.sending");
      sendSafe({ type: "REDEEM_TRIAL_CODE", code }).then((r) => {
        btn.disabled = false;
        if (r && r.ok) {
          inp.value = "";
          showCodeRow(false);
          say("panel.trial.code.ok");
          return;
        }
        const map = {
          trial_code_unknown: "panel.trial.code.bad",
          trial_code_used: "panel.trial.code.used",
          trial_code_expired: "panel.trial.code.expired",
          trial_code_paused: "panel.trial.code.paused"
        };
        say(map[r && r.code] || "panel.trial.code.fail");
      }).catch(() => {
        btn.disabled = false;
        say("panel.trial.code.fail");
      });
    };
    btn.addEventListener("click", send);
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") send();
    });
  }
  async function copyLicenseKey() {
    const key = String((await getSettingsAsync().catch(() => null) || {}).licenseKey || "").trim();
    if (!key) return false;
    try {
      await navigator.clipboard.writeText(key);
      return true;
    } catch (e) {
      return false;
    }
  }
  function wireHintBtn(btn) {
    if (btn.dataset.faiWired) return;
    btn.dataset.faiWired = "1";
    btn.addEventListener("click", () => {
      if (btn.dataset.faiAction === "collect") {
        sendSafe({ type: "RUN_FULL_COLLECT" });
        return;
      }
      if (btn.dataset.faiAction === "trial") {
        sendSafe({ type: "OPEN_TRIAL_PATH" });
        return;
      }
      if (btn.dataset.faiAction === "pricing") {
        copyLicenseKey().then((copied) => {
          sendSafe({ type: "OPEN_PRICING" });
          try {
            chrome.storage.local.set({ [SUB_RENEW_KEY]: { ..._renewMark, copied } });
          } catch (e) {
          }
        });
        return;
      }
      if (btn.dataset.faiAction === "quota-check") {
        btn.disabled = true;
        quotaCheck().finally(() => {
          btn.disabled = false;
        });
        return;
      }
      if (btn.dataset.faiAction === "consent") {
        sendSafe({ type: "SAVE_SETTINGS", settings: { masterEnabled: true, privacyDeclinedAt: 0 } });
        try {
          FaiConsent.ask();
        } catch (e) {
        }
        return;
      }
      sendSafe({ type: "OPEN_OPTIONS" });
    });
  }
  function applyOwnerSettings(s) {
    if (!s) return;
    refreshSetupHint(s);
    const _prevUiLang = state.uiLang;
    const _prevNativeLang = state.nativeLang;
    state.uiLang = s.interfaceLanguage || "ru";
    if (typeof FaiLock !== "undefined") FaiLock.init({ lang: state.uiLang, skipWhen: () => !!state._pultActive });
    state.nativeLang = s.nativeLanguage || "ru";
    state.creatorGender = s.creatorGender || "female";
    state.collectDossier = s.collectDossier !== false;
    state.dossierDeltaMin = Math.min(20, Math.max(1, parseInt(s.dossierDeltaMin, 10) || 1));
    state.coachEnabled = s.coachEnabled !== false;
    const _coachBlk = document.getElementById("fai-coach");
    if (_coachBlk) _coachBlk.style.display = state.coachEnabled ? "" : "none";
    const _coachBtn = document.getElementById("fai-coach-btn");
    if (_coachBtn) _coachBtn.style.display = state.coachEnabled ? "" : "none";
    if (!state.coachEnabled) {
      const _ct = document.getElementById("fai-coach-toggle");
      if (_ct) _ct.style.display = "none";
    }
    state._proxyOn = s.useProxy === true && !!s.licenseKey;
    const _provSelVis = document.getElementById("fai-provider-select");
    if (_provSelVis) _provSelVis.style.display = state._proxyOn ? "none" : "";
    state.styleLearnEnabled = s.styleLearnEnabled === true;
    const _lsBtn = document.getElementById("fai-learnstyle-btn");
    if (_lsBtn) _lsBtn.style.display = state.styleLearnEnabled ? "" : "none";
    const _prevMasterOn = state._masterInit ? state.masterEnabled !== false : null;
    state._masterInit = true;
    state.masterEnabled = s.masterEnabled !== false;
    state.translatorEnabled = s.translatorEnabled !== false;
    state.translateContext = s.translateContext !== false;
    state.notificationsEnabled = s.notificationsEnabled === true;
    state._bgWorkEnabled = s.bgWorkEnabled === true;
    state._bgWorkAck = s.bgWorkAck === true;
    state._pultVeilOpacity = typeof s.pultVeilOpacity === "number" ? s.pultVeilOpacity : 0.74;
    state._pultLockPin = s.pultLockPin || "";
    pultProtect();
    if (state._pultActive) applyPultVeil();
    const _master = state.masterEnabled;
    const _pnl = document.getElementById("fansly-ai-panel");
    const _show = _master && s.panelHidden !== true;
    if (_pnl) _pnl.style.display = _show && !state._pultActive ? "" : "none";
    if (_show && _initialized && state._panelShown === false && extractContactIdFromUrl()) activateForContact();
    if (_show && state._panelShown === false) state._outreachClosed = false;
    state._panelShown = _show;
    if (_initialized) {
      if (_master && state.notificationsEnabled) {
        startNotifWatch();
        if (_show) renderOutreachFromStorage();
        else removeOutreachPanel();
      } else removeOutreachPanel();
      const ce = _master && s.carouselEnabled === true && !state._tgPaused;
      const manualOn = ce === true && state._lastCarouselEnabled === false;
      state._lastCarouselEnabled = ce;
      state._carouselWanted = ce;
      if (!ce && carousel.running) stopNightMode("common.reason.settingsChange");
      else if (ce && !carousel.running) startNightMode(manualOn);
    }
    state.tgDialogue = state.masterEnabled && s.telegramEnabled === true;
    state.tgMuteExcluded = s.tgMuteExcluded === true;
    state.tgPoll = state.masterEnabled && s.telegramEnabled === true;
    state.tgPause = state.masterEnabled && s.telegramEnabled === true && s.tgTopics === true;
    if (state.tgPoll && !state._tgPollTimer && !_isInviteTab) {
      pollTgPause();
      state._tgPollTimer = setInterval(pollTgPause, 1e4);
    }
    if (!state.tgPoll && state._tgPollTimer) {
      clearInterval(state._tgPollTimer);
      state._tgPollTimer = null;
      releaseTgLeaderIfOurs();
      state._tgPollLead = false;
      pultProtect();
    }
    if (_prevMasterOn === true && !state.masterEnabled && s.telegramEnabled === true) {
      sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.masterOff", state.uiLang) });
    }
    if (_prevUiLang !== state.uiLang) refreshPanelI18n();
    if (_prevNativeLang !== state.nativeLang) {
      clearTimeout(state._retransTimer);
      state._retransTimer = setTimeout(() => {
        state.transCache.clear();
        retranslateHistory();
      }, 3e3);
    }
    let _consentNow = false;
    try {
      _consentNow = !!(s.privacyConsentAt && (s.privacyConsentRev | 0) >= (FaiConsent.REV | 0));
    } catch (e) {
    }
    if (state._consentWas === false && _consentNow) retranslateHistory();
    state._consentWas = _consentNow;
  }
  function refreshPanelI18n() {
    const panel = document.getElementById("fansly-ai-panel");
    updatePanelContact();
    if (state.contactData) {
      renderDossier();
      renderBrief();
      updateExcludeBtn();
    }
    if (carousel.running) renderExcludedChip();
    renderOutreachFromStorage();
    if (panel && typeof applyI18n === "function") applyI18n(panel, state.uiLang);
  }
  const TGP_KEY = "fansly_tg_poll_leader";
  const TGP_STALE_MS = 25e3;
  function readTgLeader() {
    return new Promise((r) => chrome.storage.local.get(TGP_KEY, (d) => r(d[TGP_KEY] || null)));
  }
  function claimTgLeader() {
    return new Promise((r) => chrome.storage.local.set({ [TGP_KEY]: { tabId: _tabId(), ts: Date.now(), hidden: document.hidden, pult: !!carousel.running } }, r));
  }
  function releaseTgLeaderIfOurs() {
    readTgLeader().then((l) => {
      if (l && l.tabId === _tabId()) chrome.storage.local.remove(TGP_KEY);
    });
  }
  async function tgPollAllowed() {
    const l = await readTgLeader();
    const alive = !!(l && Date.now() - (l.ts || 0) < TGP_STALE_MS);
    const mine = !!(l && l.tabId === _tabId());
    if (alive && !mine && !carousel.running && (l.pult || !(l.hidden && !document.hidden))) return false;
    await claimTgLeader();
    return true;
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && state.tgPoll) pollTgPause();
  });
  window.addEventListener("beforeunload", releaseTgLeaderIfOurs);
  async function pollTgPause() {
    if (!state.tgPoll) return;
    const lead = await tgPollAllowed();
    state._tgPollLead = lead;
    pultProtect();
    if (!lead) return;
    const r = await sendSafe({ type: "TG_POLL", caps: TG_CMD_CAPS });
    if (!r?.success) return;
    let queued = false;
    if (Array.isArray(r.relays) && r.relays.length) {
      for (const rel of r.relays) carousel.relayQueue.push({ type: "relay", fan: rel.fan, text: rel.text, id: rel.id, pid: rel.pid });
      queued = true;
    }
    if (Array.isArray(r.genVars) && r.genVars.length) {
      for (const g of r.genVars) carousel.relayQueue.push(tgGenTask(g));
      queued = true;
    }
    if (Array.isArray(r.sendVars) && r.sendVars.length) {
      for (const sv of r.sendVars) carousel.relayQueue.push(tgSendTask(sv));
      queued = true;
    }
    if (Array.isArray(r.cmds) && r.cmds.length) {
      for (const c of r.cmds) carousel.relayQueue.push({ type: "cmd", cmd: c.cmd, fan: c.fan, id: c.id, pid: c.pid, arg: c.arg });
      queued = true;
    }
    if (queued) drainRelays();
  }
  function navAcquire(tag) {
    carousel.navBusy = true;
    carousel._navTag = tag || "?";
    carousel._navAt = carousel._navTouch = Date.now();
    return ++carousel._navGen;
  }
  function navTouch() {
    carousel._navTouch = Date.now();
  }
  function navRelease(token) {
    if (token != null && token !== carousel._navGen) return;
    carousel.navBusy = false;
    carousel._navTag = "";
  }
  async function drainRelays() {
    if (carousel.navBusy || !carousel.relayQueue.length) return;
    const tok = navAcquire("relay");
    try {
      while (carousel.relayQueue.length) {
        await deliverTask(carousel.relayQueue.shift());
        navTouch();
        await sleep(800);
      }
    } finally {
      navRelease(tok);
    }
  }
  async function searchContactEl(fan, id) {
    const input = q("search");
    if (!input) return null;
    input.focus();
    input.value = fan;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    let el = null;
    for (let i = 0; i < 12 && !el; i++) {
      await sleep(260);
      el = findContactEl(id, fan);
    }
    if (!el) clearContactSearch();
    return el;
  }
  function clearContactSearch() {
    const input = q("search");
    if (!input) return;
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }
  async function ensureChatOpen(fan, id, opts = {}) {
    const onTarget = () => id ? state.currentContactId === id : !!state.currentContactId && state.currentContact === fan;
    const openedId = () => state.currentContactId || id || null;
    if (onTarget()) return { ok: true, id: openedId() };
    let el = findContactEl(id, fan);
    let usedSearch = false;
    if (!el) {
      el = await searchContactEl(fan, id);
      usedSearch = !!el;
    }
    if (!el) {
      if (!opts.quiet) tgStatusLine(t("panel.tg.notFoundInList", state.uiLang, { fan }), fan);
      return { ok: false, id: null, notFound: true };
    }
    carousel._visitId = id || null;
    carousel._visitAt = Date.now();
    PLAT.openRow(el);
    await sleep(CONFIG.CONTACT_DELAY + 400);
    if (usedSearch) clearContactSearch();
    activateForContact(fan, id);
    await sleep(3800);
    if (!onTarget()) {
      tgStatusLine(t("panel.tg.notOpened", state.uiLang, { fan }), fan);
      return { ok: false, id: null };
    }
    return { ok: true, id: openedId() };
  }
  function tgStatusLine(line, fan) {
    tgMirrorLine(line, fan, false, [line + "#" + Date.now() + "#" + Math.random().toString(36).slice(2, 6)]);
  }
  function ackTgTask(task, ok = false) {
    if (task && task.pid) sendSafe({ type: "TG_ACK", pid: task.pid, ...ok ? { ok: true } : {} });
  }
  const tgGenTask = (g) => ({
    type: "genvar",
    fan: g.fan,
    id: g.id,
    hint: g.hint,
    proactive: g.proactive,
    forceOR: g.forceOR,
    pid: g.pid,
    single: g.single === true,
    turns: Array.isArray(g.turns) ? g.turns : null,
    again: g.again === true
  });
  const tgSendTask = (sv) => ({ type: "sendvar", fan: sv.fan, id: sv.id, idx: sv.idx, pid: sv.pid, text: typeof sv.text === "string" && sv.text.trim() ? sv.text : null });
  const tgVarKey = (id, fan) => id || fan;
  const SEND_CYR = ["ru", "uk", "be", "bg", "sr", "mk", "kk"];
  const SEND_LAT = ["en", "es", "de", "fr", "it", "pt", "pl", "cs", "tr", "nl", "sv", "da", "no", "nb", "fi", "ro", "hu", "sk", "sl", "hr", "lt", "lv", "et", "id", "ms"];
  function sendWrongScript(text, fanLang) {
    const s = String(text || ""), cyr = (s.match(/[Ѐ-ӿ]/g) || []).length, lat = (s.match(/[a-z]/gi) || []).length;
    const tl = String(fanLang || "en").toLowerCase().split(/[-_]/)[0];
    if (SEND_LAT.includes(tl)) return cyr > 0 && cyr * 3 >= lat;
    if (SEND_CYR.includes(tl)) return lat >= 8 && cyr * 3 < lat;
    return false;
  }
  async function latestFanTextForTarget(expectId) {
    for (let i = 0; i < 12; i++) {
      if (expectId && state.currentContactId !== expectId) return null;
      const lm = latestFanMsg();
      if (lm) return lm.isMedia ? null : lm.text || null;
      await sleep(500);
    }
    return null;
  }
  function sendResultLine(status, fan, shown) {
    if (status === "sent") return t("panel.tg.sentArrow", state.uiLang, { text: shown });
    const key = status === "unconfirmed" ? "panel.tg.sendUnconfirmed" : status === "wrong-chat" ? "panel.tg.sendWrongChat" : status === "busy" ? "panel.tg.sendBusy" : status === "no-field" ? "panel.tg.sendNoField" : status === "translate-failed" ? "panel.tg.sendTranslateFailed" : "panel.tg.sendFailed";
    return t(key, state.uiLang, { fan, text: shown });
  }
  const TG_CMD_CAPS = ["hist", "info", "draft", "lang", "unread", "del", "ban", "unban", "unread_all", "status"];
  function tgCmdLine(text, fan) {
    return sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "cmd", text, fan: fan || null });
  }
  const TG_HIST_N = 10, TG_HIST_LINE = 300;
  async function tgCmdHist(task, expectId) {
    const wrongChat = () => !!(expectId && state.currentContactId !== expectId);
    const gone = () => tgCmdLine(t("panel.tg.cmd.wrongChat", state.uiLang, { fan: task.fan }), task.fan);
    let list = [];
    for (let i = 0; i < 12 && !list.length; i++) {
      if (wrongChat()) return gone();
      ensureHistoryForCurrent();
      list = state.chatHistory.filter((e) => e.text || e.mediaType);
      if (!list.length) await sleep(500);
    }
    if (!list.length) return tgCmdLine(t("panel.tg.cmd.histEmpty", state.uiLang, { fan: task.fan }), task.fan);
    const lines = [];
    for (const e of list.slice(-TG_HIST_N)) {
      const own = e.role === "model";
      const tr = e.text ? await translateForOwner(e.text, own ? outGenders() : inGenders()) || e.text : "";
      const body = (e.mediaType ? mediaLabel(e.mediaType, e.mediaLocked) + (tr ? " " + tr : "") : tr).replace(/\s+/g, " ").trim();
      lines.push(`${own ? "\u{1F916}" : "\u{1F464}"} ${timeStr(e.timestamp)} \xB7 ${body.length > TG_HIST_LINE ? body.slice(0, TG_HIST_LINE) + "\u2026" : body}`);
    }
    if (wrongChat()) return gone();
    return tgCmdLine(t("panel.tg.cmd.histHead", state.uiLang, { fan: task.fan, n: lines.length }) + "\n" + lines.join("\n"), task.fan);
  }
  function chatMenuState() {
    if (PLATFORM === "onlyfans") return { ready: false, banned: null, receipts: null, card: null };
    const head = q("contactHeader");
    const ready = !!(head && (q("displayName", head)?.textContent || "").trim());
    const banned = ready ? !!head.querySelector(".user-icon i.fa-ban") : null;
    const item = receiptsItem();
    const receipts = item ? !!item.querySelector(":scope > i.fa-user-xmark") : null;
    return { ready, banned, receipts, card: ready ? !!head.querySelector(".user-icon i.fa-credit-card") : null };
  }
  function receiptsItem() {
    const list = document.querySelector(".message-content-header [appxddropdown].more-dropdown > .dropdown-list");
    if (!list) return null;
    const own = (el, cls) => !!el.querySelector(":scope > i." + cls);
    const rr = [...list.querySelectorAll(":scope > .dropdown-item:not([data-menu-item]):not([data-dropdown-value])")].filter((el) => !el.querySelector("app-account-username") && (own(el, "fa-user-xmark") || own(el, "fa-user-check")));
    return rr.length === 1 ? rr[0] : null;
  }
  const TG_CMD_FRESH = ["info", "unread"];
  async function leaveChat() {
    if (PLATFORM === "onlyfans") return false;
    const open = () => !!q("headerWrap");
    if (!open()) return true;
    const items = [...document.querySelectorAll('[data-menu-item="message"]')].sort((a, b) => (a.matches("[routerlink]") ? 1 : 0) - (b.matches("[routerlink]") ? 1 : 0));
    for (const el of items) {
      el.dispatchEvent(new MouseEvent("click", { bubbles: false, cancelable: true, composed: true, view: window }));
      for (let i = 0; i < 6; i++) {
        await sleep(250);
        if (!open()) {
          detectContact();
          return true;
        }
      }
    }
    return false;
  }
  async function readReceiptsFresh() {
    const dd = document.querySelector(".message-content-header [appxddropdown].more-dropdown");
    if (!dd) return null;
    const isOpen = () => dd.classList.contains("dropdown-open");
    const click = () => dd.dispatchEvent(new MouseEvent("click", { bubbles: false, cancelable: true, composed: true, view: window }));
    let opened = isOpen();
    if (!opened) {
      click();
      for (let i = 0; i < 6 && !opened; i++) {
        await sleep(250);
        opened = isOpen();
      }
    }
    if (!opened) return null;
    await sleep(300);
    const receipts = chatMenuState().receipts;
    click();
    for (let i = 0; i < 4 && isOpen(); i++) await sleep(250);
    return receipts;
  }
  const RR_MODAL = "app-conversation-read-receipts-change-modal.active-modal";
  const tgQuietClick = (el) => el.dispatchEvent(new MouseEvent("click", { bubbles: false, cancelable: true, composed: true, view: window }));
  async function tgCmdUnread(task, expectId) {
    const say = (key) => tgCmdLine(t(key, state.uiLang, { fan: task.fan }), task.fan);
    const wrongChat = () => !!(expectId && state.currentContactId !== expectId);
    if (wrongChat()) return say("panel.tg.cmd.wrongChat");
    if (!task.fresh) return say("panel.tg.cmd.urNoFresh");
    for (let i = 0; i < 12 && !chatMenuState().ready; i++) {
      if (wrongChat()) return say("panel.tg.cmd.wrongChat");
      await sleep(500);
    }
    const dd = document.querySelector(".message-content-header [appxddropdown].more-dropdown");
    const menuOpen = () => !!dd && dd.classList.contains("dropdown-open");
    const openMenu = async () => {
      if (!dd) return false;
      if (!menuOpen()) {
        tgQuietClick(dd);
        for (let i = 0; i < 6 && !menuOpen(); i++) await sleep(250);
      }
      if (menuOpen()) await sleep(300);
      return menuOpen();
    };
    const closeMenu = async () => {
      if (menuOpen()) {
        tgQuietClick(dd);
        for (let i = 0; i < 4 && menuOpen(); i++) await sleep(250);
      }
    };
    const modal = () => document.querySelector(RR_MODAL);
    const closeModal = async () => {
      const no = modal() && modal().querySelector(".modal-footer .btn:not(.solid-blue)");
      if (no) {
        tgQuietClick(no);
        for (let i = 0; i < 8 && modal(); i++) await sleep(250);
      }
    };
    if (!await openMenu()) return say("panel.tg.cmd.urNoMenu");
    const item = receiptsItem();
    if (!item || !/read\s*receipt|прочтени/i.test(item.textContent || "")) {
      await closeMenu();
      return say("panel.tg.cmd.urNoItem");
    }
    const was = !!item.querySelector(":scope > i.fa-user-xmark");
    if (wrongChat()) {
      await closeMenu();
      return say("panel.tg.cmd.wrongChat");
    }
    tgQuietClick(item);
    for (let i = 0; i < 12 && !modal(); i++) await sleep(250);
    const yes = modal() && modal().querySelector(".modal-footer .btn.solid-blue");
    if (!yes) {
      await closeModal();
      await closeMenu();
      return say("panel.tg.cmd.urNoConfirm");
    }
    if (wrongChat()) {
      await closeModal();
      await closeMenu();
      return say("panel.tg.cmd.wrongChat");
    }
    tgQuietClick(yes);
    for (let i = 0; i < 16 && modal(); i++) await sleep(250);
    if (modal()) await closeModal();
    await closeMenu();
    const now = await openMenu() ? chatMenuState().receipts : null;
    await closeMenu();
    if (now === null) return say("panel.tg.cmd.urUnknown");
    if (now === was) return say(now ? "panel.tg.cmd.urStillOn" : "panel.tg.cmd.urStillOff");
    return say(now ? "panel.tg.cmd.urOn" : "panel.tg.cmd.urOff");
  }
  const SETJOB_KEY = "fansly_tg_setjob", SETJOB_WAIT_MS = 6e4, SETJOB_FRESH_MS = 9e4;
  const setJobRead = () => new Promise((r) => chrome.storage.local.get(SETJOB_KEY, (d) => r(d && d[SETJOB_KEY] || null)));
  const setJobWrite = (rec) => new Promise((r) => chrome.storage.local.set({ [SETJOB_KEY]: rec }, () => r()));
  async function tgCmdUnreadAll(task) {
    const say = (key) => tgCmdLine(t(key, state.uiLang), null);
    const token = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    await setJobWrite({ token, job: "rr", at: Date.now(), state: "open" });
    const opened = await sendSafe({ type: "OPEN_SETTINGS_JOB" });
    if (!opened || !opened.success) {
      chrome.storage.local.remove(SETJOB_KEY);
      return say("panel.tg.cmd.urAllNoTab");
    }
    let rec = null;
    for (let i = 0; i < SETJOB_WAIT_MS / 500; i++) {
      await sleep(500);
      rec = await setJobRead();
      if (!rec || rec.token !== token || rec.state === "done") break;
    }
    chrome.storage.local.remove(SETJOB_KEY);
    if (!rec || rec.token !== token || rec.state !== "done") return say("panel.tg.cmd.urAllTimeout");
    if (rec.err || typeof rec.now !== "boolean") return say("panel.tg.cmd.urAllNoRow");
    if (rec.now === rec.was) return say(rec.now ? "panel.tg.cmd.urAllStillOn" : "panel.tg.cmd.urAllStillOff");
    return say(rec.now ? "panel.tg.cmd.urAllOn" : "panel.tg.cmd.urAllOff");
  }
  function settingsRrRow() {
    return [...document.querySelectorAll(".fansly-settings-row.toggle-row")].find((r) => /read\s*receipt|уведомлени\S*\s+о\s+прочтени/i.test((r.querySelector(".fansly-settings-label") || {}).textContent || "")) || null;
  }
  function tgContainedClick(el) {
    const ev = new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window });
    const stop = (e) => {
      if (e === ev) e.stopPropagation();
    };
    document.documentElement.addEventListener("click", stop);
    try {
      el.dispatchEvent(ev);
    } finally {
      document.documentElement.removeEventListener("click", stop);
    }
  }
  async function settingsJobRun() {
    const q2 = await sendSafe({ type: "SETTINGS_JOB_QUERY" });
    if (!q2 || !q2.mine) return;
    const job = await setJobRead();
    const close = () => setTimeout(() => sendSafe({ type: "CLOSE_TAB" }), 800);
    const stage = job && Date.now() - (job.at || 0) <= SETJOB_FRESH_MS ? job.state : null;
    if (stage !== "open" && stage !== "check") {
      close();
      return;
    }
    const finish = async (res) => {
      await setJobWrite({ ...job, state: "done", ...res });
      close();
    };
    try {
      if (stage === "open") await setJobWrite({ ...job, state: "run" });
      if (job.job === "status") return await settingsStatusJob(job, stage, finish);
      let row = null;
      for (let i = 0; i < 30 && !row; i++) {
        row = settingsRrRow();
        if (!row) await sleep(500);
      }
      const sw = row && row.querySelector("app-xd-switch .switch");
      if (!sw) return await finish({ err: "NoRow" });
      const isOn = () => sw.classList.contains("selected");
      if (stage === "check") return await finish({ now: isOn() });
      const was = isOn();
      tgContainedClick(sw.querySelector(".switch-toggle") || sw);
      await sleep(3e3);
      await setJobWrite({ ...job, state: "check", was });
      location.reload();
    } catch (e) {
      console.warn("[FanslyAI] /ur \u0434\u043B\u044F \u0432\u0441\u0435\u0445: \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u0432\u043E \u0432\u043A\u043B\u0430\u0434\u043A\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043A \u0443\u043F\u0430\u043B\u043E \u2014", e);
      await finish({ err: "NoRow" });
    }
  }
  const TG_STATUS_ICON = { online: "\u{1F7E2}", away: "\u{1F7E1}", hidden: "\u26AB" };
  const STATUS_OPT = { online: "online", away: "away", hidden: "offline" };
  function statusMode() {
    const a = document.querySelector('.user-account app-account-avatar[activeaccount="true"] > a');
    if (!a) return null;
    return a.classList.contains("available") ? "online" : a.classList.contains("away") ? "away" : a.classList.contains("offline") ? "hidden" : null;
  }
  async function tgCmdStatus(task) {
    const L = state.uiLang, want = String(task.arg || "");
    const name = (m) => t("panel.tg.cmd.statusName." + m, L);
    const say = (key, vars) => tgCmdLine(t(key, L, vars), null);
    if (!STATUS_OPT[want]) return say("panel.tg.cmd.unknown", { cmd: task.cmd });
    const token = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    await setJobWrite({ token, job: "status", arg: want, at: Date.now(), state: "open" });
    const opened = await sendSafe({ type: "OPEN_SETTINGS_JOB" });
    if (!opened || !opened.success) {
      chrome.storage.local.remove(SETJOB_KEY);
      return say("panel.tg.cmd.urAllNoTab");
    }
    let rec = null;
    for (let i = 0; i < SETJOB_WAIT_MS / 500; i++) {
      await sleep(500);
      rec = await setJobRead();
      if (!rec || rec.token !== token || rec.state === "done") break;
    }
    chrome.storage.local.remove(SETJOB_KEY);
    if (!rec || rec.token !== token || rec.state !== "done") return say("panel.tg.cmd.urAllTimeout");
    if (rec.err) return say(rec.was ? "panel.tg.cmd.statusUnknown" : "panel.tg.cmd.statusNoSwitch");
    if (!STATUS_OPT[rec.now]) return say("panel.tg.cmd.statusUnknown");
    if (rec.now !== want) return say("panel.tg.cmd.statusStill", { mode: name(rec.now) });
    return say(rec.same ? "panel.tg.cmd.statusAlready" : "panel.tg.cmd.statusSet", { icon: TG_STATUS_ICON[want], mode: name(want) });
  }
  async function settingsStatusJob(job, stage, finish) {
    let mode = null;
    for (let i = 0; i < 30 && !mode; i++) {
      mode = statusMode();
      if (!mode) await sleep(500);
    }
    if (stage === "check") return finish(mode ? { now: mode } : { err: "NoSwitch" });
    if (!mode) return finish({ err: "NoSwitch" });
    if (mode === job.arg) return finish({ was: mode, now: mode, same: true });
    const option = () => {
      const ic = document.querySelector(".user-account app-online-status-controller .status-icon." + STATUS_OPT[job.arg]);
      return ic ? ic.closest(".status-wrapper") : null;
    };
    let wrap = option();
    if (!wrap) {
      const acc = document.querySelector("[appxddropdown].user-account");
      if (acc) {
        tgQuietClick(acc);
        for (let i = 0; i < 6 && !wrap; i++) {
          await sleep(250);
          wrap = option();
        }
      }
    }
    if (!wrap) return finish({ err: "NoSwitch" });
    tgContainedClick(wrap.querySelector(".status-text") || wrap);
    await sleep(3e3);
    await setJobWrite({ ...job, state: "check", was: mode });
    location.reload();
  }
  const DEL_MODAL = "app-button-new-confirmation-modal.active-modal";
  async function tgCmdDel(task, expectId) {
    const say = (key, vars) => tgCmdLine(t(key, state.uiLang, { fan: task.fan, ...vars || {} }), task.fan);
    const wrongChat = () => !!(expectId && state.currentContactId !== expectId);
    const modal = () => document.querySelector(DEL_MODAL);
    const cancel = async () => {
      const no = modal() && modal().querySelector(".modal-footer .btn:not(.solid-blue)");
      if (no) {
        tgQuietClick(no);
        for (let i = 0; i < 8 && modal(); i++) await sleep(250);
      }
    };
    let own = [];
    for (let i = 0; i < 12 && !own.length; i++) {
      if (wrongChat()) return say("panel.tg.cmd.wrongChat");
      own = [...qa("messageNode")].filter((n) => PLAT.isOwn(n));
      if (!own.length) await sleep(500);
    }
    if (!own.length) return say("panel.tg.cmd.delNone");
    const node = own[own.length - 1];
    const text = getMessageText(node) || "", ts = PLAT.timeOf(node);
    const label = bodyMediaEl(node) ? mediaLabel(detectMediaType(node), detectMediaLocked(node)) : "";
    const btn = node.querySelector(".delete-my-message");
    if (!btn) return say("panel.tg.cmd.delNoButton");
    if (modal()) return say("panel.tg.cmd.delBusy");
    const host = btn.closest("app-button-new");
    const targets = [host, host && host.firstElementChild, btn.parentElement, btn].filter((el, i, a) => el && a.indexOf(el) === i);
    for (const el of targets) {
      if (wrongChat()) {
        await cancel();
        return say("panel.tg.cmd.wrongChat");
      }
      tgQuietClick(el);
      for (let i = 0; i < 4 && !modal(); i++) await sleep(250);
      if (modal()) break;
    }
    const yes = modal() && modal().querySelector(".modal-footer .btn.solid-blue");
    if (!yes) {
      await cancel();
      return say("panel.tg.cmd.delNoConfirm");
    }
    if (!/delete\s+this\s+message|удалить\s+(это\s+)?сообщени/i.test(modal().textContent || "")) {
      await cancel();
      return say("panel.tg.cmd.delWrongModal");
    }
    if (wrongChat() || !document.contains(node)) {
      await cancel();
      return say("panel.tg.cmd.wrongChat");
    }
    tgQuietClick(yes);
    const gone = () => !document.contains(node) || !node.querySelector(".delete-my-message");
    for (let i = 0; i < 16 && (modal() || !gone()); i++) await sleep(250);
    if (modal()) await cancel();
    const shown = text ? await translateForOwner(text, outGenders()) || text : "";
    const body = (label + (label && shown ? " " : "") + shown).replace(/\s+/g, " ").trim() || "\u2014";
    const what = (ts ? timeStr(ts) + " \xB7 " : "") + (body.length > TG_HIST_LINE ? body.slice(0, TG_HIST_LINE) + "\u2026" : body);
    return say(gone() ? "panel.tg.cmd.delDone" : "panel.tg.cmd.delFailed", { text: what });
  }
  async function tgCmdBlock(task, expectId, want) {
    const say = (key) => tgCmdLine(t(key, state.uiLang, { fan: task.fan }), task.fan);
    const wrongChat = () => !!(expectId && state.currentContactId !== expectId);
    const banned = () => chatMenuState().banned;
    const modal = () => document.querySelector(DEL_MODAL);
    const cancel = async () => {
      const no = modal() && modal().querySelector(".modal-footer .btn:not(.solid-blue)");
      if (no) {
        tgQuietClick(no);
        for (let i = 0; i < 8 && modal(); i++) await sleep(250);
      }
    };
    for (let i = 0; i < 12 && !chatMenuState().ready; i++) {
      if (wrongChat()) return say("panel.tg.cmd.wrongChat");
      await sleep(500);
    }
    if (wrongChat()) return say("panel.tg.cmd.wrongChat");
    const was = banned();
    if (was === null) return say("panel.tg.cmd.banNoState");
    if (was === want) return say(want ? "panel.tg.cmd.banAlready" : "panel.tg.cmd.unbanAlready");
    const dd = document.querySelector(".message-content-header [appxddropdown].more-dropdown");
    const menuOpen = () => !!dd && dd.classList.contains("dropdown-open");
    const closeMenu = async () => {
      if (menuOpen()) {
        tgQuietClick(dd);
        for (let i = 0; i < 4 && menuOpen(); i++) await sleep(250);
      }
    };
    if (dd && !menuOpen()) {
      tgQuietClick(dd);
      for (let i = 0; i < 6 && !menuOpen(); i++) await sleep(250);
    }
    if (!menuOpen()) return say("panel.tg.cmd.banNoMenu");
    await sleep(300);
    const item = dd.querySelector(':scope > .dropdown-list [data-menu-item="block"]');
    const offers = !item ? null : item.querySelector(":scope > i.fa-ban") ? true : item.querySelector(":scope > i.fa-user-check") ? false : null;
    if (offers !== want) {
      await closeMenu();
      return say("panel.tg.cmd.banNoItem");
    }
    if (modal()) {
      await closeMenu();
      return say("panel.tg.cmd.banBusy");
    }
    const host = item.closest("app-button-new");
    const targets = [host, host && host.firstElementChild, item.parentElement, item].filter((el, i, a) => el && a.indexOf(el) === i);
    for (const el of targets) {
      if (wrongChat()) {
        await cancel();
        await closeMenu();
        return say("panel.tg.cmd.wrongChat");
      }
      tgQuietClick(el);
      for (let i = 0; i < 4 && !modal() && banned() !== want; i++) await sleep(250);
      if (modal() || banned() === want) break;
    }
    const m = modal(), yes = m && m.querySelector(".modal-footer .btn.solid-blue");
    if (yes) {
      const q2 = [...m.querySelectorAll(".modal-body, .modal-body *")].filter((el) => !el.closest("app-account-username")).flatMap((el) => [...el.childNodes]).filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ");
      const unblock = /\bunblock\b|разблокировать/i.test(q2), block = !unblock && /\bblock\b|заблокировать/i.test(q2);
      if (want ? !block : !unblock) {
        await cancel();
        await closeMenu();
        return say("panel.tg.cmd.banWrongModal");
      }
      if (wrongChat()) {
        await cancel();
        await closeMenu();
        return say("panel.tg.cmd.wrongChat");
      }
      tgQuietClick(yes);
      for (let i = 0; i < 16 && (modal() || banned() !== want); i++) await sleep(250);
      if (modal()) await cancel();
    } else if (m) await cancel();
    await closeMenu();
    if (banned() === want) return say(want ? "panel.tg.cmd.banDone" : "panel.tg.cmd.unbanDone");
    return say(yes ? want ? "panel.tg.cmd.banFailed" : "panel.tg.cmd.unbanFailed" : "panel.tg.cmd.banNoConfirm");
  }
  const TG_INFO_FACTS = 5, TG_INFO_FACT = 160;
  const TG_STAGE_ICON = { lead: "\u{1F331}", acquaint: "\u{1F44B}", interest: "\u{1F4AC}", brief: "\u{1F4CB}", paid: "\u{1F4B0}", repeat: "\u{1F501}", lost: "\u{1F6AA}", cold: "\u{1F4A4}" };
  const TG_CLOSENESS = { new: "\u{1F331}", interested: "\u{1F4AC}", regular: "\u{1F525}", supporter: "\u{1F48E}" };
  function tgInfoCard(card) {
    return t(card === true ? "panel.tg.cmd.infoCardYes" : card === false ? "panel.tg.cmd.infoCardNo" : "panel.tg.cmd.infoCardUnknown", state.uiLang);
  }
  function tgInfoChips(f, card) {
    const L = state.uiLang, money = (n) => (+(+n).toFixed(2)).toString(), daysAgo = (at) => Math.floor((Date.now() - at) / 864e5);
    const hot = [], ref = [];
    hot.push(TG_STAGE_ICON[f.stage] + " " + t("crm.stage." + f.stage, L));
    if (f.contact && f.contact.notCustomer) hot.push(t("crm.card.notCustomer.badge", L));
    if (f.stuck) hot.push(t("crm.stuck." + f.stuck.key, L, { n: f.stuck.n }));
    if (f.sub && f.sub.tierName) hot.push("\u2B50 " + f.sub.tierName);
    if (f.spent > 0) hot.push(t("crm.card.spent", L, { n: money(f.spent) }));
    if (f.buyCount > 0) hot.push(t("crm.card.buys", L, { n: f.buyCount }));
    if (f.lastBuyAt) hot.push(t("panel.tg.cmd.infoLastBuy", L, { d: new Date(f.lastBuyAt).toLocaleDateString(L, { day: "2-digit", month: "2-digit", year: "2-digit" }) }));
    if (f.activeSub && f.sub && f.sub.price) hot.push(t("crm.card.perMonth", L, { n: money(f.sub.price) }));
    if (f.activeSub && f.sub && f.sub.billingCycle) hot.push(t("crm.card.cycle", L, { v: f.sub.billingCycle }));
    if (f.activeSub && f.sub && f.sub.renewOn === true) hot.push(t("crm.card.renewOn", L));
    if (f.activeSub && f.sub && f.sub.renewOn === false) hot.push(t("crm.card.renewOff", L));
    if (f.activeSub && f.daysLeft != null) hot.push(t("crm.card.renews", L, { n: f.daysLeft }));
    if (f.expired) {
      const dt = (f.sub && f.sub.endDate || "").replace(/^[A-Za-z]+,\s*/, "");
      hot.push(t("crm.card.expired", L) + (dt ? " " + dt : ""));
    }
    if (f.deleted) hot.push(t("crm.card.deleted", L));
    if (f.months) ref.push(t("crm.card.months", L, { n: f.months }));
    if (f.firstSubAt) ref.push(t("crm.card.since", L, { d: new Date(f.firstSubAt).toLocaleDateString(L, { month: "short", year: "numeric" }) }));
    if (f.subCount > 1) ref.push(t("crm.card.subcount", L, { n: f.subCount }));
    ref.push(tgInfoCard(card));
    const d = f.contact && f.contact.dossier;
    if (d && d.lastMessageAt) {
      const n = daysAgo(d.lastMessageAt);
      ref.push(t(n <= 0 ? "crm.card.lastMsgToday" : "crm.card.lastMsg", L, { n }));
    }
    if (d && TG_CLOSENESS[d.closeness]) ref.push(TG_CLOSENESS[d.closeness] + " " + t("crm.card.closeness", L, { v: t("common.closeness." + d.closeness, L) }));
    const likeAt = f.lastLikeAt;
    if (likeAt) {
      const n = daysAgo(likeAt);
      (n <= 30 && f.expired ? hot : ref).push(t(n <= 0 ? "crm.card.lastLikeToday" : "crm.card.lastLike", L, { n }));
    }
    return { hot, ref };
  }
  function tgInfoSpent(f) {
    const L = state.uiLang, money = (n) => (+(+n).toFixed(2)).toString(), p = [];
    if (f.subSpent > 0) p.push(t("crm.tip.spent.subs", L, { n: money(f.subSpent) }));
    if (f.buySpent > 0) p.push(t("crm.tip.spent.buys", L, { n: money(f.buySpent) }));
    if (f.tipSpent > 0) p.push(t("crm.tip.spent.tips", L, { n: money(f.tipSpent) }));
    if (f.buysNoAmount > 0) p.push(t("crm.tip.spent.unknown", L, { n: f.buysNoAmount }));
    return p.map((s) => s.replace(/^·\s*/, "")).join(" \xB7 ");
  }
  async function tgCmdInfo(task, expectId) {
    const L = state.uiLang;
    const wrongChat = () => !!(expectId && state.currentContactId !== expectId);
    const gone = () => tgCmdLine(t("panel.tg.cmd.wrongChat", L, { fan: task.fan }), task.fan);
    let c = null, st = chatMenuState();
    for (let i = 0; i < 12; i++) {
      if (wrongChat()) return gone();
      c = contactDataIsCurrent() ? state.contactData : null;
      st = chatMenuState();
      if (c && st.ready) break;
      await sleep(500);
    }
    if (!c) return tgCmdLine(t("panel.tg.cmd.infoNoContact", L, { fan: task.fan }), task.fan);
    const receipts = task.fresh ? await readReceiptsFresh() : null;
    const handle = c.handle || "";
    const f = await tgInfoCrm(c, task.fan);
    if (wrongChat()) return gone();
    const card = st.card || f && f.paid ? true : st.card === false ? false : (f ? f.hasCard : c.hasCard) ? true : null;
    const out = [tgInfoHead(task, c, f), ...tgInfoMoney(f, handle, card)];
    out.push(t(st.banned === true ? "panel.tg.cmd.infoBanYes" : st.banned === false ? "panel.tg.cmd.infoBanNo" : "panel.tg.cmd.infoBanUnknown", L) + " \xB7 " + t(receipts === true ? "panel.tg.cmd.infoRrOn" : receipts === false ? "panel.tg.cmd.infoRrOff" : "panel.tg.cmd.infoRrUnknown", L));
    out.push(...tgInfoFacts(c));
    return tgCmdLine(out.join("\n"), task.fan);
  }
  async function tgInfoCrm(c, fanName) {
    const handle = c.handle || "";
    const [stores, set] = await Promise.all([
      new Promise((r) => chrome.storage.local.get(CRM.STORE_KEYS, (d) => r(d || {}))),
      sendSafe({ type: "GET_SETTINGS" })
    ]);
    try {
      return handle ? CRM.computeFan(handle, c.name || fanName, stores, c, { briefStaleHours: set?.result?.briefStaleHours ?? 48 }) : null;
    } catch (e) {
      console.warn("[FanslyAI] /i: \u0440\u0430\u0441\u0447\u0451\u0442 CRM \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F \u2014", e);
      return null;
    }
  }
  function tgInfoHead(task, c, f) {
    const L = state.uiLang, handle = c.handle || "";
    return "\u2139\uFE0F " + task.fan + (handle ? ` (@${handle})` : "") + (f ? " \xB7 " + t("panel.tg.cmd.infoScore", L, { n: f.score }) : "") + " \xB7 " + t("panel.tg.cmd.infoLang", L, { lang: String(c.lang || "en").toUpperCase() });
  }
  function tgInfoMoney(f, handle, card) {
    if (!f) return [t(handle ? "panel.tg.cmd.infoCrmFailed" : "panel.tg.cmd.infoNoHandle", state.uiLang), tgInfoCard(card)];
    const ch = tgInfoChips(f, card), sp = tgInfoSpent(f);
    return [ch.hot.join(" \xB7 "), ch.ref.join(" \xB7 "), ...sp ? [sp] : []];
  }
  function tgInfoFacts(c) {
    const L = state.uiLang, out = [];
    const pinned = (c.dossier && c.dossier.manualFacts || []).filter(Boolean);
    const facts = [...pinned, ...(c.dossier && c.dossier.facts || []).filter((x) => x && !pinned.includes(x))];
    if (!facts.length) return out;
    out.push(t("panel.tg.cmd.infoFacts", L, { n: facts.length }));
    for (const x of facts.slice(0, TG_INFO_FACTS)) {
      const s = String(x).replace(/\s+/g, " ").trim();
      out.push((pinned.includes(x) ? "\u{1F4CC} " : "\u2022 ") + (s.length > TG_INFO_FACT ? s.slice(0, TG_INFO_FACT) + "\u2026" : s));
    }
    if (facts.length > TG_INFO_FACTS) out.push(t("panel.tg.cmd.infoFactsMore", L, { n: facts.length - TG_INFO_FACTS }));
    return out;
  }
  async function tgCmdInfoNoChat(task) {
    const L = state.uiLang;
    const c = task.id ? await readContactRecord(task.id) : null;
    if (!c) return tgStatusLine(t("panel.tg.notFoundInList", L, { fan: task.fan }), task.fan);
    const handle = c.handle || "";
    const f = await tgInfoCrm(c, task.fan);
    const card = f && f.paid || (f ? f.hasCard : c.hasCard) ? true : null;
    const text = [
      tgInfoHead(task, c, f),
      t(f && f.deleted ? "panel.tg.cmd.infoNoChatGone" : "panel.tg.cmd.infoNoChat", L),
      ...tgInfoMoney(f, handle, card),
      ...tgInfoFacts(c)
    ].join("\n");
    return tgCmdLine(text, task.fan);
  }
  const TG_LANGS = ["en", "es", "pt", "de", "fr", "it", "pl", "tr", "ru", "uk"];
  const TG_LANG_ALIAS = { ua: "uk", eng: "en", "\u0440\u0443": "ru", "\u0440\u0443\u0441": "ru", "\u0430\u043D\u0433\u043B": "en" };
  async function tgCmdLang(task, rec) {
    const L = state.uiLang, list = TG_LANGS.join(", "), up = (x) => String(x || "en").toUpperCase();
    if (!rec) return tgCmdLine(t("panel.tg.cmd.infoNoContact", L, { fan: task.fan }), task.fan);
    const raw = String(task.arg || "").trim().toLowerCase(), want = TG_LANG_ALIAS[raw] || raw;
    const cur = String(rec.lang || "en").toLowerCase();
    if (!raw) return tgCmdLine(t("panel.tg.cmd.langShow", L, { fan: task.fan, lang: up(cur), list }), task.fan);
    if (!TG_LANGS.includes(want)) return tgCmdLine(t("panel.tg.cmd.langUnknown", L, { arg: raw.slice(0, 32), list }), task.fan);
    if (want === cur) return tgCmdLine(t("panel.tg.cmd.langSame", L, { fan: task.fan, lang: up(cur) }), task.fan);
    let saved;
    if (rec === state.contactData && contactDataIsCurrent()) {
      saveContact(state.currentContact, { lang: want });
      const btn = document.getElementById("fai-fan-lang");
      if (btn) btn.textContent = up(want);
      saved = true;
    } else {
      saved = !!task.id && await ContactStore.patchRecord(ContactStore.keyOfId(task.id), { lang: want });
    }
    return tgCmdLine(t(saved ? "panel.tg.cmd.langSet" : "panel.tg.cmd.langFailed", L, { fan: task.fan, from: up(cur), to: up(want) }), task.fan);
  }
  async function tgCmdLangOpen(task, expectId) {
    let rec = null;
    for (let i = 0; i < 12 && !rec; i++) {
      if (expectId && state.currentContactId !== expectId) return tgCmdLine(t("panel.tg.cmd.wrongChat", state.uiLang, { fan: task.fan }), task.fan);
      rec = contactDataIsCurrent() ? state.contactData : null;
      if (!rec) await sleep(500);
    }
    return tgCmdLang(task, rec);
  }
  async function runTgCmd(task, expectId) {
    if (task.cmd === "hist") return tgCmdHist(task, expectId);
    if (task.cmd === "info") return tgCmdInfo(task, expectId);
    if (task.cmd === "lang") return tgCmdLangOpen(task, expectId);
    if (task.cmd === "unread") return task.fan ? tgCmdUnread(task, expectId) : tgCmdUnreadAll(task);
    if (task.cmd === "del" && task.fan) return tgCmdDel(task, expectId);
    if (task.cmd === "status" && !task.fan) return tgCmdStatus(task);
    if (task.cmd === "ban" && task.fan) return tgCmdBlock(task, expectId, true);
    if (task.cmd === "unban" && task.fan) return tgCmdBlock(task, expectId, false);
    return tgCmdLine(t("panel.tg.cmd.unknown", state.uiLang, { cmd: task.cmd }), task.fan);
  }
  async function deliverTask(task) {
    if (!task) return;
    if (state.masterEnabled === false) return;
    if (task.type === "cmd" && !task.fan) {
      await runTgCmd(task, null);
      return ackTgTask(task);
    }
    if (!task.fan || task.type === "relay" && !task.text) return ackTgTask(task);
    if (task.type === "cmd" && task.cmd === "lang" && task.id) {
      const rec = contactDataIsCurrent() && state.currentContactId === task.id ? state.contactData : await readContactRecord(task.id);
      if (rec) {
        await tgCmdLang(task, rec);
        return ackTgTask(task);
      }
    }
    if (task.type === "cmd" && TG_CMD_FRESH.includes(task.cmd)) task.fresh = await leaveChat();
    const infoCmd = task.type === "cmd" && task.cmd === "info";
    const open = await ensureChatOpen(task.fan, task.id, { quiet: infoCmd });
    if (!open.ok) {
      if (infoCmd && open.notFound) await tgCmdInfoNoChat(task);
      return ackTgTask(task);
    }
    const expectId = open.id;
    const sendOpts = { manual: true, skipTranslate: true, expectId, expectFan: task.fan };
    const msPerWord = carousel.settings?.nightMsPerWord || 700;
    const vkey = tgVarKey(expectId, task.fan);
    let sentOk = false;
    if (task.type === "relay") {
      const fanLang = state.contactData?.lang || "en";
      const tr = await translateOutgoing(task.text, fanLang, expectId);
      if (tr == null && fanLang !== state.nativeLang) {
        tgStatusLine(sendResultLine("translate-failed", task.fan, task.text), task.fan);
      } else {
        const translated = tr != null ? tr : task.text;
        state.transCache.set(tcKey(translated, outGenders()), task.text);
        const status = await humanTypeAndSend(translated, msPerWord, sendOpts);
        tgStatusLine(sendResultLine(status, task.fan, translated), task.fan);
      }
    } else if (task.type === "genvar" && task.single) {
      const text = await latestFanTextForTarget(expectId);
      const hint = (task.hint || "").trim();
      if (!text && !hint) {
        tgStatusLine(t("panel.tg.noIncoming", state.uiLang, { fan: task.fan }), task.fan);
        return ackTgTask(task);
      }
      const res = await processDialogue({
        text: text || "",
        hint,
        trigger: "manual",
        regenerate: true,
        proactive: !text,
        forceOR: !!task.forceOR,
        single: true,
        turns: task.turns || [],
        again: !!task.again
      });
      const draft = res.success ? String(res.suggestions?.[0] || "").trim() : "";
      if (!draft) {
        tgStatusLine(res.noOpenRouter ? t("panel.tg.noOpenRouter", state.uiLang) : t("panel.tg.genFailed", state.uiLang, { fan: task.fan }), task.fan);
        return ackTgTask(task);
      }
      if (!state.tgVariants) state.tgVariants = {};
      state.tgVariants[vkey] = [draft];
      const shown = await translateForOwner(draft, outGenders()) || draft;
      sendSafe({
        type: "NOTIFY_TELEGRAM",
        notifyType: "variants",
        fan: task.fan,
        text: t("panel.tg.draftHeader", state.uiLang, { fan: task.fan }) + "\n" + shown,
        variantCount: 1,
        single: true,
        draft,
        task: hint,
        again: !!task.again
      });
    } else if (task.type === "genvar") {
      let res;
      if (task.proactive) {
        res = await processDialogue({ text: "", hint: task.hint || "", trigger: "manual", regenerate: true, proactive: true, forceOR: !!task.forceOR });
      } else {
        const text = await latestFanTextForTarget(expectId);
        if (!text) {
          tgStatusLine(t("panel.tg.noIncoming", state.uiLang, { fan: task.fan }), task.fan);
          return ackTgTask(task);
        }
        res = await processDialogue({ text, trigger: "manual", regenerate: true });
      }
      if (!res.success || !res.suggestions?.length) {
        tgStatusLine(res.noOpenRouter ? t("panel.tg.noOpenRouter", state.uiLang) : t("panel.tg.genFailed", state.uiLang, { fan: task.fan }), task.fan);
        return ackTgTask(task);
      }
      const variants = res.suggestions.slice(0, 3);
      if (!state.tgVariants) state.tgVariants = {};
      state.tgVariants[vkey] = variants;
      const translated = [];
      for (const v of variants) translated.push(await translateForOwner(v, outGenders()) || v);
      const body = t("panel.tg.variantsHeader", state.uiLang, { fan: task.fan }) + "\n" + translated.map((tx, i) => `${i + 1}. ${tx}`).join("\n\n");
      sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "variants", fan: task.fan, text: body, variantCount: variants.length });
    } else if (task.type === "sendvar") {
      const variants = state.tgVariants?.[vkey];
      const chosen = task.text || variants && variants[task.idx] || "";
      if (!chosen) {
        tgStatusLine(t("panel.tg.variantUnavailable", state.uiLang, { fan: task.fan }), task.fan);
        return ackTgTask(task);
      }
      const fanLang = state.contactData?.lang || "en";
      if (sendWrongScript(chosen, fanLang)) {
        tgStatusLine(t("panel.tg.sendWrongLang", state.uiLang, { fan: task.fan, lang: fanLang.toUpperCase() }), task.fan);
        return ackTgTask(task);
      }
      const status = await humanTypeAndSend(chosen, msPerWord, sendOpts);
      const shown = await translateForOwner(chosen, outGenders()) || chosen;
      tgStatusLine(sendResultLine(status, task.fan, shown), task.fan);
      if (status === "sent") {
        sentOk = true;
        if (state.tgVariants) delete state.tgVariants[vkey];
      }
    } else if (task.type === "cmd") {
      await runTgCmd(task, expectId);
    }
    ackTgTask(task, sentOk);
    if (_isInviteTab && (task.type === "relay" || task.type === "sendvar")) finishInviteTab();
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const randInt = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
  async function getSettingsAsync() {
    const r = await sendSafe({ type: "GET_SETTINGS" });
    return r?.result || {};
  }
  const LEADER_KEY = "fansly_ai_carousel_leader";
  const LEADER_STALE_MS = 18e4;
  const LEADER_TICK_MS = 5e3;
  const LEADER_UNLOAD_GRACE_MS = 6e4;
  const LEADER_RECLAIM_MS = 15e3;
  const LEADER_RECLAIM_WINDOW_MS = 9e4;
  const LEADER_PAGE_AT = Date.now();
  const BUILD_STAMP = true ? "2e0e758@20261107.1705" : "dev";
  const PULT_PREV_KEY = "fai_pult_prev";
  const BOOT_KEY = "fansly_browser_start";
  let _bootAt = 0;
  const CLOSED_KEY = "fansly_pult_closed";
  let _closedPage = "";
  const HUMAN_IDLE_MS = 12e4;
  let _lastHumanAt = Date.now();
  function noteHuman(e) {
    if (e && e.isTrusted) _lastHumanAt = Date.now();
  }
  window.addEventListener("keydown", noteHuman, true);
  window.addEventListener("pointerdown", noteHuman, true);
  function humanIdle() {
    return Date.now() - _lastHumanAt > HUMAN_IDLE_MS;
  }
  function pultPrevGet() {
    try {
      return sessionStorage.getItem(PULT_PREV_KEY);
    } catch (e) {
      return null;
    }
  }
  function pultPrevSet() {
    try {
      sessionStorage.setItem(PULT_PREV_KEY, _tabId());
    } catch (e) {
    }
  }
  function pultPrevClear() {
    try {
      sessionStorage.removeItem(PULT_PREV_KEY);
    } catch (e) {
    }
  }
  function readLeader() {
    return new Promise((r) => chrome.storage.local.get([LEADER_KEY, BOOT_KEY, CLOSED_KEY], (d) => {
      _bootAt = d[BOOT_KEY] || 0;
      _closedPage = d[CLOSED_KEY] && d[CLOSED_KEY].page || "";
      r(d[LEADER_KEY] || null);
    }));
  }
  function claimLeader() {
    pultPrevSet();
    return new Promise((r) => chrome.storage.local.set({ [LEADER_KEY]: { tabId: _tabId(), ts: Date.now(), stamp: BUILD_STAMP } }, r));
  }
  function leaderStateOf(l, me, prev, now, stamp, fresh, bootAt = 0, closedPage = "") {
    if (!l) return "free";
    if (l.tabId === me) return "mine";
    const age = now - (l.ts || 0);
    const gone = !!l.unloading || l.stamp !== stamp;
    if (fresh && prev && l.tabId === prev && (gone || age >= LEADER_RECLAIM_MS)) return "reclaim";
    if (closedPage && l.tabId === closedPage) return "dead";
    if (bootAt && (l.ts || 0) < bootAt && age >= LEADER_RECLAIM_MS) return "dead";
    return age < (gone ? LEADER_UNLOAD_GRACE_MS : LEADER_STALE_MS) ? "alive" : "dead";
  }
  function leaderStateNow(l) {
    const now = Date.now();
    return leaderStateOf(l, _tabId(), pultPrevGet(), now, BUILD_STAMP, now - LEADER_PAGE_AT < LEADER_RECLAIM_WINDOW_MS, _bootAt, _closedPage);
  }
  function leaderState() {
    return readLeader().then(leaderStateNow);
  }
  function leaderNote(l, now) {
    if (!l) return "";
    const age = Math.max(0, now - (l.ts || 0));
    const why = l.unloading ? ", \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u0443\u0445\u043E\u0434\u0438\u0442" : l.stamp !== BUILD_STAMP ? ", \u043E\u0442 \u043F\u0440\u0435\u0436\u043D\u0435\u0439 \u0441\u0431\u043E\u0440\u043A\u0438" : "";
    const left = Math.max(0, (why ? LEADER_UNLOAD_GRACE_MS : LEADER_STALE_MS) - age);
    return "\u043E\u0442\u043C\u0435\u0442\u043A\u0430 " + Math.round(age / 1e3) + " \u0441 \u043D\u0430\u0437\u0430\u0434" + why + ", \u043E\u0441\u0432\u043E\u0431\u043E\u0434\u0438\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 " + Math.round(left / 1e3) + " \u0441";
  }
  function mayTakeOver() {
    return document.hidden || humanIdle();
  }
  const PULT_OPEN_WAIT_MS = 6e4;
  let _pultOpenAt = 0;
  function pultOpenPending() {
    return Date.now() - _pultOpenAt < PULT_OPEN_WAIT_MS;
  }
  function pultOffWanted(s) {
    return !carousel.running && !!state._carouselWanted && s === "dead" && !mayTakeOver() && !pultOpenPending();
  }
  function askPultOpened() {
    sendSafe({ type: "PULT_OPEN_CHECK" }).then((r) => {
      if (!r?.yes) return;
      state._pultOpened = true;
      if (state._carouselWanted && !carousel.running) startNightMode(false, true);
    });
  }
  function renderPultOff(show) {
    const box = document.getElementById("fai-pult-off");
    if (!box) return;
    box.style.display = show ? "flex" : "none";
    if (!show) return;
    const here = document.getElementById("fai-pult-off-here"), open = document.getElementById("fai-pult-off-open");
    document.getElementById("fai-pult-off-text").textContent = t("panel.pultOff.text", state.uiLang);
    here.textContent = t("panel.pultOff.here", state.uiLang);
    open.textContent = t("panel.pultOff.open", state.uiLang);
    if (box.dataset.faiWired) return;
    box.dataset.faiWired = "1";
    here.addEventListener("click", () => {
      box.style.display = "none";
      startNightMode(false, true);
    });
    open.addEventListener("click", () => {
      _pultOpenAt = Date.now();
      box.style.display = "none";
      sendSafe({ type: "OPEN_PULT_TAB" });
    });
  }
  function refreshPultOff() {
    if (!PLAT.isMessagesPage() || state.masterEnabled === false) {
      renderPultOff(false);
      return;
    }
    leaderState().then((s) => renderPultOff(pultOffWanted(s)));
  }
  async function nightModeBlocked(manual = false) {
    const l = await readLeader(), s = leaderStateNow(l);
    if (s === "alive") return "\u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0432\u0435\u0434\u0451\u0442 \u0434\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 (" + leaderNote(l, Date.now()) + ")";
    if ((s === "dead" || s === "free") && !manual && pultOpenPending()) return "\u0436\u0434\u0451\u043C \u0432\u043A\u043B\u0430\u0434\u043A\u0443 \u043F\u0443\u043B\u044C\u0442\u0430, \u043E\u0442\u043A\u0440\u044B\u0442\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u043E\u0439 (\u0434\u043E \u043C\u0438\u043D\u0443\u0442\u044B)";
    if (s === "dead" && !manual && !mayTakeOver()) return "\u043F\u0443\u043B\u044C\u0442 \u0432 \u0434\u0440\u0443\u0433\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435 \u043C\u043E\u043B\u0447\u0438\u0442, \u043D\u043E \u0437\u0434\u0435\u0441\u044C \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0447\u0435\u043B\u043E\u0432\u0435\u043A";
    return "";
  }
  function releaseLeaderIfOurs() {
    pultPrevClear();
    readLeader().then((l) => {
      if (l && l.tabId === _tabId()) chrome.storage.local.remove(LEADER_KEY);
    });
  }
  function leaderOnPageHide() {
    if (!carousel.running) return;
    try {
      chrome.storage.local.set({ [LEADER_KEY]: { tabId: _tabId(), ts: Date.now(), stamp: BUILD_STAMP, unloading: true } });
    } catch (e) {
    }
  }
  window.addEventListener("pagehide", leaderOnPageHide);
  async function leaderTick() {
    if (!PLAT.isMessagesPage() || state.masterEnabled === false) {
      renderPultOff(false);
      return;
    }
    const s = await leaderState();
    if (carousel.running) {
      if (s === "alive") {
        console.log("[FanslyAI] \u{1F6A9} \u043B\u0438\u0434\u0435\u0440\u0441\u0442\u0432\u043E \u043F\u0435\u0440\u0435\u0445\u0432\u0430\u0447\u0435\u043D\u043E \u0434\u0440\u0443\u0433\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u043E\u0439 \u2014 \u0443\u0441\u0442\u0443\u043F\u0430\u044E");
        stopNightMode("common.reason.otherTab");
      } else claimLeader();
    } else if (state._carouselWanted) {
      const opened = !!state._pultOpened, waiting = pultOpenPending();
      if (s === "mine" || s === "reclaim" || s === "free" && !waiting || s === "dead" && (opened || !waiting && mayTakeOver()))
        startNightMode(false, opened);
    }
    renderPultOff(pultOffWanted(s));
  }
  function startLeaderTick() {
    if (!state._leaderTimer) state._leaderTimer = setInterval(leaderTick, LEADER_TICK_MS);
  }
  async function startNightMode(manual = false, takeOver = manual) {
    if (carousel.running) return;
    const blocked = await nightModeBlocked(takeOver);
    if (blocked) {
      console.log("[FanslyAI] \u{1F6A9} \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0437\u0434\u0435\u0441\u044C \u043D\u0435 \u0441\u0442\u0430\u0440\u0442\u0443\u0435\u0442: " + blocked);
      if (!takeOver) refreshPultOff();
      return;
    }
    await claimLeader();
    await new Promise((r) => setTimeout(r, 150 + Math.random() * 250));
    if (await leaderState() === "alive") {
      console.log("[FanslyAI] \u{1F6A9} \u0433\u043E\u043D\u043A\u0443 \u0437\u0430 \u043B\u0438\u0434\u0435\u0440\u0441\u0442\u0432\u043E \u043F\u0440\u043E\u0438\u0433\u0440\u0430\u043B\u0438 \u2014 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0432\u0435\u0434\u0451\u0442 \u0434\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430");
      return;
    }
    if (carousel.running) return;
    carousel.settings = await getSettingsAsync();
    carousel.processed = 0;
    carousel.lastHandledText = {};
    carousel.triedThisRound = /* @__PURE__ */ new Set();
    carousel.rowMirrored = {};
    carousel.rowSnap = {};
    carousel.rowPending = /* @__PURE__ */ new Map();
    carousel.lastRowPreview = {};
    carousel.rowResync = {};
    carousel._rowSeenBadge = {};
    carousel.excludedIds = await loadExcludedIds();
    carousel.pushStreak = {};
    carousel.msgTs = await new Promise((r) => chrome.storage.local.get("fansly_msg_ts", (d) => r(d.fansly_msg_ts || {})));
    if (manual) {
      carousel.mirrorSince = Date.now();
      chrome.storage.local.set({ fansly_mirror_since: carousel.mirrorSince });
    } else {
      const ms = await new Promise((r) => chrome.storage.local.get("fansly_mirror_since", (d) => r(d.fansly_mirror_since)));
      carousel.mirrorSince = ms || Date.now();
      if (!ms) chrome.storage.local.set({ fansly_mirror_since: carousel.mirrorSince });
    }
    carousel._catchupNotified = false;
    carousel.running = true;
    state._pultOpened = false;
    renderPultOff(false);
    pultProtect();
    startLeaderTick();
    ensureRowObserver(true);
    if (PLATFORM !== "onlyfans") await rowLastRestore();
    if (PLATFORM !== "onlyfans") startStaleWatch();
    startNavGuard();
    showNightBar();
    showPultMode();
    const exc = carousel.excludedIds.size ? t("panel.night.excludedSuffix", state.uiLang, { n: carousel.excludedIds.size }) : "";
    setNightStatus(t("panel.night.started", state.uiLang));
    renderExcludedChip();
    console.log("[FanslyAI] \u{1F501} \u0417\u0435\u0440\u043A\u0430\u043B\u043E \u0441\u0442\u0430\u0440\u0442 | \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u043E:", carousel.excludedIds.size);
    sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.carouselStarted", state.uiLang, { exc }) });
    carouselStep();
  }
  function stopNightMode(reasonKey = "") {
    const wasRunning = carousel.running;
    const reason = reasonKey ? t(reasonKey, state.uiLang) : "";
    carousel.running = false;
    releaseLeaderIfOurs();
    clearTimeout(carousel.nextTimer);
    clearInterval(carousel.countdownTimer);
    clearTimeout(state._incomingDebounce);
    stopStaleWatch();
    stopNavGuard();
    pultProtect();
    stopRowObserver();
    setNightStatus(t("panel.night.stopped", state.uiLang, { reasonSuffix: reason ? ": " + reason : "", n: carousel.processed }));
    console.log("[FanslyAI] \u{1F319} \u0421\u0442\u043E\u043F:", reason, "| \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E:", carousel.processed);
    if (wasRunning) sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.carouselStopped", state.uiLang, { reasonSuffix: reason ? " \xB7 " + reason : "", n: carousel.processed }) });
    const btn = document.getElementById("fai-night-btn");
    if (btn) btn.classList.remove("active");
    hidePultMode();
    setTimeout(() => {
      if (!carousel.running) hideNightBar();
    }, 5e3);
  }
  const NAV_STUCK_MS = 3 * 6e4;
  const NAV_TAG_RU = { step: "\u0448\u0430\u0433 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u0438", relay: "\u043E\u0447\u0435\u0440\u0435\u0434\u044C \u043E\u0442\u0432\u0435\u0442\u043E\u0432 \u0438\u0437 \u0422\u0435\u043B\u0435\u0433\u0440\u0430\u043C\u0430", stale: "\u0441\u0432\u0435\u0440\u043A\u0430 \u0441\u043F\u0438\u0441\u043A\u0430" };
  function startNavGuard() {
    if (carousel.navGuardTimer) return;
    carousel.navGuardTimer = setInterval(navGuardCheck, 60 * 1e3);
  }
  function stopNavGuard() {
    clearInterval(carousel.navGuardTimer);
    carousel.navGuardTimer = null;
  }
  function navGuardCheck() {
    if (!carousel.running || !carousel.navBusy) return;
    const idleMs = Date.now() - (carousel._navTouch || carousel._navAt || Date.now());
    if (idleMs < NAV_STUCK_MS) return;
    const tag = carousel._navTag || "?", min = Math.round(idleMs / 6e4);
    carousel._navGen++;
    carousel.navBusy = false;
    carousel._navTag = "";
    console.warn("[FanslyAI] \u{1F513} \u043C\u044C\u044E\u0442\u0435\u043A\u0441 \u043D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u0438 \u043D\u0435 \u043E\u0442\u043F\u0443\u0441\u043A\u0430\u043B\u0438 " + min + " \u043C\u0438\u043D (" + (NAV_TAG_RU[tag] || tag) + ") \u2192 \u0441\u043D\u0438\u043C\u0430\u044E, \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0435\u0442");
    sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.navStuck", state.uiLang, { min }) });
    reportBug("pult_health", { code: "nav_stuck", ageMs: idleMs, name: tag }, "bug");
  }
  const STALE = {
    checkMs: 60 * 1e3,
    // как часто проверяем
    minStaleMs: 4 * 60 * 1e3,
    // держится рассинхрон до reload (не дёргать на лаг доставки)
    baseCooldownMs: 20 * 60 * 1e3,
    // не чаще 1 reload / 20 мин
    maxCooldownMs: 2 * 60 * 60 * 1e3
    // потолок backoff
  };
  function startStaleWatch() {
    if (carousel.staleTimer) return;
    carousel.staleSince = 0;
    carousel.staleTimer = setInterval(staleCheck, STALE.checkMs);
  }
  function stopStaleWatch() {
    clearInterval(carousel.staleTimer);
    carousel.staleTimer = null;
    carousel.staleSince = 0;
  }
  async function staleReconcileFirst() {
    const first = q("contactLink");
    if (!first) return false;
    const tok = navAcquire("stale");
    try {
      PLAT.openRow(first);
      await sleep(2500);
      await scrollContactListTop();
      return readEnvelopeUnread() <= 0 || findUnreadContacts().length > 0;
    } catch (e) {
      return false;
    } finally {
      navRelease(tok);
    }
  }
  async function staleCheck() {
    if (!carousel.running) return;
    const envelope = readEnvelopeUnread();
    if (envelope <= 0) {
      carousel.staleSince = 0;
      try {
        sessionStorage.removeItem("fai_staleCount");
      } catch (e) {
      }
      return;
    }
    await scrollContactListTop();
    if (findUnreadContacts().length > 0) {
      carousel.staleSince = 0;
      try {
        sessionStorage.removeItem("fai_staleCount");
      } catch (e) {
      }
      return;
    }
    const now = Date.now();
    if (!carousel.staleSince) {
      carousel.staleSince = now;
      return;
    }
    if (now - carousel.staleSince < STALE.minStaleMs) return;
    if (carousel.navBusy || carousel.relayQueue.length) return;
    let lastReload = 0, count = 0;
    try {
      lastReload = parseInt(sessionStorage.getItem("fai_lastReload") || "0", 10) || 0;
      count = parseInt(sessionStorage.getItem("fai_staleCount") || "0", 10) || 0;
    } catch (e) {
    }
    const cooldown = Math.min(STALE.baseCooldownMs * Math.pow(2, count), STALE.maxCooldownMs);
    if (now - lastReload < cooldown) return;
    if (await staleReconcileFirst()) {
      carousel.staleSince = 0;
      try {
        sessionStorage.removeItem("fai_staleCount");
      } catch (e) {
      }
      console.log("[FanslyAI] \u2705 \u0440\u0430\u0441\u0441\u0438\u043D\u0445\u0440\u043E\u043D \u0441\u043D\u044F\u0442 \u0437\u0430\u0445\u043E\u0434\u043E\u043C \u043D\u0430 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0444\u0430\u043D\u0430 \u2014 reload \u043E\u0442\u043C\u0435\u043D\u0451\u043D");
      return;
    }
    const mins = Math.round((now - carousel.staleSince) / 6e4);
    console.warn(`[FanslyAI] \u{1F504} \u0441\u043F\u0438\u0441\u043E\u043A \u0437\u0430\u0432\u0438\u0441 ${mins} \u043C\u0438\u043D, \u043A\u043E\u043D\u0432\u0435\u0440\u0442=${envelope}, \u043D\u0435\u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u043F\u0438\u0441\u043A\u0435 0 \u2192 \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0436\u0430\u044E (\u043F\u043E\u043F\u044B\u0442\u043A\u0430 ${count + 1})`);
    sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.staleReload", state.uiLang, { envelope }) });
    try {
      sessionStorage.setItem("fai_lastReload", String(now));
      sessionStorage.setItem("fai_staleCount", String(count + 1));
    } catch (e) {
    }
    setTimeout(() => location.reload(), 800);
  }
  let _keepAliveCtx = null;
  let _keepAliveGainTimer = null;
  function startKeepAlive() {
    try {
      if (_keepAliveCtx) return;
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      _keepAliveCtx = new Ctx();
      const osc = _keepAliveCtx.createOscillator();
      const gain = _keepAliveCtx.createGain();
      const kaFreq = Math.round(Math.min(2e4, _keepAliveCtx.sampleRate / 2 * 0.9));
      osc.frequency.value = kaFreq;
      gain.gain.value = document.hidden ? 0.05 : 0;
      osc.connect(gain);
      gain.connect(_keepAliveCtx.destination);
      osc.start();
      _keepAliveCtx._osc = osc;
      _keepAliveCtx._gain = gain;
      clearInterval(_keepAliveGainTimer);
      _keepAliveGainTimer = setInterval(() => {
        if (_keepAliveCtx?._gain) _keepAliveCtx._gain.gain.value = document.hidden ? 0.05 : 0;
      }, 2e3);
      console.log("[FanslyAI] \u{1F50A} keep-alive \u0432\u043A\u043B (" + (kaFreq / 1e3).toFixed(1) + "\u043A\u0413\u0446 \u043F\u0440\u0438 " + (_keepAliveCtx.sampleRate / 1e3).toFixed(1) + "\u043A\u0413\u0446 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430, \u0437\u0432\u0443\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u0444\u043E\u043D\u0435), state=", _keepAliveCtx.state);
      _keepAliveCtx.resume?.().then(() => console.log("[FanslyAI] \u{1F50A} keep-alive resume \u2192 state=", _keepAliveCtx?.state)).catch((e) => console.warn("[FanslyAI] keep-alive resume fail:", e.message));
      if (_keepAliveCtx.state !== "running") keepAliveOnGesture();
    } catch (e) {
      console.warn("[FanslyAI] keep-alive failed:", e.message);
    }
  }
  let _kaGestureOn = false;
  function keepAliveOnGesture() {
    if (_kaGestureOn) return;
    _kaGestureOn = true;
    function off() {
      window.removeEventListener("pointerdown", wake, true);
      window.removeEventListener("keydown", wake, true);
      _kaGestureOn = false;
    }
    function wake() {
      if (!_keepAliveCtx || _keepAliveCtx.state === "running") return off();
      _keepAliveCtx.resume().then(() => {
        if (_keepAliveCtx?.state === "running") {
          console.log("[FanslyAI] \u{1F50A} keep-alive \u043E\u0436\u0438\u043B \u043E\u0442 \u043A\u043B\u0438\u043A\u0430/\u043A\u043B\u0430\u0432\u0438\u0448\u0438");
          off();
        }
      }).catch(() => {
      });
    }
    window.addEventListener("pointerdown", wake, true);
    window.addEventListener("keydown", wake, true);
  }
  function pultProtect() {
    const need = !!(carousel.running || state._tgPollLead);
    if (need !== !!state._protectOn) {
      state._protectOn = need;
      sendSafe({ type: "PULT_DISCARDABLE", on: !need, page: _tabId() });
    }
    const sound = need && state._bgWorkEnabled && state._bgWorkAck;
    if (sound) startKeepAlive();
    else if (state._protectSound && !document.getElementById("fai-scan-veil")) stopKeepAlive();
    state._protectSound = sound;
  }
  function stopKeepAlive() {
    try {
      clearInterval(_keepAliveGainTimer);
      _keepAliveGainTimer = null;
      if (!_keepAliveCtx) return;
      _keepAliveCtx._osc?.stop();
      _keepAliveCtx.close();
      _keepAliveCtx = null;
      console.log("[FanslyAI] \u{1F50A} keep-alive \u0432\u044B\u043A\u043B");
    } catch (e) {
    }
  }
  function escapeHtmlC(s) {
    return String(s || "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
  }
  async function carouselStep() {
    if (!carousel.running) return;
    if (!isExtensionAlive()) {
      notifyContextDead();
      carousel.running = false;
      clearTimeout(carousel.nextTimer);
      clearInterval(carousel.countdownTimer);
      stopRowObserver();
      return;
    }
    const s = carousel.settings;
    if (carousel.navBusy) {
      scheduleNext(3);
      return;
    }
    carousel._lastStepAt = Date.now();
    const _si = q("search");
    if (_si && _si.value) {
      _si.value = "";
      _si.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(400);
    }
    await scrollContactListTop();
    ensureRowObserver();
    const unread = findUnreadContacts(true);
    const activity = scanRecentActivity();
    const freshAct = activity.filter((a) => !carousel.triedThisRound.has(a.id));
    if (freshAct.length >= 5 && !carousel._catchupNotified) {
      carousel._catchupNotified = true;
      const agoM = (ts) => Math.max(1, Math.round((Date.now() - ts) / 6e4));
      const list = freshAct.slice(0, 8).map((a) => `${a.name} (${agoM(a.ts)}m)`).join(", ") + (freshAct.length > 8 ? " +" + (freshAct.length - 8) : "");
      console.log("[FanslyAI] \u23F3 \u0434\u043E\u0433\u043E\u043D \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0441\u0442\u043E\u044F:", freshAct.map((a) => ({ id: a.id, name: a.name, "\u0430\u043A\u0442_\u043C\u0438\u043D": agoM(a.ts), "\u0437\u043D\u0430\u043A_\u043C\u0438\u043D": carousel.msgTs[a.id] ? agoM(carousel.msgTs[a.id]) : "\u2014" })));
      sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.catchup", state.uiLang, { n: freshAct.length, list }) });
    } else if (!freshAct.length) carousel._catchupNotified = false;
    const seenId = new Set(unread.map((u) => u.id));
    const queue = unread.concat(activity.filter((a) => !seenId.has(a.id)));
    const item = queue.find((u) => u.id && u.id !== state.currentContactId && !carousel.triedThisRound.has(u.id) && !(carousel.excludedIds.has(u.id) && state.tgMuteExcluded));
    if (!item) {
      carousel.triedThisRound.clear();
      setNightStatus(t("panel.night.idle", state.uiLang, { n: carousel.processed }));
      if (carousel.running) scheduleNext(carousel.idleSec, true);
      return;
    }
    carousel.triedThisRound.add(item.id);
    console.log("[FanslyAI] \u{1F319} \u0428\u0430\u0433:", item.name, item.id, item.fromActivity ? "(\u043F\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438: ts=" + new Date(item.ts).toLocaleTimeString() + ", \u0437\u043D\u0430\u043A=" + (carousel.msgTs[item.id] ? new Date(carousel.msgTs[item.id]).toLocaleTimeString() : "-") + ")" : "(\u043F\u043E \u0431\u0435\u0439\u0434\u0436\u0443 " + item.count + ")");
    setNightStatus(t("panel.night.opening", state.uiLang, { name: item.name }));
    const navTok = navAcquire("step");
    try {
      carousel._visitId = item.id;
      carousel._visitAt = Date.now();
      PLAT.openRow(item.el);
      await sleep(CONFIG.CONTACT_DELAY + 400);
      activateForContact(item.name, item.id);
      await sleep(3800);
      navTouch();
      if (!carousel.running) return;
      detectContact();
      if (state.currentContact) item.name = state.currentContact;
      if (state.currentContactId && item.id && state.currentContactId !== item.id) {
        console.log("[FanslyAI] \u{1F319} \u041D\u0435 \u043E\u0442\u043A\u0440\u044B\u043B\u0441\u044F (\u043E\u0436\u0438\u0434\u0430\u043B\u0438", item.id, "\u043F\u043E\u043B\u0443\u0447\u0438\u043B\u0438", state.currentContactId, ")");
        setNightStatus(t("panel.night.notOpened", state.uiLang, { name: item.name }));
      } else {
        markActivityHandled(item.id, item.ts);
        try {
          const rowEl = item.el && item.el.isConnected ? item.el : rowElFor(item.id);
          if (rowEl) {
            carousel.lastRowPreview[item.id] = collapseKey(q("rowPreview", rowEl)?.innerText || "");
            rowLastSave(item.id);
          }
        } catch (e) {
        }
        const lm = latestFanMsg();
        const text = lm && !lm.isMedia ? lm.text : null;
        if (latestFanMsg()?.isMedia) {
          const lm2 = latestFanMsg();
          scheduleMirrorScan(true);
          setNightStatus(t("panel.night.skipMedia", state.uiLang, { name: item.name, type: lm2.mediaType || "?" }));
        } else if (text && text === carousel.lastHandledText[item.id]) {
          setNightStatus(t("panel.night.alreadyAnswered", state.uiLang, { name: item.name }));
        } else if (text) {
          carousel.lastHandledText[item.id] = text;
          scheduleMirrorScan(true);
        } else {
          setNightStatus(t("panel.night.noIncoming", state.uiLang, { name: item.name }));
        }
      }
    } catch (e) {
      console.error("[FanslyAI] \u{1F319} \u041E\u0448\u0438\u0431\u043A\u0430 \u0448\u0430\u0433\u0430:", e.message);
    } finally {
      navRelease(navTok);
      drainRelays();
      if (carousel.running) {
        const pauseSec = randInt(s.nightPauseMin || 40, s.nightPauseMax || 180);
        scheduleNext(pauseSec);
      }
    }
  }
  function scheduleNext(pauseSec, idle = false) {
    let left = pauseSec;
    clearTimeout(carousel.nextTimer);
    clearInterval(carousel.countdownTimer);
    carousel.countdownTimer = setInterval(() => {
      left--;
      if (idle) setNightStatus(t("panel.night.idleCountdown", state.uiLang, { left, n: carousel.processed }));
      else setNightStatus(t("panel.night.nextCountdown", state.uiLang, { left, n: carousel.processed }));
      if (left <= 0) clearInterval(carousel.countdownTimer);
    }, 1e3);
    carousel.nextTimer = setTimeout(() => {
      clearInterval(carousel.countdownTimer);
      carouselStep();
    }, pauseSec * 1e3);
  }
  function showNightBar() {
    const bar = document.getElementById("fai-night-bar");
    if (bar) bar.style.display = "flex";
    const btn = document.getElementById("fai-night-btn");
    if (btn) btn.classList.add("active");
  }
  function hideNightBar() {
    const bar = document.getElementById("fai-night-bar");
    if (bar) bar.style.display = "none";
    const list = document.getElementById("fai-night-excl-list");
    if (list) list.style.display = "none";
  }
  function pultVeilAlpha() {
    const v = typeof state._pultVeilOpacity === "number" ? state._pultVeilOpacity : 0.74;
    return Math.max(0.15, Math.min(0.95, v));
  }
  function applyPultVeil() {
    const dim = document.getElementById("fai-pult-dim");
    if (!dim) return;
    if (state._pultLocked) dim.style.cssText = "position:fixed;inset:0;background:rgba(6,6,12,.985);backdrop-filter:blur(9px);z-index:2147482000";
    else {
      const a = pultVeilAlpha();
      dim.style.cssText = `position:fixed;inset:0;background:rgba(8,8,16,${a});backdrop-filter:blur(2px);z-index:2147482000`;
    }
  }
  const _pmk = (tag, css, txt) => {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (txt != null) e.textContent = txt;
    return e;
  };
  const PULT_ZOOM = 0.25;
  const PULT_BOX_SCALE = 2.6;
  const pultZoom = (f) => {
    if (typeof FaiLock !== "undefined") FaiLock.setScale(f > 0 && f < 1 ? 1 / f : 1);
    if (typeof FaiConsent !== "undefined" && FaiConsent.setScale) FaiConsent.setScale(f > 0 && f < 1 ? 1 / f : 1);
    return sendSafe({ type: "VAULT_ZOOM", factor: f }).catch(() => {
    });
  };
  function applyPultScale(box) {
    if (!box || !(PULT_ZOOM > 0) || PULT_ZOOM >= 1) return;
    const k = PULT_BOX_SCALE;
    const dragged = box.style.transform === "none" || /scale\(/.test(box.style.transform) && box.style.transform.indexOf("translate") < 0;
    box.style.transformOrigin = dragged ? "top left" : "center";
    box.style.transform = dragged ? `scale(${k})` : `translate(-50%,-50%) scale(${k})`;
  }
  function showPultMode() {
    state._pultActive = true;
    const pnl = document.getElementById("fansly-ai-panel");
    if (pnl) pnl.style.display = "none";
    pultZoom(PULT_ZOOM);
    const existing = document.getElementById("fai-pult");
    if (existing) {
      renderPultBox(existing);
      applyPultScale(existing);
      applyPultVeil();
      return;
    }
    const dim = _pmk("div", "", null);
    dim.id = "fai-pult-dim";
    const box = _pmk("div", 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:2147483600;width:min(440px,92vw);background:#12121f;border:2px solid #e91e8c;border-radius:16px;padding:20px 22px;box-shadow:0 12px 48px rgba(0,0,0,.6);text-align:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#f0f0f0', null);
    box.id = "fai-pult";
    document.body.append(dim, box);
    chrome.storage.local.get("fai_pult_pos", (d) => {
      const p = d.fai_pult_pos;
      if (p && p.left) {
        box.style.left = p.left;
        box.style.top = p.top;
        box.style.transform = "none";
        applyPultScale(box);
      }
    });
    renderPultBox(box);
    applyPultScale(box);
    applyPultVeil();
  }
  function paintPultMoney() {
    const el = document.getElementById("fai-pult-money");
    if (!el) return;
    el.innerHTML = "";
    if (!_money) {
      el.style.display = "none";
      return;
    }
    el.style.cssText = "display:flex;align-items:center;gap:8px;text-align:left;background:linear-gradient(90deg,#4a3410,#5a3f14);border:1px solid #7a5a20;border-radius:10px;padding:8px 11px;margin-bottom:12px";
    const b = _pmk("button", "flex-shrink:0;background:#e91e8c;color:#fff;border:none;border-radius:7px;padding:5px 12px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit", _money.btn);
    b.type = "button";
    b.dataset.faiAction = _money.action;
    wireHintBtn(b);
    el.append(_pmk("span", "flex:1;font-size:12px;line-height:1.4;color:#ffd9a0", _money.text), b);
  }
  function renderPultBox(box) {
    box.innerHTML = "";
    const title = _pmk("div", "font-size:18px;font-weight:800;color:#f3a3cf;margin-bottom:8px;cursor:move;user-select:none", null);
    title.append(_pmk("span", "font-size:26px;display:block;margin-bottom:2px", "\u{1F4E1}"), _pmk("span", "", t("panel.pult.title", state.uiLang)));
    title.title = t("panel.pult.recenter", state.uiLang);
    wirePultDrag(box, title);
    box.append(title);
    if (state._pultLocked) {
      box.append(
        _pmk("div", "font-size:40px;margin:10px 0 6px", "\u{1F512}"),
        _pmk("div", "font-size:15px;font-weight:700;color:#f3a3cf;margin-bottom:6px", t("panel.pult.locked.title", state.uiLang)),
        _pmk("div", "font-size:12px;color:#8a8aa5;line-height:1.5;margin-bottom:14px", t("panel.pult.locked.hint", state.uiLang))
      );
      const btnUnlock = _pmk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer", t("panel.pult.unlock", state.uiLang));
      btnUnlock.addEventListener("click", () => promptUnlock(box));
      const status2 = _pmk("div", "font-size:12px;color:#8a8aa5;min-height:16px;margin-top:12px");
      status2.id = "fai-pult-status";
      box.append(btnUnlock, status2);
      return;
    }
    box.append(_pmk("div", "font-size:13px;line-height:1.5;color:#e6e6f0;margin-bottom:12px", t("panel.pult.warn", state.uiLang)));
    const money = _pmk("div", "display:none", null);
    money.id = "fai-pult-money";
    box.append(money);
    paintPultMoney();
    const bgRow = _pmk("label", "display:flex;align-items:flex-start;gap:8px;text-align:left;background:#1a1a2e;border:1px solid #2e2e50;border-radius:10px;padding:9px 11px;margin-bottom:10px;cursor:pointer", null);
    const bgChk = document.createElement("input");
    bgChk.type = "checkbox";
    bgChk.style.cssText = "margin-top:2px;flex-shrink:0";
    bgChk.checked = !!(state._bgWorkEnabled && state._bgWorkAck);
    const bgTxt = _pmk("span", "", null);
    bgTxt.append(_pmk("div", "font-size:13px;color:#ececf5;font-weight:600", t("panel.pult.bgwork", state.uiLang)), _pmk("div", "font-size:11px;color:#8a8aa5;margin-top:2px", t("panel.pult.bgwork.sub", state.uiLang)));
    bgRow.append(bgChk, bgTxt);
    bgChk.addEventListener("change", () => {
      if (bgChk.checked) {
        if (state._bgWorkAck) persistSetting("bgWorkEnabled", true);
        else {
          bgChk.checked = false;
          showBgWarn(box);
        }
      } else persistSetting("bgWorkEnabled", false);
    });
    box.append(bgRow);
    const vRow = _pmk("div", "text-align:left;margin-bottom:12px", null);
    vRow.append(_pmk("div", "font-size:11px;color:#8a8aa5;margin-bottom:4px", t("panel.pult.veil", state.uiLang)));
    const slider = document.createElement("input");
    slider.type = "range";
    slider.min = "15";
    slider.max = "95";
    slider.value = String(Math.round(pultVeilAlpha() * 100));
    slider.style.cssText = "width:100%;accent-color:#e91e8c;cursor:pointer";
    slider.addEventListener("input", () => {
      state._pultVeilOpacity = +slider.value / 100;
      applyPultVeil();
    });
    slider.addEventListener("change", () => persistSetting("pultVeilOpacity", +slider.value / 100));
    vRow.append(slider);
    box.append(vRow);
    const status = _pmk("div", "font-size:12px;color:#8a8aa5;min-height:16px;margin-bottom:14px");
    status.id = "fai-pult-status";
    box.append(status);
    const btnOpen = _pmk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;margin-bottom:8px", t("panel.pult.openChat", state.uiLang));
    btnOpen.addEventListener("click", () => sendSafe({ type: "OPEN_WORK_TAB" }));
    const btnLock = _pmk("button", "width:100%;background:#241a34;color:#e6c8ff;border:1px solid #5a3a7a;border-radius:10px;padding:10px;font-size:13px;cursor:pointer;margin-bottom:8px", t("panel.pult.lock", state.uiLang));
    btnLock.addEventListener("click", () => lockPult(box));
    const btnStop = _pmk("button", "width:100%;background:#1a1a2e;color:#cfcfe0;border:1px solid #3a3a5c;border-radius:10px;padding:10px;font-size:13px;cursor:pointer", t("panel.pult.stop", state.uiLang));
    btnStop.addEventListener("click", () => {
      stopNightMode("common.reason.manual");
      persistSetting("carouselEnabled", false);
    });
    box.append(btnOpen, btnLock, btnStop);
  }
  function showBgWarn(box) {
    box.innerHTML = "";
    box.append(
      _pmk("div", "font-size:30px;margin-bottom:6px", "\u26A0\uFE0F"),
      _pmk("div", "font-size:16px;font-weight:800;color:#f3a3cf;margin-bottom:10px", t("panel.pult.warn.bg.title", state.uiLang)),
      _pmk("div", "font-size:13px;line-height:1.55;color:#e6e6f0;margin-bottom:14px;text-align:left", t("panel.pult.warn.bg.body", state.uiLang))
    );
    const ackRow = _pmk("label", "display:flex;align-items:flex-start;gap:8px;text-align:left;margin-bottom:14px;cursor:pointer", null);
    const ackChk = document.createElement("input");
    ackChk.type = "checkbox";
    ackChk.style.cssText = "margin-top:2px;flex-shrink:0";
    ackRow.append(ackChk, _pmk("span", "font-size:13px;color:#ececf5", t("panel.pult.warn.bg.ack", state.uiLang)));
    const go = _pmk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;margin-bottom:8px;opacity:.5", t("panel.pult.warn.bg.continue", state.uiLang));
    go.disabled = true;
    ackChk.addEventListener("change", () => {
      go.disabled = !ackChk.checked;
      go.style.opacity = ackChk.checked ? "1" : ".5";
    });
    go.addEventListener("click", () => {
      if (!ackChk.checked) return;
      persistSettings({ bgWorkAck: true, bgWorkEnabled: true });
      state._bgWorkAck = true;
      state._bgWorkEnabled = true;
      renderPultBox(box);
    });
    const cancel = _pmk("button", "width:100%;background:#1a1a2e;color:#cfcfe0;border:1px solid #3a3a5c;border-radius:10px;padding:10px;font-size:13px;cursor:pointer", t("panel.pult.warn.bg.cancel", state.uiLang));
    cancel.addEventListener("click", () => renderPultBox(box));
    box.append(ackRow, go, cancel);
  }
  function _pinInput() {
    const inp = document.createElement("input");
    inp.type = "text";
    inp.inputMode = "numeric";
    inp.autocomplete = "off";
    inp.name = "fai-pult-pin";
    inp.setAttribute("autocorrect", "off");
    inp.setAttribute("autocapitalize", "off");
    inp.spellcheck = false;
    inp.style.cssText = "width:100%;background:#0e0e18;border:1px solid #3a3a5c;border-radius:10px;padding:11px;font-size:20px;text-align:center;letter-spacing:6px;color:#fff;margin-bottom:8px;-webkit-text-security:disc";
    return inp;
  }
  function lockPult(box) {
    if (state._pultLockPin) {
      state._pultLocked = true;
      applyPultVeil();
      renderPultBox(box);
    } else showSetPin(box);
  }
  function showSetPin(box) {
    box.innerHTML = "";
    box.append(
      _pmk("div", "font-size:34px;margin-bottom:8px", "\u{1F512}"),
      _pmk("div", "font-size:14px;color:#e6e6f0;margin-bottom:6px", t("panel.pult.setpin.prompt", state.uiLang)),
      _pmk("div", "font-size:11px;color:#8a8aa5;line-height:1.5;margin-bottom:10px", t("panel.pult.setpin.hint", state.uiLang))
    );
    const inp = _pinInput();
    const doLock = () => {
      state._pultLocked = true;
      applyPultVeil();
      renderPultBox(box);
    };
    const withPin = _pmk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;margin-bottom:8px;opacity:.5", t("panel.pult.setpin.withPin", state.uiLang));
    withPin.disabled = true;
    const setAndLock = () => {
      const pin = inp.value.replace(/\D/g, "").slice(0, 12);
      if (pin.length < 4) return;
      state._pultLockPin = pin;
      persistSetting("pultLockPin", pin);
      doLock();
    };
    inp.addEventListener("input", () => {
      inp.value = inp.value.replace(/\D/g, "").slice(0, 12);
      const ok = inp.value.length >= 4;
      withPin.disabled = !ok;
      withPin.style.opacity = ok ? "1" : ".5";
    });
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") setAndLock();
    });
    withPin.addEventListener("click", setAndLock);
    const noPin = _pmk("button", "width:100%;background:#241a34;color:#e6c8ff;border:1px solid #5a3a7a;border-radius:10px;padding:10px;font-size:13px;cursor:pointer;margin-bottom:8px", t("panel.pult.setpin.noPin", state.uiLang));
    noPin.addEventListener("click", doLock);
    const cancel = _pmk("button", "width:100%;background:#1a1a2e;color:#cfcfe0;border:1px solid #3a3a5c;border-radius:10px;padding:10px;font-size:13px;cursor:pointer", t("panel.pult.warn.bg.cancel", state.uiLang));
    cancel.addEventListener("click", () => renderPultBox(box));
    box.append(inp, withPin, noPin, cancel);
    inp.focus();
  }
  function promptUnlock(box) {
    const pin = state._pultLockPin || "";
    if (!pin) {
      state._pultLocked = false;
      applyPultVeil();
      renderPultBox(box);
      return;
    }
    box.innerHTML = "";
    box.append(_pmk("div", "font-size:34px;margin-bottom:8px", "\u{1F512}"), _pmk("div", "font-size:14px;color:#e6e6f0;margin-bottom:12px", t("panel.pult.pin.prompt", state.uiLang)));
    const inp = _pinInput();
    const err = _pmk("div", "font-size:12px;color:#ef9a9a;min-height:16px;margin-bottom:8px", "");
    const submit = () => {
      if (inp.value === pin) {
        state._pultLocked = false;
        applyPultVeil();
        renderPultBox(box);
      } else {
        err.textContent = t("panel.pult.pin.wrong", state.uiLang);
        inp.value = "";
        inp.focus();
      }
    };
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submit();
    });
    const ok = _pmk("button", "width:100%;background:#e91e8c;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;margin-bottom:8px", t("panel.pult.unlock", state.uiLang));
    ok.addEventListener("click", submit);
    const back = _pmk("button", "width:100%;background:#1a1a2e;color:#cfcfe0;border:1px solid #3a3a5c;border-radius:10px;padding:10px;font-size:13px;cursor:pointer", t("panel.pult.warn.bg.cancel", state.uiLang));
    back.addEventListener("click", () => renderPultBox(box));
    box.append(inp, err, ok, back);
    inp.focus();
  }
  function wirePultDrag(box, handle) {
    handle.addEventListener("dblclick", () => {
      box.style.left = "50%";
      box.style.top = "50%";
      box.style.transform = "translate(-50%,-50%)";
      applyPultScale(box);
      chrome.storage.local.remove("fai_pult_pos");
    });
    handle.addEventListener("mousedown", (e) => {
      const r = box.getBoundingClientRect();
      box.style.left = r.left + "px";
      box.style.top = r.top + "px";
      box.style.transform = "none";
      applyPultScale(box);
      const offX = e.clientX - r.left, offY = e.clientY - r.top;
      const onMove = (ev) => {
        const x = Math.max(0, Math.min(ev.clientX - offX, window.innerWidth - box.offsetWidth));
        const y = Math.max(0, Math.min(ev.clientY - offY, window.innerHeight - box.offsetHeight));
        box.style.left = x + "px";
        box.style.top = y + "px";
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
        chrome.storage.local.set({ fai_pult_pos: { left: box.style.left, top: box.style.top } });
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
      e.preventDefault();
    });
  }
  function hidePultMode() {
    state._pultActive = false;
    state._pultLocked = false;
    pultZoom(1);
    if (typeof FaiLock !== "undefined") FaiLock.refresh();
    document.getElementById("fai-pult")?.remove();
    document.getElementById("fai-pult-dim")?.remove();
    const pnl = document.getElementById("fansly-ai-panel");
    if (pnl) pnl.style.display = state._panelShown ? "" : "none";
  }
  function setNightStatus(msg) {
    const el = document.getElementById("fai-night-status");
    if (el) el.textContent = msg;
    const pel = document.getElementById("fai-pult-status");
    if (pel) pel.textContent = msg;
  }
  async function reincludeContact(id, name) {
    await setContactExcludedById(id, false);
    carousel.excludedIds.delete(id);
    if (state.currentContactId === id && state.contactData) {
      state.contactData.excludeFromAuto = false;
      updateExcludeBtn();
    }
    renderExcludedChip();
  }
  async function renderExcludedChip() {
    const chip = document.getElementById("fai-night-excluded");
    const list = document.getElementById("fai-night-excl-list");
    if (!chip || !list) return;
    const excl = await loadExcludedContacts();
    if (!excl.length) {
      chip.style.display = "none";
      list.style.display = "none";
      list.innerHTML = "";
      return;
    }
    chip.style.display = "";
    chip.textContent = t("panel.excluded.chip", state.uiLang, { n: excl.length });
    list.innerHTML = "";
    excl.forEach((c) => {
      const row = document.createElement("div");
      row.className = "fai-excl-row";
      const nm = document.createElement("span");
      nm.className = "fai-excl-name";
      nm.textContent = c.name || t("panel.excluded.noName", state.uiLang);
      const btn = document.createElement("button");
      btn.className = "fai-excl-return";
      btn.textContent = t("panel.excluded.return", state.uiLang);
      btn.addEventListener("click", () => reincludeContact(c.id, c.name));
      row.appendChild(nm);
      row.appendChild(btn);
      list.appendChild(row);
    });
  }
  function isExtensionAlive() {
    try {
      return !!chrome.runtime?.id;
    } catch (e) {
      return false;
    }
  }
  let _ctxDeadShown = false;
  function notifyContextDead() {
    if (_ctxDeadShown) return;
    _ctxDeadShown = true;
    try {
      const inPult = !!document.getElementById("fai-pult-dim");
      const k = inPult && typeof PULT_BOX_SCALE !== "undefined" ? PULT_BOX_SCALE : 1;
      const px = (n) => Math.round(n * k) + "px";
      const b = document.createElement("div");
      b.id = "fai-ctx-dead";
      b.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#e91e8c;color:#fff;font-weight:700;font-size:" + px(16) + ";line-height:1.35;font-family:-apple-system,system-ui,sans-serif;padding:" + px(14) + " " + px(18) + ";text-align:center;cursor:pointer;box-shadow:0 4px 18px rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;gap:" + px(14) + ";flex-wrap:wrap";
      const txt = document.createElement("span");
      txt.textContent = t("panel.ctxDead.banner", state.uiLang);
      const btn = document.createElement("span");
      btn.textContent = t("panel.ctxDead.btn", state.uiLang);
      btn.style.cssText = "background:#fff;color:#c2185b;border-radius:" + px(9) + ";padding:" + px(7) + " " + px(16) + ";font-weight:800;white-space:nowrap";
      b.append(txt, btn);
      b.addEventListener("click", () => location.reload());
      document.body.appendChild(b);
    } catch (e) {
    }
  }
  window.addEventListener("error", (e) => {
    if (/context invalidated/i.test(e?.message || "")) notifyContextDead();
  });
  async function processDialogue({ text, hint = "", trigger = "manual", mediaType = null, mediaLocked = false, regenerate = false, proactive = false, forceOR = false, single = false, turns = null, again = false }) {
    if (!isExtensionAlive()) return { success: false, error: "extension dead" };
    if (!text && !mediaType && !proactive) return { success: false, error: "no text" };
    const target = { name: state.currentContact, id: state.currentContactId, data: contactDataIsCurrent() ? state.contactData : null };
    let wide = null;
    if (single) {
      const [crm, tiers] = await Promise.all([
        crmSummaryFresh(target.data),
        new Promise((r2) => chrome.storage.local.get("fansly_tiers", (d) => r2(d && d.fansly_tiers && d.fansly_tiers.list || null)))
      ]);
      if (state.currentContactId !== target.id) return { success: false, error: "contact changed" };
      wide = { crm, tiers };
    }
    const intent = detectIntent(text);
    console.log(`[FanslyAI] Intent: ${intent.type} (${intent.label}) | trigger: ${trigger} | "${text.slice(0, 40)}"`);
    let briefStaleByTopic = false;
    const brief = state.contactData?.brief;
    if (brief && brief.collectedAtMsg != null) {
      const msgsSince = (state.contactData?.totalMsgs || 0) - brief.collectedAtMsg;
      if (msgsSince > 10) briefStaleByTopic = true;
    }
    const mwEl = document.getElementById("fai-maxwords-input");
    const maxWords = mwEl ? parseInt(mwEl.value) || 0 : state.maxWords || 0;
    ensureHistoryForCurrent();
    const ctx = {
      history: state.chatHistory.slice(single ? -12 : -10),
      fanName: state.currentContact || "",
      fanGender: state.fanGender,
      totalMsgs: state.contactData?.totalMsgs || 0,
      hint,
      isSubscribed: state.contactData?.isSubscribed ?? false,
      tierName: state.contactData?.tierName || null,
      hasCard: state.contactData?.hasCard || false,
      fanLang: state.contactData?.lang || "en",
      maxWords,
      dossier: state.contactData?.dossier || null,
      brief,
      recentOwnReplies: getRecentOwnReplies(),
      gapSinceLast: computeGap(state.contactData?.dossier?.lastMessageAt),
      trigger,
      proactive,
      forceOR,
      forceProvider: state._proxyOn ? "auto" : state.forceProvider || "auto",
      // ручной override провайдера (direct-режим, минуя каскад); при прокси селект скрыт — старое значение не должно молча рулить
      briefStaleByTopic,
      replyTo: state.lastIncomingReply || null,
      // #2: цитата
      pushStreak: carousel.pushStreak?.[state.currentContactId] || 0,
      // Блок 9: лестница увода/затухания
      allowExplicitContact: state.contactData?.allowExplicit ?? null,
      // пер-контакт оверрайд (приоритет над общей настройкой)
      mediaIncoming: mediaType ? { type: mediaType, locked: !!mediaLocked } : null,
      // реакция на присланное медиа
      // Один черновик: режим, память ветки и поля совета (те же имена и смысл, что в buildCoachCtx). crm — тот же плоский
      // объект, что у панели (crmSummary), но посчитанный заново: кеш панели на вкладке пульта может быть пуст.
      ...single ? {
        single: true,
        turns: turns || [],
        again: !!again,
        crm: wide.crm,
        tiers: wide.tiers,
        note: (state.contactData?.note || "").trim().slice(0, 300),
        isCreator: state.contactData?.isCreator === true,
        topics: (state.contactData?.dossier?.topics || []).slice(0, 10),
        lastInGapMs: (() => {
          const li = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
          return li && li.timestamp ? Date.now() - li.timestamp : null;
        })()
      } : {}
    };
    let r;
    try {
      r = await sendSafe({ type: "GENERATE_SUGGESTIONS", text, intent, context: ctx });
    } catch (e) {
      console.error("[FanslyAI] processDialogue error:", e.message);
      return { success: false, error: e.message, intent };
    }
    if (!r?.success) {
      return {
        success: false,
        error: r?.error || "no result",
        noOpenRouter: r?.noOpenRouter === true,
        quotaExhausted: r?.quotaExhausted === true,
        subscriptionExpired: r?.subscriptionExpired === true,
        intent
      };
    }
    if (!regenerate) {
      if (state.collectDossier !== false) {
        try {
          if (r.dossier_update) applyDossierUpdate(r.dossier_update, false, target);
        } catch (e) {
          console.warn("[FanslyAI] applyDossierUpdate \u0441\u0431\u043E\u0439:", e.message);
        }
        try {
          if (r.brief) applyBrief(r.brief, target);
        } catch (e) {
          console.warn("[FanslyAI] applyBrief \u0441\u0431\u043E\u0439:", e.message);
        }
      }
      if (target.data) {
        if (!target.data.dossier) {
          target.data.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
        }
        target.data.dossier.lastMessageAt = Date.now();
        savePatchTo(target, target.name, { dossier: target.data.dossier });
      }
      const pid = target.id;
      if (pid) {
        if (/coy/.test(r.provider || "")) carousel.pushStreak[pid] = (carousel.pushStreak[pid] || 0) + 1;
        else carousel.pushStreak[pid] = 0;
      }
    }
    return {
      success: true,
      suggestions: r.result,
      dossier_update: r.dossier_update || null,
      brief: r.brief || null,
      // Блок 4 — пока может быть null
      media_hint: r.media_hint || null,
      // Блок 6 — пока может быть null
      provider: r.provider || "?",
      intent
    };
  }
  function syncFanLang(cid, nv) {
    if (!nv || typeof nv.lang !== "string" || !nv.lang) return false;
    if (!cid || state.currentContactId !== cid || !contactDataIsCurrent()) return false;
    if (state.contactData.lang === nv.lang) return false;
    state.contactData.lang = nv.lang;
    const btn = document.getElementById("fai-fan-lang");
    if (btn) btn.textContent = nv.lang.toUpperCase();
    return true;
  }
  function detectIntent(text) {
    const t2 = text.toLowerCase();
    for (const ci of state.customIntents || []) {
      const kws = (ci.keywords || "").split(",").map((k) => k.trim().toLowerCase()).filter(Boolean);
      if (kws.length && kws.some((k) => t2.includes(k))) {
        return {
          type: "custom_" + (ci.label || "intent"),
          label: `${ci.emoji || "\u{1F3AF}"} ${ci.label || "\u0418\u043D\u0442\u0435\u043D\u0442"}`,
          priority: "high",
          instruction: ci.instruction || ""
        };
      }
    }
    if (/\bcustom\b|\bvideo\b.*\bmake\b|\bfilm\b.*\bme\b|make.*video|record.*for me/.test(t2) || /кастом|индивидуальн|снимешь|сними\b|запиши|сделай.*виде|персональн.*виде|видео.*для меня/.test(t2))
      return { type: "custom_video", key: "common.intent.customVideo", label: "\u{1F3AC} \u041A\u0430\u0441\u0442\u043E\u043C\u043D\u043E\u0435 \u0432\u0438\u0434\u0435\u043E", priority: "high" };
    if (/scam|rip ?off|ignor(e|ing) me|disappoint|you never|waste of/.test(t2) || /развод|обман|игнор|кидал|обиде|разочарова|зря потратил|непорядочн/.test(t2))
      return { type: "complaint", key: "common.intent.complaint", label: "\u26A0\uFE0F \u041D\u0435\u0434\u043E\u0432\u043E\u043B\u044C\u0441\u0442\u0432\u043E", priority: "high" };
    if (/\bthank|\bthanks\b|appreciate|sent you|you('| a)re the best/.test(t2) || /спасибо|благодар|признателен|ты лучшая|отправил тебе/.test(t2))
      return { type: "gratitude", key: "common.intent.gratitude", label: "\u{1F64F} \u0411\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u043D\u043E\u0441\u0442\u044C", priority: "medium" };
    if (/price|cost|how much|\brate\b|\bpay\b|\btip\b/.test(t2) || /цена|сколько стоит|стоимость|сколько.*стоит|почём|сколько за|расценк/.test(t2))
      return { type: "pricing", key: "common.intent.pricing", label: "\u{1F4B0} \u0426\u0435\u043D\u0430", priority: "high" };
    if (/subscribe|\btier\b|\bplan\b|\bunlock\b/.test(t2) || /подписк|подписат|подписаться|тариф|разблокир/.test(t2))
      return { type: "subscription", key: "common.intent.subscription", label: "\u2B50 \u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430", priority: "medium" };
    if (/\bbye\b|good ?night|gtg|see (you|ya)|talk later|gotta go/.test(t2) || /пока\b|спокойной ночи|до встречи|до завтра|побежал|мне пора|надо идти/.test(t2))
      return { type: "goodbye", key: "common.intent.goodbye", label: "\u{1F44B} \u041F\u0440\u043E\u0449\u0430\u043D\u0438\u0435", priority: "low" };
    if (/\b(hi|hello|hey|sup|yo|hola|ciao)\b/.test(t2) || /^\s*(привет|здравств|хай|доброе утро|добрый день|добрый вечер|здаров)/.test(t2))
      return { type: "greeting", key: "common.intent.greeting", label: "\u{1F44B} \u041F\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435", priority: "low" };
    if (/ready|give yourself|\bnaughty\b|\bwild\b|\bkinky\b|\bsex\b|\bnude\b|show me/.test(t2) || /покажи|голая|голый|сексуальн|возбуж|желани|хочу тебя|красотк|развратн|обнаж/.test(t2))
      return { type: "flirt", key: "common.intent.flirt", label: "\u{1F525} \u0424\u043B\u0438\u0440\u0442", priority: "medium" };
    return { type: "general", key: "common.intent.general", label: "\u{1F4AC} \u041E\u0431\u0449\u0435\u043D\u0438\u0435", priority: "low" };
  }
  function mediaMarkText(type) {
    if (!type) return "";
    const k = { photo: "common.media.photo", video: "common.media.video", audio: "common.media.audio", gif: "common.media.gif", blurred: "common.media.blurred", bundle: "common.media.bundle", media: "common.media.attachment" }[type] || "common.media.attachment";
    return "[" + t(k, state.uiLang) + "]";
  }
  function replyQuoteStr(reply) {
    if (!reply) return "";
    const label = t(reply.isMine ? "common.reply.toYours" : "common.reply.toHis", state.uiLang);
    const mark = reply.mediaType ? mediaMarkText(reply.mediaType) + " " : "";
    const txt = (reply.text || "").replace(/\s+/g, " ").trim();
    const short = txt.length > 50 ? txt.slice(0, 50) + "\u2026" : txt;
    return `${label}: ${(mark + short).trim()}`;
  }
  function replyGenders(reply) {
    return reply.isMine ? outGenders() : inGenders();
  }
  function replyCached(reply) {
    if (!reply || !reply.text || state.translatorEnabled === false) return reply;
    trCtxChatSync();
    const tr = state.transCache.get(tcKey(reply.text, replyGenders(reply)));
    return tr != null ? { ...reply, text: tr } : reply;
  }
  async function replyTranslated(reply) {
    if (!reply || !reply.text) return reply;
    const tr = await translateForOwner(reply.text, replyGenders(reply));
    return tr ? { ...reply, text: tr } : reply;
  }
  function appendMessageToHistory(entry) {
    const history = document.getElementById("fai-chat-history");
    if (!history) return null;
    const empty = history.querySelector(".fai-empty-history");
    if (empty) empty.remove();
    const msg = document.createElement("div");
    const mediaMark = mediaMarkText(entry.mediaType);
    const replyNow = entry.reply ? replyCached(entry.reply) : null;
    const replyHtml = replyNow ? `<div class="fai-msg-reply">\u21A9 ${escapeHtmlC(replyQuoteStr(replyNow))}</div>` : "";
    if (entry.isMedia) {
      msg.className = `fai-msg media ${entry.role}`;
      msg.innerHTML = `${replyHtml}
        <div class="fai-msg-name">${entry.role === "subscriber" ? escapeHtmlC(state.currentContact) || t("common.subFallback", state.uiLang) : t("common.you", state.uiLang)}</div>
        <div class="fai-msg-text">${mediaMark || "\u{1F4CE}"}</div>`;
    } else {
      msg.className = `fai-msg ${entry.role}`;
      const name = entry.role === "subscriber" ? escapeHtmlC(state.currentContact) || t("common.subFallback", state.uiLang) : t("common.you", state.uiLang);
      const markAttr = mediaMark ? ` data-media-mark="${mediaMark}"` : "";
      const textHtml = mediaMark ? `${mediaMark} ${escapeHtmlC(entry.text)}` : escapeHtmlC(entry.text);
      msg.innerHTML = `${replyHtml}
        <div class="fai-msg-name">${name} \xB7 ${timeStr(entry.timestamp)}</div>
        <div class="fai-msg-text"${markAttr}>${textHtml}</div>`;
    }
    history.appendChild(msg);
    if (entry.reply && entry.reply.text && replyNow === entry.reply) {
      replyTranslated(entry.reply).then((r) => {
        const el = msg.querySelector(".fai-msg-reply");
        if (el && r !== entry.reply) el.textContent = "\u21A9 " + replyQuoteStr(r);
      }).catch(() => {
      });
    }
    scrollHistoryToBottom();
    return msg;
  }
  function scrollHistoryToBottom() {
    const h = document.getElementById("fai-chat-history");
    if (h) h.scrollTop = h.scrollHeight;
  }
  function clearIntent() {
    const bar = document.getElementById("fai-intent-bar");
    if (bar) bar.style.display = "none";
  }
  chrome.storage.local.get("fai_panel_ui", (d) => {
    state._panelUi = d.fai_panel_ui || {};
  });
  function panelUiSet(patch) {
    state._panelUi = Object.assign({}, state._panelUi, patch);
    chrome.storage.local.get("fai_panel_ui", (d) => chrome.storage.local.set({ fai_panel_ui: Object.assign({}, d.fai_panel_ui, patch) }));
  }
  function showSuggestions(suggestions, provider = "") {
    const list = document.getElementById("fai-suggestion-list");
    const block = document.getElementById("fai-suggestions");
    if (!list || !block) return;
    block.style.display = "flex";
    const sugTg = document.getElementById("fai-sug-toggle");
    const sugCollapsed = !!(state._panelUi && state._panelUi.sugCollapsed);
    list.style.display = sugCollapsed ? "none" : "";
    if (sugTg) sugTg.textContent = sugCollapsed ? "\u25B8" : "\u25BE";
    const badge = document.getElementById("fai-provider-badge");
    if (badge) badge.textContent = provider ? `\xB7 ${provider}` : "";
    list.innerHTML = "";
    const fanLang = state.contactData?.lang || "en";
    const sameLang = !fanLang || fanLang === state.nativeLang;
    const sameText = (a, b) => String(a || "").trim().replace(/\s+/g, " ").toLowerCase() === String(b || "").trim().replace(/\s+/g, " ").toLowerCase();
    suggestions.forEach((fanText, idx) => {
      const btn = document.createElement("button");
      btn.className = "fai-suggestion-btn";
      btn.innerHTML = `
        <span class="fai-idx">${idx + 1}</span>
        <span class="fai-suggestion-text">
          <span class="fai-suggestion-ru">\u23F3</span>
          <span class="fai-suggestion-en">${escapeHtmlC(fanText)}</span>
        </span>`;
      const ruEl = btn.querySelector(".fai-suggestion-ru");
      const enEl = btn.querySelector(".fai-suggestion-en");
      if (ruEl) ruEl.title = t("panel.sug.forYou", state.uiLang);
      if (enEl) enEl.title = t("panel.sug.toFan", state.uiLang);
      btn.addEventListener("click", () => insertToSendField(fanText));
      list.appendChild(btn);
      if (sameLang) {
        if (ruEl) {
          ruEl.textContent = fanText;
          ruEl.title = "";
        }
        if (enEl) enEl.style.display = "none";
        return;
      }
      enqueueTranslate(fanText, state.nativeLang, (result) => {
        const tr = result || fanText;
        if (ruEl) ruEl.textContent = tr;
        if (enEl && sameText(tr, fanText)) enEl.style.display = "none";
      }, outGenders());
    });
  }
  function clearSuggestions() {
    const list = document.getElementById("fai-suggestion-list");
    const block = document.getElementById("fai-suggestions");
    if (list) list.innerHTML = "";
    if (block) block.style.display = "none";
    clearIntent();
  }
  function refreshPaidState(hist) {
    try {
      const nodes = [...qa("messageNode")].filter((n) => PLAT.isOwn(n) && q("media", n));
      const own = hist.filter((m) => m.role === "model" && (m.mediaType || m.isMedia));
      for (let i = 1; i <= Math.min(nodes.length, own.length); i++) {
        const st = detectPaidState(nodes[nodes.length - i]);
        if (st) own[own.length - i].mediaPaid = st;
      }
    } catch (e) {
    }
  }
  async function buildCoachCtx() {
    ensureHistoryForCurrent();
    const hist = state.chatHistory.slice(-12);
    refreshPaidState(hist);
    return {
      history: hist,
      fanName: state.currentContact || "",
      fanGender: state.fanGender,
      dossier: state.contactData?.dossier || null,
      brief: state.contactData?.brief || null,
      tierName: state.contactData?.tierName || null,
      isSubscribed: state.contactData?.isSubscribed ?? false,
      isCreator: state.contactData?.isCreator === true,
      // фан сам криейтор (бейдж в шапке): детектился давно, но никуда не шёл
      // Заметка криейтера — написана человеком и ценнее всей автоматики; карта на файле объясняет трение
      // при покупке; закрытый по токсичности диалог — чтобы совет не звал тепло возвращаться к тому, кого закрыли.
      note: (state.contactData?.note || "").trim().slice(0, 300),
      hasCard: state.contactData?.hasCard === true,
      topics: (state.contactData?.dossier?.topics || []).slice(0, 10),
      fanLang: state.contactData?.lang || "en",
      allowExplicitContact: state.contactData?.allowExplicit ?? null,
      crm: crmCurrent(),
      // финансовый портрет фана (траты/тир/подписка/таймлайн) → совет CRM-осознанный. Через гард: кеш общий на вкладку, чужие деньги в промпт попасть не должны
      // Лестница тарифов со страницы /posts: без неё совет предлагал апгрейд тому, кто уже на самом дорогом
      tiers: (await new Promise((r) => chrome.storage.local.get("fansly_tiers", (d) => r(d.fansly_tiers))))?.list || null,
      // Разрыв с последнего ВХОДЯЩЕГО фана → совет учитывает свежесть (не «фан ответил только что», если прошло время)
      lastInGapMs: (() => {
        const li = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
        return li && li.timestamp ? Date.now() - li.timestamp : null;
      })(),
      // только реальный ТЕКСТ фана (как lastIncoming): кривое своё медиа-«subscriber» больше не даёт «только что написал»
      // Подсказка из панели («Доп. инструкция для AI») — то же поле, что рулит генерацией ответов. Раньше совет
      // его не видел, и сообщить ему то, чего нет в переписке, было нечем (Alex 2026-08-21).
      hint: (document.getElementById("fai-hint-input")?.value || "").trim()
    };
  }
  async function requestCoach() {
    const btn = document.getElementById("fai-coach-btn");
    const body = document.getElementById("fai-coach-body");
    if (!btn || !body) return;
    body.style.display = "block";
    coachZone(true);
    const tg = document.getElementById("fai-coach-toggle");
    if (tg) {
      tg.style.display = "";
      tg.textContent = "\u25BE";
    }
    if (!state.currentContact) {
      body.innerHTML = `<span style="color:#888">${t("panel.coach.noContact", state.uiLang)}</span>`;
      return;
    }
    const label = btn.textContent;
    btn.disabled = true;
    body.innerHTML = `<span style="color:#9a8fd0">${t("panel.coach.loading", state.uiLang)}</span>`;
    {
      const l = document.getElementById("fai-coach-lead");
      if (l) {
        l.textContent = "";
        l.style.display = "none";
      }
    }
    const cid0 = state.currentContactId || state.currentContact;
    setCoachFolded(cid0, false);
    const ctx = await buildCoachCtx();
    try {
      const r = await sendSafe({ type: "COACH", context: ctx });
      btn.disabled = false;
      btn.textContent = label;
      if ((state.currentContactId || state.currentContact) !== cid0) return;
      if (!r?.success) {
        const stop = aiStopLine(r);
        if (stop) {
          body.innerHTML = `<span style="color:#ef9a9a">${escapeHtmlC(stop)}</span>`;
          return;
        }
        const h = humanError(r?.error);
        body.innerHTML = `<span style="color:#ef9a9a">${escapeHtmlC(h.text)}</span>` + (h.hint ? `<div style="color:#8a8aa5;font-size:11px;margin-top:4px">${escapeHtmlC(h.hint)}</div>` : "");
        return;
      }
      state._panelChat = state._panelChat || {};
      if (cid0) state._panelChat[cid0] = [];
      renderCoach(r);
      applyCoachFold(coachFolded(cid0));
      state._coachCache = state._coachCache || {};
      if (cid0) state._coachCache[cid0] = { r, hint: ctx.hint || "" };
    } catch (e) {
      btn.disabled = false;
      btn.textContent = label;
      body.innerHTML = `<span style="color:#ef9a9a">${t("panel.coach.fail", state.uiLang)}</span>`;
    }
  }
  function clearCoach() {
    const body = document.getElementById("fai-coach-body");
    if (body) {
      body.innerHTML = "";
      body.style.display = "none";
    }
    const lead = document.getElementById("fai-coach-lead");
    if (lead) {
      lead.textContent = "";
      lead.style.display = "none";
    }
    const tg = document.getElementById("fai-coach-toggle");
    if (tg) tg.style.display = "none";
    coachZone(false);
  }
  function coachFolded(ck) {
    return !!(ck && state._coachFold && state._coachFold[ck]);
  }
  function setCoachFolded(ck, v) {
    if (!ck) return;
    state._coachFold = state._coachFold || {};
    state._coachFold[ck] = v;
  }
  function applyCoachFold(folded) {
    const b = document.getElementById("fai-coach-body");
    const lead = document.getElementById("fai-coach-lead");
    const tg = document.getElementById("fai-coach-toggle");
    if (b) b.style.display = folded ? "none" : "block";
    if (lead) lead.style.display = !folded && lead.textContent ? "block" : "none";
    if (tg) {
      tg.style.display = "";
      tg.textContent = folded ? "\u25B8" : "\u25BE";
    }
    coachZone(true);
  }
  function toggleCoach() {
    const b = document.getElementById("fai-coach-body");
    if (!b) return;
    const folded = b.style.display !== "none";
    setCoachFolded(state.currentContactId || state.currentContact, folded);
    applyCoachFold(folded);
  }
  function coachZone(on) {
    const z = document.getElementById("fai-coach");
    if (z) z.style.display = on ? "" : "none";
  }
  function ensureCoachCap() {
    const z = document.getElementById("fai-coach");
    if (!z) return;
    let cap = z.querySelector(".fai-coach-cap");
    if (!cap) {
      cap = document.createElement("div");
      cap.className = "fai-coach-cap";
      z.insertBefore(cap, z.firstChild);
    }
    cap.textContent = t("panel.coach.zone", state.uiLang);
  }
  function restoreCoach() {
    if (state.coachEnabled === false) {
      clearCoach();
      return;
    }
    const ck = state.currentContactId || state.currentContact;
    const cached = state._coachCache && ck ? state._coachCache[ck] : null;
    if (!cached) {
      clearCoach();
      return;
    }
    const curHint = (document.getElementById("fai-hint-input")?.value || "").trim();
    if (cached.hint && curHint && cached.hint !== curHint) {
      clearCoach();
      return;
    }
    renderCoach(cached.r);
    applyCoachFold(coachFolded(ck));
  }
  function splitAdvice(text) {
    const s = String(text || "").trim();
    if (!s) return { lead: "", rest: "" };
    const m = s.match(/^(.{20,220}?[.!?])(\s+[«"(A-ZА-ЯЁ].*)$/s);
    return m ? { lead: m[1].trim(), rest: m[2].trim() } : { lead: s, rest: "" };
  }
  function renderCoach(r) {
    const body = document.getElementById("fai-coach-body");
    if (!body) return;
    body.innerHTML = "";
    coachZone(true);
    ensureCoachCap();
    const leadEl = document.getElementById("fai-coach-lead");
    const { lead, rest } = splitAdvice(r.advice);
    if (leadEl) {
      leadEl.textContent = lead;
      leadEl.style.display = lead ? "block" : "none";
      leadEl.style.cssText += ";margin:2px 0 6px;padding:0;background:none;border:none;font-size:12.5px;font-weight:600;line-height:1.35;color:#efe9ff";
      if (lead) leadEl.style.display = "block";
    }
    if (r.phase) {
      const el = document.createElement("div");
      el.style.cssText = "color:#9a8fd0;font-size:11px;margin-bottom:4px";
      el.textContent = "\u{1F539} " + r.phase;
      body.appendChild(el);
    }
    if (rest) {
      const el = document.createElement("div");
      el.style.cssText = "color:#e0e0e0;margin-bottom:6px";
      el.textContent = rest;
      body.appendChild(el);
    } else if (!leadEl && r.advice) {
      const el = document.createElement("div");
      el.style.cssText = "color:#e0e0e0;margin-bottom:6px";
      el.textContent = r.advice;
      body.appendChild(el);
    }
    const ex = Array.isArray(r.examples) ? r.examples.filter((e) => typeof e === "string" && e.trim()) : [];
    if (ex.length) {
      const el = document.createElement("div");
      el.className = "fai-chat-msg fai-chat-assistant fai-coach-reply";
      ex.forEach((e, i) => {
        if (i) el.appendChild(document.createElement("br"));
        el.appendChild(phraseChip(e.trim()));
      });
      body.appendChild(el);
    }
    const seed = [r.advice || "", ...Array.isArray(r.examples) ? r.examples.map((e) => `\xAB${e}\xBB`) : []].filter(Boolean).join("\n");
    renderChatBox(body, seed);
  }
  function chatTurns(id) {
    state._panelChat = state._panelChat || {};
    return state._panelChat[id] = state._panelChat[id] || [];
  }
  function appendChatMsg(thread, role, text) {
    const el = document.createElement("div");
    el.className = "fai-chat-msg fai-chat-" + role;
    if (role === "assistant") appendChatText(el, text);
    else el.textContent = text;
    thread.appendChild(el);
    thread.scrollTop = thread.scrollHeight;
    return el;
  }
  const CHAT_PHRASE_RE = /«([^»\n]{2,300})»|"([^"\n]{2,300})"|“([^”\n]{2,300})”/g;
  function sendablePhrase(p) {
    if (p.length < 16) return false;
    if ((p.match(/\s/g) || []).length < 2) return false;
    const bare = (s) => s.replace(/[^\p{L}\p{N}]/gu, "").toLowerCase();
    if ((state.tiers || []).some((t2) => t2 && t2.name && bare(t2.name) === bare(p))) return false;
    return true;
  }
  function phraseChip(phrase) {
    const chip = document.createElement("span");
    chip.className = "fai-chat-phrase";
    chip.textContent = phrase;
    chip.title = t("panel.chat.insert", state.uiLang);
    chip.addEventListener("click", () => {
      if (String(window.getSelection() || "").trim()) return;
      insertToSendField(phrase);
    });
    return chip;
  }
  function appendChatText(el, text) {
    const s = String(text || "");
    let last = 0, m;
    CHAT_PHRASE_RE.lastIndex = 0;
    while (m = CHAT_PHRASE_RE.exec(s)) {
      const phrase = (m[1] || m[2] || m[3] || "").trim();
      if (!phrase || !sendablePhrase(phrase)) continue;
      if (m.index > last) el.appendChild(document.createTextNode(s.slice(last, m.index)));
      el.appendChild(phraseChip(phrase));
      last = m.index + m[0].length;
    }
    if (last < s.length) el.appendChild(document.createTextNode(s.slice(last)));
  }
  function insertToSendField(text) {
    const inputEl = document.getElementById("fai-custom-input");
    if (!inputEl) return;
    inputEl.value = text;
    inputEl.focus();
    inputEl.setSelectionRange(text.length, text.length);
    inputEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
  function renderChatBox(body, seedAdvice) {
    if (!body) return;
    const cid = state.currentContactId || state.currentContact;
    if (!cid) return;
    const turns = chatTurns(cid);
    if (!turns.some((m) => m.seed)) turns.unshift({ role: "assistant", content: seedAdvice || t("panel.chat.seed", state.uiLang), seed: true });
    const box = document.createElement("div");
    box.className = "fai-chat-box";
    const thread = document.createElement("div");
    thread.className = "fai-chat-thread";
    box.appendChild(thread);
    turns.filter((m) => !m.seed).forEach((m) => appendChatMsg(thread, m.role, m.content));
    const row = document.createElement("div");
    row.className = "fai-chat-row";
    const input = document.createElement("input");
    input.type = "text";
    input.className = "fai-chat-input";
    input.placeholder = t("panel.chat.ph", state.uiLang);
    input.dataset.i18nPh = "panel.chat.ph";
    const send = document.createElement("button");
    send.className = "fai-chat-send";
    send.textContent = "\u27A4";
    send.title = t("panel.chat.send", state.uiLang);
    send.dataset.i18nTitle = "panel.chat.send";
    row.appendChild(input);
    row.appendChild(send);
    box.appendChild(row);
    body.appendChild(box);
    let sending = false;
    const sameContact = () => (state.currentContactId || state.currentContact) === cid;
    const liveThread = () => thread.isConnected ? thread : document.querySelector("#fai-coach-body .fai-chat-thread");
    const run = async () => {
      const ask = (input.value || "").trim();
      if (!ask || sending) return;
      sending = true;
      send.disabled = true;
      input.value = "";
      appendChatMsg(thread, "user", ask);
      const myTurn = { role: "user", content: ask };
      turns.push(myTurn);
      const wait = appendChatMsg(thread, "status", t("panel.chat.thinking", state.uiLang));
      let r = null;
      const drop = () => {
        const i = turns.indexOf(myTurn);
        if (i >= 0) turns.splice(i, 1);
      };
      try {
        const ctx = await buildCoachCtx();
        if (!sameContact()) {
          wait.remove();
          sending = false;
          send.disabled = false;
          drop();
          return;
        }
        r = await sendSafe({ type: "PANEL_CHAT", context: ctx, turns: turns.filter((m) => m.content).slice(-8) });
      } catch (e) {
        r = { success: false, error: e.message };
      }
      wait.remove();
      sending = false;
      send.disabled = false;
      if (r?.success && r.text) {
        turns.push({ role: "assistant", content: r.text });
        const tEl2 = liveThread();
        if (tEl2 && sameContact()) appendChatMsg(tEl2, "assistant", r.text);
        return;
      }
      drop();
      const tEl = liveThread();
      if (!tEl || !sameContact()) return;
      const msg = aiStopLine(r) || (r?.blocked ? t("panel.chat.blocked", state.uiLang) : humanError(r?.error).text);
      appendChatMsg(tEl, "status", msg);
    };
    send.addEventListener("click", run);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        run();
      }
    });
  }
  const PANEL_REV = "2026-11-04.1";
  function createPanel() {
    const existing = document.getElementById("fansly-ai-panel");
    if (existing) {
      if (existing.dataset.faiRev === PANEL_REV) return;
      existing.remove();
    }
    const panel = document.createElement("div");
    panel.id = "fansly-ai-panel";
    panel.dataset.faiRev = PANEL_REV;
    panel.innerHTML = `
      <!-- \u0428\u0430\u043F\u043A\u0430: \u0421\u041B\u0415\u0412\u0410 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u0444\u0430\u043D\u0435 (\u043D\u0438\u043A, \u043F\u043E\u043B, \u043F\u043B\u0430\u0442\u043D\u044B\u0439, \u044F\u0437\u044B\u043A), \u0421\u041F\u0420\u0410\u0412\u0410 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043D\u0430\u0434 \u043F\u0430\u043D\u0435\u043B\u044C\u044E.
           \u0420\u0430\u043D\u044C\u0448\u0435 \u0438\u043D\u0434\u0438\u043A\u0430\u0442\u043E\u0440\u044B \u0438 \u043A\u043D\u043E\u043F\u043A\u0438 \u0448\u043B\u0438 \u043E\u0434\u043D\u0438\u043C \u0440\u044F\u0434\u043E\u043C \u2014 \xAB\u0440\u044F\u0434 \u0437\u0430\u0433\u0430\u0434\u043E\u0447\u043D\u044B\u0445 \u0438\u043A\u043E\u043D\u043E\u043A\xBB (\u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15).
           \u0420\u043E\u0431\u043E\u0442 \u{1F916} \u0443\u0431\u0440\u0430\u043D \u0441\u043E\u0432\u0441\u0435\u043C: \u0430\u0441\u0441\u043E\u0446\u0438\u0430\u0446\u0438\u044F \u0441 \u0431\u043E\u0442\u043E\u043C \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0440\u0435\u0447\u0438\u0442 \u043F\u043E\u0437\u0438\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430. -->
      <div class="fai-header" id="fai-header">
        <span class="fai-contact" id="fai-contact-name" data-i18n="panel.contact.selectChat">\u0412\u044B\u0431\u0435\u0440\u0438 \u0447\u0430\u0442</span>
        <span class="fai-header-info" id="fai-header-info">
          <!-- \u26A0\uFE0F \u0431\u0435\u0437 data-i18n-title: \u0442\u0443\u043B\u0442\u0438\u043F \u0434\u0438\u043D\u0430\u043C\u0438\u0447\u0435\u0441\u043A\u0438\u0439 (\u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u043E\u043B + \u0447\u0442\u043E \u0441\u0434\u0435\u043B\u0430\u0435\u0442 \u043A\u043B\u0438\u043A), \u0435\u0433\u043E \u0441\u0442\u0430\u0432\u0438\u0442
               updateGenderBtn \u2014 applyI18n \u0438\u043D\u0430\u0447\u0435 \u0437\u0430\u0442\u0438\u0440\u0430\u043B \u0431\u044B \u0435\u0433\u043E \u0441\u0442\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439 -->
          <button class="fai-header-btn" id="fai-fan-gender" title="\u041F\u043E\u043B \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0430">\u{1F468}</button>
          <button class="fai-header-btn fai-status-star" id="fai-subscribed" data-i18n-title="panel.btn.subscribed.title" title="\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438">\u2606</button>
          <span id="fai-tier" style="font-size:9px;color:#9ad;max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span>
          <button class="fai-header-btn fai-lang-btn" id="fai-fan-lang" data-i18n-title="panel.btn.fanLang.title" title="\u042F\u0437\u044B\u043A \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0430">EN</button>
        </span>
        <span class="fai-stats-badge" id="fai-stats">0</span>
        <div class="fai-header-actions">
          <!--@full-start@-->
          <button class="fai-header-btn" id="fai-exclude-btn">\u{1F514}</button>
          <button class="fai-header-btn" id="fai-tour-btn" data-i18n-title="panel.tour.btn.title" title="\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u043F\u0430\u043D\u0435\u043B\u0438">?</button>
          <button class="fai-header-btn" id="fai-night-btn" style="display:none">\u{1F501}</button>
          <!-- \u041C\u0435\u043D\u044E \xAB\u2026\xBB \u0443\u0434\u0430\u043B\u0435\u043D\u043E (Alex, 2026-08-16): \u043F\u043E\u0441\u043B\u0435 \u0432\u044B\u043D\u043E\u0441\u0430 \xAB\u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0438\xBB \u0432 \u043A\u043E\u043D\u0441\u043E\u043B\u044C \u0432 \u043D\u0451\u043C \u043E\u0441\u0442\u0430\u043B\u0441\u044F
               \u043E\u0434\u0438\u043D \u043F\u0443\u043D\u043A\u0442 \u2014 \u0440\u0430\u0434\u0438 \u043D\u0435\u0433\u043E \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u0449\u043D\u043E\u0441\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u0430. \xAB?\xBB (\u0442\u0443\u0440) \u0432\u0435\u0440\u043D\u0443\u043B\u0430\u0441\u044C \u0432 \u0448\u0430\u043F\u043A\u0443. -->
          <!-- (\u043A\u043D\u043E\u043F\u043A\u0430 \xAB?\xBB \u2014 \u0432\u044B\u0448\u0435 \u0432 \u044D\u0442\u043E\u043C \u0436\u0435 \u0440\u044F\u0434\u0443, id fai-tour-btn) -->
          <!--@full-end@-->
          <button class="fai-header-btn" id="fai-collapse-btn" data-i18n-title="panel.btn.collapse.title" title="\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C">\u25B2</button>
          <button class="fai-header-btn" id="fai-close-btn" data-i18n-title="panel.btn.close.title" title="\u0417\u0430\u043A\u0440\u044B\u0442\u044C">\xD7</button>
        </div>
      </div>
      <!-- \u041F\u043E\u043A\u0430 \u043A\u043B\u044E\u0447 \u043D\u0435 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D, \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0434\u0451\u0442 \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u043C Google, \u0430 \u0418\u0418 \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0432\u043E\u0432\u0441\u0435 \u2014 \u0438 \u0447\u0435\u043B\u043E\u0432\u0435\u043A \u043E\u0431
           \u044D\u0442\u043E\u043C \u041D\u0415 \u0417\u041D\u0410\u0415\u0422: \u043E\u043D \u0432\u0438\u0434\u0438\u0442 \u043F\u0440\u043E\u0441\u0442\u043E \xAB\u0442\u0430\u043A \u0441\u0435\u0431\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\xBB \u0438 \u0434\u0435\u043B\u0430\u0435\u0442 \u0432\u044B\u0432\u043E\u0434 \u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0435 (\u0436\u0438\u0432\u043E\u0439 \u0441\u043B\u0443\u0447\u0430\u0439 \u0441
           \u0442\u0435\u0441\u0442\u0435\u0440\u043E\u043C, Alex 2026-08-19). \u041F\u043E\u044D\u0442\u043E\u043C\u0443 \u043F\u043B\u0430\u0448\u043A\u0430, \u0430 \u043D\u0435 \u0442\u0435\u043A\u0441\u0442: \u0440\u0430\u0441\u0447\u0451\u0442 \u043D\u0430 \u0442\u043E, \u0447\u0442\u043E \u0447\u0438\u0442\u0430\u0442\u044C \u043D\u0435 \u0431\u0443\u0434\u0443\u0442, \u0430
           \u043A\u043D\u043E\u043F\u043A\u0443 \u0443\u0432\u0438\u0434\u044F\u0442. \u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0435\u0451 \u043D\u0435\u043B\u044C\u0437\u044F \u043D\u0430\u043C\u0435\u0440\u0435\u043D\u043D\u043E \u2014 \u043E\u043D\u0430 \u0438 \u0442\u0430\u043A \u0438\u0441\u0447\u0435\u0437\u0430\u0435\u0442, \u043A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043A\u043B\u044E\u0447 \u043F\u043E\u044F\u0432\u0438\u043B\u0441\u044F, \u0430
           \u043A\u0440\u0435\u0441\u0442\u0438\u043A \u043E\u0437\u043D\u0430\u0447\u0430\u043B \u0431\u044B \u0440\u043E\u0432\u043D\u043E \u0442\u043E\u0442 \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0439, \u043E\u0442 \u043A\u043E\u0442\u043E\u0440\u043E\u0433\u043E \u043B\u0435\u0447\u0438\u043C\u0441\u044F: \u0437\u0430\u043A\u0440\u044B\u043B \u043D\u0435 \u0433\u043B\u044F\u0434\u044F \u0438 \u0441\u043F\u0438\u0441\u0430\u043B \u043D\u0430 \u043F\u0440\u043E\u0434\u0443\u043A\u0442.
           Build-neutral: \u0432 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A\u0435 (store) \u043E\u043D\u0430 \u0433\u043E\u0432\u043E\u0440\u0438\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u2014 \u043E\u0431\u0435\u0449\u0430\u0442\u044C \u0442\u0430\u043C \u0418\u0418 \u043D\u0435\u0447\u0435\u0441\u0442\u043D\u043E. -->
      <div class="fai-setup-hint" id="fai-setup-hint" style="display:none">
        <span id="fai-setup-hint-text"></span>
        <button id="fai-setup-hint-btn" type="button"></button>
      </div>
      <!-- \u0412\u0432\u043E\u0434 \u043A\u043E\u0434\u0430 \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u044F. \u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u0422\u041E\u041B\u042C\u041A\u041E \u043A\u043E\u0433\u0434\u0430 \u0441\u0435\u0440\u0432\u0435\u0440 \u0437\u0430\u043A\u0440\u044B\u043B \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0432\u044B\u0434\u0430\u0447\u0443 \u0438 \u043D\u0430\u0437\u0432\u0430\u043B
           \u043F\u0443\u0442\u044C \xAB\u043A\u043E\u0434\xBB: \u0434\u043E \u044D\u0442\u043E\u0433\u043E \u043C\u043E\u043C\u0435\u043D\u0442\u0430 \u043F\u043E\u043B\u044F \u043D\u0435\u0442 \u0432\u043E\u0432\u0441\u0435, \u0447\u0442\u043E\u0431\u044B \u043D\u0435 \u0441\u043F\u0440\u0430\u0448\u0438\u0432\u0430\u0442\u044C \u0442\u043E, \u0447\u0435\u0433\u043E \u0443 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 \u043D\u0435\u0442 \u0438 \u043D\u0435
           \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C. \u041A\u043E\u0434 \u0432\u0432\u043E\u0434\u0438\u0442\u0441\u044F \u0417\u0414\u0415\u0421\u042C, \u0430 \u043D\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435: \u043F\u0443\u0442\u044C \xAB\u043F\u043B\u0430\u0448\u043A\u0430 \u2192 \u0441\u0430\u0439\u0442 \u2192 \u043A\u043B\u044E\u0447 \u2192 \u0432\u0441\u0442\u0430\u0432\u044C \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438\xBB
           \u044D\u0442\u043E \u0442\u0440\u0438 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0430 \u0438 \u043A\u043E\u043F\u0438\u043F\u0430\u0441\u0442\u0430 \u0434\u043B\u044F \u0442\u043E\u0433\u043E, \u043A\u0442\u043E \u0435\u0449\u0451 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0437\u0430\u043F\u043B\u0430\u0442\u0438\u043B (Alex 2026-09-02). -->
      <div class="fai-setup-hint" id="fai-code-row" style="display:none">
        <input id="fai-code-input" type="text" autocomplete="off" spellcheck="false">
        <button id="fai-code-btn" type="button"></button>
      </div>
      <!--@full-start@-->
      <!-- \u041F\u0443\u043B\u044C\u0442 \u0432\u043A\u043B\u044E\u0447\u0451\u043D, \u0430 \u0436\u0438\u0432\u043E\u0433\u043E \u043D\u0435\u0442 \u043D\u0438 \u0432 \u043E\u0434\u043D\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435, \u0438 \u044D\u0442\u0430 \u0435\u0433\u043E \u043D\u0435 \u0437\u0430\u0431\u0438\u0440\u0430\u0435\u0442: \u0437\u0434\u0435\u0441\u044C \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0447\u0435\u043B\u043E\u0432\u0435\u043A (09.10, \u0410\u043B\u0435\u043A\u0441).
           \u041E\u0431\u044A\u044F\u0441\u043D\u044F\u0435\u043C \u0438 \u0434\u0430\u0451\u043C \u0432\u044B\u0431\u043E\u0440 \u2014 \u043F\u0443\u043B\u044C\u0442 \u0437\u0434\u0435\u0441\u044C \u0438\u043B\u0438 \u0432 \u043D\u043E\u0432\u043E\u0439 \u0444\u043E\u043D\u043E\u0432\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435. \u0411\u0435\u0437 \u043A\u0440\u0435\u0441\u0442\u0438\u043A\u0430: \u0433\u0430\u0441\u043D\u0435\u0442, \u043A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0443\u043B\u044C\u0442 \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u0430\u043B. -->
      <div class="fai-setup-hint fai-pult-off" id="fai-pult-off" style="display:none">
        <span id="fai-pult-off-text"></span>
        <button id="fai-pult-off-here" type="button"></button>
        <button id="fai-pult-off-open" type="button"></button>
      </div>
      <div class="fai-night-bar" id="fai-night-bar" style="display:none">
        <span class="fai-night-icon">\u{1F319}</span>
        <span class="fai-night-status" id="fai-night-status">\u2014</span>
        <span class="fai-night-excluded" id="fai-night-excluded" style="display:none"></span>
        <!-- \u041A\u043D\u043E\u043F\u043A\u0430 \u23F9 \xAB\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C\xBB \u0443\u0431\u0440\u0430\u043D\u0430 (Alex, 2026-08-16): \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044E \u0432\u044B\u043A\u043B\u044E\u0447\u0430\u044E\u0442 \u0442\u0443\u043C\u0431\u043B\u0435\u0440\u043E\u043C \xAB\u0422\u0435\u043B\u0435\u0433\u0440\u0430\u043C\xBB
             \u0432 \u043F\u043E\u043F\u0430\u043F\u0435 \u0438 \u043A\u043D\u043E\u043F\u043A\u043E\u0439 \u0421\u0422\u041E\u041F \u043D\u0430 \u043F\u043B\u0430\u0448\u043A\u0435 \u043F\u0443\u043B\u044C\u0442\u0430 \u2014 \u0442\u0440\u0435\u0442\u044C\u044F \u0442\u043E\u0447\u043A\u0430 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0432 \u043F\u0430\u043D\u0435\u043B\u0438 \u043D\u0435 \u043D\u0443\u0436\u043D\u0430. -->
      </div>
      <div class="fai-night-excl-list" id="fai-night-excl-list" style="display:none"></div>
      <!--@full-end@-->
      <!-- \u0421\u041F\u0420\u0410\u0412\u041A\u0410 \u041E \u0424\u0410\u041D\u0415: \u0434\u043E\u0441\u044C\u0435 + CRM-\u043F\u043E\u0440\u0442\u0440\u0435\u0442 + \u0431\u0440\u0438\u0444 \u043F\u043E\u0434 \u043E\u0434\u043D\u043E\u0439 \u0441\u0432\u0451\u0440\u0442\u043A\u043E\u0439 \u0441 \u043E\u0434\u043D\u043E\u0441\u0442\u0440\u043E\u0447\u043D\u044B\u043C \u0441\u0430\u043C\u043C\u0430\u0440\u0438.
           \u0420\u0430\u043D\u044C\u0448\u0435 \u044D\u0442\u043E \u0431\u044B\u043B\u0438 \u0442\u0440\u0438 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0435 \u0441\u0435\u043A\u0446\u0438\u0438 \u0441 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0430\u043C\u0438 \u0442\u043E\u0433\u043E \u0436\u0435 \u0432\u0435\u0441\u0430, \u0447\u0442\u043E \u0438 \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u0437\u043E\u043D\u0430, \u0438 \u043F\u044F\u0442\u044C
           \u0431\u043B\u043E\u043A\u043E\u0432 \u043A\u043E\u043D\u043A\u0443\u0440\u0438\u0440\u043E\u0432\u0430\u043B\u0438 \u0437\u0430 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u0435 (\u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15). \u0420\u0430\u0431\u043E\u0447\u0430\u044F \u0437\u043E\u043D\u0430 \u2014 \u043B\u0435\u043D\u0442\u0430, \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B,
           \u043F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 \u2014 \u0442\u0435\u043F\u0435\u0440\u044C \u043D\u0438\u0447\u0435\u043C \u043D\u0435 \u043F\u0435\u0440\u0435\u043A\u0440\u044B\u0432\u0430\u0435\u0442\u0441\u044F. \u0420\u0430\u0437\u043C\u0435\u0442\u043A\u0430 \u0432\u043D\u0443\u0442\u0440\u0438 \u041D\u0415 \u043C\u0435\u043D\u044F\u043B\u0430\u0441\u044C: id \u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0438 \u0446\u0435\u043B\u044B. -->
      <div class="fai-about" id="fai-about">
        <div class="fai-about-head" id="fai-about-head">
          <span class="fai-about-title" data-i18n="panel.about.title">\u0421\u043F\u0440\u0430\u0432\u043A\u0430 \u043E \u0444\u0430\u043D\u0435</span>
          <span class="fai-about-sum" id="fai-about-sum"></span>
          <span class="fai-about-caret" id="fai-about-caret">\u25B8</span>
        </div>
        <div class="fai-about-body" id="fai-about-body" style="display:none">
      <div class="fai-dossier" id="fai-dossier">
        <div class="fai-dossier-header" id="fai-dossier-toggle">
          <span id="fai-closeness-badge" class="fai-closeness" title="new">\u{1F331}</span>
          <span class="fai-dossier-label" data-i18n="panel.dossier.label">\u0434\u043E\u0441\u044C\u0435</span>
          <span id="fai-facts-count" class="fai-facts-count"></span>
          <!--@full-start@-->
          <button id="fai-analyze-btn" class="fai-dossier-analyze-btn" data-i18n-title="panel.dossier.analyze.title" title="\u041F\u0440\u043E\u0430\u043D\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0447\u0430\u0442\u0430">\u{1F50D}</button>
          <!--@cws-cut-start@--><button id="fai-diagnose-btn" class="fai-dossier-analyze-btn" data-i18n-title="panel.dossier.diagnose.title" title="\u{1F52C} \u041D\u0430\u0439\u0442\u0438 \u0447\u0442\u043E \u0431\u043B\u043E\u043A\u0438\u0440\u0443\u0435\u0442 Gemini (\u0432 service-worker console)">\u{1F52C}</button><!--@cws-cut-end@-->
          <button id="fai-learnstyle-btn" class="fai-dossier-analyze-btn" data-i18n-title="panel.dossier.learnstyle.title" title="\u{1F4DA} \u0423\u0447\u0438\u0442\u044C\u0441\u044F \u0441\u0442\u0438\u043B\u044E \u0441 \u044D\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430" style="display:none">\u{1F4DA}</button>
          <!--@full-end@-->
          <button class="fai-dossier-btn" id="fai-dossier-btn">\u25BE</button>
        </div>
        <div class="fai-dossier-body" id="fai-dossier-body" style="display:none">
          <div id="fai-facts-list" class="fai-facts-list"></div>
          <div class="fai-dossier-add">
            <input type="text" id="fai-fact-input" data-i18n-ph="panel.fact.add.ph" placeholder="\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0444\u0430\u043A\u0442...">
            <button id="fai-fact-add-btn" class="fai-fact-add-btn">+</button>
          </div>
        </div>
      </div>
      <!--@full-start@-->
      <div class="fai-crm" id="fai-crm" style="display:none;padding:6px 10px;border-top:1px solid rgba(255,255,255,.07)"></div>
      <!--@full-end@-->
      <!--@full-start@-->
      <div class="fai-brief" id="fai-brief" style="display:none">
        <div class="fai-brief-header" id="fai-brief-header" style="cursor:pointer">
          <span class="fai-brief-icon">\u{1F4CB}</span>
          <span class="fai-brief-label" data-i18n="panel.brief.label">\u0431\u0440\u0438\u0444 \u043D\u0430 \u043A\u0430\u0441\u0442\u043E\u043C</span>
          <button id="fai-brief-lang" class="fai-brief-lang" data-i18n-title="panel.brief.lang.title" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B / \u043F\u0435\u0440\u0435\u0432\u043E\u0434">\u{1F310}</button>
          <button id="fai-brief-clear" class="fai-brief-clear" data-i18n-title="panel.brief.clear.title" title="\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0431\u0440\u0438\u0444">\xD7</button>
          <button id="fai-brief-toggle" class="fai-brief-lang" data-i18n-title="panel.brief.toggle.title" title="\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C/\u0440\u0430\u0437\u0432\u0435\u0440\u043D\u0443\u0442\u044C">\u25BE</button>
        </div>
        <div class="fai-brief-body" id="fai-brief-body"></div>
      </div>
      <!--@full-end@-->
        </div><!-- /fai-about-body -->
      </div><!-- /fai-about -->
      <div class="fai-body" id="fai-body">
        <div class="fai-chat-history" id="fai-chat-history">
          <div class="fai-empty-history" data-i18n="panel.history.empty">\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0438 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u0437\u0434\u0435\u0441\u044C</div>
        </div>
        <!--@full-start@-->
        <div class="fai-intent-bar" id="fai-intent-bar" style="display:none">
          <span class="fai-intent-badge" id="fai-intent-badge"></span>
        </div>
        <div class="fai-suggestions" id="fai-suggestions" style="display:none">
          <div class="fai-suggestions-label"><span data-i18n="panel.suggestions.label">\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043E\u0442\u0432\u0435\u0442\u0430</span> <span class="fai-provider-badge" id="fai-provider-badge"></span> <button class="fai-regen-btn" id="fai-sug-toggle" data-i18n-title="panel.sug.toggle.title" title="\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C/\u0440\u0430\u0437\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B">\u25BE</button></div>
          <div id="fai-suggestion-list"></div>
        </div>
        <!-- \u0420\u044F\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u043E\u0432 (\u0434\u0438\u0437\u0430\u0439\u043D-\u043F\u0440\u0430\u0432\u043A\u0430 2026-08-21): \xAB\u0421\u043E\u0432\u0435\u0442\xBB \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435 \u043D\u0430 \u0432\u0441\u044E \u043F\u043E\u043B\u043E\u0441\u0443 \u2014 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F
             \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u043B\u0430 \u0441\u044E\u0434\u0430 \u0438\u0437 \u0441\u0442\u0440\u043E\u043A\u0438 \u0432\u0432\u043E\u0434\u0430 \u0438 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u0430 \u043F\u043E\u0434\u043F\u0438\u0441\u044C (\u043E\u0434\u0438\u043D\u043E\u043A\u0438\u0439 \u25B6 \u043D\u0435 \u0447\u0438\u0442\u0430\u043B\u0441\u044F \u2014 \u0442\u043E\u0442 \u0436\u0435 \u0434\u0435\u0444\u0435\u043A\u0442,
             \u0447\u0442\u043E \xAB\u043E\u0434\u0438\u043D\u043E\u043A\u0438\u0439 0\xBB \u0438\u0437 \u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15). \u0420\u0435\u0434\u043A\u0438\u0435 \u043F\u043E\u043B\u044F (\u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440/\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F/\u2264 \u0441\u043B\u043E\u0432)
             \u0441\u043F\u0440\u044F\u0442\u0430\u043D\u044B \u0437\u0430 \u270F\uFE0F \u0432 \u0432\u044B\u0435\u0437\u0436\u0430\u044E\u0449\u0438\u0439 \u0440\u044F\u0434 \u0441 \u043B\u0438\u043F\u043A\u0438\u043C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435\u043C; \u0442\u043E\u0447\u043A\u0430 \u043D\u0430 \u270F\uFE0F = \u0441\u043A\u0440\u044B\u0442\u0430\u044F \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F
             \u0438\u043B\u0438 \u043B\u0438\u043C\u0438\u0442 \u0441\u043B\u043E\u0432 \u0441\u0435\u0439\u0447\u0430\u0441 \u0412\u041B\u0418\u042F\u042E\u0422 \u043D\u0430 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044E (\u0441\u043A\u0440\u044B\u0432\u0430\u0442\u044C \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043C\u043E\u0436\u043D\u043E, \u0435\u0433\u043E \u044D\u0444\u0444\u0435\u043A\u0442 \u2014 \u043D\u0435\u043B\u044C\u0437\u044F).
             \u0420\u044F\u0434 \u041D\u0415 \u0432\u043D\u0443\u0442\u0440\u0438 #fai-coach: \u0442\u043E\u0442 \u043F\u0440\u044F\u0447\u0435\u0442\u0441\u044F \u0442\u0443\u043C\u0431\u043B\u0435\u0440\u043E\u043C \xAB\u0421\u043E\u0432\u0435\u0442\u044B\xBB, \u0430 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u0430 \u0436\u0438\u0442\u044C \u0432\u0441\u0435\u0433\u0434\u0430. -->
        <div class="fai-tools" id="fai-tools" style="display:none;margin:4px 0;gap:4px;align-items:stretch">
          <!-- \xAB\u25B6 \u041E\u0442\u0432\u0435\u0442\u044B\xBB \u0421\u041F\u0420\u042F\u0422\u0410\u041D\u0410 (Alex 2026-08-21): \u0442\u0440\u0438 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430 \u0441\u0432\u0435\u0440\u0445\u0443 \u0437\u0430\u043D\u0438\u043C\u0430\u043B\u0438 \u043C\u0435\u0441\u0442\u043E \u0434\u043E \u0442\u043E\u0433\u043E, \u043A\u0430\u043A \u043F\u043E\u043D\u0430\u0434\u043E\u0431\u0438\u043B\u0438\u0441\u044C,
               \u0438 \u0440\u043E\u0436\u0434\u0430\u043B\u0438\u0441\u044C \u0431\u0435\u0437 \u0435\u0434\u0438\u043D\u043E\u0433\u043E \u0443\u0442\u043E\u0447\u043D\u0435\u043D\u0438\u044F. \u0422\u0435\u043F\u0435\u0440\u044C \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043F\u0440\u043E\u0441\u044F\u0442 \u0441\u043B\u043E\u0432\u0430\u043C\u0438 \u0432 \xAB\u{1F4AC} \u041E\u0431\u0441\u0443\u0434\u0438\u0442\u044C\xBB \u2014 \u0442\u0430\u043C \u0443 \u043C\u043E\u0434\u0435\u043B\u0438 \u0443\u0436\u0435
               \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0430, \u0438 \u043E\u043D\u0438 \u043F\u043E\u043B\u0443\u0447\u0430\u044E\u0442\u0441\u044F \u0442\u043E\u0447\u043D\u0435\u0435. \u041A\u043D\u043E\u043F\u043A\u0430 \u0438 \u0432\u0435\u0441\u044C \u043F\u0443\u0442\u044C \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0416\u0418\u0412\u042B (\u0435\u0451 \u0437\u043E\u0432\u0451\u0442 \u0435\u0449\u0451 \u0438
               \u0422\u0413-\u043A\u043E\u043C\u0430\u043D\u0434\u0430 /g), \u0441\u043F\u0440\u044F\u0442\u0430\u043D\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0430\u043C\u0430 \u043A\u043D\u043E\u043F\u043A\u0430 \u2014 \u0432\u0435\u0440\u043D\u0443\u0442\u044C = \u0441\u043D\u044F\u0442\u044C display:none. -->
          <!-- \u041A\u043D\u043E\u043F\u043A\u0430 \xAB\u041E\u0431\u0441\u0443\u0434\u0438\u0442\u044C\xBB \u0438 \u0441\u0432\u0451\u0440\u0442\u043A\u0430 \u043E\u0431\u0441\u0443\u0436\u0434\u0435\u043D\u0438\u044F \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u043B\u0438 \u0432 \u0440\u044F\u0434 \u0432\u0432\u043E\u0434\u0430 (\u0441\u043C. .fai-input-area):
               \u0446\u0435\u043B\u0430\u044F \u043F\u043E\u043B\u043E\u0441\u0430 \u043F\u043E\u0434 \u043D\u0438\u0445 \u0441\u044A\u0435\u0434\u0430\u043B\u0430 \u0432\u044B\u0441\u043E\u0442\u0443 \u043F\u0430\u043D\u0435\u043B\u0438. \u0421\u0430\u043C \u0440\u044F\u0434 \u0442\u0435\u043F\u0435\u0440\u044C \u043F\u0443\u0441\u0442\u043E\u0439 \u0438 \u0441\u043F\u0440\u044F\u0442\u0430\u043D. -->
          <!-- \u270F\uFE0F \u0421\u041F\u0420\u042F\u0422\u0410\u041D\u0410 \u0432\u043C\u0435\u0441\u0442\u0435 \u0441\u043E \u0441\u0432\u043E\u0438\u043C \u0440\u044F\u0434\u043E\u043C (Alex 2026-08-21): \xAB\u0434\u043E\u043F. \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F\xBB, \u0432\u044B\u0431\u043E\u0440 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0438 \xAB\u2264 \u0441\u043B\u043E\u0432\xBB
               \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u043B\u0438 \u0432 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440 \u2014 \u0443\u0442\u043E\u0447\u043D\u0435\u043D\u0438\u0435 \u0441\u043B\u043E\u0432\u0430\u043C\u0438 \u0432 \xAB\u{1F4AC} \u041E\u0431\u0441\u0443\u0434\u0438\u0442\u044C\xBB \u0434\u0435\u043B\u0430\u0435\u0442 \u0442\u043E \u0436\u0435 \u0441\u0430\u043C\u043E\u0435 \u0438 \u043F\u043E\u043D\u044F\u0442\u043D\u0435\u0435. \u0420\u044F\u0434 \u0438 \u0432\u0441\u0435
               \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0438 \u0436\u0438\u0432\u044B (\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F \u043A\u0430\u043A \u043F\u0443\u0441\u0442\u044B\u0435/\u0434\u0435\u0444\u043E\u043B\u0442\u043D\u044B\u0435), \u0432\u0435\u0440\u043D\u0443\u0442\u044C = \u0441\u043D\u044F\u0442\u044C display:none \u0442\u0443\u0442 \u0438 \u0443 #fai-hint-row. -->
          <button class="fai-coach-toggle" id="fai-tools-toggle" data-i18n-title="panel.tools.title" title="\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u0434\u043B\u044F AI \u0438 \u043B\u0438\u043C\u0438\u0442 \u0441\u043B\u043E\u0432" style="display:none;position:relative;padding:6px 9px;background:#2a2540;color:#c9b8ff;border:1px solid #3a3560;border-radius:8px;cursor:pointer;font-size:12px">\u270F\uFE0F<span id="fai-tools-dot" style="display:none;position:absolute;top:2px;right:2px;width:6px;height:6px;border-radius:50%;background:#e91e8c"></span></button>
        </div>
        <div class="fai-coach" id="fai-coach" style="margin:0">
          <!-- \u0412\u044B\u0432\u043E\u0434 \u0441\u043E\u0432\u0435\u0442\u0430 \u043E\u0434\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439 \u2014 \u0432\u0438\u0434\u0435\u043D \u0432\u0441\u0435\u0433\u0434\u0430; \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0438 \u043F\u0440\u0438\u043C\u0435\u0440\u044B \u0443\u0435\u0437\u0436\u0430\u044E\u0442 \u0432 \u0442\u0435\u043B\u043E \u043F\u043E \u25BE.
               \u0420\u0430\u043D\u044C\u0448\u0435 \u0441\u043E\u0432\u0435\u0442 \u0431\u044B\u043B \u0441\u043F\u043B\u043E\u0448\u043D\u044B\u043C \u0430\u0431\u0437\u0430\u0446\u0435\u043C \u043D\u0430 \u0448\u0435\u0441\u0442\u044C \u0441\u0442\u0440\u043E\u043A \u043C\u0435\u043B\u043A\u0438\u043C \u0448\u0440\u0438\u0444\u0442\u043E\u043C, \u0438 \u0432 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0435 \u0435\u0433\u043E
               \u043F\u0440\u043E\u0441\u0442\u043E \u043D\u0435 \u0447\u0438\u0442\u0430\u043B\u0438 (\u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15). -->
          <div class="fai-coach-lead" id="fai-coach-lead" style="display:none"></div>
          <div class="fai-coach-body" id="fai-coach-body" style="display:none;margin-top:4px;padding:8px;background:#181428;border:1px solid #2a2540;border-radius:8px;font-size:12px;line-height:1.45"></div>
        </div>
        <div class="fai-hint-row" id="fai-hint-row" style="display:none">
          <select id="fai-provider-select" data-i18n-title="panel.provider.title" title="\u041F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 (\u0430\u0432\u0442\u043E = \u043A\u0430\u0441\u043A\u0430\u0434)">
            <option value="auto" data-i18n="panel.provider.auto">\u0430\u0432\u0442\u043E</option>
            <option value="openrouter">OpenRouter</option>
            <option value="gemini">Gemini</option>
            <option value="groq">Groq</option>
            <option value="claude">Claude</option>
          </select>
          <input type="text" id="fai-hint-input" data-i18n-ph="panel.hint.ph" placeholder="\u0414\u043E\u043F. \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u0434\u043B\u044F AI (\u0432\u0441\u0435\u0433\u0434\u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430)...">
          <!-- \u041E\u0434\u0438\u043D\u043E\u043A\u043E\u0435 \u043F\u043E\u043B\u0435 \xAB0\xBB \u0432\u043D\u0438\u0437\u0443 \u043F\u0430\u043D\u0435\u043B\u0438 \u043D\u0435 \u0447\u0438\u0442\u0430\u043B\u043E\u0441\u044C \u0432\u043E\u043E\u0431\u0449\u0435 (\u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15) \u2014 \u043F\u043E\u0434\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u043C -->
          <span class="fai-maxwords" data-i18n-title="panel.maxwords.title" title="\u041C\u0430\u043A\u0441. \u0441\u043B\u043E\u0432 (0 = \u0431\u0435\u0437 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F)">
            <span class="fai-maxwords-cap" data-i18n="panel.maxwords.label">\u2264 \u0441\u043B\u043E\u0432</span>
            <input type="number" id="fai-maxwords-input" min="0" max="200" value="0">
          </span>
        </div>
        <!--@full-end@-->
        <!-- \xAB\u{1F4AC}\xBB \u0440\u044F\u0434\u043E\u043C \u0441 \u043F\u043E\u043B\u0435\u043C \u043E\u0442\u0432\u0435\u0442\u0430, \u0430 \u043D\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u043F\u043E\u043B\u043E\u0441\u043E\u0439 (Alex 2026-08-22): \u0446\u0435\u043B\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u043F\u043E\u0434 \u043E\u0434\u043D\u0443 \u043A\u043D\u043E\u043F\u043A\u0443
             \u0441\u044A\u0435\u0434\u0430\u043B\u0430 \u0432\u044B\u0441\u043E\u0442\u0443 \u043F\u0430\u043D\u0435\u043B\u0438. \u0417\u0434\u0435\u0441\u044C \u0436\u0435 \u0438 \u0441\u043C\u044B\u0441\u043B\u043E\u0432\u0430\u044F \u043F\u0430\u0440\u0430: \u0441\u043B\u0435\u0432\u0430 \u043F\u0438\u0448\u0435\u0448\u044C \u0444\u0430\u043D\u0443, \u0441\u043F\u0440\u0430\u0432\u0430 \u2014 \u043E\u0431\u0441\u0443\u0436\u0434\u0430\u0435\u0448\u044C \u0441 \u0418\u0418. -->
        <div class="fai-input-area">
          <textarea id="fai-custom-input" data-i18n-ph="panel.custom.ph" placeholder="\u0421\u0432\u043E\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442..."></textarea>
          <button class="fai-send-btn" id="fai-coach-toggle" data-i18n-title="panel.coach.toggle.title" title="\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C/\u0440\u0430\u0437\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u043E\u0431\u0441\u0443\u0436\u0434\u0435\u043D\u0438\u0435" style="display:none;background:#2a2540;color:#c9b8ff;border:1px solid #3a3560">\u25BE</button>
          <button class="fai-send-btn" id="fai-coach-btn" data-i18n-title="panel.coach.title" title="\u041E\u0431\u0441\u0443\u0434\u0438\u0442\u044C \u044D\u0442\u043E\u0442 \u0434\u0438\u0430\u043B\u043E\u0433 \u0441 \u0418\u0418" style="background:#2a2540;color:#c9b8ff;border:1px solid #3a3560">\u{1F4AC}</button>
          <button class="fai-send-btn" id="fai-send-btn">\u2191</button>
        </div>
        <div class="fai-status" id="fai-status"></div>
      </div>
    `;
    if (typeof applyI18n === "function") applyI18n(panel, state.uiLang || "ru");
    chrome.storage.local.get([CONFIG.POS_KEY], (result) => applyPanelGeometry(panel, result[CONFIG.POS_KEY]));
    new ResizeObserver(() => {
      if (!isExtensionAlive()) {
        notifyContextDead();
        return;
      }
      savePanelGeometry(panel);
    }).observe(panel);
    document.body.appendChild(panel);
    bindPanelEvents(panel);
    if (state._panelShown === false || state._pultActive) panel.style.display = "none";
    makeDraggable(panel);
    if (typeof refreshUpdateBanner === "function") refreshUpdateBanner();
    if (typeof refreshTgAlertBanner === "function") refreshTgAlertBanner();
    if (typeof refreshPultOff === "function") refreshPultOff();
    if (typeof refreshLayoutBanner === "function") refreshLayoutBanner();
    console.log("[FanslyAI] Panel created v0.3 \u2713");
  }
  async function refreshUpdateBanner() {
    const panel = document.getElementById("fansly-ai-panel");
    if (!panel) return;
    const info = await new Promise((r) => chrome.storage.local.get("fansly_update_info", (d) => r(d.fansly_update_info)));
    const old = document.getElementById("fai-update-banner");
    const dismissed = sessionStorage.getItem("fai_update_dismissed");
    if (!info || !info.version || dismissed === info.version) {
      if (old) old.remove();
      return;
    }
    if (old) old.remove();
    const b = document.createElement("div");
    b.id = "fai-update-banner";
    b.style.cssText = "display:flex;align-items:center;gap:6px;background:#2a1f3d;color:#e8d9ff;border-bottom:1px solid #4a3a6a;padding:6px 8px;font-size:11px";
    const txt = document.createElement("span");
    txt.style.cssText = "flex:1";
    txt.textContent = t("panel.update.available", state.uiLang, { v: info.version });
    b.appendChild(txt);
    const safeUrl = (() => {
      try {
        const u = new URL(String(info.url || ""));
        const ok = u.protocol === "https:" && ["velourapp.github.io", "github.com", "objects.githubusercontent.com"].includes(u.hostname);
        return ok ? u.href : "";
      } catch (e) {
        return "";
      }
    })();
    if (safeUrl) {
      const a = document.createElement("a");
      a.textContent = t("panel.update.get", state.uiLang);
      a.href = safeUrl;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.style.cssText = "color:#c9a0ff;font-weight:600;text-decoration:none;cursor:pointer";
      if (info.notes) a.title = info.notes;
      b.appendChild(a);
    }
    const x = document.createElement("span");
    x.textContent = "\u2716";
    x.title = t("panel.update.dismiss", state.uiLang);
    x.style.cssText = "cursor:pointer;opacity:.6;flex-shrink:0";
    x.addEventListener("click", () => {
      sessionStorage.setItem("fai_update_dismissed", info.version);
      b.remove();
    });
    b.appendChild(x);
    panel.insertBefore(b, panel.firstChild);
  }
  if (!window.__faiUpdateListener) {
    window.__faiUpdateListener = true;
    try {
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area === "local" && ch.fansly_update_info) refreshUpdateBanner();
      });
    } catch (e) {
    }
  }
  async function refreshTgAlertBanner() {
    const d = await new Promise((r) => chrome.storage.local.get(["fansly_tg_alert", "fansly_tg_hold", "fansly_tg_group", "fansly_tg_mode"], r));
    const al = d.fansly_tg_alert, hold = d.fansly_tg_hold, grp = d.fansly_tg_group, mode = d.fansly_tg_mode;
    const pausedNow = !!(hold && hold.list && hold.list.length) || !!(al && (al.kind === "bot_no_rights" || al.kind === "bot_removed")) || !!(grp && grp.public);
    if (state._tgPaused !== pausedNow) {
      state._tgPaused = pausedNow;
      if (_initialized) sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
      });
    }
    const panel = document.getElementById("fansly-ai-panel");
    if (!panel) return;
    document.getElementById("fai-tg-alert")?.remove();
    document.getElementById("fai-tg-hold")?.remove();
    document.getElementById("fai-tg-group")?.remove();
    document.getElementById("fai-tg-mode")?.remove();
    const strip = (id) => {
      const b = document.createElement("div");
      b.id = id;
      b.style.cssText = "display:flex;align-items:flex-start;gap:6px;background:#3d1f2a;color:#ffd9e6;border-bottom:1px solid #6a3a4a;padding:6px 8px;font-size:11px;line-height:1.4";
      return b;
    };
    if (hold && hold.list && hold.list.length) {
      const b = strip("fai-tg-hold");
      const ids = hold.list.map((e) => String(e.id));
      const txt = document.createElement("span");
      txt.style.cssText = "flex:1";
      txt.textContent = t("panel.tgAlert.hold", state.uiLang, { who: hold.list.map((e) => e.who || e.id).join(", ") });
      b.appendChild(txt);
      const ok = document.createElement("span");
      ok.textContent = t("panel.tgAlert.confirm", state.uiLang);
      ok.style.cssText = "cursor:pointer;flex-shrink:0;background:#ffd9e6;color:#5a1f30;border-radius:6px;padding:2px 8px;font-weight:600;white-space:nowrap";
      ok.addEventListener("click", () => {
        ok.style.opacity = ".5";
        sendSafe({ type: "TG_HOLD_CONFIRM", ids }).then(() => refreshTgAlertBanner());
      });
      b.appendChild(ok);
      panel.insertBefore(b, panel.firstChild);
    }
    const key = al?.kind === "bot_removed" ? "panel.tgAlert.botRemoved" : al?.kind === "bot_no_rights" ? al.single ? "panel.tgAlert.botNoRightsSingle" : "panel.tgAlert.botNoRights" : null;
    if (key && !al.dismissed) {
      const b = strip("fai-tg-alert");
      const txt = document.createElement("span");
      txt.style.cssText = "flex:1";
      txt.textContent = t(key, state.uiLang, { who: al.by ? " (" + al.by + ")" : "" });
      b.appendChild(txt);
      const x = document.createElement("span");
      x.textContent = "\u2716";
      x.title = t("panel.tgAlert.dismiss", state.uiLang);
      x.style.cssText = "cursor:pointer;opacity:.6;flex-shrink:0";
      x.addEventListener("click", () => {
        chrome.storage.local.get("fansly_tg_alert", (d2) => {
          if (d2.fansly_tg_alert) chrome.storage.local.set({ fansly_tg_alert: { ...d2.fansly_tg_alert, dismissed: true } });
        });
        b.remove();
      });
      b.appendChild(x);
      panel.insertBefore(b, panel.firstChild);
    }
    if (grp && grp.public && !grp.dismissed) {
      const b = strip("fai-tg-group");
      const txt = document.createElement("span");
      txt.style.cssText = "flex:1";
      txt.textContent = t("panel.tgAlert.groupPublic", state.uiLang);
      b.appendChild(txt);
      const x = document.createElement("span");
      x.textContent = "\u2716";
      x.title = t("panel.tgAlert.dismiss", state.uiLang);
      x.style.cssText = "cursor:pointer;opacity:.6;flex-shrink:0";
      x.addEventListener("click", () => {
        chrome.storage.local.get("fansly_tg_group", (d2) => {
          if (d2.fansly_tg_group) chrome.storage.local.set({ fansly_tg_group: { ...d2.fansly_tg_group, dismissed: true } });
        });
        b.remove();
      });
      b.appendChild(x);
      panel.insertBefore(b, panel.firstChild);
    }
    if (mode && mode.switched === "single" && !mode.dismissed) {
      const b = strip("fai-tg-mode");
      const txt = document.createElement("span");
      txt.style.cssText = "flex:1";
      txt.textContent = t("panel.tgAlert.modeSingle", state.uiLang);
      b.appendChild(txt);
      const x = document.createElement("span");
      x.textContent = "\u2716";
      x.title = t("panel.tgAlert.dismiss", state.uiLang);
      x.style.cssText = "cursor:pointer;opacity:.6;flex-shrink:0";
      x.addEventListener("click", () => {
        chrome.storage.local.get("fansly_tg_mode", (d2) => {
          if (d2.fansly_tg_mode) chrome.storage.local.set({ fansly_tg_mode: { ...d2.fansly_tg_mode, dismissed: true } });
        });
        b.remove();
      });
      b.appendChild(x);
      panel.insertBefore(b, panel.firstChild);
    }
  }
  if (!window.__faiTgAlertListener) {
    window.__faiTgAlertListener = true;
    try {
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area === "local" && (ch.fansly_tg_alert || ch.fansly_tg_hold || ch.fansly_tg_group || ch.fansly_tg_mode)) refreshTgAlertBanner();
      });
    } catch (e) {
    }
  }
  function bindPanelEvents(panel) {
    const LANGS = ["EN", "ES", "PT", "DE", "FR", "IT", "PL", "TR", "RU", "UK"];
    document.getElementById("fai-sug-toggle")?.addEventListener("click", () => {
      const nv = !(state._panelUi && state._panelUi.sugCollapsed);
      panelUiSet({ sugCollapsed: nv });
      const list = document.getElementById("fai-suggestion-list");
      if (list) list.style.display = nv ? "none" : "";
      const tg = document.getElementById("fai-sug-toggle");
      if (tg) tg.textContent = nv ? "\u25B8" : "\u25BE";
    });
    const _provSel = document.getElementById("fai-provider-select");
    if (_provSel) {
      _provSel.value = state.forceProvider || "auto";
      _provSel.addEventListener("change", () => {
        state.forceProvider = _provSel.value;
        if (isExtensionAlive()) chrome.storage.local.set({ fansly_force_provider: _provSel.value });
        const nm = _provSel.options[_provSel.selectedIndex].text;
        setStatus(_provSel.value === "auto" ? t("panel.provider.autoSet", state.uiLang) : t("panel.provider.forcedSet", state.uiLang, { p: nm }));
        setTimeout(() => setStatus(""), 2500);
      });
      if (state._proxyOn) _provSel.style.display = "none";
    }
    const _updToolsDot = () => {
      const dot = document.getElementById("fai-tools-dot");
      if (!dot) return;
      const hv = (document.getElementById("fai-hint-input")?.value || "").trim();
      const mw = parseInt(document.getElementById("fai-maxwords-input")?.value) || 0;
      dot.style.display = hv || mw > 0 ? "" : "none";
    };
    const _applyToolsOpen = (open) => {
      const row = document.getElementById("fai-hint-row");
      const btn = document.getElementById("fai-tools-toggle");
      if (row) row.style.display = open ? "" : "none";
      if (btn) btn.style.borderColor = open ? "#e91e8c" : "#3a3560";
    };
    state._toolsOpen = false;
    _applyToolsOpen(state._toolsOpen);
    _updToolsDot();
    document.getElementById("fai-tools-toggle")?.addEventListener("click", () => {
      state._toolsOpen = !state._toolsOpen;
      _applyToolsOpen(state._toolsOpen);
      panelUiSet({ toolsOpen: state._toolsOpen });
    });
    document.getElementById("fai-hint-input")?.addEventListener("input", _updToolsDot);
    document.getElementById("fai-night-btn").addEventListener("click", () => {
      if (carousel.running) {
        stopNightMode("common.reason.manual");
        persistSetting("carouselEnabled", false);
      } else if (state._tgPaused) {
        if (typeof refreshTgAlertBanner === "function") refreshTgAlertBanner();
      } else {
        startNightMode(true);
        persistSetting("carouselEnabled", true);
      }
    });
    document.getElementById("fai-night-excluded").addEventListener("click", () => {
      const list = document.getElementById("fai-night-excl-list");
      if (list) list.style.display = list.style.display === "block" ? "none" : "block";
    });
    document.getElementById("fai-exclude-btn").addEventListener("click", () => {
      if (!state.contactData) return;
      const next = !state.contactData.excludeFromAuto;
      state.contactData.excludeFromAuto = next;
      saveContact(state.currentContact, { excludeFromAuto: next });
      updateExcludeBtn();
      if (next) carousel.excludedIds.add(state.currentContactId);
      else carousel.excludedIds.delete(state.currentContactId);
    });
    document.getElementById("fai-analyze-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      if (state._panelUi && state._panelUi.analyzeHintHidden) {
        triggerHistoryAnalysis(true);
        return;
      }
      showAnalyzeHint(() => triggerHistoryAnalysis(true));
    });
    document.getElementById("fai-tour-btn")?.addEventListener("click", () => startPanelTour());
    document.getElementById("fai-diagnose-btn").addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!state.currentContact) {
        setStatus(t("panel.status.openChat", state.uiLang));
        setTimeout(() => setStatus(""), 1500);
        return;
      }
      const history = collectHistoryFromDom();
      setStatus(t("panel.status.diagnosing", state.uiLang, { n: history.length }));
      const r = await sendSafe({ type: "DIAGNOSE_BLOCK", history, fanName: state.currentContact });
      if (r?.success) {
        setStatus(t("panel.status.diagnoseResult", state.uiLang, { n: r.blockedBlocks?.length || 0, rateSuffix: r.rateHit ? t("panel.status.diagnoseRateSuffix", state.uiLang) : "" }));
      } else {
        setStatus("\u{1F52C} " + humanErrorLine(r?.error));
      }
      setTimeout(() => setStatus(""), 6e3);
    });
    document.getElementById("fai-learnstyle-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      if (!state.currentContact) {
        setStatus(t("panel.status.openChat", state.uiLang));
        setTimeout(() => setStatus(""), 1500);
        return;
      }
      const history = collectHistoryFromDom().filter((m) => m.text && !m.isMedia);
      const mine = history.filter((m) => m.role === "model");
      if (mine.length < 4) {
        setStatus(t("panel.status.learnNeedMore", state.uiLang));
        setTimeout(() => setStatus(""), 2600);
        return;
      }
      const transcript = history.slice(-80).map((m) => `${m.role === "model" ? "Creator" : "Fan"}: ${m.text}`).join("\n");
      chrome.storage.local.set({ fansly_realdialog_pending: { transcript, ts: Date.now() } }, () => {
        sendSafe({ type: "OPEN_ONBOARDING_REALDIALOG" });
        setStatus(t("panel.status.learnOpening", state.uiLang));
        setTimeout(() => setStatus(""), 2e3);
      });
    });
    document.getElementById("fai-brief-header").addEventListener("click", (e) => {
      if (e.target.closest("#fai-brief-lang, #fai-brief-clear")) return;
      state.briefCollapsed = !state.briefCollapsed;
      applyBriefCollapsed();
    });
    document.getElementById("fai-brief-lang").addEventListener("click", () => {
      state.briefShowOriginal = !state.briefShowOriginal;
      const btn = document.getElementById("fai-brief-lang");
      btn.classList.toggle("active", state.briefShowOriginal);
      btn.title = t(state.briefShowOriginal ? "panel.brief.lang.title.original" : "panel.brief.lang.title.translated", state.uiLang);
      renderBrief();
    });
    document.getElementById("fai-brief-clear").addEventListener("click", () => {
      if (confirm(t("panel.confirm.clearBrief", state.uiLang))) clearBrief();
    });
    document.getElementById("fai-dossier-toggle").addEventListener("click", (e) => {
      if (e.target.closest("#fai-fact-input, #fai-fact-add-btn")) return;
      const body = document.getElementById("fai-dossier-body");
      const btn = document.getElementById("fai-dossier-btn");
      const open = body.style.display !== "none";
      body.style.display = open ? "none" : "block";
      btn.textContent = open ? "\u25BE" : "\u25B4";
    });
    const addFact = () => {
      const input = document.getElementById("fai-fact-input");
      const fact = input.value.trim();
      if (!fact || !state.contactData) return;
      if (!state.contactData.dossier) {
        state.contactData.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
      }
      const dd = state.contactData.dossier;
      if (!dd.factDates) dd.factDates = {};
      if (!dd.manualFacts) dd.manualFacts = [];
      if (!dd.facts.includes(fact)) {
        if (dd.manualFacts.length >= PINNED_MAX) {
          setStatus(t("panel.dossier.pin.limit", state.uiLang, { n: PINNED_MAX }));
          setTimeout(() => setStatus(""), 5e3);
          return;
        }
        dd.facts.push(fact);
        dd.factDates[fact] = Date.now();
        if (!dd.manualFacts.includes(fact)) dd.manualFacts.push(fact);
        saveContact(state.currentContact, { dossier: dd });
        renderDossier();
      }
      input.value = "";
    };
    document.getElementById("fai-fact-add-btn").addEventListener("click", addFact);
    document.getElementById("fai-fact-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addFact();
      }
    });
    document.getElementById("fai-fan-gender").addEventListener("click", () => {
      state.fanGender = state.fanGender === "male" ? "female" : "male";
      updateGenderBtn();
      if (state.contactData) state.contactData.gender = state.fanGender;
      if (state.currentContact) saveContact(state.currentContact, { gender: state.fanGender });
      setStatus(t("panel.status.fanGender", state.uiLang, { gender: t(state.fanGender === "male" ? "common.gender.male" : "common.gender.female", state.uiLang) }));
      setTimeout(() => setStatus(""), 1500);
    });
    if (BUILD === "full") {
      const _sb0 = document.getElementById("fai-subscribed");
      if (_sb0) {
        _sb0.style.cursor = "default";
        _sb0.title = t(subTitleKey(!!state.contactData?.isSubscribed), state.uiLang);
      }
    }
    document.getElementById("fai-subscribed").addEventListener("click", () => {
      if (BUILD === "full") return;
      const current = state.contactData?.isSubscribed || false;
      const next = !current;
      if (state.contactData) state.contactData.isSubscribed = next;
      const btn = document.getElementById("fai-subscribed");
      btn.textContent = next ? "\u2B50" : "\u2606";
      btn.title = t(next ? "panel.sub.title.on" : "panel.sub.title.off", state.uiLang);
      if (state.currentContact) saveContact(state.currentContact, { isSubscribed: next });
      setStatus(t(next ? "panel.status.subscribedOn" : "panel.status.subscribedOff", state.uiLang));
      setTimeout(() => setStatus(""), 1500);
    });
    document.getElementById("fai-fan-lang").addEventListener("click", () => {
      const currentLang = (state.contactData?.lang || "en").toUpperCase();
      const idx = LANGS.indexOf(currentLang);
      const next = LANGS[(idx + 1) % LANGS.length];
      const nextLower = next.toLowerCase();
      if (state.contactData) state.contactData.lang = nextLower;
      document.getElementById("fai-fan-lang").textContent = next;
      if (state.currentContact) saveContact(state.currentContact, { lang: nextLower });
      setStatus(t("panel.status.fanLang", state.uiLang, { lang: next }));
      setTimeout(() => setStatus(""), 1500);
    });
    document.getElementById("fai-maxwords-input").addEventListener("change", (e) => {
      state.maxWords = parseInt(e.target.value) || 0;
      _updToolsDot();
    });
    document.getElementById("fai-about-head")?.addEventListener("click", aboutToggle);
    applyAboutOpen();
    document.getElementById("fai-collapse-btn").addEventListener("click", () => {
      const collapsed = panel.classList.toggle("collapsed");
      document.getElementById("fai-collapse-btn").textContent = collapsed ? "\u25BC" : "\u25B2";
    });
    document.getElementById("fai-close-btn").addEventListener("click", () => {
      panel.style.display = "none";
      persistSetting("panelHidden", true);
    });
    document.getElementById("fai-send-btn").addEventListener("click", () => {
      const input = document.getElementById("fai-custom-input");
      const text = input.value.trim();
      if (text) {
        panelSend(text);
        mirrorOutgoingToTG(text);
        input.value = "";
      }
    });
    document.getElementById("fai-coach-btn")?.addEventListener("click", requestCoach);
    document.getElementById("fai-coach-toggle")?.addEventListener("click", toggleCoach);
    document.getElementById("fai-custom-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        document.getElementById("fai-send-btn").click();
      }
    });
  }
  const PANEL_MARGIN = 12;
  function panelWidthCap() {
    return Math.max(Math.round(window.innerWidth * 0.48), 480);
  }
  function panelDefaultGeometry() {
    const width = Math.max(320, Math.min(760, panelWidthCap(), window.innerWidth - PANEL_MARGIN * 2));
    const height = Math.max(320, window.innerHeight - PANEL_MARGIN * 2);
    return {
      width: width + "px",
      height: height + "px",
      left: Math.max(0, window.innerWidth - width - PANEL_MARGIN) + "px",
      top: PANEL_MARGIN + "px"
    };
  }
  function clampPanelIntoView(panel) {
    if (!panel || panel.style.display === "none") return;
    const collapsed = panel.classList.contains("collapsed");
    const w = Math.min(panel.offsetWidth, panelWidthCap(), Math.max(280, window.innerWidth - PANEL_MARGIN));
    if (w !== panel.offsetWidth) panel.style.width = w + "px";
    if (!collapsed) {
      const h = Math.min(panel.offsetHeight, Math.max(200, window.innerHeight - PANEL_MARGIN));
      if (h !== panel.offsetHeight) panel.style.height = h + "px";
    }
    const l = parseInt(panel.style.left), tp = parseInt(panel.style.top);
    panel.style.left = Math.max(0, Math.min(isNaN(l) ? 0 : l, window.innerWidth - w)) + "px";
    panel.style.top = Math.max(0, Math.min(isNaN(tp) ? 0 : tp, Math.max(0, window.innerHeight - 60))) + "px";
  }
  function applyPanelGeometry(panel, saved) {
    const g = saved && saved.left && saved.top ? saved : panelDefaultGeometry();
    panel.style.right = "auto";
    panel.style.bottom = "auto";
    panel.style.left = g.left;
    panel.style.top = g.top;
    if (g.width) panel.style.width = g.width;
    if (g.height && !panel.classList.contains("collapsed")) panel.style.height = g.height;
    clampPanelIntoView(panel);
  }
  let _geomSaveTimer = null;
  function savePanelGeometry(panel) {
    if (!isExtensionAlive()) return;
    clearTimeout(_geomSaveTimer);
    _geomSaveTimer = setTimeout(() => {
      if (!isExtensionAlive()) return;
      chrome.storage.local.get([CONFIG.POS_KEY], (d) => {
        const next = { ...d[CONFIG.POS_KEY] || {}, left: panel.style.left, top: panel.style.top };
        if (!panel.classList.contains("collapsed")) {
          next.width = panel.offsetWidth + "px";
          next.height = panel.offsetHeight + "px";
        }
        chrome.storage.local.set({ [CONFIG.POS_KEY]: next });
      });
    }, 250);
  }
  function makeDraggable(panel) {
    let dragging = false, ox, oy;
    const header = panel.querySelector("#fai-header");
    header.addEventListener("mousedown", (e) => {
      if (e.target.closest("button, input, select, label, a")) return;
      if (e.target.closest("#fai-contact-name span[title]")) return;
      dragging = true;
      panel.classList.add("dragging");
      const rect = panel.getBoundingClientRect();
      ox = e.clientX - rect.left;
      oy = e.clientY - rect.top;
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const maxX = Math.max(0, window.innerWidth - panel.offsetWidth);
      const maxY = Math.max(0, window.innerHeight - panel.offsetHeight);
      panel.style.left = Math.max(0, Math.min(e.clientX - ox, maxX)) + "px";
      panel.style.top = Math.max(0, Math.min(e.clientY - oy, maxY)) + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    });
    document.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      panel.classList.remove("dragging");
      savePanelGeometry(panel);
    });
    window.addEventListener("resize", () => {
      clampPanelIntoView(panel);
      savePanelGeometry(panel);
    });
  }
  function updateExcludeBtn() {
    const btn = document.getElementById("fai-exclude-btn");
    if (!btn) return;
    const excluded = state.contactData?.excludeFromAuto;
    btn.textContent = excluded ? "\u{1F515}" : "\u{1F514}";
    btn.classList.toggle("fai-excluded", !!excluded);
  }
  function updatePanelContact() {
    const el = document.getElementById("fai-contact-name");
    if (!el) return;
    const name = state.currentContact || t("panel.contact.selectChat", state.uiLang);
    const handle = state.contactData?.handle;
    el.onclick = null;
    el.style.cursor = "";
    el.title = "";
    if (handle) {
      el.textContent = "";
      const link = document.createElement("span");
      link.style.cssText = "cursor:pointer";
      link.title = t("panel.contact.openCrm", state.uiLang);
      link.appendChild(document.createTextNode(name + " "));
      const hn = document.createElement("span");
      hn.className = "fai-handle";
      hn.textContent = "@" + handle;
      link.appendChild(hn);
      link.onclick = () => sendSafe({ type: "CRM_OPEN", handle });
      el.appendChild(link);
      if (state._panelUi && !state._panelUi.tourDone && !state._tourTried) {
        state._tourTried = true;
        (typeof FaiConsent !== "undefined" ? FaiConsent.given() : Promise.resolve(false)).then((ok) => {
          if (!ok) {
            state._tourTried = false;
            return;
          }
          setTimeout(() => {
            try {
              startPanelTour();
            } catch (e) {
            }
          }, 1500);
        }, () => {
          state._tourTried = false;
        });
      }
    } else {
      el.textContent = name;
    }
  }
  function updateStats() {
    const el = document.getElementById("fai-stats");
    if (el) el.textContent = state.chatHistory.length;
  }
  function setStatus(msg) {
    const el = document.getElementById("fai-status");
    if (el) el.textContent = msg;
  }
  function sendSafe(msg) {
    if (!isExtensionAlive()) return Promise.resolve(null);
    try {
      return chrome.runtime.sendMessage(msg).catch(() => null);
    } catch (e) {
      return Promise.resolve(null);
    }
  }
  async function translateOutgoing(text, fanLang, chatId = null) {
    if (await new Promise((r2) => {
      try {
        chrome.storage.local.get("fansly_dbg_trfail", (d) => r2(!!(d && d.fansly_dbg_trfail)));
      } catch (e) {
        r2(false);
      }
    })) {
      try {
        chrome.storage.local.remove("fansly_dbg_trfail");
      } catch (e) {
      }
      console.warn("[FanslyAI] \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430: \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0433\u043E \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F (__faiTrFailNext)");
      return null;
    }
    const ctx = trContextOut(chatId);
    const r = await sendSafe({ type: "TRANSLATE", text, targetLang: fanLang, ...outGenders(), ...ctx ? { ctx } : {} });
    return r && r.success && typeof r.result === "string" && r.result.trim() ? r.result : null;
  }
  window.__faiTrFailNext = function() {
    chrome.storage.local.set({ fansly_dbg_trfail: Date.now() });
    return "\u0432\u0437\u0432\u0435\u0434\u0435\u043D\u043E: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0433\u043E \u043D\u0435 \u0443\u0434\u0430\u0441\u0442\u0441\u044F \u043E\u0434\u0438\u043D \u0440\u0430\u0437 (\u043A\u043D\u043E\u043F\u043A\u0430 \u2191 \u043F\u0430\u043D\u0435\u043B\u0438 \u0438\u043B\u0438 \u043E\u0442\u0432\u0435\u0442 \u0438\u0437 \u0422\u0413, \u0432 \u043B\u044E\u0431\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435)";
  };
  function setNativeValue(el, value) {
    el.value = value;
  }
  function insertDraftReview(el, text) {
    el.focus();
    try {
      document.execCommand("selectAll", false, null);
      const ok = document.execCommand("insertText", false, text);
      if (ok && (el.value === text || (el.textContent || "") === text)) return true;
    } catch (e) {
    }
    if ("value" in el && el.tagName === "TEXTAREA") {
      el.value = text;
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
      return true;
    }
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
    return true;
  }
  async function maybeInsertPendingDraft() {
    const pd = await new Promise((r) => chrome.storage.local.get("fansly_pending_draft", (d) => r(d.fansly_pending_draft)));
    if (!pd || !pd.text || Date.now() - (pd.at || 0) > 12e4) return;
    if (pd.msgId && !location.pathname.includes(pd.msgId)) return;
    chrome.storage.local.remove("fansly_pending_draft");
    await waitForElement(selStr("textarea"), 15e3).catch(() => {
    });
    const el = q("textarea");
    if (el) insertDraftReview(el, pd.text);
  }
  async function humanTypeAndSend(text, msPerWord = 700, opts = {}) {
    if (!isExtensionAlive()) return "aborted";
    if (PLATFORM === "onlyfans") return ONLYFANS.setAndSend(text);
    if (state.typingNow) {
      console.log("[FanslyAI] \u043F\u0435\u0447\u0430\u0442\u044C \u0443\u0436\u0435 \u0438\u0434\u0451\u0442, \u043F\u0440\u043E\u043F\u0443\u0441\u043A");
      return "busy";
    }
    state.typingNow = true;
    try {
      return await _humanType(text, msPerWord, opts);
    } finally {
      state.typingNow = false;
    }
  }
  const PANEL_SEND_FAIL = { "translate-failed": "panel.status.translateFailed", "busy": "panel.status.sendBusy", "no-field": "panel.status.sendNoField", "wrong-chat": "panel.status.sendWrongChat" };
  async function panelSend(text) {
    clearSendFailed();
    const expectId = state.currentContactId || null;
    const status = await humanTypeAndSend(text, carousel.settings?.nightMsPerWord || 700, { manual: true, expectId });
    const key = PANEL_SEND_FAIL[status];
    if (key || status === "aborted") {
      const input = document.getElementById("fai-custom-input");
      if (input && !input.value.trim()) input.value = text;
    }
    if (key) setStatus(t(key, state.uiLang));
    else if (status === "aborted" && !isExtensionAlive()) notifyContextDead();
    return status;
  }
  function clearSendFailed() {
    const el = document.getElementById("fai-status");
    if (el && Object.values(PANEL_SEND_FAIL).some((k) => el.textContent === t(k, state.uiLang))) setStatus("");
  }
  function countOwnMessages() {
    try {
      return [...qa("messageNode")].filter((n) => PLAT.isOwn(n)).length;
    } catch (e) {
      return -1;
    }
  }
  async function waitSendConfirmed(ownBefore, textarea, expectId) {
    let clearedAt = -1;
    for (let i = 0; i < 20; i++) {
      await sleep(250);
      if (expectId && state.currentContactId !== expectId) return false;
      if (ownBefore >= 0 && countOwnMessages() > ownBefore) return true;
      if (!textarea.value && clearedAt < 0) clearedAt = i;
      if (clearedAt >= 0 && i - clearedAt >= 8) return true;
    }
    return clearedAt >= 0;
  }
  async function _humanType(text, msPerWord = 700, opts = {}) {
    if (!isExtensionAlive()) return "aborted";
    const wrongChat = () => !!(opts.expectId && (state.currentContactId !== opts.expectId || extractContactIdFromUrl() !== opts.expectId));
    const aborted = () => (opts.manual ? !isExtensionAlive() : !carousel.running) || wrongChat();
    const bail = (why) => {
      try {
        const el = q("textarea");
        if (el && el.value && text.startsWith(el.value)) {
          setNativeValue(el, "");
          el.dispatchEvent(new InputEvent("input", { bubbles: true }));
        }
      } catch (e) {
      }
      return why;
    };
    const fanLang = state.contactData?.lang || "en";
    if (!opts.skipTranslate && fanLang && fanLang !== state.nativeLang) {
      const tr = await translateOutgoing(text, fanLang, opts.expectId || null);
      if (tr == null) return "translate-failed";
      text = tr;
    }
    if (wrongChat()) return "wrong-chat";
    const textarea = q("textarea");
    if (!textarea) {
      if (PLATFORM === "fansly" && state.currentContactId && chatFeedReadable()) chatLayoutMiss("chatinput", state.currentContactId, "textarea");
      return "no-field";
    }
    const words = text.split(/(\s+)/);
    const cap = 25e3;
    const perWord = Math.min(msPerWord, Math.floor(cap / Math.max(1, text.split(/\s+/).length)));
    textarea.focus();
    setNativeValue(textarea, "");
    textarea.dispatchEvent(new InputEvent("input", { bubbles: true }));
    if (document.hidden && (typeof _keepAliveCtx === "undefined" || _keepAliveCtx?.state !== "running")) {
      await new Promise((res) => setTimeout(res, Math.min(perWord * 3, 6e3)));
      if (aborted()) return bail(wrongChat() ? "wrong-chat" : "aborted");
      setNativeValue(textarea, text);
      textarea.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
    } else {
      let cur = "";
      for (let i = 0; i < words.length; i++) {
        if (aborted()) return bail(wrongChat() ? "wrong-chat" : "aborted");
        cur += words[i];
        setNativeValue(textarea, cur);
        textarea.dispatchEvent(new InputEvent("input", { bubbles: true, data: words[i] }));
        if (words[i].trim()) {
          await new Promise((res) => setTimeout(res, perWord + Math.random() * perWord * 0.4));
        }
      }
    }
    state.suppressUntil = Date.now() + 2500;
    await new Promise((res) => setTimeout(res, 300 + Math.random() * 250));
    if (wrongChat()) return bail("wrong-chat");
    const ownBefore = countOwnMessages();
    textarea.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      bubbles: true,
      cancelable: true
    }));
    await sleep(150);
    if (textarea.value.length > 0) {
      if (wrongChat()) return bail("wrong-chat");
      const btn = q("sendBtn");
      if (btn) btn.click();
    }
    return await waitSendConfirmed(ownBefore, textarea, opts.expectId) ? "sent" : "unconfirmed";
  }
  async function init() {
    if (!isExtensionAlive()) {
      notifyContextDead();
      return;
    }
    console.log("[FanslyAI] init()");
    try {
      sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
      });
      if (!state._settingsListener) {
        state._settingsListener = true;
        chrome.storage.onChanged.addListener((ch, area) => {
          if (area !== "local") return;
          if (ch.fansly_ai_settings) {
            sendSafe({ type: "GET_SETTINGS" }).then((r) => {
              if (r?.result) applyOwnerSettings(r.result);
            });
          }
          if (ch[SUB_PAUSE_KEY] || ch[SUB_RENEW_KEY]) refreshSetupHintNow();
          else if (ch[QUOTA_KEY] && quotaOut(ch[QUOTA_KEY].oldValue) !== quotaOut(ch[QUOTA_KEY].newValue)) refreshSetupHintNow();
          for (const k in ch) {
            if (!k.startsWith("fai_contact_")) continue;
            const nv = ch[k].newValue, ov = ch[k].oldValue;
            const cid0 = k.slice("fai_contact_".length);
            syncFanLang(cid0, nv);
            const openHere = !!state.contactData && !!state.currentContactId && state.currentContactId === cid0;
            if (openHere && nv && nv.dossier) {
              const a = JSON.stringify(nv.dossier.manualFacts || []);
              const b = JSON.stringify(ov && ov.dossier && ov.dossier.manualFacts || []);
              if (a !== b) {
                state.contactData.dossier = nv.dossier;
                renderDossier();
              }
            }
            const nowExcl = !!(nv && nv.excludeFromAuto);
            const wasExcl = !!(ov && ov.excludeFromAuto);
            if (nowExcl === wasExcl) continue;
            const cid = cid0;
            if (nowExcl) carousel.excludedIds.add(cid);
            else carousel.excludedIds.delete(cid);
            const openAffected = !!state.contactData && !!state.currentContactId && state.currentContactId === cid;
            if (openAffected) {
              state.contactData.excludeFromAuto = nowExcl;
              updateExcludeBtn();
            }
            renderExcludedChip();
          }
        });
      }
      if (!state._heartbeatTimer) {
        faiHeartbeat();
        state._heartbeatTimer = setInterval(faiHeartbeat, 5 * 60 * 1e3);
      }
      createPanel();
      chatListProbe();
      chrome.storage.local.get("fansly_force_provider", (d) => {
        state.forceProvider = d.fansly_force_provider || "auto";
        const _ps = document.getElementById("fai-provider-select");
        if (_ps) _ps.value = state.forceProvider;
      });
      sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
        if (state.masterEnabled !== false && !extractContactIdFromUrl()) {
          waitForElement(selStr("contactLink"), 8e3).then((first) => {
            if (first) PLAT.openRow(first);
          }).catch(() => {
          });
        }
      });
      await waitForElement(selStr("textarea"), 3e4);
      chatInitReady();
      await new Promise((r) => setTimeout(r, 800));
      detectContact();
      watchContactChanges();
      watchContactList();
      if (extractContactIdFromUrl()) activateForContact();
      _initialized = true;
      console.log("[FanslyAI] \u2713 Ready v0.3");
      startLeaderTick();
      askPultOpened();
      sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
      });
    } catch (err) {
      if (!isExtensionAlive()) {
        notifyContextDead();
        return;
      }
      if ((err.message || "").startsWith("Timeout")) {
        console.log("[FanslyAI] init: \u0436\u0434\u0443 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u0447\u0430\u0442\u0430\u2026");
        chatInitNoInput();
      } else console.error("[FanslyAI] Init error:", err.message);
      if (PLAT.isMessagesPage()) setTimeout(init, 5e3);
    }
  }
  let _lastUrl = location.href;
  let _initPending = false;
  const VAULT_TARGET_TTL = 12e4;
  function readVaultTargeted() {
    return new Promise((r) => chrome.storage.local.get("fansly_vault_targeted", (d) => {
      const tg = d && d.fansly_vault_targeted;
      if (!tg) return r(null);
      if (Date.now() - (tg.at || 0) >= VAULT_TARGET_TTL) {
        chrome.storage.local.remove("fansly_vault_targeted");
        return r(null);
      }
      r(tg);
    }));
  }
  const SCHED_REQ_TTL = 10 * 60 * 1e3;
  function readScheduledScan() {
    return new Promise((r) => chrome.storage.local.get("fansly_scheduled_scan", (d) => {
      const sched = d && d.fansly_scheduled_scan;
      if (!sched) return r(null);
      if (!(Date.now() - (sched.at || 0) < SCHED_REQ_TTL)) {
        chrome.storage.local.remove("fansly_scheduled_scan");
        return r(null);
      }
      r(sched);
    }));
  }
  const pageTest = (key) => ({ test: (path) => ScanPages.at(key, path) });
  const SCAN_AUTH_PAGES = { vault: pageTest("vault"), frames: pageTest("vault"), subs: pageTest("subs"), earnings: pageTest("earnings"), broadcast: pageTest("broadcast"), notifhist: pageTest("notifications") };
  function scanPageNote(path, sched, targeted) {
    const page = targeted ? "vault" : sched && sched.type;
    const re = page && SCAN_AUTH_PAGES[page];
    if (!re) return;
    if (re.test(path)) {
      state._scanPage = { page, re };
      return;
    }
    sendSafe({ type: "SCAN_TAB_QUERY" }).then((r) => {
      if (r && r.scanTab) scanPageLost(page);
    });
  }
  function scanRouteCheck() {
    const sp = state._scanPage;
    if (sp && !sp.re.test(location.pathname)) scanPageLost(sp.page);
  }
  function scanPageLost(page) {
    if (state._scanPageLost) return;
    state._scanPageLost = true;
    state._scanPage = null;
    hideScanVeil();
    scanZoom(1);
    sendSafe({ type: "SCAN_AUTH_LOST", page });
    console.warn("[FanslyAI] \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u0441\u043A\u0430\u043D\u0430 \xAB" + page + "\xBB \u0443\u0448\u043B\u0430 \u0441 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0430 (\u0441\u0435\u0439\u0447\u0430\u0441 " + location.pathname + ") \u2014 \u043F\u043E\u0445\u043E\u0436\u0435, Fansly \u043F\u0440\u043E\u0441\u0438\u0442 \u0432\u043E\u0439\u0442\u0438 \u0437\u0430\u043D\u043E\u0432\u043E. \u0421\u043A\u0430\u043D \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D, \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0430 \u0434\u043B\u044F \u0432\u0445\u043E\u0434\u0430.");
  }
  function scanDone(msg) {
    const lost = state._scanPageLost;
    state._scanPage = null;
    if (lost || !msg) return Promise.resolve(null);
    return sendSafe(msg);
  }
  const stepDone = (scanType) => {
    const stopped = (res) => !!res && (res.stopped === true || res.note === "stopped");
    return [(res) => scanDone({ type: stopped(res) ? "SCHEDULED_SCAN_STOPPED" : "SCHEDULED_SCAN_DONE", scanType }), () => scanDone({ type: "SCHEDULED_SCAN_FAILED", scanType })];
  };
  function authSeenLater(path) {
    const re = Object.values(SCAN_AUTH_PAGES).find((x) => x.test(path));
    if (!re) return;
    state._scanPageLost = false;
    setTimeout(() => {
      try {
        if (isExtensionAlive() && re.test(location.pathname)) chrome.storage.local.remove("fansly_auth_lost");
      } catch (e) {
      }
    }, 6e3);
  }
  async function earlyScanVeil(path) {
    if (PLATFORM !== "fansly") return;
    authSeenLater(path);
    if (document.getElementById("fai-scan-veil")) return;
    const targeted = await readVaultTargeted();
    const sched = await readScheduledScan();
    chrome.storage.local.get(["fansly_ai_settings", "fansly_creator_handle"], (d) => {
      scanPageNote(path, sched, targeted);
      const foreground = sched && sched.full || targeted;
      if (!foreground) return;
      const onVault = ScanPages.at("vault", path);
      if (targeted && !onVault) return;
      const PAGE_OF = { vault: "vault", subs: "subs", earnings: "earnings", posts: "posts", notifhist: "notifications" };
      if (sched && sched.type && !(PAGE_OF[sched.type] && ScanPages.at(PAGE_OF[sched.type], path))) return;
      if (sched && sched.type === "posts" && !ScanPages.isOwn("posts", path, d.fansly_creator_handle)) return;
      const lang = d.fansly_ai_settings && d.fansly_ai_settings.interfaceLanguage || state.uiLang || "ru";
      const quick = onVault && !!targeted;
      showScanVeil(
        t(quick ? "panel.vault.veil.quickTitle" : onVault ? "panel.vault.veil.title" : "panel.scan.veil.title", lang),
        t(quick ? "panel.vault.veil.quickWarn" : onVault ? "panel.vault.veil.warn" : "panel.scan.veil.warn", lang)
      );
      const st = document.getElementById("fai-scan-veil-status");
      const opening = t("panel.scan.veil.opening", lang);
      if (st) st.textContent = opening;
      setTimeout(() => {
        const s2 = document.getElementById("fai-scan-veil-status");
        if (s2 && s2.textContent === opening) {
          hideScanVeil();
          scanZoom(1);
        }
      }, 6e4);
      if (onVault) scanZoom(SCAN_ZOOM);
    });
  }
  const _pageDuty = /* @__PURE__ */ new Set();
  function isNotifPage(url) {
    if (PLATFORM !== "fansly") return /\/notifications/.test(url);
    try {
      return ScanPages.at("notifications", new URL(url, location.href).pathname);
    } catch (e) {
      return false;
    }
  }
  function routeScanPage(path) {
    if (isNotifPage(location.href)) {
      if (PLATFORM === "fansly") {
        _pageDuty.add("notifhist");
      }
      initNotifications();
      if (PLATFORM === "fansly") initNotifDeep();
      return;
    }
    if (PLATFORM !== "fansly") return;
    const key = ScanPages.keyAt(path);
    if (key) _pageDuty.add(key);
    if (key === "vault") initVault();
    else if (key === "subs") initSubs();
    else if (key === "earnings") initEarnings();
    else if (key === "broadcast") initBroadcast();
    else if (key === "posts") initPosts();
    else if (/^\/settings\/privacy/.test(path)) settingsJobRun().catch(() => {
    });
    else badgeWatchOnPage();
  }
  function syncPanelsToRoute() {
    const PAGE_DUTIES = [
      { key: "vault", at: (p) => ScanPages.at("vault", p), run: () => initVault() },
      { key: "subs", at: (p) => ScanPages.at("subs", p), run: () => initSubs() },
      { key: "earnings", at: (p) => ScanPages.at("earnings", p), run: () => initEarnings() },
      { key: "broadcast", at: (p) => ScanPages.at("broadcast", p), run: () => initBroadcast() },
      { key: "posts", at: (p) => ScanPages.at("posts", p), run: () => initPosts() },
      // Уведомления: лёгкий скан и приём заявки на сбор истории — вместе, как при загрузке (routeScanPage). До 06.11 лёгкий скан звала
      // каждая смена адреса (onUrlChange) — заново на любой смене адреса внутри страницы, а в первые 1,5 с после «Сообщений» (_initPending) — ни разу.
      { key: "notifhist", at: (p) => ScanPages.at("notifications", p), run: () => {
        initNotifications();
        initNotifDeep();
      } }
    ];
    const path = location.pathname;
    for (const d of PAGE_DUTIES) {
      if (!d.at(path)) {
        _pageDuty.delete(d.key);
        continue;
      }
      if (!_pageDuty.has(d.key) && PLATFORM === "fansly") {
        _pageDuty.add(d.key);
        try {
          earlyScanVeil(path);
          d.run();
        } catch (e) {
        }
      }
    }
    const work = document.getElementById("fansly-ai-panel");
    if (work) {
      if (!PLAT.isMessagesPage()) {
        work.dataset.faiRouteHidden = "1";
        work.style.display = "none";
      } else if (work.dataset.faiRouteHidden) {
        delete work.dataset.faiRouteHidden;
        if (state._panelShown !== false && !state._pultActive) work.style.display = "";
      }
    }
  }
  function onUrlChange(newUrl) {
    if (!isExtensionAlive()) {
      notifyContextDead();
      return;
    }
    scanRouteCheck();
    syncPanelsToRoute();
    if (_initPending) return;
    if (_notifWatchStarted && /\/messages/.test(newUrl)) renderOutreachFromStorage();
    else removeOutreachPanel();
    checkPendingInvite();
    const isMessaging = PLAT.isMessagesPage(newUrl);
    if (!isMessaging) {
      _initialized = false;
      if (PLATFORM !== "fansly" && isNotifPage(newUrl)) initNotifications();
      return;
    }
    if (_initialized) return;
    _initPending = true;
    _initialized = false;
    if (state.observer) {
      state.observer.disconnect();
      state.observer = null;
    }
    state.active = false;
    setTimeout(() => {
      _initPending = false;
      init();
    }, 1500);
  }
  setInterval(() => {
    const cur = location.href;
    if (cur !== _lastUrl) {
      _lastUrl = cur;
      onUrlChange(cur);
    }
  }, 300);
  async function initNotifications() {
    const s = await getSettingsAsync();
    console.log("[FanslyAI] \u{1F514} notifications: \u0440\u0430\u0437\u043E\u0432\u044B\u0439 \u0441\u043A\u0430\u043D \u0432\u043A\u043B\u0430\u0434\u043A\u0438");
    if (!s.notificationsEnabled) return;
    const off = await scanIsOff("notif");
    if (!off) await waitForElement(selStr("notifRow"), 2e4).catch(() => {
    });
    if (!off && await notifFilterHeal()) {
      await sleep(1500);
      await waitForElement(selStr("notifRow"), 15e3).catch(() => {
      });
    }
    const scanOnce = await new Promise((r) => chrome.storage.local.get("fansly_notif_scan", (d) => r(d.fansly_notif_scan)));
    const had = () => new Promise((r) => chrome.storage.local.get("fansly_ledger", (d) => {
      const v = d && d.fansly_ledger;
      r(!!v && Object.keys(v).length > 0);
    }));
    if (off) scanOffSkip("notif");
    else if (q("notifRow")) {
      if (await Scans.notifNickSeen()) layoutSeen("notif");
      else if (scanOnce || await had()) layoutMissNote({ area: "notif", key: "notifUser" });
      await scanNotifications();
      await sleep(2500);
      await scanNotifications();
    } else if (scanOnce || await had()) layoutMissNote({ area: "notif", key: "notifRow" });
    if (scanOnce) {
      chrome.storage.local.remove("fansly_notif_scan");
      setTimeout(() => sendSafe({ type: "CLOSE_TAB" }), 800);
    }
  }
  function removeOutreachPanel() {
    document.getElementById("fai-outreach-panel")?.remove();
  }
  async function scanNotifications() {
    const s = await getSettingsAsync();
    if (!s.notificationsEnabled) return;
    const threshold = parseInt(s.notifyLikeThreshold) || 3;
    const paidOnly = s.notifyPaidOnly === true;
    const acc = {};
    const ledgerEv = {};
    const likeEv = [];
    const CUT = Date.now() - 48 * 3600 * 1e3;
    qa("notifRow").forEach((el) => {
      const tag = el.tagName.toLowerCase();
      const txt = el.innerText || "";
      const href = q("notifUser", el)?.getAttribute("href") || "";
      const handle = href.replace(/^\//, "").trim();
      const ev = notifParse(el);
      if (ev) (ledgerEv[ev.handle] = ledgerEv[ev.handle] || []).push(ev);
      const isLike = /like/.test(tag) || qm("notifLikeRow", el);
      const isFollow = /follow/.test(tag) || qm("notifFollowRow", el);
      const isPaidSub = /Subscription\s+Purchase/i.test(txt) && !!q("notifAmount", el);
      const isPurchase = qm("notifMediaOrder", el);
      if (!isLike && !isFollow && !isPaidSub && !isPurchase) return;
      if (!handle) return;
      const name = q("displayName", el)?.innerText?.trim() || handle;
      if (!acc[handle]) acc[handle] = { name, likes: 0, follower: false, paidSub: false, purchases: [], lastAt: 0, lastLikeAt: 0 };
      const nAt = parseMsgTime(subText(q("notifTime", el))) || 0;
      if (nAt > acc[handle].lastAt) acc[handle].lastAt = nAt;
      if (isLike) {
        acc[handle].likes++;
        if (nAt > acc[handle].lastLikeAt) acc[handle].lastLikeAt = nAt;
      }
      if (isFollow) acc[handle].follower = true;
      if (isLike) likeEv.push({ kind: "like", handle, name, mediaId: q("notifMedia", el)?.getAttribute("data-media-id") || null, at: nAt || null });
      if (isFollow) likeEv.push({ kind: "follow", handle, name, at: nAt || null });
      if (isPaidSub) acc[handle].paidSub = true;
      if (isPurchase) {
        const amount = parseMoney(q("notifAmount", el)?.innerText) || 0;
        if (amount > 0) acc[handle].purchases.push({ amount });
      }
    });
    chrome.storage.local.get(null, (all) => {
      const store = all.fansly_outreach || {};
      const done = all.fansly_outreach_done || {};
      const byName = contactsByName(all);
      const ledger = all.fansly_ledger || {};
      let ledgerChanged = false;
      const keysByHandle = {};
      for (const [h, arr] of Object.entries(ledger)) keysByHandle[h] = new Set((arr || []).map(Scans.ledgerKey));
      const DONE_TTL = 3 * 864e5;
      for (const [h, evs] of Object.entries(ledgerEv)) {
        if (!ledger[h]) ledger[h] = [];
        if (!keysByHandle[h]) keysByHandle[h] = /* @__PURE__ */ new Set();
        for (const e of evs) {
          if (e.type === "media" && !((e.amount || 0) > 0)) continue;
          const k = Scans.ledgerKey(e);
          if (keysByHandle[h].has(k)) {
            if (e.type === "media" && (e.amount || 0) > 0) {
              const ex = ledger[h].find((x) => x.type === "media" && x.mediaId === e.mediaId);
              if (ex && !((ex.amount || 0) > 0)) {
                ex.amount = e.amount;
                if (e.at) ex.at = e.at;
                if (e.name) ex.name = e.name;
                ledgerChanged = true;
              }
            }
            continue;
          }
          keysByHandle[h].add(k);
          ledger[h].push({ type: e.type, amount: e.amount, mediaId: e.mediaId, tier: e.tier, at: e.at, name: e.name });
          ledgerChanged = true;
          if (e.type === "media" && (e.amount || 0) > 0 && (e.at || 0) >= CUT) {
            sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("panel.tg.purchase", state.uiLang, { name: e.name, amount: e.amount }) });
          }
        }
      }
      for (const [h, v] of Object.entries(acc)) {
        if (done[h] && Date.now() - done[h] < DONE_TTL) continue;
        const countFollow = v.follower && !paidOnly;
        const hasPurchase = v.purchases && v.purchases.length;
        const flagged = v.paidSub || v.likes >= threshold || countFollow || hasPurchase;
        if (!flagged) continue;
        const parts = [];
        if (hasPurchase) {
          const total = v.purchases.reduce((sum, p) => sum + (p.amount || 0), 0);
          parts.push(t("common.outreach.purchased", state.uiLang, { amount: total }));
        }
        if (v.paidSub) parts.push(t("common.outreach.paidSub", state.uiLang));
        if (v.likes >= threshold) parts.push(t("common.outreach.likes", state.uiLang, { n: v.likes }));
        if (countFollow) parts.push(t("common.outreach.followedFree", state.uiLang));
        const reason = parts.join(" + ");
        if (!store[h]) {
          store[h] = { handle: h, name: v.name, likes: v.likes, follower: v.follower, paidSub: v.paidSub, reason, flaggedAt: Date.now(), lastAt: v.lastAt || 0, lastLikeAt: v.lastLikeAt || 0, notifiedTg: false };
        } else {
          store[h].likes = Math.max(store[h].likes || 0, v.likes);
          store[h].follower = store[h].follower || v.follower;
          store[h].paidSub = store[h].paidSub || v.paidSub;
          store[h].name = v.name;
          store[h].reason = reason;
          store[h].lastAt = Math.max(store[h].lastAt || 0, v.lastAt || 0);
          store[h].lastLikeAt = Math.max(store[h].lastLikeAt || 0, v.lastLikeAt || 0);
        }
      }
      const silenceMs = Math.max(1, parseInt(s.inviteSilenceDays, 10) || 7) * 864e5;
      const signalsOn = s.outreachTgSignals === true;
      for (const v of Object.values(store)) {
        if (signalsOn && !v.notifiedTg && (v.lastAt || 0) >= CUT) {
          const cd = byName[v.name];
          const lm = cd && cd.dossier && cd.dossier.lastMessageAt;
          if (lm && Date.now() - lm < silenceMs) continue;
          sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "outreach", fan: v.name, handle: v.handle, text: t("panel.tg.outreach", state.uiLang, { name: v.name, reason: v.reason }) });
          v.notifiedTg = true;
        }
      }
      const toSet = { fansly_outreach: store };
      if (ledgerChanged) toSet.fansly_ledger = ledger;
      const likes = all.fansly_likes || {};
      if (CRM.likesMerge(likes, likeEv)) toSet.fansly_likes = likes;
      chrome.storage.local.set(toSet);
    });
  }
  let _notifWatchStarted = false;
  function startNotifWatch() {
    if (_notifWatchStarted) return;
    _notifWatchStarted = true;
    renderOutreachFromStorage();
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "local" && ch.fansly_outreach) {
        const oN = Object.keys(ch.fansly_outreach.oldValue || {}).length, nN = Object.keys(ch.fansly_outreach.newValue || {}).length;
        if (nN > oN) state._outreachClosed = false;
        renderOutreachFromStorage();
      }
    });
    startBadgeWatch();
  }
  let _badgeWatchStarted = false;
  function startBadgeWatch() {
    if (_badgeWatchStarted) return;
    _badgeWatchStarted = true;
    const _badgeSeen = /* @__PURE__ */ new WeakMap();
    setInterval(() => {
      if (!state.notificationsEnabled || !state.masterEnabled) return;
      let grew = false, vals = [];
      qa("navNotif").forEach((el) => {
        const n = parseInt((el.textContent || "").trim(), 10) || 0;
        const prev = _badgeSeen.get(el) || 0;
        if (n > prev) grew = true;
        _badgeSeen.set(el, n);
        vals.push(n);
      });
      if (grew) {
        console.log("[FanslyAI] \u{1F514} \u0431\u0435\u0439\u0434\u0436 \u043D\u043E\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0439 \u0432\u044B\u0440\u043E\u0441", vals, "\u2014 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u044E \u0441\u043A\u0430\u043D");
        sendSafe({ type: "SCAN_NOTIFICATIONS" });
      }
    }, 2e4);
  }
  function badgeWatchOnPage() {
    const apply = (s) => {
      if (!s) return;
      state.masterEnabled = s.masterEnabled !== false;
      state.notificationsEnabled = s.notificationsEnabled === true;
      if (state.masterEnabled && state.notificationsEnabled) startBadgeWatch();
    };
    getSettingsAsync().then(apply);
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "local" && ch.fansly_ai_settings) getSettingsAsync().then(apply);
    });
  }
  function outreachKind(cd) {
    if (!cd) return "cold";
    if (cd.brief && (cd.brief.wants || cd.brief.details?.length)) return "brief";
    const dz = cd.dossier;
    if (dz && (dz.lastMessageAt || dz.facts?.length || dz.closeness && dz.closeness !== "new")) return "active";
    return "cold";
  }
  function contactsByName(all) {
    const m = {};
    for (const k in all) if (k.startsWith("fai_contact_") && all[k]?.name) m[all[k].name] = all[k];
    return m;
  }
  function renderOutreachFromStorage() {
    if (!isExtensionAlive()) {
      notifyContextDead();
      return;
    }
    chrome.storage.local.get(null, (all) => renderOutreachPanel(all.fansly_outreach || {}, contactsByName(all)));
  }
  function injectOutreachPanel() {
    if (document.getElementById("fai-outreach-panel")) return;
    const p = document.createElement("div");
    p.id = "fai-outreach-panel";
    p.className = "fai-outreach-panel";
    p.innerHTML = `<div class="fai-outreach-head" id="fai-outreach-head"><span class="fai-outreach-title" id="fai-outreach-title">${t("panel.outreach.header", state.uiLang)}</span><span class="fai-outreach-ctrls"><button class="fai-outreach-ctrl" id="fai-outreach-collapse" title="${t("panel.outreach.collapse.title", state.uiLang)}">\u25BE</button><button class="fai-outreach-ctrl" id="fai-outreach-close" title="${t("panel.outreach.close.title", state.uiLang)}">\u2715</button></span></div><div class="fai-outreach-list" id="fai-outreach-list"></div>`;
    document.body.appendChild(p);
    const head = document.getElementById("fai-outreach-head");
    const collapseBtn = document.getElementById("fai-outreach-collapse");
    const applyCollapsed = (collapsed, persist) => {
      p.classList.toggle("collapsed", collapsed);
      collapseBtn.textContent = collapsed ? "\u25B8" : "\u25BE";
      if (persist) chrome.storage.local.set({ fai_outreach_collapsed: collapsed });
    };
    chrome.storage.local.get(["fai_outreach_pos", "fai_outreach_collapsed"], (d) => {
      const pos = d.fai_outreach_pos;
      if (pos) {
        p.style.left = pos.left;
        p.style.top = pos.top;
        p.style.right = "auto";
        p.style.bottom = "auto";
      }
      applyCollapsed(!!d.fai_outreach_collapsed, false);
    });
    collapseBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      applyCollapsed(!p.classList.contains("collapsed"), true);
    });
    document.getElementById("fai-outreach-close").addEventListener("click", (e) => {
      e.stopPropagation();
      state._outreachClosed = true;
      removeOutreachPanel();
      persistSetting("panelHidden", true);
    });
    head.addEventListener("mousedown", (e) => {
      if (e.target.closest(".fai-outreach-ctrl")) return;
      const r = p.getBoundingClientRect();
      p.style.left = r.left + "px";
      p.style.top = r.top + "px";
      p.style.right = "auto";
      p.style.bottom = "auto";
      const offX = e.clientX - r.left, offY = e.clientY - r.top;
      let moved = false;
      const onMove = (ev) => {
        moved = true;
        const x = Math.max(0, Math.min(ev.clientX - offX, window.innerWidth - p.offsetWidth));
        const y = Math.max(0, Math.min(ev.clientY - offY, window.innerHeight - p.offsetHeight));
        p.style.left = x + "px";
        p.style.top = y + "px";
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
        if (moved) chrome.storage.local.set({ fai_outreach_pos: { left: p.style.left, top: p.style.top } });
        p._draggedJustNow = moved;
        setTimeout(() => {
          p._draggedJustNow = false;
        }, 0);
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
      e.preventDefault();
    });
    head.addEventListener("click", (e) => {
      if (e.target.closest(".fai-outreach-ctrl")) return;
      if (!p._draggedJustNow) applyCollapsed(!p.classList.contains("collapsed"), true);
    });
  }
  function renderOutreachPanel(store, byName = {}) {
    removeOutreachPanel();
    return;
    if (state._panelShown === false) {
      removeOutreachPanel();
      return;
    }
    if (state._outreachClosed) {
      removeOutreachPanel();
      return;
    }
    const fans = Object.values(store || {}).sort((a, b) => (b.flaggedAt || 0) - (a.flaggedAt || 0));
    if (!fans.length) {
      removeOutreachPanel();
      return;
    }
    injectOutreachPanel();
    const title = document.getElementById("fai-outreach-title");
    if (title) title.textContent = t("panel.outreach.headerCount", state.uiLang, { n: fans.length });
    const list = document.getElementById("fai-outreach-list");
    if (!list) return;
    list.innerHTML = "";
    fans.forEach((v) => {
      const kind = outreachKind(byName[v.name]);
      const row = document.createElement("div");
      row.className = "fai-outreach-row";
      const _url = PLAT.profileUrl(v.handle);
      const _nameHtml = _url ? `<a class="fai-outreach-name" href="${_url}" target="_blank" rel="noopener">${escapeHtmlC(v.name)}</a>` : `<span class="fai-outreach-name">${escapeHtmlC(v.name)}</span>`;
      const kindLabel = kind === "brief" ? t("common.outreach.kind.brief", state.uiLang) : kind === "active" ? t("common.outreach.kind.active", state.uiLang) : "";
      const cleanReason = (v.reason || "").split(" + ").filter((seg) => !/\$0(?![\d.])/.test(seg)).join(" + ");
      if (!cleanReason && !kindLabel) return;
      const reasonText = kindLabel ? cleanReason ? `${kindLabel} \xB7 ${cleanReason}` : kindLabel : cleanReason;
      row.innerHTML = `${_nameHtml}<span class="fai-outreach-reason">${escapeHtmlC(reasonText)}</span>`;
      const btn = document.createElement("button");
      btn.className = "fai-outreach-invite";
      if (kind === "cold") {
        btn.textContent = t("panel.outreach.invite", state.uiLang);
        btn.addEventListener("click", () => startInvite(v.handle, v.name));
      } else {
        btn.textContent = t("panel.outreach.open", state.uiLang);
        btn.addEventListener("click", () => {
          if (_url) window.open(_url, "_blank", "noopener");
          removeOutreach(v.handle);
        });
      }
      const del = document.createElement("button");
      del.className = "fai-outreach-del";
      del.textContent = "\u2715";
      del.title = t("panel.outreach.remove.title", state.uiLang);
      del.addEventListener("click", () => removeOutreach(v.handle));
      row.appendChild(btn);
      row.appendChild(del);
      list.appendChild(row);
    });
  }
  function removeOutreach(handle) {
    chrome.storage.local.get(["fansly_outreach", "fansly_outreach_done"], (d) => {
      const store = d.fansly_outreach || {};
      const done = d.fansly_outreach_done || {};
      delete store[handle];
      done[handle] = Date.now();
      chrome.storage.local.set({ fansly_outreach: store, fansly_outreach_done: done }, () => renderOutreachPanel(store));
    });
  }
  function startInvite(handle, name) {
    if (!handle) return;
    removeOutreach(handle);
    sendSafe({ type: "START_INVITE", handle, name });
  }
  function clearPendingInvite() {
    chrome.storage.local.remove("fansly_pending_invite");
  }
  function finishInviteTab() {
    sendSafe({ type: "TG_UNCLAIM_INVITE" });
    setTimeout(() => sendSafe({ type: "CLOSE_TAB" }), 1500);
  }
  let _isInviteTab = false;
  let _inviteRunning = false;
  async function checkPendingInvite() {
    if (_inviteRunning) return;
    const inv = await new Promise((r) => chrome.storage.local.get("fansly_pending_invite", (d) => r(d.fansly_pending_invite)));
    if (!inv || !inv.handle) return;
    if (inv.at && Date.now() - inv.at > 3e5) {
      clearPendingInvite();
      return;
    }
    const path = location.pathname;
    if (path === "/" + inv.handle) {
      _isInviteTab = true;
      _inviteRunning = true;
      const btn = await waitForElement('.dm-profile.dm-allowed .dm-button[data-menu-item="message"]', 12e3).catch(() => null);
      _inviteRunning = false;
      if (!btn) {
        const notAllowed = document.querySelector(".dm-profile") && !document.querySelector(".dm-profile.dm-allowed");
        if (notAllowed) console.log("[FanslyAI] \u2709\uFE0F \u0438\u043D\u0432\u0430\u0439\u0442: DM \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D \u0443 \u0444\u0430\u043D\u0430");
        else console.warn("[FanslyAI] \u2709\uFE0F \u0438\u043D\u0432\u0430\u0439\u0442: \u043A\u043D\u043E\u043F\u043A\u0430 DM \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
        clearPendingInvite();
        sendSafe({ type: "CLOSE_TAB" });
        return;
      }
      btn.click();
      return;
    }
    if (/\/messages\/\d+/.test(path)) {
      if (!_isInviteTab) return;
      _inviteRunning = true;
      let ready = false;
      for (let i = 0; i < 40; i++) {
        if (state.currentContact && q("textarea")) {
          ready = true;
          break;
        }
        await sleep(500);
      }
      if (ready) {
        activateForContact();
        for (let i = 0; i < 25 && !state.contactData; i++) await sleep(300);
      }
      clearPendingInvite();
      _inviteRunning = false;
      if (ready && state.contactData) await triggerInvite();
      else {
        console.warn("[FanslyAI] \u2709\uFE0F \u0438\u043D\u0432\u0430\u0439\u0442: \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0447\u0430\u0442. currentContact=", state.currentContact, "| contactData=", !!state.contactData);
        sendSafe({ type: "CLOSE_TAB" });
      }
    }
  }
  async function triggerInvite() {
    const s = await getSettingsAsync();
    const hint = (s.inviteInstruction || "").trim() || t("options.default.inviteInstruction", state.uiLang);
    setStatus(t("panel.status.generatingInvite", state.uiLang));
    const res = await processDialogue({ text: "", hint, trigger: "manual", regenerate: true, proactive: true });
    if (!res.success || !res.suggestions?.length) {
      setStatus(t("panel.status.inviteFailed", state.uiLang));
      return;
    }
    const variants = res.suggestions.slice(0, 3);
    showSuggestions(variants, res.provider);
    const fan = state.currentContact;
    if (fan && state.tgPause) {
      if (!state.tgVariants) state.tgVariants = {};
      state.tgVariants[tgVarKey(state.currentContactId, fan)] = variants;
      sendSafe({ type: "TG_CLAIM_INVITE", fan });
      const tr = [];
      for (const v of variants) tr.push(await translateForOwner(v, outGenders()) || v);
      const body = t("panel.tg.inviteHeader", state.uiLang, { fan }) + "\n" + tr.map((tx, i) => `${i + 1}. ${tx}`).join("\n\n");
      sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "variants", fan, text: body, variantCount: variants.length });
    }
    setStatus(t("panel.status.inviteReady", state.uiLang));
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== "TG_ROUTED") return;
    const tasks = [];
    (msg.relays || []).forEach((r) => tasks.push({ type: "relay", fan: r.fan, text: r.text, id: r.id, pid: r.pid }));
    (msg.genVars || []).forEach((g) => tasks.push(tgGenTask(g)));
    (msg.sendVars || []).forEach((sv) => tasks.push(tgSendTask(sv)));
    if (!tasks.length) return;
    carousel.relayQueue.push(...tasks);
    drainRelays();
  });
  window.addEventListener("beforeunload", () => {
    if (_isInviteTab) sendSafe({ type: "TG_UNCLAIM_INVITE" });
  });
  const SCAN_ZOOM = 0.25;
  try {
    VaultSync.init({
      send: sendSafe,
      sel: { q, qa, qm, selStr },
      waitForElement,
      synthClick,
      waitVisible,
      keepAlive: { start: startKeepAlive, stop: stopKeepAlive },
      report: reportBug,
      crumb: bugCrumb,
      getSettings: getSettingsAsync,
      stack: bugStackFrames,
      layout: { seen: layoutSeen }
    });
  } catch (e) {
    console.warn("[FanslyAI] vault-sync.js \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \u2014 \u0441\u043A\u0430\u043D \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u043D\u0435 \u0431\u0443\u0434\u0435\u0442:", e && e.message);
  }
  const scanLayout = { seen: layoutSeen, report: (key, got) => reportBug("sel_miss", { key, got }) };
  try {
    Scans.init({ sel: { q, qa, qm, selStr }, waitForElement, synthClick, waitVisible, keepAlive: { start: startKeepAlive, stop: stopKeepAlive }, parsers: ScanParsers, layout: scanLayout });
  } catch (e) {
    console.warn("[FanslyAI] scans.js \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \u2014 \u0441\u043A\u0430\u043D\u044B \u0441\u0442\u0440\u0430\u043D\u0438\u0446 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u043D\u0435 \u0431\u0443\u0434\u0443\u0442:", e && e.message);
  }
  let _scanVeilK = 1;
  let _scanZoomSeq = 0;
  function applyScanVeilScale() {
    document.getElementById("fai-scan-veil")?.style.setProperty("--fai-k", String(_scanVeilK));
  }
  function scanZoom(f) {
    if (state._scanPageLost && f > 0 && f < 1) return Promise.resolve(null);
    const k = f > 0 && f < 1 ? 1 / f : 1, seq = ++_scanZoomSeq;
    const apply = () => {
      if (seq !== _scanZoomSeq) return;
      _scanVeilK = k;
      if (typeof FaiLock !== "undefined") FaiLock.setScale(k);
      if (typeof FaiConsent !== "undefined" && FaiConsent.setScale) FaiConsent.setScale(k);
      applyScanVeilScale();
    };
    const sent = sendSafe({ type: "VAULT_ZOOM", factor: f }).catch(() => null);
    if (k === 1) {
      apply();
      return sent;
    }
    return sent.then((r) => {
      if (r && r.success) apply();
      return r;
    });
  }
  function showScanVeil(title, warn, opts) {
    if (state._scanPageLost) return;
    const px = (n) => `calc(${n}px * var(--fai-k, 1))`;
    const mk = (tag, css, txt) => {
      const e = document.createElement(tag);
      e.style.cssText = css;
      if (txt != null) e.textContent = txt;
      return e;
    };
    const addStop = (box2, onStop) => {
      if (document.getElementById("fai-scan-veil-stop")) return;
      const stopBtn = mk("button", `margin-top:${px(14)};background:#3a2030;color:#f3a3cf;border:${px(1)} solid #e91e8c;border-radius:${px(10)};padding:${px(8)} ${px(14)};font-size:${px(13)};cursor:pointer;font-family:inherit`, "\u23F9 " + t("panel.vault.veil.stop", state.uiLang));
      stopBtn.id = "fai-scan-veil-stop";
      stopBtn.addEventListener("click", () => {
        stopBtn.disabled = true;
        stopBtn.textContent = t("panel.vault.veil.stopping", state.uiLang);
        try {
          onStop();
        } catch (e) {
        }
      });
      const lockBtn = box2.querySelector("button");
      if (lockBtn) box2.insertBefore(stopBtn, lockBtn);
      else box2.append(stopBtn);
    };
    const shown = document.getElementById("fai-scan-veil");
    if (shown) {
      if (opts && typeof opts.onStop === "function") addStop(shown, opts.onStop);
      return;
    }
    const dim = document.createElement("div");
    dim.id = "fai-scan-veil-dim";
    dim.style.cssText = "position:fixed;inset:0;background:rgba(8,8,16,.9);backdrop-filter:blur(3px);z-index:2147483200";
    const box = document.createElement("div");
    box.id = "fai-scan-veil";
    box.style.cssText = `position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:2147483600;width:min(${px(440)},92vw);background:#12121f;border:${px(2)} solid #e91e8c;border-radius:${px(16)};padding:${px(22)} ${px(24)};box-shadow:0 ${px(12)} ${px(48)} rgba(0,0,0,.6);text-align:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#f0f0f0`;
    box.style.setProperty("--fai-k", String(_scanVeilK));
    const status = mk("div", `font-size:${px(12)};color:#8a8aa5;min-height:${px(16)};margin-top:${px(14)}`);
    status.id = "fai-scan-veil-status";
    box.append(
      mk("div", `font-size:${px(34)};margin-bottom:${px(6)}`, "\u{1F5C2}\uFE0F"),
      mk("div", `font-size:${px(18)};font-weight:800;color:#f3a3cf;margin-bottom:${px(10)}`, title),
      mk("div", `font-size:${px(14)};line-height:1.5;color:#e6e6f0`, warn),
      status
    );
    if (opts && typeof opts.onStop === "function") addStop(box, opts.onStop);
    if (typeof FaiLock !== "undefined") {
      const lockBtn = mk("button", `margin-top:${px(14)};background:#1a1a2e;color:#cfcfe0;border:${px(1)} solid #3a3a5c;border-radius:${px(10)};padding:${px(8)} ${px(14)};font-size:${px(13)};cursor:pointer;font-family:inherit`, "\u{1F512} " + t("lock.btn.title", state.uiLang));
      FaiLock.init({ lang: state.uiLang, skipWhen: () => !!state._pultActive });
      FaiLock.setLang(state.uiLang);
      FaiLock.wire(lockBtn);
      box.append(lockBtn);
    }
    document.body.append(dim, box);
  }
  function hideScanVeil() {
    document.getElementById("fai-scan-veil")?.remove();
    document.getElementById("fai-scan-veil-dim")?.remove();
  }
  function waitVisible() {
    if (!document.hidden) return Promise.resolve();
    return new Promise((res) => {
      let done = false;
      const finish = () => {
        if (done || document.hidden) return;
        done = true;
        document.removeEventListener("visibilitychange", finish);
        window.removeEventListener("focus", finish);
        clearInterval(iv);
        res();
      };
      const iv = setInterval(finish, 400);
      document.addEventListener("visibilitychange", finish);
      window.addEventListener("focus", finish);
    });
  }
  const veilWrite = (txt) => {
    const v = document.getElementById("fai-scan-veil-status");
    if (v) v.textContent = txt;
  };
  function synthClick(el) {
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    let target = document.elementFromPoint(x, y);
    if (!target || !el.contains(target) && !target.contains(el)) target = el.querySelector(".image-overlay") || el;
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
  }
  const VAULT_PICK_TTL = 5 * 60 * 1e3;
  async function vaultPickerAutofill() {
    const pick = await new Promise((r) => chrome.storage.local.get("fansly_vault_pick", (d) => r(d.fansly_vault_pick)));
    if (!pick || !pick.filename || Date.now() - (pick.at || 0) > VAULT_PICK_TTL) return;
    await new Promise((r) => chrome.storage.local.remove("fansly_vault_pick", r));
    const miss = (key) => reportBug("sel_miss", { key, got: 0 });
    const modal = await waitForElement(selStr("vaultPickerModal"), 8e3).catch(() => null);
    if (!modal) {
      miss("pickerModal");
      return;
    }
    const albums = () => [...qa("vaultAlbum", modal)].filter((a) => q("vaultAlbumName", a));
    const nameOf = (a) => (q("vaultAlbumName", a).textContent || "").replace(/\s+/g, " ").trim();
    for (let i = 0, n = -1, same = 0; i < 40 && same < 3; i++) {
      const m = albums().length;
      same = m > 0 && m === n ? same + 1 : 0;
      n = m;
      if (same < 3) await sleep(200);
    }
    const find = (nm) => albums().find((a) => nameOf(a).toLowerCase() === (nm || "").toLowerCase());
    const album = (pick.folders || []).map(find).find(Boolean) || find("All") || albums()[0];
    if (!album) {
      miss("pickerAlbums");
      return;
    }
    synthClick(q("vaultAlbumMedia", album) || album);
    let lupa = null;
    for (let i = 0; i < 25 && !lupa; i++) {
      await sleep(300);
      lupa = q("vaultPickerSearch", modal);
    }
    if (!lupa) {
      miss("pickerSearch");
      return;
    }
    synthClick(lupa);
    let input = null;
    for (let i = 0; i < 15 && !input; i++) {
      await sleep(200);
      input = q("vaultPickerInput", modal);
    }
    if (!input) {
      miss("pickerInput");
      return;
    }
    await VaultSync.typeSearch(input, pick.filename, modal);
  }
  function vaultPickItem(item) {
    if (q("vaultPickIcon", item)) return true;
    if (!q("vaultPickUploadIcon", item)) return false;
    const menu = item.parentElement;
    return !!menu && [...menu.children].some((x) => x !== item && qm("vaultPickUploadNew", x));
  }
  document.addEventListener("click", (e) => {
    let item = null;
    try {
      item = e.target.closest && e.target.closest(selStr("vaultPickMenuItem"));
    } catch (err) {
    }
    if (item && vaultPickItem(item)) vaultPickerAutofill();
  }, true);
  let vaultStopRequest = null;
  function vaultStopFromVeil() {
    if (vaultStopRequest) return vaultStopRequest();
    try {
      VaultSync.stop();
    } catch (e) {
    }
  }
  let _vaultVeilOn = false;
  function vaultPhase(phase, info) {
    const lang = state.uiLang;
    if (phase === "begin") {
      _vaultVeilOn = true;
      if (info && info.kind === "frames") return scanZoom(SCAN_ZOOM).then(() => showScanVeil(t("panel.vault.veil.framesTitle", lang), t("panel.vault.veil.framesWarn", lang), { onStop: vaultStopFromVeil }));
      const quick = !!(info && info.kind === "quick");
      showScanVeil(
        t(quick ? "panel.vault.veil.quickTitle" : "panel.vault.veil.title", lang),
        t(quick ? "panel.vault.veil.quickWarn" : "panel.vault.veil.warn", lang),
        { onStop: vaultStopFromVeil }
      );
      scanZoom(SCAN_ZOOM);
      return;
    }
    _vaultVeilOn = false;
    hideScanVeil();
    if (!info || info.zoom !== false) scanZoom(1);
  }
  function vaultFail(err, mode, setStatus2, silent) {
    if (err && typeof err === "object") {
      err._faiReported = true;
      err._faiMode = mode;
    }
    if (state._scanPageLost) return;
    try {
      console.error("[FanslyAI] \u0441\u043A\u0430\u043D \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430 \u043F\u0440\u0435\u0440\u0432\u0430\u043D (" + mode + "):", err);
    } catch (e) {
    }
    if (err && err.layoutMiss) layoutMissNote(err.layoutMiss);
    else reportBug("exception", { src: "content", scan: "vault", code: mode, ...bugStackFrames(err) });
    if (silent) return;
    setStatus2(t("panel.vault.failed", state.uiLang));
  }
  function vaultRun(mode, setStatus2, extra, silent) {
    const onProgress = (txt) => {
      setStatus2(txt);
      if (_vaultVeilOn) veilWrite(txt);
    };
    const run = async () => {
      if (await new Promise((r) => chrome.storage.local.get("fansly_dbg_vaultfail", (d) => r(!!d.fansly_dbg_vaultfail)))) {
        chrome.storage.local.remove("fansly_dbg_vaultfail");
        throw new Error("\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430: \u0441\u0431\u043E\u0439 \u0441\u043A\u0430\u043D\u0430 \u043F\u043E \u043A\u043E\u043C\u0430\u043D\u0434\u0435 __faiVaultFailNext()");
      }
      return VaultSync.start(Object.assign({ mode, lang: state.uiLang, onPhase: vaultPhase, onProgress }, extra));
    };
    return run().then((res) => res, (err) => {
      vaultFail(err, mode, setStatus2, silent);
      throw err;
    });
  }
  let _scanVeilOn = false;
  function scanPhase(phase, info) {
    const lang = state.uiLang;
    if (phase === "begin") {
      _scanVeilOn = true;
      showScanVeil(t("panel.scan.veil.title", lang), t("panel.scan.veil.warn", lang), { onStop: () => {
        try {
          Scans.stop();
        } catch (e) {
        }
      } });
      if (info && info.zoom) scanZoom(SCAN_ZOOM);
      return;
    }
    _scanVeilOn = false;
    hideScanVeil();
    if (info && info.zoom) scanZoom(1);
  }
  const noStatus = () => {
  };
  function scanFail(err, page, mode) {
    if (err && typeof err === "object") err._faiReported = true;
    if (state._scanPageLost) return Promise.resolve(true);
    if (err && err.layoutMiss) return layoutMissNote(err.layoutMiss);
    try {
      console.error("[FanslyAI] \u0441\u043A\u0430\u043D \xAB" + page + "\xBB \u043F\u0440\u0435\u0440\u0432\u0430\u043D:", err);
    } catch (e) {
    }
    reportBug("exception", { src: "content", scan: page, code: mode || "run", ...bugStackFrames(err) });
    return Promise.resolve(true);
  }
  const LAYOUT_KEY = "fansly_layout_miss", LAYOUT_TG_EVERY = 24 * 3600 * 1e3, LAYOUT_SUSPECT_KEY = "fansly_layout_suspect", LAYOUT_RUNS = 3, LAYOUT_RUN = { id: Math.random().toString(36).slice(2, 10) }, LAYOUT_AT_ONCE = /* @__PURE__ */ new Set(["chatfeed", "chatinput"]);
  function layoutMissNote(miss) {
    if (!miss || !miss.area) return Promise.resolve(false);
    reportBug("sel_miss", { key: miss.area + ":" + miss.key, got: 0 });
    const where = " (" + location.pathname + ")";
    return new Promise((done) => chrome.storage.local.get([LAYOUT_KEY, LAYOUT_SUSPECT_KEY], (d) => {
      const all = d && d[LAYOUT_KEY] || {}, sus = d && d[LAYOUT_SUSPECT_KEY] || {};
      let since = Date.now();
      if (!all[miss.area] && !LAYOUT_AT_ONCE.has(miss.area)) {
        const s = sus[miss.area] || { n: 0, at: Date.now() };
        if (s.run !== LAYOUT_RUN.id) {
          s.n++;
          s.run = LAYOUT_RUN.id;
        }
        s.key = miss.key;
        try {
          console.warn("[FanslyAI] \u0441\u0442\u043E\u0440\u043E\u0436 \u0432\u0451\u0440\u0441\u0442\u043A\u0438: \xAB" + miss.area + "\xBB \u2014 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E " + miss.key + where + ", \u043F\u0440\u043E\u0433\u043E\u043D " + s.n + " \u0438\u0437 " + LAYOUT_RUNS);
        } catch (e) {
        }
        if (s.n < LAYOUT_RUNS) {
          sus[miss.area] = s;
          chrome.storage.local.set({ [LAYOUT_SUSPECT_KEY]: sus });
          done(false);
          return;
        }
        since = s.at;
        delete sus[miss.area];
        if (Object.keys(sus).length) chrome.storage.local.set({ [LAYOUT_SUSPECT_KEY]: sus });
        else chrome.storage.local.remove(LAYOUT_SUSPECT_KEY);
      } else try {
        console.warn("[FanslyAI] \u0441\u0442\u043E\u0440\u043E\u0436 \u0432\u0451\u0440\u0441\u0442\u043A\u0438: \xAB" + miss.area + "\xBB \u2014 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E " + miss.key + where);
      } catch (e) {
      }
      const prev = all[miss.area] || {};
      const tg = !(prev.tgAt && Date.now() - prev.tgAt < LAYOUT_TG_EVERY);
      all[miss.area] = { at: prev.at || since, key: miss.key, tgAt: tg ? Date.now() : prev.tgAt, hidden: prev.hidden === true };
      chrome.storage.local.set({ [LAYOUT_KEY]: all });
      if (tg) sendSafe({ type: "NOTIFY_TELEGRAM", notifyType: "status", text: t("layout.miss.tg", state.uiLang, { page: t("layout.page." + miss.area, state.uiLang), what: t("layout.what." + miss.area, state.uiLang) }) });
      done(true);
    }));
  }
  function layoutSeen(area) {
    chrome.storage.local.get([LAYOUT_KEY, LAYOUT_SUSPECT_KEY], (d) => {
      for (const k of [LAYOUT_KEY, LAYOUT_SUSPECT_KEY]) {
        const all = d && d[k];
        if (!all || !all[area]) continue;
        delete all[area];
        if (Object.keys(all).length) chrome.storage.local.set({ [k]: all });
        else chrome.storage.local.remove(k);
      }
    });
  }
  const CHAT_LAYOUT = { probeMs: 25e3, tickMs: 1e3, listFirstMs: 2e4, listAgainMs: 4e4 };
  const CHAT_AREAS = ["chatfeed", "chatinput", "chatlist"];
  const _chatMiss = { chatfeed: /* @__PURE__ */ new Set(), chatinput: /* @__PURE__ */ new Set() }, _chatNoted = {};
  let _layoutMiss = null, _chatProbeSeq = 0, _chatListArmed = false, _initNoInput = 0;
  function chatLayoutNote(area, key) {
    if (_chatNoted[area]) return;
    _chatNoted[area] = true;
    layoutMissNote({ area, key });
  }
  function chatLayoutMiss(area, id, key) {
    _chatMiss[area].add(String(id));
    if (_chatMiss[area].size >= 2) chatLayoutNote(area, key);
  }
  function chatLayoutOk(area) {
    if (_chatMiss[area]) _chatMiss[area].clear();
    _chatNoted[area] = false;
    if (_layoutMiss && _layoutMiss[area] || !LAYOUT_AT_ONCE.has(area)) layoutSeen(area);
  }
  function chatFeedReadable() {
    return !!q("messageContent") && qa("messageNode").length > 0;
  }
  function chatRowOf(id) {
    for (const a of qa("contactLink")) if (PLAT.contactIdFromHref(a.getAttribute("href")) === String(id)) return a;
    return null;
  }
  function chatSawFan(id) {
    const c = state.contactData;
    return !!(c && state._dataFor === "fai_contact_" + id && c.dossier && c.dossier.lastMessageAt);
  }
  function chatHasHistory(id) {
    const row = chatRowOf(id), pv = row && q("rowPreview", row);
    return !!(pv && (pv.textContent || "").trim()) || chatSawFan(id);
  }
  function chatLayoutProbe() {
    if (PLATFORM !== "fansly") return;
    const id = state.currentContactId;
    if (!id) return;
    const seq = ++_chatProbeSeq, t0 = Date.now();
    let feedOk = false;
    const tick = () => {
      if (seq !== _chatProbeSeq || state.currentContactId !== id || !isExtensionAlive()) return;
      const root = q("messageContent"), feed = !!root && qa("messageNode").length > 0, input = !!q("textarea");
      if (feed && !feedOk) {
        feedOk = true;
        chatLayoutOk("chatfeed");
      }
      if (feed && input) {
        chatLayoutOk("chatinput");
        return;
      }
      if (Date.now() - t0 < CHAT_LAYOUT.probeMs) {
        setTimeout(tick, CHAT_LAYOUT.tickMs);
        return;
      }
      if (state._nameUnresolved) return;
      if (feed) {
        chatLayoutMiss("chatinput", id, "textarea");
        return;
      }
      if (q("contactHeader") && (root ? chatSawFan(id) : chatHasHistory(id))) chatLayoutMiss("chatfeed", id, root ? "messageNode" : "messageContent");
    };
    setTimeout(tick, CHAT_LAYOUT.tickMs);
  }
  function chatInitNoInput() {
    if (PLATFORM !== "fansly") return;
    if (!extractContactIdFromUrl() || !chatFeedReadable()) {
      _initNoInput = 0;
      return;
    }
    if (++_initNoInput >= 2) chatLayoutNote("chatinput", "textarea");
  }
  function chatInitReady() {
    _initNoInput = 0;
    if (PLATFORM === "fansly" && q("textarea")) chatLayoutOk("chatinput");
  }
  function chatListProbe() {
    if (PLATFORM !== "fansly" || _chatListArmed || !PLAT.isMessagesPage()) return;
    _chatListArmed = true;
    const check = (again) => {
      if (!isExtensionAlive()) return;
      if (!PLAT.isMessagesPage()) {
        _chatListArmed = false;
        return;
      }
      if (qa("contactLink").length) {
        chatLayoutOk("chatlist");
        return;
      }
      const drawn = !!q("contactList");
      if (!drawn && extractContactIdFromUrl()) return;
      if (!again) {
        setTimeout(() => check(true), CHAT_LAYOUT.listAgainMs);
        return;
      }
      chatHasChats().then((has) => {
        if (has) chatLayoutNote("chatlist", drawn ? "contactLink" : "contactList");
      });
    };
    setTimeout(() => check(false), CHAT_LAYOUT.listFirstMs);
  }
  function chatHasChats() {
    const env = q("navEnvelope");
    if ((parseInt((env && env.textContent || "").trim(), 10) || 0) > 0) return Promise.resolve(true);
    return new Promise((r) => {
      try {
        const st = chrome.storage.local, has = (keys) => r((keys || []).some((k) => k.startsWith("fai_contact_")));
        if (typeof st.getKeys === "function") st.getKeys(has);
        else st.get(null, (all) => has(Object.keys(all || {})));
      } catch (e) {
        r(false);
      }
    });
  }
  function refreshLayoutBanner() {
    document.getElementById("fai-layout-chat")?.remove();
    const panel = document.getElementById("fansly-ai-panel"), all = _layoutMiss || {};
    const areas = CHAT_AREAS.filter((a) => all[a] && !all[a].hidden);
    if (!panel || !areas.length) return;
    const b = document.createElement("div");
    b.id = "fai-layout-chat";
    b.style.cssText = "display:flex;align-items:flex-start;gap:6px;background:#3a2a1a;color:#f5cfa0;border-bottom:1px solid #6a4a2a;padding:6px 8px;font-size:11px;line-height:1.4";
    const txt = document.createElement("div");
    txt.style.cssText = "flex:1";
    for (const a of areas) {
      const line = document.createElement("div");
      line.textContent = t("layout.miss.panel", state.uiLang, { what: t("layout.what." + a, state.uiLang), since: layoutSince(all[a].at) });
      txt.appendChild(line);
    }
    const x = document.createElement("span");
    x.textContent = "\u2716";
    x.title = t("layout.miss.hide", state.uiLang);
    x.style.cssText = "cursor:pointer;opacity:.6;flex-shrink:0";
    x.addEventListener("click", () => {
      chrome.storage.local.get(LAYOUT_KEY, (d) => {
        const cur = d && d[LAYOUT_KEY];
        if (!cur) return;
        for (const a of areas) if (cur[a]) cur[a] = Object.assign({}, cur[a], { hidden: true });
        chrome.storage.local.set({ [LAYOUT_KEY]: cur });
      });
      b.remove();
    });
    b.append(txt, x);
    panel.insertBefore(b, panel.firstChild);
  }
  function layoutSince(at) {
    const d = new Date(at || Date.now()), lang = state.uiLang || "ru";
    return d.toLocaleString(lang, (/* @__PURE__ */ new Date()).toDateString() === d.toDateString() ? { hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  }
  function layoutCacheWire() {
    try {
      chrome.storage.local.get(LAYOUT_KEY, (d) => {
        _layoutMiss = d && d[LAYOUT_KEY] || null;
        refreshLayoutBanner();
      });
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area === "local" && ch[LAYOUT_KEY]) {
          _layoutMiss = ch[LAYOUT_KEY].newValue || null;
          refreshLayoutBanner();
        }
      });
    } catch (e) {
    }
  }
  layoutCacheWire();
  const SCAN_OFF_KEY = "fansly_scan_off";
  function scanIsOff(area) {
    return new Promise((r) => {
      try {
        chrome.storage.local.get(SCAN_OFF_KEY, (d) => r(!!(d && d[SCAN_OFF_KEY] && d[SCAN_OFF_KEY][area])));
      } catch (e) {
        r(false);
      }
    });
  }
  function scanOffSkip(area, setStatus2) {
    try {
      console.log("[FanslyAI] \u0441\u043A\u0430\u043D \xAB" + area + "\xBB \u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D (selectors.json) \u2014 \u043D\u0435 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u044E");
    } catch (e) {
    }
    if (setStatus2) setStatus2(t("scanoff.status", state.uiLang, { page: t("layout.page." + area, state.uiLang) }));
    return { off: true };
  }
  function scanRun(page, mode, setStatus2, scheduled) {
    const onProgress = (txt) => {
      setStatus2(txt);
      if (_scanVeilOn) veilWrite(txt);
    };
    const run = async () => await scanIsOff(page) ? scanOffSkip(page, setStatus2) : Scans.start({ page, mode, scheduled: !!scheduled, lang: state.uiLang, onPhase: scanPhase, onProgress });
    return run().then((res) => res, (err) => scanFail(err, page, mode).then((failed) => {
      if (failed) throw err;
      return { layoutSuspect: true };
    }));
  }
  function scanBusyNow() {
    try {
      return !!Scans.status().running;
    } catch (e) {
      return false;
    }
  }
  function onScanBusyAsk(request, sender, sendResponse) {
    if (!request || request.type !== "SCAN_BUSY") return;
    sendResponse({ busy: scanBusyNow() });
  }
  chrome.runtime.onMessage.addListener(onScanBusyAsk);
  async function notifFilterHeal() {
    if (scanBusyNow() || state._scanPage) return false;
    try {
      return !!await Scans.healNotifFilter();
    } catch (e) {
      return false;
    }
  }
  const VAULT_STATE_KEY = "fansly_vault_sync";
  const VAULT_OLD_KEYS = ["fansly_catalog_needfull", "fansly_catalog_counts", "fansly_catalog_doscan_at", "fansly_scan_failed"];
  function vaultStateLoad() {
    return new Promise((r) => chrome.storage.local.get([VAULT_STATE_KEY, ...VAULT_OLD_KEYS], (d) => {
      d = d || {};
      if (d[VAULT_STATE_KEY]) return r(d[VAULT_STATE_KEY]);
      const st = VaultMachine.migrate({ needfull: d.fansly_catalog_needfull, counts: d.fansly_catalog_counts, doscan_at: d.fansly_catalog_doscan_at, scan_failed: d.fansly_scan_failed });
      chrome.storage.local.set({ [VAULT_STATE_KEY]: st }, () => chrome.storage.local.remove(VAULT_OLD_KEYS, () => r(st)));
    }));
  }
  const vaultStateSave = (st) => new Promise((r) => chrome.storage.local.set({ [VAULT_STATE_KEY]: st }, r));
  function vaultStatusFor(st) {
    const lang = state.uiLang, d = VaultMachine.describe(st, { now: Date.now() });
    if (d.busy) return t("catalog.sync.busy", lang);
    if (d.note === "aborted") return t("panel.vault.offer.aborted", lang);
    if (d.note === "stopped") return t("panel.vault.offer.stopped", lang);
    if (st.note === "noOverview") return t("panel.vault.checkSkip", lang);
    if (st.note === "siteMismatch") return t("panel.vault.mismatch", lang, { n: d.drift });
    if (st.note === "upToDate") return t("panel.vault.upToDate", lang);
    if (d.offer) return t(d.offer === "folders" ? "panel.vault.offer.folders" : "panel.vault.offer.update", lang, { n: d.drift });
    return null;
  }
  async function vaultOperation(trigger, setStatus2, opts) {
    opts = opts || {};
    if (await scanIsOff("vault")) return scanOffSkip("vault", opts.silent ? null : setStatus2);
    let st = await vaultStateLoad();
    const apply = async (ev) => {
      const r = VaultMachine.step(st, Object.assign({ now: Date.now() }, ev));
      st = r.state;
      await vaultStateSave(st);
      return r.effects;
    };
    const snapOf = async (res) => res && res.snap ? Object.assign({}, res.snap, { gaps: await VaultSync.gapFolders() }) : null;
    const counted = async (res) => {
      const eff = await apply({ type: "counts", snap: await snapOf(res) });
      if (st.snapshot && st.snapshot.drift > 0) reportBug("vault_drift", { drift: st.snapshot.drift });
      return eff;
    };
    let effects = await apply({ type: "start", trigger });
    if (!effects.length) {
      if (!opts.silent) {
        const s = vaultStatusFor(st);
        if (s) setStatus2(s);
      }
      return st;
    }
    const beat = setInterval(() => {
      apply({ type: "beat" }).catch(() => {
      });
    }, VaultMachine.BEAT_MS);
    const onHide = () => {
      st = VaultMachine.step(st, { type: "abort", now: Date.now() }).state;
      try {
        chrome.storage.local.set({ [VAULT_STATE_KEY]: st });
      } catch (e) {
      }
      try {
        if (typeof VaultSync.release === "function") VaultSync.release();
      } catch (e) {
      }
    };
    window.addEventListener("pagehide", onHide);
    vaultStopRequest = async () => {
      const eff = await apply({ type: "stop" });
      for (const e of eff) if (e.do === "cancel") {
        try {
          VaultSync.stop();
        } catch (e2) {
        }
      }
    };
    let scanned = false;
    try {
      while (effects.length) {
        const next = [];
        for (const e of effects) {
          if (e.do === "check") next.push(...await counted(await vaultRun("check", setStatus2, opts.silent ? { periodic: true } : null, opts.silent)));
          else if (e.do === "scan") {
            scanned = true;
            const res = e.plan.whole ? await vaultRun("full", setStatus2, null, opts.silent) : await vaultRun("targeted", setStatus2, { folders: { drifted: e.plan.incr, gaps: e.plan.full } }, opts.silent);
            next.push(...await apply({ type: "scanEnd", added: (res && res.added) | 0, reachedEndAll: !!(res && res.reachedEndAll), stopped: !!(res && res.stopped) }));
            next.push(...await counted(res));
          } else if (e.do === "sweep") await vaultRun("sweep", setStatus2, null, opts.silent);
          else if (e.do === "cancel") {
            if (typeof VaultSync.stop === "function") VaultSync.stop();
          }
        }
        effects = next;
      }
      if (!opts.silent && !scanned) {
        const s = vaultStatusFor(st);
        if (s) setStatus2(s);
      }
    } catch (err) {
      await apply({ type: "error", name: err && err.name || "Error", mode: err && err._faiMode || null });
      throw err;
    } finally {
      clearInterval(beat);
      window.removeEventListener("pagehide", onHide);
      vaultStopRequest = null;
    }
    return st;
  }
  window.__faiVaultFailNext = function() {
    chrome.storage.local.set({ fansly_dbg_vaultfail: Date.now() });
    return "\u0432\u0437\u0432\u0435\u0434\u0435\u043D\u043E: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0437\u0430\u043F\u0443\u0441\u043A \u0441\u043A\u0430\u043D\u0430 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430 \u0443\u043F\u0430\u0434\u0451\u0442 \u043E\u0434\u0438\u043D \u0440\u0430\u0437 (\u0432 \u043B\u044E\u0431\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435)";
  };
  async function initVault() {
    const s = await getSettingsAsync();
    state.uiLang = s.interfaceLanguage || "ru";
    const tg = await readVaultTargeted();
    if (tg) {
      chrome.storage.local.remove("fansly_vault_targeted");
      const trigger = tg.trigger || (tg.quick ? "catalogQuick" : "offer");
      vaultOperation(trigger, noStatus).then((st) => !!st && st.note === "stopped", () => false).then((stopped) => scanDone(stopped ? { type: "TARGETED_VAULT_DONE", stopped: true } : { type: "TARGETED_VAULT_DONE" }));
      return;
    }
    const sched = await readScheduledScan();
    if (sched && sched.type === "frames") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      if (await scanIsOff("vault")) {
        scanOffSkip("vault");
        scanDone({ type: "FRAMES_SCAN_DONE" });
        return;
      }
      vaultRun("frames", noStatus).finally(() => scanDone({ type: "FRAMES_SCAN_DONE" }));
      return;
    }
    if (sched && sched.type === "vault") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      if (sched.full) {
        const [ok, failed] = stepDone("vault");
        vaultOperation("collectAll", noStatus).then((st) => sched.chain ? ok(st) : scanDone(null), () => sched.chain ? failed() : scanDone(null));
        return;
      }
      vaultOperation("periodic", noStatus, { silent: true }).then(...stepDone("vault"));
      return;
    }
    const vs = await new Promise((r) => chrome.storage.local.get("fansly_vault_search", (d) => r(d.fansly_vault_search)));
    if (vs && vs.filename && Date.now() - (vs.at || 0) < 3e4) {
      chrome.storage.local.remove("fansly_vault_search");
      VaultSync.findFile(vs.filename, vs.folders || [], { lang: state.uiLang, onProgress: noStatus });
    }
  }
  async function initSubs() {
    const s = await getSettingsAsync();
    state.uiLang = s.interfaceLanguage || "ru";
    const sched = await readScheduledScan();
    if (sched && sched.type === "subs") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      scanRun("subs", null, noStatus, !sched.full).then(...stepDone("subs"));
    }
  }
  async function saveCreatorStats(stillOwn = () => true) {
    let st = {};
    for (let i = 0; i < 25; i++) {
      st = scrapeCreatorStats();
      if (st.followers != null || st.likes != null || st.subscribers != null) break;
      await sleep(400);
    }
    if (!stillOwn()) return;
    if (st.followers == null && st.likes == null && st.subscribers == null) return;
    await new Promise((r) => chrome.storage.local.set({ fansly_creator_stats: { at: Date.now(), ...st } }, r));
    const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    await new Promise((r) => chrome.storage.local.get("fansly_stats_daily", (d) => {
      const m = d.fansly_stats_daily || {}, prev = m[day] || {};
      m[day] = { subscribers: st.subscribers ?? prev.subscribers ?? null, followers: st.followers ?? prev.followers ?? null, likes: st.likes ?? prev.likes ?? null };
      const keys = Object.keys(m).sort();
      while (keys.length > 120) delete m[keys.shift()];
      chrome.storage.local.set({ fansly_stats_daily: m }, r);
    }));
    console.log("[FanslyAI] \u0441\u0442\u0430\u0442\u0430 \u043F\u0440\u043E\u0444\u0438\u043B\u044F:", JSON.stringify(st));
  }
  async function initEarnings() {
    const s = await getSettingsAsync();
    state.uiLang = s.interfaceLanguage || "ru";
    saveCreatorStats();
    const sched = await readScheduledScan();
    if (sched && sched.type === "earnings") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      scanRun("earnings", sched.full ? "full" : "quick", noStatus, !sched.full).then(...stepDone("earnings"));
    }
  }
  async function initBroadcast() {
    const s = await getSettingsAsync();
    state.uiLang = s.interfaceLanguage || "ru";
    const sched = await readScheduledScan();
    if (sched && sched.type === "broadcast") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      scanRun("broadcast", null, noStatus, true).finally(() => scanDone({ type: sched.once ? "CLOSE_TAB" : "SCHEDULED_SCAN_DONE", scanType: "broadcast" })).catch(() => {
      });
    }
  }
  function tierModal() {
    return [...qa("subModal")].find((m) => q("subModalTier", m) || q("subBenefits", m)) || null;
  }
  function closeSubModal() {
    const m = tierModal();
    if (!m) return;
    const xs = [...qa("subModalClose")], others = [...qa("subModal")].filter((o) => o !== m);
    for (let el = m; el && !others.some((o) => el.contains(o)); el = el.parentElement) {
      const x = xs.find((i) => el.contains(i));
      if (x) {
        x.click();
        return;
      }
    }
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  }
  async function subModalGone() {
    for (let i = 0; i < 10; i++) {
      if (!tierModal()) return true;
      if (i % 5 === 0) closeSubModal();
      await sleep(200);
    }
    return !tierModal();
  }
  function tierCard(tierName) {
    for (const box of document.querySelectorAll(".subscription-plans")) {
      if (subText(box.querySelector(".subscription-tier-title")) !== tierName) continue;
      const card = q("subPlanCard", box) || box.querySelector(".subscription-plan");
      if (card) return card;
    }
    return null;
  }
  async function scrapePerks(tierName) {
    try {
      if (!await subModalGone()) return { failed: "\u043F\u0440\u0435\u0436\u043D\u0435\u0435 \u043E\u043A\u043D\u043E \u0442\u0430\u0440\u0438\u0444\u0430 \u043D\u0435 \u0437\u0430\u043A\u0440\u044B\u043B\u043E\u0441\u044C" };
      const card = tierCard(tierName);
      if (!card) return { failed: "\u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0442\u0430\u0440\u0438\u0444\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430" };
      card.click();
      let modal = null, other = "";
      for (let i = 0; i < 15 && !modal; i++) {
        await sleep(200);
        const m = tierModal();
        if (!m) continue;
        const shown = subText(q("subModalTier", m));
        if (!shown || shown === tierName) modal = m;
        else other = shown;
      }
      if (!modal) {
        await subModalGone();
        return { failed: other ? "\u0432 \u043E\u043A\u043D\u0435 \u0434\u0440\u0443\u0433\u043E\u0439 \u0442\u0430\u0440\u0438\u0444 (\xAB" + other + "\xBB)" : "\u043E\u043A\u043D\u043E \u0442\u0430\u0440\u0438\u0444\u0430 \u043D\u0435 \u043E\u0442\u043A\u0440\u044B\u043B\u043E\u0441\u044C" };
      }
      const box = q("subBenefits", modal);
      const perks = box ? [...box.children].filter((row) => row.querySelector("i.fa-stars")).map((row) => subText(row).trim()).filter((x) => x && x.length <= 200) : [];
      await subModalGone();
      return { perks };
    } catch (e) {
      try {
        closeSubModal();
      } catch (_) {
      }
      return { failed: "\u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435: " + (e && e.message || e) };
    }
  }
  async function dropUnconfirmedTiers(own) {
    if (!own) return;
    const cur = await new Promise((r) => chrome.storage.local.get("fansly_tiers", (d) => r(d.fansly_tiers)));
    if (!cur || ScanPages.sameHandle(cur.owner, own)) return;
    await new Promise((r) => chrome.storage.local.remove("fansly_tiers", r));
    console.log("[FanslyAI] \u0442\u0430\u0440\u0438\u0444\u044B: \u043D\u0430 \u0441\u0432\u043E\u0451\u043C \u043F\u0440\u043E\u0444\u0438\u043B\u0435 \u0438\u0445 \u043D\u0435\u0442 \u2014 \u0443\u0431\u0440\u0430\u043D \u0441\u043F\u0438\u0441\u043E\u043A \u0431\u0435\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430");
  }
  async function saveTiers(own, stillOwn = () => true) {
    let list = [];
    for (let i = 0; i < 20; i++) {
      list = scrapeTiers();
      if (list.length) break;
      await sleep(400);
    }
    if (!stillOwn()) return;
    if (!list.length) {
      console.log("[FanslyAI] \u0442\u0430\u0440\u0438\u0444\u044B: \u0431\u043B\u043E\u043A\u043E\u0432 .subscription-plans \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u2014 \u043F\u0440\u043E\u043F\u0443\u0441\u043A");
      await dropUnconfirmedTiers(own);
      return;
    }
    const prev = await new Promise((r) => chrome.storage.local.get("fansly_tiers", (d) => r(d.fansly_tiers && d.fansly_tiers.list || [])));
    const missed = [];
    for (const t2 of list) {
      if (!stillOwn()) return;
      let res = await scrapePerks(t2.name);
      if (res.failed) {
        const first = res.failed;
        await sleep(1e3);
        res = await scrapePerks(t2.name);
        if (res.perks) console.log(`[FanslyAI] \u0442\u0430\u0440\u0438\u0444\u044B: \u0443\u0441\u043B\u043E\u0432\u0438\u044F \xAB${t2.name}\xBB \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u044B \u0441\u043E \u0432\u0442\u043E\u0440\u043E\u0439 \u043F\u043E\u043F\u044B\u0442\u043A\u0438 (\u043F\u0435\u0440\u0432\u0430\u044F: ${first})`);
      }
      if (res.perks) {
        t2.perks = res.perks;
        continue;
      }
      const old = prev.find((x) => x.name === t2.name);
      t2.perks = old && Array.isArray(old.perks) ? old.perks : [];
      missed.push(`\xAB${t2.name}\xBB \u2014 ${res.failed}${t2.perks.length ? ", \u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u044B \u043F\u0440\u0435\u0436\u043D\u0438\u0435 (" + t2.perks.length + ")" : ""}`);
    }
    await new Promise((r) => chrome.storage.local.set({ fansly_tiers: { at: Date.now(), owner: own, list } }, r));
    console.log("[FanslyAI] \u0442\u0430\u0440\u0438\u0444\u044B \u0441\u043D\u044F\u0442\u044B:", list.map((x) => `${x.name} $${x.price}${x.perks?.length ? " \xB7 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 " + x.perks.length : ""}`).join(" \xB7 "));
    if (missed.length) console.warn("[FanslyAI] \u0442\u0430\u0440\u0438\u0444\u044B: \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u043D\u0435 \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u044B \u2014 " + missed.join("; "));
  }
  async function initPosts() {
    const path = location.pathname, own = await ownHandle();
    if (!ScanPages.isOwn("posts", path, own)) {
      console.log("[FanslyAI] \u043F\u043E\u0441\u0442\u044B: \u0447\u0443\u0436\u043E\u0439 \u043F\u0440\u043E\u0444\u0438\u043B\u044C \u2014 \u0442\u0430\u0440\u0438\u0444\u044B, \u0446\u0438\u0444\u0440\u044B \u0438 \u0437\u0430\u044F\u0432\u043A\u0438 \u043D\u0435 \u0442\u0440\u043E\u0433\u0430\u0435\u043C");
      return;
    }
    const stillOwn = () => {
      const p = location.pathname, h = ScanPages.handleAt("posts", p);
      return ScanPages.at("posts", p) && (!h || ScanPages.sameHandle(h, own));
    };
    saveTiers(own, stillOwn);
    saveCreatorStats(stillOwn);
    const s = await getSettingsAsync();
    state.uiLang = s.interfaceLanguage || "ru";
    const sched = await readScheduledScan();
    if (sched && sched.type === "posts") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      if (sched.after === "vault") {
        scanRun("posts", "quick", noStatus, false).finally(() => scanDone({ type: "TARGETED_VAULT_DONE" }));
        return;
      }
      scanRun("posts", sched.full ? "full" : "quick", noStatus, !sched.full).then(...stepDone("posts"));
    }
  }
  async function initNotifDeep() {
    const scanOnce = await new Promise((r) => chrome.storage.local.get("fansly_notif_scan", (d) => r(d.fansly_notif_scan)));
    if (scanOnce) return;
    const s = await getSettingsAsync();
    state.uiLang = s.interfaceLanguage || "ru";
    const sched = await readScheduledScan();
    if (sched && sched.type === "notifhist") {
      chrome.storage.local.remove("fansly_scheduled_scan");
      scanRun("notifhist", null, noStatus).then(...stepDone("notifhist"));
    }
  }
  async function seeOwnHandle() {
    for (let i = 0; i < 6; i++) {
      const a = document.querySelector('.avatar-container a[href^="/"]') || document.querySelector('app-account-avatar a[href^="/"]');
      const h = a && (a.getAttribute("href") || "").replace(/^\//, "").trim();
      if (h && !/^(creator|explore|notifications|messages|home|search|settings|post|wall)\b/i.test(h) && !h.includes("/")) {
        chrome.storage.local.get("fansly_creator_handle", (d) => {
          if (d.fansly_creator_handle !== h) chrome.storage.local.set({ fansly_creator_handle: h });
        });
        return h;
      }
      await sleep(1500);
    }
    return null;
  }
  const _ownHandleSeen = PLATFORM === "fansly" ? seeOwnHandle() : Promise.resolve(null);
  async function ownHandle() {
    return await _ownHandleSeen || new Promise((r) => chrome.storage.local.get("fansly_creator_handle", (d) => r(d && d.fansly_creator_handle || null)));
  }
  checkPendingInvite();
  ScanPages.ready.then(() => earlyScanVeil(location.pathname));
  if (PLAT.isMessagesPage()) {
    init();
    getSettingsAsync().then((s) => {
      if (s.notificationsEnabled) startNotifWatch();
    });
    if (PLATFORM === "fansly") setTimeout(maybeSendCrmReminders, 45e3);
    setTimeout(maybeInsertPendingDraft, 2500);
  } else ScanPages.ready.then(() => routeScanPage(location.pathname));
})();
