const BEFORE_CONSENT = true;
let _consentOk = false;
importScripts("i18n.js");
importScripts("crm-core.js");
importScripts("idb.js");
importScripts("consent.js");
importScripts("ai-core.js");
importScripts("parsers.js");
importScripts("contact-store.js");
ContactStore.initBackground({ hashString: Parsers.hashString });
importScripts("tg-core.js");
TgCore.init({ getSettings, saveSettings, fetchWithTimeout, generatePost, startInviteFlow });
importScripts("scan-pages.js");
const PLATFORM = true ? "fansly" : "fansly";
const BUILD = true ? "full" : "full";
const BUILDSTAMP = true ? "5006cae@20261108.0052" : "dev";
function detectBrowserLang(supported, fallback = "en") {
  const langs = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || ""];
  for (const l of langs) {
    const code = (l || "").toLowerCase().split("-")[0];
    if (supported.includes(code)) return code;
  }
  return fallback;
}
const DEFAULT_SETTINGS = {
  nativeLanguage: detectBrowserLang(["en", "ru", "uk", "es", "pt", "de", "fr", "it", "pl", "tr"]),
  // список = опции #nativeLanguage в options.html
  translateProvider: "deepl",
  translateContext: true,
  // живой перевод с контекстом диалога (todo #44); false — как до фичи (откат без релиза, интерфейса у ключа нет)
  // Прокси Velour Cloud: ИИ + DeepL через сервер по license-ключу (мастер-ключи на сервере). Свои ключи — под Advanced.
  useProxy: false,
  licenseKey: "",
  proxyBaseUrl: "https://api.velourff.com",
  bugReportEnabled: false,
  // opt-in диагностика для саппорта (только тех-метаданные, без ПДн). Дефолт OFF
  aiProvider: "mock",
  /*@cws-cut-start@*/
  ollamaEndpoint: "http://localhost:11434",
  /*@cws-cut-end@*/
  claudeApiKey: "",
  deepLApiKey: "",
  geminiApiKey: "",
  groqApiKey: "",
  // OpenRouter — запасной провайдер. Работает поверх любого основного.
  openrouterApiKey: "",
  openrouterModel: AiCore.MODELS.openrouter,
  // платная база: чистый русский, стабильный JSON (euryale сыпал мусор). :free = общий пул → 429
  creatorGender: "female",
  geminiModel: AiCore.MODELS.gemini,
  // имена моделей — в ai-core.js (MODELS), модуль подключён выше
  basePrompt: "",
  // переопределение промпта — фича убрана из UI в v0.5 (дефолт пустой → инертно)
  interfaceLanguage: detectBrowserLang(["ru", "en", "es", "de", "fr", "tr"]),
  // язык интерфейса — из браузера, иначе 'en' (см. detectBrowserLang выше)
  collectDossier: true,
  // собирать ИИ-досье+бриф (профилирование контакта; нужен ключ ИИ). full-only; в store нет — только ручные заметки
  dossierDeltaMin: 1,
  // сколько новых сообщений ФАНА копить до обновления досье. Каждое обновление = обращение из пакета,
  // а по одной короткой реплике фактов обычно нет. 1 = как было; больше — реже обращения, позже бриф. full-only
  crmEnabled: true,
  // CRM (база фанов): тумблер мастера настройки → прячет кнопку CRM в попапе. full-only
  coachEnabled: true,
  // «Советы» (коучинг в панели): тумблер мастера → прячет блок #fai-coach. full-only
  setupCompleted: false,
  // мастер настройки пройден — чтобы не открывать его повторно. full-only
  // v0.5 плашка-тумблеры (попап пишет → content реагирует через applyOwnerSettings/onChanged)
  masterEnabled: true,
  // главный рубильник («Velour на <площадке сборки>», попап) — выкл = стоп ВСЕЙ работы: панели, пульт, сканы, уведомления
  translatorEnabled: true,
  // переводчик (отображение перевода владельцу)
  aiEnabled: false,
  // авто-варианты (3 ответа): по умолчанию ВЫКЛ, тумблер скрыт из попапа (Alex 2026-07-28)
  carouselEnabled: false,
  // карусель-монитор вкл/выкл (стоп при master off)
  panelHidden: false,
  // рабочая панель скрыта (косметика; бот всё равно работает)
  // Персонаж
  creatorName: "",
  creatorAge: "",
  creatorCity: "",
  creatorAbout: "",
  creatorTimezone: "",
  // IANA TZ легенды (напр. Europe/Istanbul). Пусто = зона браузера
  // Подписки / тиры
  tiersInfo: "",
  // Кастомный контент: цена/условия удалены из продукта (2026-08-17) — осталось только табу (в «Персонаже»)
  customTaboo: "",
  // Стиль общения (few-shot примеры)
  styleExamples: "",
  styleDescription: "",
  // калибровка стиля (онбординг Фаза 2) — плоский ключ: читается buildPrompt + переживает сохранение options
  styleLearnEnabled: false,
  // показывать в панели кнопку 📚 «учиться стилю с чата» — действие разовое, дефолт OFF
  // Модель отказала отвечать → мягкий ответ вместо ошибки.
  // Отключить, если модель не отказывает
  nsfwGracefulHandling: false,
  // (Alex 2026-07-29) выкл — запасной ответ не нужен
  // Темп работы карусели (карусель = зеркало в Телеграм; авто-отправка удалена 2026-08-08).
  // Мёртвые поля автопилота (nightAutoSend / nightMaxPerSession / nightTyping / nightConfirmSend) убраны
  // 2026-08-14: их никто не читал, а тумблеры в UI врали пользователю, что что-то включают.
  frameMinVideoSec: 120,
  // кадры из видео снимаем только у роликов НЕ КОРОЧЕ этого, сек (0 = у всех).
  // Дефолт 120: у коротких роликов обложка и так почти всё показывает, а разметка
  // кадров — самая дорогая часть (≈13 с на кадр). Порог опускается вручную.
  nightPauseMin: 40,
  // мин. пауза между диалогами, сек
  nightPauseMax: 180,
  // макс. пауза, сек
  nightMsPerWord: 700,
  // задержка на слово при ручной отправке из панели, мс (cap ~25с на сообщение)
  briefStaleHours: 240,
  // через сколько часов без упоминания бриф считается устаревшим (Alex 2026-07-29: 10 дней)
  // Красные линии — на что модель НЕ соглашается (держит дистанцию художника)
  redLines: null,
  // null — умолчание: текст словаря на языке интерфейса (options.default.redLines); '' — без красных линий (п.64)
  // Кастомные интенты: [{ label, emoji, keywords, instruction }]
  customIntents: [],
  // false = бот уклоняется (артист-дистанция), true = поддерживает в характере (через Groq)
  allowExplicit: true,
  // (Alex 2026-07-29)
  // Тиры (имя/цена/цвет) авто-снимаются со страницы /posts в fansly_tiers — ручного маппинга больше нет
  // Телеграм-уведомления (Блок 10, Phase 1: подключение + срочные, один чат)
  telegramEnabled: false,
  telegramBotToken: "",
  telegramChatId: "",
  tgNotifyBrief: true,
  // 🆕 собран бриф на кастом
  tgNotifyDialogue: true,
  // 💬 весь диалог в реалтайме (Alex 2026-07-29)
  tgMuteExcluded: true,
  // не зеркалить в ТГ исключённых (скрытая пометка «исключён», Alex 2026-07-29); токсичность снята (todo п.48)
  tgCleanProcessed: true,
  // убирать отработанные сообщения (варианты/подтверждения) из ТГ — deleteMessage (Alex 2026-07-29)
  tgTopics: true,
  // топики: ветка на фана + ⚠️важное (Alex 2026-07-29); требует супергруппу-форум, бот админ
  // Нотификации: монитор лайков/фолловов на /notifications → кого стоит пригласить в диалог
  notificationsEnabled: true,
  // мониторинг активности: по умолчанию ВКЛ (Alex 2026-07-28); тумблер скрыт из попапа, панель аутрича не показываем — работает только фоновый скан (леджер/ТГ-сигналы)
  notifyLikeThreshold: 3,
  // лайков (пост+медиа) для флага на аутрич; follower флагует сразу
  notifyPaidOnly: false,
  // нотификации: только платные подписки (бесплатных-фолловеров не флагуем)
  inviteSilenceDays: 7,
  // ТГ-пинг «стоит пригласить» лайкера — только если чат молчит ≥N дней (или истории нет); живой диалог = шум
  inviteInstruction: null
  // null — умолчание: options.default.inviteInstruction на языке интерфейса (п.64)
};
const LEGACY_DEFAULTS = {
  redLines: "\u041D\u0435 \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u044E\u0441\u044C \u043D\u0430 \u043B\u0438\u0447\u043D\u044B\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0438 \u0438 \u0441\u0432\u0438\u0434\u0430\u043D\u0438\u044F, \u0432\u0438\u0434\u0435\u043E\u0437\u0432\u043E\u043D\u043A\u0438 \u0438 \u0441\u043E\u0437\u0432\u043E\u043D\u044B, \u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u0432 Discord / Telegram / WhatsApp / \u0434\u0440\u0443\u0433\u0438\u0435 \u043C\u0435\u0441\u0441\u0435\u043D\u0434\u0436\u0435\u0440\u044B \u0432\u043D\u0435 Fansly, \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0444\u0438\u043B\u044C\u043C\u043E\u0432, \u043E\u0431\u043C\u0435\u043D \u043B\u0438\u0447\u043D\u044B\u043C\u0438 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430\u043C\u0438. \u0414\u0435\u0440\u0436\u0443 \u0434\u0438\u0441\u0442\u0430\u043D\u0446\u0438\u044E \u2014 \u043E\u0431\u0449\u0430\u0435\u043C\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0434\u0435\u0441\u044C.",
  inviteInstruction: "\u041D\u0430\u043F\u0438\u0448\u0438 \u0435\u043C\u0443 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0435 \u0442\u0451\u043F\u043B\u043E\u0435 \u043F\u0435\u0440\u0432\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u2014 \u043E\u043D \u043D\u0435\u0434\u0430\u0432\u043D\u043E \u043F\u0440\u043E\u044F\u0432\u0438\u043B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u044C (\u043B\u0430\u0439\u043A\u0438/\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430). \u041F\u043E\u0437\u043D\u0430\u043A\u043E\u043C\u044C\u0441\u044F \u0438 \u043C\u044F\u0433\u043A\u043E \u043F\u0440\u0438\u0433\u043B\u0430\u0441\u0438 \u043F\u043E\u043E\u0431\u0449\u0430\u0442\u044C\u0441\u044F. \u0411\u0435\u0437 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u0438 \u0434\u0430\u0432\u043B\u0435\u043D\u0438\u044F, \u043F\u043E-\u0447\u0435\u043B\u043E\u0432\u0435\u0447\u0435\u0441\u043A\u0438, \u0432 \u0442\u0432\u043E\u0451\u043C \u0441\u0442\u0438\u043B\u0435."
};
function redLinesText(s) {
  return s.redLines == null ? t("options.default.redLines", s.interfaceLanguage || "ru") : String(s.redLines);
}
const RESET_SETTINGS = {
  translatorEnabled: DEFAULT_SETTINGS.translatorEnabled,
  bugReportEnabled: DEFAULT_SETTINGS.bugReportEnabled
};
Object.assign(RESET_SETTINGS, {
  styleLearnEnabled: DEFAULT_SETTINGS.styleLearnEnabled,
  collectDossier: DEFAULT_SETTINGS.collectDossier,
  dossierDeltaMin: DEFAULT_SETTINGS.dossierDeltaMin,
  briefStaleHours: DEFAULT_SETTINGS.briefStaleHours,
  crmRemindersEnabled: false,
  // ключей ниже в DEFAULT_SETTINGS нет: код читает их как «включено только при true»
  scheduledScanEnabled: false,
  scheduledScanHours: 1,
  autoTagNew: false,
  frameMinVideoSec: DEFAULT_SETTINGS.frameMinVideoSec,
  notificationsEnabled: DEFAULT_SETTINGS.notificationsEnabled,
  outreachTgSignals: false,
  notifyLikeThreshold: DEFAULT_SETTINGS.notifyLikeThreshold,
  notifyPaidOnly: DEFAULT_SETTINGS.notifyPaidOnly,
  inviteSilenceDays: DEFAULT_SETTINGS.inviteSilenceDays,
  inviteInstruction: DEFAULT_SETTINGS.inviteInstruction,
  bgWorkEnabled: false
  // работа пульта в фоне; согласие с риском (bgWorkAck) остаётся
});
const BUG_BUF_KEY = "fansly_bugbuf";
const BUG_BUF_MAX = 50;
const BUG_FLUSH_AT = 30;
const BUG_FLUSH_ALARM = "fansly_bug_flush";
const BUG_FLUSH_HOURS = 6;
const BUG_THROTTLE_MS = 6e4;
const BUG_CODES = /* @__PURE__ */ new Set([
  "exception",
  "net_fail",
  "all_providers_failed",
  "proxy_401",
  "proxy_402",
  "sync_timeout",
  "vault_notend",
  "vault_drift",
  "vault_short",
  "stale_lock",
  // vault_short — папка собрана не полностью (недобор против счётчика сайта)
  "storage_quota",
  "quota_bytes_err",
  "sel_miss",
  "trial_fail",
  // конверт /v1/trial не принят (наша ошибка сборки запроса, не состояние человека)
  "catalog_write_fail",
  // пачка правок каталога не доехала до базы (мост content→background→IndexedDB)
  // На сайте несколько папок с одним именем (#97): сверить такую нельзя, плашка каталога просит переименовать.
  // Наружу — только числа: folders (сколько имён задвоено) и got (сколько плиток их носят); имён папок нет.
  // ⚠️ Код новый, а сервер режет по СВОЕМУ списку (REPORT_CODES, другой репозиторий) и незнакомое выбрасывает
  // молча: пока код не добавлен там, событие не доезжает, а selftest прокси краснеет на сверке списков.
  "vault_dupname",
  // Живучесть пульта. Подвид едет в поле code: gap (вкладка замирала), stall (карусель не шагает),
  // nav_stuck (сторож снял залипший мьютекс), discard (вкладку выгрузили вопреки запрету). Один код на
  // все подвиды намеренно: КОДЫ режет ещё и сервер по своему списку в другом репозитории, и незнакомый
  // он выбрасывает молча (так потеряли vault_short) — а поле code уже в обоих whitelist, поэтому новый
  // подвид не потребует деплоя прокси.
  "pult_health"
]);
const CALL_KINDS = /* @__PURE__ */ new Set([
  "reply",
  // ответ фану — панель и Телеграм-пульт
  "translate",
  // перевод через ИИ
  "translate_live",
  // перевод живого сообщения с контекстом диалога — человек смотрит на панель (todo #44); на прокси не фон
  "dossier",
  // досье по кнопке
  "dossier_auto",
  // досье фоном
  "post",
  // генерация поста
  "coach",
  // совет по диалогу
  "chat",
  // чат с ИИ в панели
  "diag",
  // вопрос по «Динамике бизнеса»
  "diag_review",
  // полный разбор «Динамики» (23.10: в пакете дороже — 30 обращений против 15 у вопроса; прокси различает по виду)
  "digest",
  // черновик из дайджеста
  "onboarding",
  // ход интервью первого запуска
  "onboarding_style"
  // разбор транскрипта в профиль стиля
]);
const NO_DASH_RULE = 'NEVER use a dash as punctuation: no "\u2014", no "\u2013", and no lone "-" between words or clauses. That is a tell-tale AI habit and nobody writes that way. Use a comma, a full stop, "..." or just start a new sentence. Hyphens INSIDE words (\u043A\u0442\u043E-\u0442\u043E, \u043F\u043E-\u0440\u0443\u0441\u0441\u043A\u0438, e-mail) are fine.';
const NO_DASH_RULE_TRANSLATE = 'NEVER use a dash as punctuation in the translation: no "\u2014", no "\u2013", and no lone "-" between words or clauses. This holds even when the original text has one: drop it and rewrite that spot with a comma, a full stop or "...". Change the punctuation only, never the wording or the meaning. Hyphens INSIDE words are fine.';
const COACH_MAX_TOKENS = 2048;
AiCore.init({
  getSettings,
  saveSettings,
  bugLog,
  bugProxyFail,
  netFailKind,
  fetchWithTimeout,
  consentGiven,
  consentError,
  DEFAULT_SETTINGS,
  CALL_KINDS,
  NO_DASH_RULE_TRANSLATE,
  BUILD,
  PLATFORM
});
AiCore.initFull({ buildPrompt, parseDialogueResponse, ctxTimeout, buildDossierPrompt });
const BUG_FIELDS = /* @__PURE__ */ new Set([
  "ep",
  "status",
  "code",
  "provider",
  "scan",
  "folders",
  "drift",
  "folderRole",
  "ageMs",
  "pct",
  "usedKb",
  "key",
  "got",
  "exp",
  "name",
  "frame",
  "frame2",
  "n",
  "src",
  "batches",
  "moved",
  "passes"
  // недобор в хранилище: сдвиг ленты и число проходов — по ним видно, листали мы или сайт не отдал
]);
const BUG_ID_FIELDS = ["ep", "status", "code", "provider", "scan", "folderRole", "key", "name", "frame", "frame2", "src"];
let _bugEnabled = false;
const _bugCrumbs = [];
function bugCrumb(code) {
  if (code) {
    _bugCrumbs.push(code);
    if (_bugCrumbs.length > 8) _bugCrumbs.shift();
  }
}
function bugStackFrames(err) {
  const out = { name: err && err.name || "Error" };
  const stack = err && err.stack || "";
  const re = /(?:chrome-extension:\/\/[a-z]+\/)?([\w.-]+\.js):(\d+):(\d+)/g;
  const frames = [];
  let m;
  while ((m = re.exec(stack)) && frames.length < 2) frames.push(`${m[1]}:${m[2]}:${m[3]}`);
  if (frames[0]) out.frame = frames[0];
  if (frames[1]) out.frame2 = frames[1];
  return out;
}
function bugSanitize(fields) {
  const out = {};
  if (fields && typeof fields === "object") {
    for (const k of Object.keys(fields)) {
      if (!BUG_FIELDS.has(k)) continue;
      const v = fields[k];
      if (typeof v === "number" && Number.isFinite(v)) out[k] = v;
      else if (typeof v === "boolean") out[k] = v;
      else if (typeof v === "string") {
        const s = v.replace(/\s+/g, " ").trim().slice(0, 48);
        if (s) out[k] = s;
      }
    }
  }
  return out;
}
function bugSanCrumbs(bc) {
  if (!Array.isArray(bc)) return void 0;
  const out = bc.filter((x) => typeof x === "string").map((x) => x.replace(/\s+/g, "").slice(0, 24)).slice(-8);
  return out.length ? out : void 0;
}
const BUG_NOTE = /* @__PURE__ */ new Set([
  "vault_drift",
  // счётчики каталога разошлись с сайтом — обычное дело, лечится баннером и нажатием
  "proxy_402",
  // месячный пакет исчерпан — это про деньги, а не про поломку
  "storage_quota",
  // хранилище браузера заполняется — предупреждение, а не отказ
  "vault_dupname"
  // два альбома с одним именем завёл сам человек — это состояние его аккаунта, а не наша поломка
]);
let _bugQueue = Promise.resolve();
function bugBufEdit(edit) {
  const step = _bugQueue.then(async () => {
    const buf = await new Promise((r) => chrome.storage.local.get(BUG_BUF_KEY, (d) => r(d[BUG_BUF_KEY] || [])));
    const next = edit(buf);
    await new Promise((r) => chrome.storage.local.set({ [BUG_BUF_KEY]: next }, r));
    return next;
  });
  _bugQueue = step.catch(() => {
  });
  return step;
}
async function bugLog(code, fields, bc, kind) {
  if (!_bugEnabled) return;
  if (!BUG_CODES.has(code)) return;
  const ev = { t: Date.now(), c: code, k: kind || (BUG_NOTE.has(code) ? "note" : "bug"), ...bugSanitize(fields) };
  const crumbs = bugSanCrumbs(bc) || (_bugCrumbs.length ? _bugCrumbs.slice() : void 0);
  if (crumbs) ev.bc = crumbs;
  const buf = await bugBufEdit((buf2) => {
    const last = buf2[buf2.length - 1];
    if (last && last.c === code && last.k === ev.k && BUG_ID_FIELDS.every((f) => last[f] === ev[f]) && ev.t - (last.t || 0) < BUG_THROTTLE_MS && !(_bugSendingTs && _bugSendingTs.has(last.t))) {
      last.n = (last.n || 1) + 1;
      last.t = ev.t;
    } else {
      buf2.push(ev);
      while (buf2.length > BUG_BUF_MAX) buf2.shift();
    }
    return buf2;
  });
  if (buf.length >= BUG_FLUSH_AT) flushBugReports();
}
async function refreshBugEnabled() {
  try {
    const s = await getSettings();
    _bugEnabled = s.bugReportEnabled === true;
  } catch (e) {
  }
}
async function bugDeviceId() {
  const d = await new Promise((r) => chrome.storage.local.get("fansly_device_id", (x) => r(x.fansly_device_id)));
  if (d) return d;
  const id = self.crypto && self.crypto.randomUUID ? self.crypto.randomUUID().replace(/-/g, "").slice(0, 8) : Math.random().toString(16).slice(2, 10);
  await new Promise((r) => chrome.storage.local.set({ fansly_device_id: id }, r));
  return id;
}
async function bugCheckQuota() {
  if (!_bugEnabled || !chrome.storage.local.getBytesInUse) return;
  try {
    const used = await new Promise((r) => chrome.storage.local.getBytesInUse(null, (b) => r(b || 0)));
    const quota = chrome.storage.local.QUOTA_BYTES || 10485760;
    const pct = Math.round(used / quota * 100);
    if (pct >= 80) bugLog("storage_quota", { pct, usedKb: Math.round(used / 1024) });
  } catch (e) {
  }
}
function netFailKind(e) {
  if (e && e.faiConsent) return null;
  if (e && e.name === "AbortError") return { code: "timeout", k: "note" };
  return { code: "fetch", k: "bug" };
}
function bugProxyFail(ep, status, code) {
  if (code === "upstream_saturated") return;
  if (status === 401) bugLog("proxy_401", { ep });
  else if (status === 402) bugLog("proxy_402", { ep });
  else if (code === "all_providers_failed") bugLog("all_providers_failed", { ep });
  else bugLog("net_fail", { ep, status: status || 0, code: code || void 0 });
}
let _bugFlushing = false;
let _bugSendingTs = null;
async function flushBugReports() {
  if (_bugFlushing) return;
  _bugFlushing = true;
  try {
    const s = await getSettings();
    if (s.bugReportEnabled !== true) return;
    if (!s.licenseKey) return;
    const sending = await bugBufEdit((buf) => {
      _bugSendingTs = new Set(buf.map((e) => e.t));
      return buf;
    });
    if (!sending.length) return;
    const sentTs = _bugSendingTs;
    const resp = await AiCore.proxyCall("/v1/report", {
      method: "POST",
      headers: { "Authorization": `Bearer ${s.licenseKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        meta: { version: chrome.runtime.getManifest().version, build: BUILD, platform: PLATFORM, stamp: BUILDSTAMP, device: await bugDeviceId(), ts: Date.now() },
        events: sending
      })
    }, 2e4);
    if (resp && resp.ok) {
      await bugBufEdit((cur) => cur.filter((e) => !sentTs.has(e.t)));
    }
  } catch (e) {
  } finally {
    _bugFlushing = false;
    _bugSendingTs = null;
  }
}
function armBugFlush() {
  if (!chrome.alarms) return;
  chrome.alarms.create(BUG_FLUSH_ALARM, { periodInMinutes: BUG_FLUSH_HOURS * 60, delayInMinutes: 3 });
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === BUG_FLUSH_ALARM) {
    bugCheckQuota();
    flushBugReports();
    AiCore.trCacheSweep().catch(() => {
    });
    AiCore.requestTrial().catch(() => {
    });
    refreshSelectors();
  }
});
const ENDPOINTS_ALARM = "fansly_endpoints_refresh";
function armEndpointsRefresh() {
  if (!chrome.alarms) return;
  chrome.alarms.create(ENDPOINTS_ALARM, { periodInMinutes: 24 * 60, delayInMinutes: 1 });
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ENDPOINTS_ALARM) AiCore.endpointsMaintain().catch(() => {
  });
});
if (typeof self !== "undefined" && self.addEventListener) {
  self.addEventListener("error", (e) => {
    try {
      bugLog("exception", { src: "bg", ...bugStackFrames(e.error) });
    } catch (_) {
    }
  });
  self.addEventListener("unhandledrejection", (e) => {
    try {
      bugLog("exception", { src: "bg", ...bugStackFrames(e.reason) });
    } catch (_) {
    }
  });
}
chrome.runtime.onInstalled.addListener((details) => {
  console.log("[FanslyAI] onInstalled v0.3");
  armBugFlush();
  armEndpointsRefresh();
  refreshBugEnabled();
  purgeTransCacheOnce();
  AiCore.trCacheMigrateOnce();
  mergeCrmNotesOnce();
  seedLikesOnce();
  chrome.storage.local.remove("fansly_ai_log");
  FaiDB.ensureMigrated().catch((e) => console.warn("[FanslyAI] \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u043E\u0442\u043B\u043E\u0436\u0435\u043D\u0430:", e && e.message));
  if (typeof armScheduledScan === "function") armScheduledScan();
  checkVersion();
  if (details && details.reason === "install") armSetupBadge();
});
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(() => {
  armBugFlush();
  armEndpointsRefresh();
  refreshBugEnabled();
  refreshSelectors();
  AiCore.trCacheMigrateOnce();
  FaiDB.ensureMigrated().catch(() => {
  });
  chrome.storage.local.set({ fansly_browser_start: Date.now() });
  if (typeof armScheduledScan === "function") armScheduledScan();
  checkVersion();
  armSetupBadge();
});
function purgeTransCacheOnce() {
  chrome.storage.local.get("fansly_trcache_purged", (d) => {
    if (d.fansly_trcache_purged) return;
    chrome.storage.local.get(null, (all) => {
      const keys = Object.keys(all).filter((k) => k.startsWith("tr_"));
      const done = () => chrome.storage.local.set({ fansly_trcache_purged: 1 });
      if (keys.length) chrome.storage.local.remove(keys, done);
      else done();
    });
  });
}
function seedLikesOnce() {
  chrome.storage.local.get(["fansly_likes_seeded", "fansly_outreach", "fansly_likes"], (d) => {
    if (d.fansly_likes_seeded) return;
    const store = d.fansly_likes || {};
    const writes = CRM.likesSeed(store, d.fansly_outreach || {}) ? { fansly_likes: store } : {};
    writes.fansly_likes_seeded = 1;
    chrome.storage.local.set(writes);
  });
}
function likesFromOutreach(outreach) {
  const s = {};
  return CRM.likesSeed(s, outreach) ? s : null;
}
const PINNED_MAX_BG = 15;
function mergeCrmNotesOnce() {
  chrome.storage.local.get(["fansly_crm_notes_merged", "fansly_crm_notes"], (d) => {
    if (d.fansly_crm_notes_merged) return;
    const notes = d.fansly_crm_notes || {};
    const handles = Object.keys(notes).filter((h) => String(notes[h] || "").trim());
    if (!handles.length) {
      chrome.storage.local.set({ fansly_crm_notes_merged: 1 });
      return;
    }
    chrome.storage.local.get(null, (all) => {
      const byHandle = {};
      for (const k in all) {
        if (!k.startsWith("fai_contact_") || !all[k] || !all[k].handle) continue;
        byHandle[String(all[k].handle).toLowerCase()] = k;
      }
      const writes = { fansly_crm_notes_premerge: notes };
      const leftover = {};
      let moved = 0, orphan = 0;
      for (const h of handles) {
        const key = byHandle[h];
        if (!key) {
          leftover[h] = notes[h];
          orphan++;
          continue;
        }
        const rec = all[key];
        const dz = rec.dossier || (rec.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null });
        if (!dz.facts) dz.facts = [];
        if (!dz.factDates) dz.factDates = {};
        if (!dz.manualFacts) dz.manualFacts = [];
        const lines = String(notes[h]).split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
        for (const line of lines) {
          if (!dz.manualFacts.includes(line)) dz.manualFacts.push(line);
          if (!dz.facts.includes(line)) dz.facts.push(line);
          if (!dz.factDates[line]) dz.factDates[line] = Date.now();
        }
        writes[key] = rec;
        moved++;
      }
      writes.fansly_crm_notes = leftover;
      writes.fansly_crm_notes_merged = 1;
      chrome.storage.local.set(writes, () => {
        console.log(`[FanslyAI] \u0437\u0430\u043C\u0435\u0442\u043A\u0438 \xAB\u0424\u0430\u043D\u043E\u0432\xBB \u0441\u0432\u0435\u0434\u0435\u043D\u044B \u0441 \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u0451\u043D\u043D\u044B\u043C\u0438 \u0444\u0430\u043A\u0442\u0430\u043C\u0438: \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u043E ${moved}, \u0431\u0435\u0437 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430 ${orphan} (\u043A\u043E\u043F\u0438\u044F \u2014 fansly_crm_notes_premerge)`);
      });
    });
  });
}
async function setPinnedFacts(handle, lines) {
  const h = String(handle || "").toLowerCase();
  if (!h) return { success: false, error: "no handle" };
  const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
  const hits = [];
  for (const k in all) {
    if (k.startsWith("fai_contact_") && all[k] && all[k].handle && String(all[k].handle).toLowerCase() === h) hits.push(k);
  }
  if (!hits.length) return { success: false, error: "no contact" };
  if (hits.length > 1) return { success: false, error: "ambiguous handle", keys: hits.length };
  const key = hits[0];
  const wanted = (Array.isArray(lines) ? lines : []).map((s) => String(s).trim()).filter(Boolean);
  const next = wanted.slice(0, PINNED_MAX_BG);
  const ok = await ContactStore.patchRecord(key, (rec) => {
    const dz = rec.dossier || { facts: [], closeness: "new", topics: [], lastMessageAt: null };
    if (!dz.facts) dz.facts = [];
    if (!dz.factDates) dz.factDates = {};
    dz.manualFacts = next;
    for (const f of next) {
      if (!dz.facts.includes(f)) dz.facts.push(f);
      if (!dz.factDates[f]) dz.factDates[f] = Date.now();
    }
    return { dossier: dz };
  });
  if (!ok) return { success: false, error: "no contact" };
  return { success: true, pinned: next.length, dropped: wanted.length - next.length };
}
async function deleteBriefByHandle(handle) {
  const l = String(handle || "").toLowerCase();
  const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
  for (const k in all) {
    if (k.startsWith("fai_contact_") && all[k] && all[k].handle && String(all[k].handle).toLowerCase() === l) {
      await ContactStore.patchRecord(k, { brief: null });
      break;
    }
  }
  return { success: true };
}
function setupLooksDone(s) {
  if (!s) return false;
  if (s.setupCompleted === true) return true;
  return !!(s.licenseKey || s.geminiApiKey || s.openrouterApiKey || s.groqApiKey || s.claudeApiKey || s.deepLApiKey || s.telegramBotToken || (s.creatorName || "").trim());
}
function armSetupBadge() {
  if (!chrome.action) return;
  chrome.storage.local.get("fansly_ai_settings", (d) => {
    const s = d.fansly_ai_settings || {};
    const done = setupLooksDone(s);
    if (done && s.setupCompleted !== true) chrome.storage.local.set({ fansly_ai_settings: { ...s, setupCompleted: true } });
    try {
      chrome.action.setBadgeText({ text: done ? "" : "1" });
      if (!done) {
        chrome.action.setBadgeBackgroundColor({ color: "#e91e8c" });
        chrome.action.setTitle({ title: t("bg.badge.setup.title", s.interfaceLanguage || "ru") });
      }
    } catch (e) {
    }
  });
}
refreshBugEnabled();
function verGt(a, b) {
  const pa = String(a || "").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "").split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return true;
    if ((pa[i] || 0) < (pb[i] || 0)) return false;
  }
  return false;
}
const CONFIG_ORIGIN = "https://velourapp.github.io";
const CONFIG_MAX_BYTES = 65536;
const UPDATE_URL_HOSTS = /* @__PURE__ */ new Set(["velourapp.github.io", "github.com", "objects.githubusercontent.com"]);
async function fetchPinnedJson(url) {
  const r = await fetchWithTimeout(url + "?t=" + Date.now(), { method: "GET", cache: "no-store", credentials: "omit" }, 1e4, BEFORE_CONSENT);
  if (!r.ok) return null;
  try {
    if (new URL(r.url).origin !== CONFIG_ORIGIN) return null;
  } catch (e) {
    return null;
  }
  const text = await r.text();
  if (text.length > CONFIG_MAX_BYTES) return null;
  try {
    return JSON.parse(text);
  } catch (e) {
    return null;
  }
}
const VERSION_URL = "https://velourapp.github.io/version.json";
function validUpdateInfo(d) {
  if (!d || typeof d !== "object" || Array.isArray(d)) return null;
  const version = String((d.version || d.latest) ?? "");
  if (!/^\d{1,4}(\.\d{1,4}){0,3}$/.test(version)) return null;
  let url = "";
  if (typeof d.url === "string" && d.url) {
    try {
      const u = new URL(d.url);
      if (u.protocol === "https:" && UPDATE_URL_HOSTS.has(u.hostname)) url = u.href;
    } catch (e) {
    }
  }
  const notes = typeof d.notes === "string" ? d.notes.replace(/[\u0000-\u001F\u007F]/g, " ").trim().slice(0, 300) : "";
  return { version, url, notes };
}
async function checkVersion() {
  if (chrome.runtime.getManifest().update_url) {
    chrome.storage.local.remove("fansly_update_info");
    return;
  }
  try {
    const info = validUpdateInfo(await fetchPinnedJson(VERSION_URL));
    if (info) chrome.storage.local.set({ fansly_version_checked: { at: Date.now(), latest: info.version } });
    if (info && verGt(info.version, chrome.runtime.getManifest().version))
      chrome.storage.local.set({ fansly_update_info: { version: info.version, url: info.url, notes: info.notes, at: Date.now() } });
    else
      chrome.storage.local.remove("fansly_update_info");
  } catch (e) {
  }
}
checkVersion();
const SELECTORS_URL = "https://velourapp.github.io/selectors.json";
const SEL_MAX_KEYS = 200;
const SEL_MAX_CAND = 8;
const SEL_MAX_LEN = 200;
const SEL_KEY_RE = /^[A-Za-z0-9_]{1,40}$/;
function validSelOverrides(d) {
  if (!d || typeof d !== "object" || Array.isArray(d)) return null;
  const out = {};
  for (const plat of [
    "fansly",
    "onlyfans"
    /*@of-end@*/
  ]) {
    const src = d[plat];
    if (!src || typeof src !== "object" || Array.isArray(src)) continue;
    const dst = {};
    let n = 0;
    for (const key of Object.keys(src)) {
      if (n >= SEL_MAX_KEYS) break;
      if (!SEL_KEY_RE.test(key)) continue;
      const v = src[key];
      const list = (Array.isArray(v) ? v : [v]).filter((s) => typeof s === "string" && s.trim() && s.length <= SEL_MAX_LEN).slice(0, SEL_MAX_CAND);
      if (!list.length) continue;
      dst[key] = list;
      n++;
    }
    if (n) out[plat] = dst;
  }
  return Object.keys(out).length ? out : null;
}
async function fetchSelOverrides() {
  try {
    const raw = await fetchPinnedJson(SELECTORS_URL);
    const clean = validSelOverrides(raw);
    if (clean) chrome.storage.local.set({ fansly_sel_overrides: clean });
    else chrome.storage.local.remove("fansly_sel_overrides");
    const pages = ScanPages.valid(raw);
    if (pages) chrome.storage.local.set({ [ScanPages.KEY]: pages });
    else chrome.storage.local.remove(ScanPages.KEY);
    ScanPages.setOverrides(pages);
    if (raw && typeof raw === "object" && !Array.isArray(raw)) await applyScanOff(validScanOff(raw, chrome.runtime.getManifest().version));
  } catch (e) {
  }
}
let _selFetch = null, _selFetchAt = 0;
function refreshSelectors(maxAgeMs = 6e4) {
  if (_selFetch && Date.now() - _selFetchAt < maxAgeMs) return _selFetch;
  _selFetchAt = Date.now();
  return _selFetch = fetchSelOverrides();
}
refreshSelectors();
const SCAN_OFF_KEY = "fansly_scan_off";
const SCAN_OFF_AREAS = ["subs", "vault", "posts", "earnings", "notifhist", "notif", "broadcast"];
function validScanOff(d, version) {
  const out = {}, off = d && d.off;
  const sec = off && typeof off === "object" && !Array.isArray(off) ? off[PLATFORM] : null;
  if (!sec || typeof sec !== "object" || Array.isArray(sec)) return out;
  for (const a of SCAN_OFF_AREAS) {
    const v = sec[a];
    if (v === "*") out[a] = "*";
    else if (typeof v === "string" && /^\d{1,4}(\.\d{1,4}){0,3}$/.test(v) && verGt(v, version)) out[a] = v;
  }
  return out;
}
async function applyScanOff(off) {
  const prev = await new Promise((r) => chrome.storage.local.get(SCAN_OFF_KEY, (d) => r(d && d[SCAN_OFF_KEY] || {})));
  const next = {}, fresh = [];
  for (const a of Object.keys(off || {})) {
    if (prev[a]) next[a] = Object.assign({}, prev[a], { below: off[a] });
    else {
      next[a] = { below: off[a], at: Date.now(), hidden: false };
      fresh.push(a);
    }
  }
  if (Object.keys(next).length) await new Promise((r) => chrome.storage.local.set({ [SCAN_OFF_KEY]: next }, r));
  else if (Object.keys(prev).length) await new Promise((r) => chrome.storage.local.remove(SCAN_OFF_KEY, r));
  if (!fresh.length) return;
  const lang = (await getSettings()).interfaceLanguage || "ru";
  for (const a of fresh) {
    try {
      await TgCore.notify("status", t(off[a] === "*" ? "scanoff.tg" : "scanoff.tg.old", lang, { page: t("layout.page." + a, lang) }));
    } catch (e) {
    }
  }
}
function scanOffNow(area) {
  return new Promise((r) => {
    try {
      chrome.storage.local.get(SCAN_OFF_KEY, (d) => r(!!(d && d[SCAN_OFF_KEY] && d[SCAN_OFF_KEY][area])));
    } catch (e) {
      r(false);
    }
  });
}
async function scanPageUrl(page) {
  await ScanPages.ready;
  const p = ScanPages.pageOf(page);
  if (!p) return null;
  const handle = p.url.includes("{handle}") ? await new Promise((r) => chrome.storage.local.get("fansly_creator_handle", (d) => r(d && d.fansly_creator_handle))) : null;
  return ScanPages.urlOf(page, { handle });
}
setTimeout(() => {
  try {
    AiCore.requestTrial();
  } catch (e) {
  }
}, 5e3);
const PROTECTED_PAGES_KEY = "fai_protected_pages";
function notePultPage(tabId, page, on) {
  const S = chrome.storage.session;
  if (tabId == null || !page || !S) return;
  S.get(PROTECTED_PAGES_KEY, (d) => {
    const map = d && d[PROTECTED_PAGES_KEY] || {};
    if (on) delete map[tabId];
    else map[tabId] = page;
    S.set({ [PROTECTED_PAGES_KEY]: map });
  });
}
function onPultTabRemoved(tabId) {
  const S = chrome.storage.session;
  if (!S) return;
  S.get(PROTECTED_PAGES_KEY, (d) => {
    const map = d && d[PROTECTED_PAGES_KEY] || {};
    const page = map[tabId];
    if (!page) return;
    delete map[tabId];
    S.set({ [PROTECTED_PAGES_KEY]: map });
    chrome.storage.local.set({ fansly_pult_closed: { page, at: Date.now() } });
  });
}
chrome.tabs.onRemoved.addListener((id) => {
  if (_sched && _sched.running && _sched.tabId === id) {
    _sched.tabId = null;
    chrome.storage.local.set({ fansly_collect_aborted: { at: Date.now(), full: !!_sched.full, step: _sched.step || "" } });
    finishSched();
  }
  onScanTabRemoved(id);
  onPultTabRemoved(id);
});
const PRICING_URL = "https://velourff.com/buy";
const pricingUrl = (tier) => tier === "base" || tier === "pro" ? `${PRICING_URL}?tier=${tier}` : PRICING_URL;
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case "TRANSLATE":
      AiCore.translate(
        request.text,
        request.targetLang,
        request.genderHint,
        request.toGender,
        request.kind,
        false,
        Array.isArray(request.ctx) && request.ctx.length ? request.ctx : null,
        typeof request.fanLang === "string" && request.fanLang ? request.fanLang : null
      ).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TRANSLATE_BATCH":
      AiCore.translateBatch(
        request.texts,
        request.targetLang,
        request.genderHint,
        request.toGender,
        request.cheapOnly === true,
        Array.isArray(request.ctx) && request.ctx.length ? request.ctx : null,
        typeof request.fanLang === "string" && request.fanLang ? request.fanLang : null
      ).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@full-start@*/
    case "GENERATE_SUGGESTIONS":
      AiCore.generate(request.text, request.intent, request.context).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@full-end@*/
    case "GET_SETTINGS":
      getSettings().then((s) => sendResponse({ success: true, result: s }));
      return true;
    // Открыть настройки из КОНТЕНТ-СКРИПТА. Сам он этого не может: chrome.tabs ему недоступен, а
    // options.html не лежит в web_accessible_resources — из-за этого в панели были подсказки словами
    // вместо кнопок (см. humanError в CHANGELOG). Теперь кнопка настоящая.
    // ⚠️ BUILD-NEUTRAL: плашку «ещё не настроено» показывает и переводчик (там она про перевод), значит
    // обработчик нужен обеим сборкам — внутри full-региона кнопка в store молча не делала бы ничего.
    // ⚠️ Вкладку открываем сами, как попап, мастер и онбординг. chrome.runtime.openOptionsPage() здесь не годится:
    // страницы настроек в манифесте нет, и он ВСЕГДА отказывал — промисом, а try/catch вокруг ловил только синхронную
    // ошибку, так что запасной путь не срабатывал и кнопка молчала («Could not create an options page», живая проверка
    // #163 08.10; «Настроить» на плашке «нет ключа» молчала так же с 25.08).
    case "OPEN_OPTIONS":
      chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
      sendResponse({ success: true });
      return true;
    case "ABOUT_INFO":
      bugDeviceId().then((id) => sendResponse({ success: true, deviceId: id, stamp: BUILDSTAMP, build: BUILD }));
      return true;
    /*@full-start@*/
    case "CHECK_VERSION_NOW":
      checkVersion().then(() => chrome.storage.local.get(["fansly_update_info", "fansly_version_checked"], (d) => sendResponse({ success: true, update: d.fansly_update_info || null, checked: d.fansly_version_checked || null })));
      return true;
    /*@full-end@*/
    case "REDEEM_TRIAL_CODE":
      AiCore.requestTrial(String(request.code || "").slice(0, 32)).then((res) => sendResponse(res || { ok: false }));
      return true;
    case "OPEN_TRIAL_PATH":
      AiCore.readTrialState().then((st) => {
        chrome.tabs.create({ url: st && st.closed === "tg" ? "https://t.me/velourmebot" : PRICING_URL });
      });
      sendResponse({ success: true });
      return true;
    case "OPEN_PRICING":
      chrome.tabs.create({ url: pricingUrl(request.tier) });
      sendResponse({ success: true });
      return true;
    case "SAVE_SETTINGS":
      if (request.settings && Object.prototype.hasOwnProperty.call(request.settings, "licenseKey")) AiCore.subPauseClear();
      saveSettings(request.settings, () => {
        armScheduledScan();
        refreshBugEnabled();
        armBugFlush();
        sendResponse({ success: true });
        if (request.settings && request.settings.privacyConsentAt) AiCore.requestTrial();
      });
      return true;
    case "RESET_SETTINGS":
      saveSettings(JSON.parse(JSON.stringify(RESET_SETTINGS)), () => {
        armScheduledScan();
        refreshBugEnabled();
        armBugFlush();
        sendResponse({ success: true, result: Object.keys(RESET_SETTINGS) });
      });
      return true;
    case "REPORT_BUG":
      bugLog(request.code, request.fields, request.bc, request.k);
      return false;
    case "GET_QUOTA":
      AiCore.getQuota(request.force === true).then((q) => sendResponse({ success: true, result: q })).catch(() => sendResponse({ success: true, result: null }));
      return true;
    /*@full-start@*/
    case "FETCH_GEMINI_MODELS":
      fetchGeminiModels(request.apiKey, request.forceRefresh).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@full-end@*/
    /*@full-start@*/
    case "REQUEST_FRAMES_SCAN":
      openFramesScan();
      sendResponse({ success: true });
      return true;
    case "RUN_FULL_COLLECT":
      if (typeof runScheduledScan === "function") runScheduledScan(true, { full: true });
      sendResponse({ success: true });
      return true;
    case "RESUME_FULL_COLLECT":
      if (typeof runScheduledScan === "function") runScheduledScan(true, { full: true, from: request.from || "subs" });
      sendResponse({ success: true });
      return true;
    case "FULL_COLLECT_STATE":
      sendResponse({ success: true, running: !!_sched.running, full: !!_sched.full });
      return true;
    case "RUN_SCHEDULED_SCAN_NOW":
      if (typeof runScheduledScan === "function") runScheduledScan(true);
      sendResponse({ success: true });
      return true;
    /*@full-end@*/
    /*@full-start@*/
    case "ANALYZE_HISTORY":
      AiCore.analyze(request.history, request.fanName, { knownFacts: request.knownFacts, contextTail: request.contextTail, mode: request.mode, manual: request.manual }).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@cws-cut-start@*/
    case "DIAGNOSE_BLOCK":
      diagnoseBlock(request.history, request.fanName).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@cws-cut-end@*/
    case "COACH":
      handleCoach(request.context).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "PANEL_CHAT":
      handlePanelChat(request.context, request.turns).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "DIAG_ASK":
      handleDiagAsk(request.context).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@full-end@*/
    case "SET_PINNED_FACTS":
      setPinnedFacts(request.handle, request.facts).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "GET_ALL_CONTACTS":
      getAllContacts().then((contacts) => sendResponse({ success: true, result: contacts }));
      return true;
    case "IMPORT_DATA":
      importData(request.data, (err) => sendResponse(err ? { success: false, error: err } : { success: true }));
      return true;
    /*@full-start@*/
    case "NOTIFY_TELEGRAM":
      TgCore.notify(request.notifyType, request.text, request.token, request.chatId, request.fan, request.variantCount, request.handle, !!request.preDeduped, { single: request.single === true, draft: request.draft, task: request.task, again: request.again === true }).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TG_POLL":
      TgCore.poll(sender.tab?.id || null, request.caps).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TG_ACK":
      TgCore.ack(request.pid, request.ok === true).then(() => sendResponse({ success: true })).catch(() => sendResponse({ success: false }));
      return true;
    case "PULT_DISCARDABLE":
      if (sender.tab?.id != null) chrome.tabs.update(sender.tab.id, { autoDiscardable: !!request.on }, () => void chrome.runtime.lastError);
      notePultPage(sender.tab?.id, request.page, !!request.on);
      sendResponse({ success: true });
      return true;
    /*@full-end@*/
    /*@full-start@*/
    case "TG_CLAIM_INVITE":
      TgCore.claimInvite(request.fan, sender.tab?.id || null);
      sendResponse({ success: true });
      return true;
    case "TG_UNCLAIM_INVITE":
      TgCore.unclaimInvite();
      sendResponse({ success: true });
      return true;
    case "START_INVITE":
      startInviteFlow(request.handle);
      sendResponse({ success: true });
      return true;
    case "CLOSE_TAB":
      if (sender.tab?.id) chrome.tabs.remove(sender.tab.id, () => void chrome.runtime.lastError);
      sendResponse({ success: true });
      return true;
    case "SCAN_NOTIFICATIONS":
      scanNotificationsTab();
      sendResponse({ success: true });
      return true;
    case "REQUEST_FULL_VAULT_SCAN":
      openFullVaultScan();
      sendResponse({ success: true });
      return true;
    case "VAULT_ZOOM": {
      const zTab = sender.tab && sender.tab.id != null ? sender.tab.id : null;
      if (zTab == null) {
        sendResponse({ success: false });
        return true;
      }
      vaultZoom(zTab, request.factor || 1).then(() => sendResponse({ success: true }));
      return true;
    }
    case "REQUEST_BROADCAST_SCAN":
      openBroadcastScan();
      sendResponse({ success: true });
      return true;
    case "TODAY_LIST":
      buildTodayList(request.limit || 20).then((items) => sendResponse({ success: true, items })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TODO_ADVICE":
      handleTodoAdvice(request.context || {}).then(sendResponse).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "DELETE_BRIEF":
      deleteBriefByHandle(request.handle).then((r) => sendResponse(r)).catch(() => sendResponse({ success: false }));
      return true;
    case "SCHEDULED_SCAN_FAILED":
    // шаг упал (отчёт уже ушёл из вкладки): «Собрать всё» встаёт с плашкой «шаг не удался»
    case "SCHEDULED_SCAN_STOPPED":
      if (onSchedStepHalted(sender, request.scanType, request.type === "SCHEDULED_SCAN_STOPPED" ? "stopped" : "failed")) {
        sendResponse({ success: true });
        return true;
      }
    // не её случай (периодика, поздний доклад, цепочки нет) — дальше как «готово»: провал в следующую ветку намеренный
    case "SCHEDULED_SCAN_DONE":
      if (!_sched.running) {
        clearTimeout(_sched.watchdog);
        if (sender.tab?.id) chrome.tabs.remove(sender.tab.id, () => void chrome.runtime.lastError);
        _sched.tabId = null;
        sendResponse({ success: true });
        return true;
      }
      if (request.scanType && _sched.step && request.scanType !== _sched.step) {
        sendResponse({ success: true });
        return true;
      }
      clearTimeout(_sched.watchdog);
      if (sender.tab?.id) _sched.tabId = sender.tab.id;
      {
        const nx = nextSchedStep(request.scanType);
        if (nx) openSchedTab(nx);
        else finishSched();
      }
      sendResponse({ success: true });
      return true;
    /*@full-end@*/
    /*@full-start@*/
    case "TG_DETECT_CHAT":
      TgCore.detectChat(request.token).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TG_SETUP_TOPICS":
      TgCore.setupTopics(request.token, request.chatId, { wizard: request.wizard === true }).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TG_VALIDATE_BOT":
      TgCore.validateBot(request.token).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TG_VERIFY_SETUP":
      TgCore.verifySetup(request.token).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "TG_SETUP_ACTIVE":
      TgCore.setSetupActive(request.on).then(() => sendResponse({ success: true }));
      return true;
    case "TG_HOLD_CONFIRM":
      TgCore.confirmHold(request.ids).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    /*@full-end@*/
    /*@full-start@*/
    case "ONBOARDING_CHAT":
      handleOnboardingChat(request.messages, request.system).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "ONBOARDING_EXTRACT":
      handleOnboardingExtract(request.messages, request.extractPrompt, request.transcript).then((r) => sendResponse(r)).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "OPEN_ONBOARDING_REALDIALOG":
      chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html?mode=realdialog") });
      sendResponse({ success: true });
      return true;
    // ── Inventory: превью-тумбы каталога живут в IndexedDB РАСШИРЕНИЯ (не storage.local — большие, и
    // не забивают get(null)). Контент-скрипт на fansly.com не видит наш IDB → шлёт dataURL сюда батчами;
    // catalog.html (тот же extension-origin) читает IDB напрямую. См. content.js syncVault / catalog.js.
    case "CATALOG_THUMB_PUT":
      catalogThumbPut(request.items || []).then(() => sendResponse({ success: true })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    // ── Кадры видео: снимает контент-скрипт на странице хранилища, размечает вкладка каталога ──
    // Кадры — расходник, живут до разметки. Одно сообщение = один ролик (≤12 кадров ≈ ≤1 МБ):
    // граница транзакции совпадает с границей возобновляемости.
    case "CATALOG_FRAME_PUT":
      FaiDB.ensureMigrated().then(() => FaiDB.framePut(request.items || [])).then((n) => sendResponse({ success: true, n })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_VIDEO_LIST":
      FaiDB.ensureMigrated().then(() => FaiDB.videoList()).then((items) => sendResponse({ success: true, items })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    // ── Метаданные каталога для контент-скрипта (у сайта нет доступа к нашей IndexedDB) ──
    // ⚠️ Ответ ОБЯЗАН проверяться на той стороне: молчаливый null здесь = потерянная разметка,
    //    в отличие от превью (те восстановимы пересканом). См. sendMeta в content.js.
    case "CATALOG_META_PATCH":
      FaiDB.ensureMigrated().then(() => FaiDB.metaPatch(request.patches || [])).then((n) => sendResponse({ success: true, n })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_META_GET":
      FaiDB.ensureMigrated().then(() => FaiDB.metaGet(request.ids || [])).then((items) => sendResponse({ success: true, items })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_META_IDS":
      FaiDB.ensureMigrated().then(() => FaiDB.metaIds()).then((ids) => sendResponse({ success: true, ids })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_META_COUNT":
      FaiDB.ensureMigrated().then(() => FaiDB.metaCount()).then((count) => sendResponse({ success: true, count })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_META_COUNTS":
      FaiDB.ensureMigrated().then(() => FaiDB.metaFolderCounts(request.lastFull || 0)).then((r) => sendResponse({ success: true, total: r.total, per: r.per })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_META_GAPS":
      FaiDB.ensureMigrated().then(() => FaiDB.promoteFrameThumbs()).then((r) => {
        if (r && r.promoted) console.log("[FanslyAI] \u043F\u0440\u0435\u0432\u044C\u044E \u0438\u0437 \u043A\u0430\u0434\u0440\u043E\u0432:", r.promoted);
        return FaiDB.metaThumbGapFolders();
      }).then((folders) => sendResponse({ success: true, folders })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CATALOG_META_UNTAG":
      FaiDB.ensureMigrated().then(() => FaiDB.metaUntagFolder(request.folder, request.keepIds || [])).then((changed) => sendResponse({ success: true, changed })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    // Папки, исчезнувшие с сайта (удалили/переименовали), после ПОЛНОГО прохода. Обойти несуществующую
    // папку нельзя, поэтому её тег иначе жил бы в каталоге вечно.
    case "CATALOG_FOLDERS_SWEEP":
      FaiDB.ensureMigrated().then(() => FaiDB.metaUntagMissingFolders(request.keep || [])).then((r) => sendResponse({ success: true, touched: r.touched, dropped: r.dropped })).catch((e) => sendResponse({ success: false, error: e.message }));
      return true;
    case "CRM_OPEN":
      chrome.tabs.create({ url: chrome.runtime.getURL("crm.html" + (request.handle ? "?handle=" + encodeURIComponent(request.handle) : "")) });
      sendResponse({ success: true });
      return true;
    case "DIAG_OPEN":
      chrome.tabs.create({ url: chrome.runtime.getURL("diag.html") });
      sendResponse({ success: true });
      return true;
    case "REQUEST_TARGETED_VAULT_SCAN":
      openTargetedVaultScan("offer");
      sendResponse({ success: true });
      return true;
    case "REQUEST_QUICK_VAULT_SCAN":
      openTargetedVaultScan("catalogQuick");
      sendResponse({ success: true });
      return true;
    case "TARGETED_VAULT_DONE":
      onTargetedVaultDone(sender, request.stopped === true);
      sendResponse({ success: true });
      return true;
    case "FRAMES_SCAN_DONE":
      onFramesScanDone(sender);
      sendResponse({ success: true });
      return true;
    case "SCAN_AUTH_LOST":
      onScanAuthLost(sender, request.page);
      sendResponse({ success: true });
      return true;
    case "SCAN_TAB_QUERY":
      scanTabQuery(sender).then((r) => sendResponse(r)).catch(() => sendResponse({ success: false, scanTab: false }));
      return true;
    // Плашка рабочей панели «Пульт включён, но сейчас не работает» → «Открыть вкладку пульта» (09.10, Алекс). Зеркало кнопки
    // пульта «Открыть вкладку для общения»: новая /messages открывается В ФОНЕ, человек остаётся в рабочей вкладке. Номер
    // новой вкладки запоминаем: она спросит при запуске (PULT_OPEN_CHECK) и станет пультом, даже если человек на неё
    // переключился, — по одному правилу «пульт забирает скрытая» его увела бы рабочая, ставшая скрытой (живая проверка 09.10).
    // Существующие не ищем: скрытая /messages-вкладка, будь она, уже забрала бы пульт сама.
    case "OPEN_PULT_TAB":
      chrome.tabs.create({ url: WORK_TAB_URL, active: false }, (tab) => {
        void chrome.runtime.lastError;
        if (tab && chrome.storage.session) chrome.storage.session.set({ fai_pult_open: { tabId: tab.id, at: Date.now() } });
      });
      sendResponse({ success: true });
      return true;
    case "PULT_OPEN_CHECK":
      if (!chrome.storage.session || sender.tab?.id == null) {
        sendResponse({ yes: false });
        return true;
      }
      chrome.storage.session.get("fai_pult_open", (d) => {
        const o = d && d.fai_pult_open;
        const yes = !!(o && o.tabId === sender.tab.id && Date.now() - o.at < 12e4);
        if (yes) chrome.storage.session.remove("fai_pult_open");
        sendResponse({ yes });
      });
      return true;
    // «/ur» в общем чате ТГ (todo #49, шаг 10; «делай сам» Алекса 14.10): отчёты о прочтении для всех разговоров меняются на
    // странице настроек Fansly, а вкладку пульта с переписки уводить нельзя — открываем отдельную вкладку В ФОНЕ под разовое
    // задание пульта. Адрес зашит: открыть этим сообщением что-то другое нельзя. Номер вкладки запоминаем: она спросит при
    // запуске (SETTINGS_JOB_QUERY) и получит «да» — только она и только две минуты; человек, сам зашедший в настройки,
    // получит «нет», и на его вкладке ничего не произойдёт. Само задание и его итог лежат в storage.local (ключ
    // fansly_tg_setjob, content.js: tgCmdUnreadAll / settingsJobRun); закрывает себя вкладка сама — прежним CLOSE_TAB.
    case "OPEN_SETTINGS_JOB":
      if (!chrome.storage.session) {
        sendResponse({ success: false });
        return true;
      }
      chrome.tabs.create({ url: "https://fansly.com/settings/privacy", active: false }, (tab) => {
        void chrome.runtime.lastError;
        if (!tab) {
          sendResponse({ success: false });
          return;
        }
        chrome.storage.session.set({ fai_setjob_tab: { tabId: tab.id, at: Date.now() } }, () => sendResponse({ success: true }));
      });
      return true;
    case "SETTINGS_JOB_QUERY":
      if (!chrome.storage.session || sender.tab?.id == null) {
        sendResponse({ mine: false });
        return true;
      }
      chrome.storage.session.get("fai_setjob_tab", (d) => {
        const o = d && d.fai_setjob_tab;
        sendResponse({ mine: !!(o && o.tabId === sender.tab.id && Date.now() - o.at < 12e4) });
      });
      return true;
    /*@full-end@*/
    case "OPEN_WORK_TAB":
      openWorkTab(sender.tab?.id ?? null).then((r) => sendResponse(r));
      return true;
    // ── Приватность: стирание данных (build-neutral — есть кеш переписки и в store) ──
    case "WIPE_FAN_DATA":
      (async () => {
        const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
        const KILL = ["fansly_ai_log", "fansly_earnings", "fansly_subs", "fansly_ledger", "fansly_purchases", "fansly_outreach", "fansly_outreach_done", "fansly_likes", "fansly_msg_ts", "fansly_mirror_since", "fansly_crm_notes", "fansly_todo_drafts", "fansly_todo_ack", "fansly_row_mirrored", "fansly_row_last", "fansly_tg_fan_ctx"];
        const keys = Object.keys(all).filter((k) => KILL.includes(k) || k.startsWith("fai_contact_") || k.startsWith("tr_"));
        if (keys.length) await new Promise((r) => chrome.storage.local.remove(keys, r));
        if (all.fansly_tg_topics && all.fansly_tg_topics.fans) {
          const tp = all.fansly_tg_topics;
          tp.fans = {};
          await new Promise((r) => chrome.storage.local.set({ fansly_tg_topics: tp }, r));
        }
        sendResponse({ success: true, removed: keys.length });
      })();
      return true;
    case "WIPE_ALL":
      (async () => {
        try {
          await FaiDB.deleteDatabase();
        } catch (e) {
          sendResponse({ success: false, error: e.message || "idb_blocked" });
          return;
        }
        const KEEP = ["fansly_ai_settings", "fansly_device_id"];
        const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
        const keys = Object.keys(all).filter((k) => !KEEP.includes(k));
        if (keys.length) await new Promise((r) => chrome.storage.local.remove(keys, r));
        sendResponse({ success: true, removed: keys.length });
      })();
      return true;
    case "DELETE_FAN":
      (async () => {
        const h = (request.handle || "").toLowerCase();
        const name = request.name || "";
        const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
        const removeKeys = [], setObj = {};
        for (const k in all) {
          if (!k.startsWith("fai_contact_") || !all[k]) continue;
          const rec = all[k];
          if (request.contactId != null && k === "fai_contact_" + request.contactId || h && rec.handle && rec.handle.toLowerCase() === h) removeKeys.push(k);
        }
        const rowMap = all.fansly_row_mirrored;
        if (rowMap && request.contactId != null && rowMap[String(request.contactId)]) {
          delete rowMap[String(request.contactId)];
          setObj.fansly_row_mirrored = rowMap;
        }
        const rowLast = all.fansly_row_last;
        if (rowLast && request.contactId != null && rowLast[String(request.contactId)]) {
          delete rowLast[String(request.contactId)];
          setObj.fansly_row_last = rowLast;
        }
        for (const store of ["fansly_subs", "fansly_purchases", "fansly_outreach", "fansly_outreach_done", "fansly_likes", "fansly_crm_notes", "fansly_ledger"]) {
          const o = all[store];
          if (!o || typeof o !== "object") continue;
          let ch = false;
          for (const key in o) if (h && key.toLowerCase() === h) {
            delete o[key];
            ch = true;
          }
          if (ch) setObj[store] = o;
        }
        if (all.fansly_earnings && typeof all.fansly_earnings === "object" && h) {
          const e = all.fansly_earnings;
          let ch = false;
          for (const oid in e) {
            const b = (e[oid] && e[oid].buyer || "").toLowerCase();
            if (b && b === h) {
              delete e[oid];
              ch = true;
            }
          }
          if (ch) setObj.fansly_earnings = e;
        }
        for (const store of ["fansly_todo_drafts", "fansly_todo_ack"]) {
          const o = all[store];
          if (!o || typeof o !== "object") continue;
          let ch = false;
          for (const key in o) if (h && key.toLowerCase().startsWith(h + "|")) {
            delete o[key];
            ch = true;
          }
          if (ch) setObj[store] = o;
        }
        const fanTid = all.fansly_tg_topics && all.fansly_tg_topics.fans && name ? all.fansly_tg_topics.fans[name] : null;
        if (fanTid != null && all.fansly_tg_fan_ctx && all.fansly_tg_fan_ctx.threads && all.fansly_tg_fan_ctx.threads[fanTid]) {
          const fc = all.fansly_tg_fan_ctx;
          delete fc.threads[fanTid];
          setObj.fansly_tg_fan_ctx = fc;
        }
        if (all.fansly_tg_topics && all.fansly_tg_topics.fans && name && all.fansly_tg_topics.fans[name] != null) {
          const tp = all.fansly_tg_topics;
          delete tp.fans[name];
          setObj.fansly_tg_topics = tp;
        }
        if (removeKeys.length) await new Promise((r) => chrome.storage.local.remove(removeKeys, r));
        if (Object.keys(setObj).length) await new Promise((r) => chrome.storage.local.set(setObj, r));
        sendResponse({ success: true, removed: removeKeys.length });
      })();
      return true;
  }
});
async function catalogThumbPut(items) {
  await FaiDB.ensureMigrated();
  return FaiDB.thumbPut(items || []);
}
async function startInviteFlow(handle) {
  if (!handle) return;
  await new Promise((r) => chrome.storage.local.set({ fansly_pending_invite: { handle, at: Date.now() } }, () => r()));
  const d = await new Promise((r) => chrome.storage.local.get(["fansly_outreach", "fansly_outreach_done"], (x) => r(x)));
  const store = d.fansly_outreach || {};
  const done = d.fansly_outreach_done || {};
  delete store[handle];
  done[handle] = Date.now();
  await new Promise((r) => chrome.storage.local.set({ fansly_outreach: store, fansly_outreach_done: done }, () => r()));
  try {
    chrome.tabs.create({ url: "https://fansly.com/" + handle, active: true });
  } catch (e) {
  }
}
let _notifScanAt = 0;
async function scanNotificationsTab() {
  if (!await consentGiven()) return;
  if (await scanOffNow("notif")) return;
  if (Date.now() - _notifScanAt < 25e3) return;
  _notifScanAt = Date.now();
  const url = await scanPageUrl("notifications");
  if (!url) return;
  const tabs = await new Promise((r) => chrome.tabs.query({ url: url.replace(/^https:/, "*:") + "*" }, (t2) => r(t2 || [])));
  if (tabs.length) {
    for (const tab of tabs) {
      if (await tabScanBusy(tab.id)) continue;
      try {
        chrome.tabs.reload(tab.id);
      } catch (e) {
      }
      return;
    }
    console.log("[FanslyAI] \u{1F514} \u043B\u0451\u0433\u043A\u0438\u0439 \u0441\u043A\u0430\u043D \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D: \u0432\u043E \u0432\u043A\u043B\u0430\u0434\u043A\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439 \u0438\u0434\u0451\u0442 \u0441\u0431\u043E\u0440, \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0435\u0433\u043E \u043E\u0431\u043E\u0440\u0432\u0430\u043B\u0430 \u0431\u044B");
    return;
  }
  await new Promise((r) => chrome.storage.local.set({ fansly_notif_scan: true }, () => r()));
  try {
    chrome.tabs.create({ url, active: false });
  } catch (e) {
  }
}
function tabScanBusy(tabId) {
  return new Promise((r) => {
    const late = setTimeout(() => r(false), 1500);
    try {
      chrome.tabs.sendMessage(tabId, { type: "SCAN_BUSY" }, (x) => {
        void chrome.runtime.lastError;
        clearTimeout(late);
        r(!!(x && x.busy));
      });
    } catch (e) {
      clearTimeout(late);
      r(false);
    }
  });
}
const SCHED_ALARM = "faiScheduledScan";
const SCHED_CHAIN = { subs: "vault", vault: "posts", posts: "earnings", earnings: null };
const SCHED_CHAIN_FULL = { subs: "vault", vault: "posts", posts: "earnings", earnings: "notifhist", notifhist: null };
const nextSchedStep = (type) => (_sched.full ? SCHED_CHAIN_FULL : SCHED_CHAIN)[type];
let _sched = { running: false, full: false, tabId: null, prevTab: null, watchdog: null };
async function armScheduledScan() {
  if (!chrome.alarms) return;
  try {
    await chrome.alarms.clear(SCHED_ALARM);
  } catch (e) {
  }
  if (PLATFORM !== "fansly") return;
  const s = await getSettings();
  if (!s.scheduledScanEnabled) return;
  const hours = Math.max(1, parseInt(s.scheduledScanHours, 10) || 1);
  const first = await new Promise((r) => chrome.storage.local.get("fansly_sched_ever", (d) => r(d.fansly_sched_ever))) ? hours * 60 : 2;
  chrome.alarms.create(SCHED_ALARM, { periodInMinutes: hours * 60, delayInMinutes: first });
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === SCHED_ALARM) runScheduledScan();
});
async function runScheduledScan(manual = false, opts = {}) {
  if (_sched.running || PLATFORM !== "fansly") return;
  const s = await getSettings();
  if (!manual && !s.scheduledScanEnabled) return;
  chrome.storage.local.set({ fansly_sched_ever: Date.now() });
  if (!manual && s.masterEnabled === false) return;
  if (opts.full) chrome.storage.local.remove("fansly_collect_aborted");
  _sched.running = true;
  _sched.full = !!opts.full;
  _sched.prevTab = await new Promise((r) => chrome.tabs.query({ active: true, lastFocusedWindow: true }, (t2) => r(t2?.[0]?.id || null)));
  await refreshSelectors(10 * 6e4);
  openSchedTab(opts.from || "subs");
}
async function openSchedTab(type) {
  if (await scanOffNow(type)) {
    console.log("[FanslyAI] \u0441\u043A\u0430\u043D \xAB" + type + "\xBB \u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D (selectors.json) \u2014 \u0448\u0430\u0433 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D");
    const nx = nextSchedStep(type);
    if (nx) openSchedTab(nx);
    else finishSched();
    return;
  }
  const url = await scanPageUrl(type === "notifhist" ? "notifications" : type);
  if (!url) {
    const nx = nextSchedStep(type);
    if (nx) {
      openSchedTab(nx);
      return;
    }
    finishSched();
    return;
  }
  console.log("[FanslyAI] \u0448\u0430\u0433 \xAB" + type + "\xBB \u2192 " + url);
  await new Promise((r) => chrome.storage.local.set({ fansly_scheduled_scan: { type, at: Date.now(), full: !!_sched.full, chain: true } }, r));
  _sched.step = type;
  if (_sched.tabId != null) {
    try {
      await chrome.tabs.update(_sched.tabId, { url });
    } catch (e) {
      _sched.tabId = null;
    }
  }
  if (_sched.tabId == null) {
    try {
      const tab = await chrome.tabs.create({ url, active: !!_sched.full });
      _sched.tabId = tab.id;
    } catch (e) {
      finishSched();
      return;
    }
  }
  clearTimeout(_sched.watchdog);
  _sched.watchdog = setTimeout(() => {
    bugLog("sync_timeout", { scan: type });
    const nx = nextSchedStep(type);
    nx ? openSchedTab(nx) : finishSched();
  }, (_sched.full ? 45 : 6) * 6e4);
}
function closeSchedTab() {
  if (_sched.tabId) {
    chrome.tabs.remove(_sched.tabId, () => void chrome.runtime.lastError);
    _sched.tabId = null;
  }
}
async function finishSched() {
  clearTimeout(_sched.watchdog);
  closeSchedTab();
  try {
    await chrome.storage.local.remove("fansly_scheduled_scan");
  } catch (e) {
  }
  if (_sched.prevTab) chrome.tabs.update(_sched.prevTab, { active: true }, () => void chrome.runtime.lastError);
  _sched = { running: false, full: false, tabId: null, prevTab: null, watchdog: null };
}
async function openFullVaultScan() {
  if (PLATFORM !== "fansly" || await scanOffNow("vault")) return;
  const url = await scanPageUrl("vault");
  if (!url) return;
  await new Promise((r) => chrome.storage.local.set({ fansly_scheduled_scan: { type: "vault", full: true, at: Date.now() } }, r));
  try {
    chrome.tabs.create({ url, active: true });
  } catch (e) {
  }
}
const SCAN_SESS = chrome.storage && chrome.storage.session || null;
const K_TARGETED = "fai_targeted_vault", K_FRAMES = "fai_frames_tab", K_ZOOM = "fai_zoom_back";
const TARGETED_ALARM = "faiTargetedVaultWatch", FRAMES_ALARM = "faiFramesWatch";
const sessGet = (key) => new Promise((r) => {
  if (!SCAN_SESS) return r(void 0);
  try {
    SCAN_SESS.get(key, (d) => {
      void chrome.runtime.lastError;
      r(d ? d[key] : void 0);
    });
  } catch (e) {
    r(void 0);
  }
});
const sessPut = (key, val) => new Promise((r) => {
  if (!SCAN_SESS) return r();
  const done = () => {
    void chrome.runtime.lastError;
    r();
  };
  try {
    if (val == null) SCAN_SESS.remove(key, done);
    else SCAN_SESS.set({ [key]: val }, done);
  } catch (e) {
    r();
  }
});
const armWatch = (name, minutes) => {
  try {
    chrome.alarms.create(name, { delayInMinutes: minutes });
  } catch (e) {
  }
};
const disarmWatch = (name) => {
  try {
    chrome.alarms.clear(name, () => void chrome.runtime.lastError);
  } catch (e) {
  }
};
const _zoomBack = /* @__PURE__ */ new Map();
const saveZoomBack = () => sessPut(K_ZOOM, _zoomBack.size ? Object.fromEntries(_zoomBack) : null);
let _framesTab = { tabId: null, prevTab: null };
let _targetedVault = { tabId: null, prevTab: null, stage: null };
const saveFrames = () => sessPut(K_FRAMES, _framesTab.tabId != null ? _framesTab : null);
const saveTargeted = () => sessPut(K_TARGETED, _targetedVault.tabId != null ? _targetedVault : null);
let _scanStateReady = null;
function scanStateReady() {
  if (!_scanStateReady) _scanStateReady = (async () => {
    const [tv, fr, zb] = await Promise.all([sessGet(K_TARGETED), sessGet(K_FRAMES), sessGet(K_ZOOM)]);
    if (tv && tv.tabId != null && _targetedVault.tabId == null) _targetedVault = { tabId: tv.tabId, prevTab: tv.prevTab ?? null, stage: tv.stage || null };
    if (fr && fr.tabId != null && _framesTab.tabId == null) _framesTab = { tabId: fr.tabId, prevTab: fr.prevTab ?? null };
    if (zb) {
      for (const id of Object.keys(zb)) if (!_zoomBack.has(+id)) _zoomBack.set(+id, zb[id]);
    }
  })().catch(() => {
  });
  return _scanStateReady;
}
scanStateReady();
async function vaultZoom(zTab, zFactor) {
  try {
    await scanStateReady();
    if (zFactor > 0 && zFactor < 1) {
      if (!_zoomBack.has(zTab)) {
        const zoom = await chrome.tabs.getZoom(zTab).catch(() => 1);
        const zs = await chrome.tabs.getZoomSettings(zTab).catch(() => null);
        _zoomBack.set(zTab, { zoom: zoom || 1, scope: zs && zs.scope || "automatic" });
        await saveZoomBack();
      }
      await chrome.tabs.setZoomSettings(zTab, { scope: "per-tab" }).catch(() => {
      });
      await chrome.tabs.setZoom(zTab, zFactor).catch(() => {
      });
    } else {
      const back = _zoomBack.get(zTab);
      if (_zoomBack.delete(zTab)) await saveZoomBack();
      await chrome.tabs.setZoomSettings(zTab, { scope: back && back.scope || "automatic" }).catch(() => {
      });
      if (back && back.scope === "per-tab") await chrome.tabs.setZoom(zTab, back.zoom || 1).catch(() => {
      });
    }
  } catch (e) {
  }
}
async function onScanTabRemoved(id) {
  await scanStateReady();
  if (_zoomBack.delete(id)) saveZoomBack();
  if (_targetedVault.tabId === id) {
    _targetedVault.tabId = null;
    closeTargetedVault();
  }
  if (_framesTab.tabId === id) {
    _framesTab.tabId = null;
    closeFramesTab();
  }
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== TARGETED_ALARM && a.name !== FRAMES_ALARM) return;
  await scanStateReady();
  if (a.name === TARGETED_ALARM) closeTargetedVault();
  else closeFramesTab();
});
async function openFramesScan() {
  if (PLATFORM !== "fansly" || await scanOffNow("vault")) return;
  await scanStateReady();
  if (_framesTab.tabId != null) {
    const alive = await new Promise((r) => chrome.tabs.get(_framesTab.tabId, (tb) => {
      void chrome.runtime.lastError;
      r(!!tb);
    }));
    if (alive) return;
    closeFramesTab();
  }
  _framesTab.prevTab = await new Promise((r) => chrome.tabs.query({ active: true, lastFocusedWindow: true }, (t2) => r(t2?.[0]?.id || null)));
  const url = await scanPageUrl("vault");
  if (!url) return;
  await new Promise((r) => chrome.storage.local.set({ fansly_scheduled_scan: { type: "frames", at: Date.now() } }, r));
  try {
    const tab = await chrome.tabs.create({ url, active: true });
    _framesTab.tabId = tab.id;
  } catch (e) {
    _framesTab.tabId = null;
    return;
  }
  await saveFrames();
  armWatch(FRAMES_ALARM, 60);
}
async function onFramesScanDone(sender) {
  await scanStateReady();
  if (_framesTab.tabId == null && sender && sender.tab && sender.tab.id != null) _framesTab.tabId = sender.tab.id;
  closeFramesTab();
}
function closeFramesTab(keepTab = false) {
  disarmWatch(FRAMES_ALARM);
  const { tabId, prevTab } = _framesTab;
  _framesTab = { tabId: null, prevTab: null };
  saveFrames();
  if (keepTab) return;
  if (tabId != null) chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);
  if (prevTab != null) chrome.tabs.update(prevTab, { active: true }, () => void chrome.runtime.lastError);
}
async function openTargetedVaultScan(trigger) {
  if (PLATFORM !== "fansly" || await scanOffNow("vault")) return;
  const url = await scanPageUrl("vault");
  if (!url) return;
  await scanStateReady();
  if (_targetedVault.tabId != null) {
    const alive = await new Promise((r) => chrome.tabs.get(_targetedVault.tabId, (tb) => {
      void chrome.runtime.lastError;
      r(!!tb);
    }));
    if (alive) return;
    closeTargetedVault();
  }
  _targetedVault.prevTab = await new Promise((r) => chrome.tabs.query({ active: true, lastFocusedWindow: true }, (t2) => r(t2?.[0]?.id || null)));
  await new Promise((r) => chrome.storage.local.set({ fansly_vault_targeted: { trigger, quick: trigger === "catalogQuick", at: Date.now() } }, r));
  _targetedVault.stage = "vault";
  try {
    const tab = await chrome.tabs.create({ url, active: true });
    _targetedVault.tabId = tab.id;
  } catch (e) {
    _targetedVault.tabId = null;
    return;
  }
  await saveTargeted();
  armWatch(TARGETED_ALARM, trigger === "catalogQuick" ? 20 : 45);
}
async function targetedVaultNextPosts() {
  const url = await scanPageUrl("posts");
  if (!url || _targetedVault.tabId == null) return false;
  await new Promise((r) => chrome.storage.local.set({ fansly_scheduled_scan: { type: "posts", full: false, after: "vault", at: Date.now() } }, r));
  try {
    await chrome.tabs.update(_targetedVault.tabId, { url });
  } catch (e) {
    return false;
  }
  _targetedVault.stage = "posts";
  await saveTargeted();
  armWatch(TARGETED_ALARM, 10);
  return true;
}
async function onTargetedVaultDone(sender, stopped) {
  await scanStateReady();
  const tab = sender && sender.tab;
  if (_targetedVault.tabId == null && tab && tab.id != null) {
    const url = tab.url || "";
    const stage = /\/creator\/vault/.test(url) ? "vault" : /\/posts(\/|$|\?)/.test(url) ? "posts" : null;
    if (!stage) return;
    _targetedVault = { tabId: tab.id, prevTab: null, stage };
  }
  if (_targetedVault.stage === "vault" && !stopped) {
    const ok = await targetedVaultNextPosts();
    if (!ok) closeTargetedVault();
  } else closeTargetedVault();
}
function closeTargetedVault(keepTab = false) {
  try {
    chrome.storage.local.remove("fansly_vault_targeted");
  } catch (e) {
  }
  if (_targetedVault.stage === "posts") {
    try {
      chrome.storage.local.remove("fansly_scheduled_scan");
    } catch (e) {
    }
  }
  disarmWatch(TARGETED_ALARM);
  const { tabId, prevTab } = _targetedVault;
  _targetedVault = { tabId: null, prevTab: null, stage: null };
  saveTargeted();
  if (keepTab) return;
  if (tabId != null) chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);
  if (prevTab != null) chrome.tabs.update(prevTab, { active: true }, () => void chrome.runtime.lastError);
}
async function onScanAuthLost(sender, page) {
  await scanStateReady();
  const tabId = sender && sender.tab && sender.tab.id != null ? sender.tab.id : null;
  await new Promise((r) => chrome.storage.local.set({ fansly_auth_lost: { at: Date.now(), page: String(page || "").slice(0, 24) } }, r));
  if (tabId == null) return;
  if (_targetedVault.tabId === tabId) {
    closeTargetedVault(true);
    return;
  }
  if (_framesTab.tabId === tabId) {
    closeFramesTab(true);
    return;
  }
  if (_sched.running && _sched.tabId === tabId) {
    if (_sched.full) {
      chrome.storage.local.set({ fansly_collect_aborted: { at: Date.now(), full: true, step: _sched.step || "", reason: "auth" } });
      _sched.tabId = null;
      _sched.prevTab = null;
    }
    finishSched();
  }
}
function onSchedStepHalted(sender, scanType, reason) {
  if (!_sched.running || !_sched.full) return false;
  if (scanType && _sched.step && scanType !== _sched.step) return false;
  if (sender && sender.tab && sender.tab.id != null) _sched.tabId = sender.tab.id;
  chrome.storage.local.set({ fansly_collect_aborted: { at: Date.now(), full: true, step: _sched.step || scanType || "", reason: reason === "stopped" ? "stopped" : "failed" } });
  finishSched();
  return true;
}
async function scanTabQuery(sender) {
  await scanStateReady();
  const id = sender && sender.tab && sender.tab.id != null ? sender.tab.id : null;
  return { success: true, scanTab: id != null && (id === _targetedVault.tabId || id === _framesTab.tabId || _sched.running && id === _sched.tabId) };
}
async function openBroadcastScan() {
  if (PLATFORM !== "fansly" || await scanOffNow("broadcast")) return;
  const url = await scanPageUrl("broadcast");
  if (!url) return;
  await new Promise((r) => chrome.storage.local.set({ fansly_scheduled_scan: { type: "broadcast", once: true, at: Date.now() } }, r));
  try {
    chrome.tabs.create({ url, active: false });
  } catch (e) {
  }
}
const TODO_DEF = { churnPri: 100, briefPri: 90, thankPri: 85, expiringPri: 80, winbackPri: 50, silentPri: 40, greetPri: 30, thankHours: 48, greetDays: 7, silentDays: 5, expiringDays: 3, winbackSpent: 20, briefMaxStaleDays: 60 };
function todoParams(st) {
  const p = { ...TODO_DEF };
  for (const k in TODO_DEF) {
    const v = st["digest_" + k];
    if (v != null && v !== "" && !Number.isNaN(+v)) p[k] = +v;
  }
  p.staleHours = st.briefStaleHours ?? 48;
  if (!(p.briefMaxStaleDays > 0)) p.briefMaxStaleDays = TODO_DEF.briefMaxStaleDays;
  p.briefMaxStaleDays = Math.min(p.briefMaxStaleDays, 90);
  return p;
}
function todoSignalFor(s, contact, p, stores, handle) {
  const cands = [];
  const spendBonus = CRM.spendW(s.spent) * 20;
  const silent = contact?.dossier?.lastMessageAt ? Math.floor((Date.now() - contact.dossier.lastMessageAt) / 864e5) : null;
  const days = s.daysLeft;
  const b = contact?.brief;
  if (b && (b.wants || b.details?.length) && b.collectedAt) {
    const h = Math.floor((Date.now() - b.collectedAt) / 36e5);
    if (h > p.staleHours && h <= p.briefMaxStaleDays * 24) cands.push({ kind: "briefStale", pri: p.briefPri + spendBonus, data: { n: Math.max(1, Math.round(h / 24)) } });
  }
  if (s.activeSub && s.sub && s.sub.renewOn === false) cands.push({ kind: "churn", pri: p.churnPri + (days != null && days >= 0 ? Math.max(0, 30 - days) : 0) + spendBonus, data: { n: days != null ? days : "?" } });
  if (s.activeSub && s.sub && days != null && days >= 0 && days <= p.expiringDays) cands.push({ kind: "expiring", pri: p.expiringPri + (p.expiringDays - days) + spendBonus, data: { n: days } });
  if (s.expired && (s.spent > p.winbackSpent || s.subCount > 1)) cands.push({ kind: "winback", pri: p.winbackPri + CRM.spendW(s.spent) * 30 + Math.min(s.subCount || 0, 6) / 6 * 8, data: { sum: +(+s.spent).toFixed(2) } });
  if (s.activeSub && s.spent > p.winbackSpent && silent != null && silent > p.silentDays) cands.push({ kind: "silent", pri: p.silentPri + Math.min(silent, 30) + spendBonus, data: { n: silent, sum: +(+s.spent).toFixed(2) } });
  const evs = CRM.pickCI(stores.fansly_ledger || {}, handle, (handle || "").toLowerCase()) || [];
  let recentPay = 0;
  for (const e of evs) if ((e.type === "tip" || e.type === "media") && e.at && Date.now() - e.at < p.thankHours * 36e5) recentPay = Math.max(recentPay, e.at);
  if (recentPay) cands.push({ kind: "thank", pri: p.thankPri + spendBonus, data: {} });
  const dsr = contact && contact.dossier;
  const talked = !!(dsr && (dsr.lastMessageAt || (dsr.facts || []).length || (dsr.topics || []).length)) || !!(contact && contact.brief && (contact.brief.wants || (contact.brief.details || []).length));
  const paidEver = s.spent > 0 || s.buyCount > 0 || s.hasBought;
  const lastLike = s.outreach && s.outreach.lastLikeAt || 0;
  if (lastLike && Date.now() - lastLike < p.greetDays * 864e5 && !s.activeSub && !talked && !paidEver) cands.push({ kind: "greet", pri: p.greetPri, data: { n: Math.max(0, Math.floor((Date.now() - lastLike) / 864e5)) } });
  if (!cands.length) return null;
  cands.sort((a, b2) => b2.pri - a.pri);
  return cands[0];
}
function cardFields(f) {
  const sub = f.sub || null;
  return {
    stage: f.stage,
    stuck: f.stuck,
    score: f.score,
    spent: f.spent,
    buyCount: f.buyCount,
    subCount: f.subCount,
    activeSub: f.activeSub,
    expired: f.expired,
    daysLeft: f.daysLeft,
    months: f.months,
    firstSubAt: f.firstSubAt,
    hasCard: f.hasCard,
    tierName: sub && sub.tierName,
    price: sub && sub.price,
    billingCycle: sub && sub.billingCycle,
    renewOn: sub ? sub.renewOn : null,
    endDate: sub && sub.endDate,
    closeness: f.contact && f.contact.dossier && f.contact.dossier.closeness,
    lastMessageAt: f.contact && f.contact.dossier && f.contact.dossier.lastMessageAt || 0,
    // когда фан последний раз ПИСАЛ
    lastLikeAt: f.lastLikeAt || 0,
    likes: f.likes || 0
    // из fansly_likes (todo #53)
  };
}
async function buildTodayList(limit = 20) {
  const s = await getSettings();
  const p = todoParams(s);
  const stores = await new Promise((r) => chrome.storage.local.get(CRM.STORE_KEYS, (d) => r(d)));
  const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
  const contacts = {};
  for (const k in all) if (k.startsWith("fai_contact_")) contacts[k] = all[k];
  const byHandle = {}, msgIdByHandle = {};
  for (const [key, c] of Object.entries(contacts)) {
    if (!c || !c.handle) continue;
    const l = c.handle.toLowerCase();
    byHandle[l] = c;
    const id = key.replace("fai_contact_", "");
    if (/^\d{10,}$/.test(id)) msgIdByHandle[l] = id;
  }
  const entries = [];
  const byLower = /* @__PURE__ */ new Map();
  const addH = (h) => {
    if (!h) return;
    const l = String(h).toLowerCase();
    if (!byLower.has(l)) byLower.set(l, h);
  };
  for (const h of Object.keys(stores.fansly_subs || {})) addH(h);
  for (const h of Object.keys(stores.fansly_ledger || {})) addH(h);
  for (const e of Object.values(stores.fansly_earnings || {})) {
    if (e && e.buyer && !e.refunded) addH(e.buyer);
  }
  for (const h of Object.keys(stores.fansly_outreach || {})) addH(h);
  for (const c of Object.values(contacts)) if (c && c.handle) addH(c.handle);
  for (const [l, h] of byLower) entries.push({ handle: h, contact: byHandle[l] || null });
  const ack = all.fansly_todo_ack || {};
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const items = [];
  const coreOpts = { briefStaleHours: p.staleHours };
  for (const { handle, contact } of entries) {
    if (contact && (contact.unknownConfirmed || contact.notCustomer)) continue;
    if (!handle) continue;
    const name = contact && contact.name || handle;
    const f = CRM.computeFan(handle, name, stores, contact, coreOpts);
    const sig = todoSignalFor(f, contact, p, stores, handle);
    if (!sig) continue;
    const key = handle.toLowerCase() + "|" + sig.kind;
    const a = ack[key];
    if (a === "forever") continue;
    if (a && typeof a === "number" && new Date(a).toISOString().slice(0, 10) === today) continue;
    if (a && typeof a === "object" && a.until && a.until > Date.now()) continue;
    items.push({ key, kind: sig.kind, handle, msgId: msgIdByHandle[handle.toLowerCase()] || null, name: f.name, pri: sig.pri, data: sig.data, crm: cardFields(f) });
  }
  items.sort((a, b) => b.pri - a.pri);
  const KIND_CAP = 3;
  const head = [], tail = [], perKind = {};
  for (const it of items) {
    const n = perKind[it.kind] = (perKind[it.kind] || 0) + 1;
    (n <= KIND_CAP ? head : tail).push(it);
  }
  return [...head, ...tail].slice(0, limit);
}
const TODO_KIND_EN = {
  churn: "He turned OFF auto-renewal; subscription expires in {n} days. Gently make him want to stay subscribed.",
  briefStale: "He requested custom content about {n} days ago and it stalled. Warmly follow up on his order.",
  expiring: "His subscription ends in {n} days. Warmly encourage him to renew.",
  winback: "Former subscriber who spent ${sum}. Warmly win him back.",
  silent: "A paying fan (spent ${sum}) has gone quiet for {n} days. Warmly re-engage him.",
  thank: "He just paid you (a tip or content purchase). Warmly thank him.",
  greet: "He recently liked your content and you two have never talked. Warmly say hi and open the conversation \u2014 do NOT write as if you already know him."
};
async function todoContactByHandle(handle) {
  const l = (handle || "").toLowerCase();
  const all = await new Promise((r) => chrome.storage.local.get(null, (d) => r(d)));
  for (const k in all) if (k.startsWith("fai_contact_") && all[k] && all[k].handle && all[k].handle.toLowerCase() === l) return all[k];
  return null;
}
async function handleTodoAdvice(context) {
  const settings = await getSettings();
  const useOR = settings.allowExplicit === true && settings.openrouterApiKey && !AiCore.proxyOn(settings);
  const chatSettings = useOR ? { ...settings, aiProvider: "openrouter" } : settings;
  if (!AiCore.proxyOn(settings) && (chatSettings.aiProvider === "mock" || !chatSettings.aiProvider)) return { success: false, error: "no provider" };
  const contact = await todoContactByHandle(context.handle);
  const stores = await new Promise((r2) => chrome.storage.local.get(CRM.STORE_KEYS, (d) => r2(d)));
  const sum = CRM.computeFan(context.handle, context.name, stores, contact, { briefStaleHours: settings.briefStaleHours });
  const reachReason = (TODO_KIND_EN[context.kind] || "").replace(/\{n\}/g, context.data?.n ?? "").replace(/\{sum\}/g, context.data?.sum ?? "");
  const coachCtx = {
    // fanLang — язык, на котором коуч выдаёт ПРИМЕРЫ ФРАЗ, а они уходят фану: черновик из дайджеста
    // вставляется прямо в поле площадки (dashboard → fansly_pending_draft → insertDraftReview), минуя
    // перевод вообще. Здесь стоял язык ВЛАДЕЛЬЦА — англоязычному фану в поле ложился русский текст
    // (Alex 2026-08-28, аудит). Берём язык контакта, как это делает панель (state.contactData?.lang).
    fanName: context.name,
    fanLang: contact?.lang || "en",
    fanGender: contact?.gender || "male",
    // второй вход в coach (дайджест): пол фана лежит в контакте — без него совет говорил бы «он» про всех
    dossier: contact?.dossier || {},
    brief: contact?.brief,
    // months/firstSubAt — computeFan их уже посчитал; без них совет дайджеста не знает даты подписки
    // (истории у него нет вовсе, `history: []`, так что календарь в транскрипте ему не поможет).
    // Портрет (стадия/сегменты/лайки/покупки) computeFan уже посчитал — довозим, иначе совет дайджеста
    // не отличит «отменил подписку» от «просто растворился», а покупателя без подписки — от бесплатника.
    crm: {
      spent: sum.spent,
      buyCount: sum.buyCount,
      activeSub: sum.activeSub,
      sub: sum.sub,
      subCount: sum.subCount,
      // computeSegments отдаёт Set, а промпт проверяет Array.isArray → строка «покупает, но не подписан»
      // была мертва на пути дайджеста (панель разворачивает в массив у себя, поэтому там работало).
      months: sum.months,
      firstSubAt: sum.firstSubAt,
      stage: sum.stage,
      segments: [...sum.segments || []],
      lastBuyAt: sum.lastBuyAt,
      likes: sum.likes || 0,
      lastLikeAt: sum.lastLikeAt || 0
    },
    isSubscribed: sum.activeSub,
    isCreator: contact?.isCreator === true,
    history: [],
    reachReason,
    note: (contact?.note || "").trim().slice(0, 300),
    hasCard: sum.hasCard === true,
    topics: (contact?.dossier?.topics || []).slice(0, 10)
  };
  const { system, user, pii } = buildCoachPrompt(coachCtx, settings, creatorLang(settings));
  const r = await AiCore.chat([{ role: "user", content: user }], system, chatSettings, { kind: "digest", maxTokens: COACH_MAX_TOKENS });
  if (!r?.success || !r.text) return { success: false, error: r?.error || "advice failed" };
  const parsed = unmaskDeep(parseCoach(r.text), pii);
  const text = parsed && parsed.examples && parsed.examples[0] || parsed && parsed.advice || "";
  if (!text) return { success: false, error: "advice parse failed" };
  const key = (context.handle || "").toLowerCase() + "|" + context.kind;
  await new Promise((res) => chrome.storage.local.get("fansly_todo_drafts", (d) => {
    const m = d.fansly_todo_drafts || {};
    m[key] = { text, advice: parsed && parsed.advice, at: Date.now() };
    chrome.storage.local.set({ fansly_todo_drafts: m }, res);
  }));
  return { success: true, text, advice: parsed && parsed.advice, examples: parsed && parsed.examples };
}
const WORK_TAB_URL = (
  /*@of-start@*/
  PLATFORM === "onlyfans" ? "https://onlyfans.com/my/chats/" : (
    /*@of-end@*/
    "https://fansly.com/messages"
  )
);
const WORK_TAB_MATCH = (
  /*@of-start@*/
  PLATFORM === "onlyfans" ? "*://onlyfans.com/my/chats*" : (
    /*@of-end@*/
    "*://fansly.com/messages*"
  )
);
async function openWorkTab(excludeTabId) {
  const tabs = await new Promise((r) => {
    try {
      chrome.tabs.query({ url: WORK_TAB_MATCH }, (t2) => {
        void chrome.runtime.lastError;
        r(t2 || []);
      });
    } catch (e) {
      r([]);
    }
  });
  for (const tb of tabs) {
    if (tb.id === excludeTabId) continue;
    const st = await new Promise((res) => {
      try {
        chrome.tabs.sendMessage(tb.id, { type: "PULT_STATE" }, (x) => {
          void chrome.runtime.lastError;
          res(x);
        });
      } catch (e) {
        res(null);
      }
    });
    if (st && st.pult === false) {
      await new Promise((res) => chrome.tabs.update(tb.id, { active: true }, () => {
        void chrome.runtime.lastError;
        res();
      }));
      if (tb.windowId != null) {
        try {
          chrome.windows.update(tb.windowId, { focused: true });
        } catch (e) {
        }
      }
      return { success: true, focused: tb.id };
    }
  }
  const nt = await new Promise((r) => chrome.tabs.create({ url: WORK_TAB_URL, active: true }, r));
  return { success: true, created: nt?.id };
}
function migrateOffSync() {
  try {
    chrome.storage.sync.get(["fansly_ai_settings"], (syncData) => {
      if (chrome.runtime.lastError) return;
      const fromSync = syncData && syncData.fansly_ai_settings;
      const wipe = () => {
        try {
          chrome.storage.sync.remove("fansly_ai_settings", () => {
            void chrome.runtime.lastError;
            try {
              chrome.storage.sync.clear(() => {
                void chrome.runtime.lastError;
              });
            } catch (e) {
            }
          });
        } catch (e) {
        }
      };
      if (!fromSync) {
        wipe();
        return;
      }
      chrome.storage.local.get("fansly_ai_settings", (localData) => {
        if (localData && localData.fansly_ai_settings) {
          wipe();
          return;
        }
        chrome.storage.local.get("fansly_ai_settings", (now) => {
          const merged = Object.assign({}, fromSync, now && now.fansly_ai_settings || {});
          chrome.storage.local.set({ fansly_ai_settings: merged }, () => {
            console.log("[FanslyAI] \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u044B \u0438\u0437 sync \u0432 local");
            wipe();
          });
        });
      });
    });
  } catch (e) {
  }
}
migrateOffSync();
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["fansly_ai_settings", "fansly_tiers"], (localData) => {
      const done = (base) => {
        const s = Object.assign({}, DEFAULT_SETTINGS, base || {});
        for (const k in LEGACY_DEFAULTS) if (typeof s[k] === "string" && s[k].trim() === LEGACY_DEFAULTS[k]) s[k] = null;
        s.tiers = localData.fansly_tiers?.list || [];
        s.tiersInfo = s.tiers.map((t2) => `${t2.name} \u2014 $${t2.price}/mo${t2.perks && t2.perks.length ? "\n  includes: " + t2.perks.join("; ") : ""}`).join("\n");
        resolve(s);
      };
      done(localData.fansly_ai_settings);
    });
  });
}
function saveSettings(settings, cb) {
  chrome.storage.local.get("fansly_ai_settings", (d) => {
    const merged = Object.assign({}, d.fansly_ai_settings || {}, settings);
    chrome.storage.local.set({ fansly_ai_settings: merged }, () => cb());
  });
}
async function getAllContacts() {
  return new Promise((resolve) => {
    chrome.storage.local.get(null, (allData) => {
      const contacts = {};
      for (const [key, val] of Object.entries(allData)) {
        if (key.startsWith("fai_contact_")) contacts[key] = val;
      }
      resolve(contacts);
    });
  });
}
const IMPORT_SKIP_SETTINGS = ["masterEnabled", "panelHidden", "carouselEnabled", "setupCompleted", "showAdvanced", "proxyBaseUrl"];
const SECRET_KEYS = ["licenseKey", "claudeApiKey", "deepLApiKey", "geminiApiKey", "groqApiKey", "openrouterApiKey", "telegramBotToken"];
function pickBackupContacts(contacts, existing) {
  const liveHandles = /* @__PURE__ */ new Set();
  for (const [k, v] of Object.entries(existing || {})) {
    if (k.startsWith("fai_contact_") && v && v.handle) liveHandles.add(String(v.handle).toLowerCase());
  }
  const out = {};
  const stats = { restored: 0, keptByKey: 0, keptByHandle: 0, rejected: 0 };
  for (const [k, rec] of Object.entries(contacts || {})) {
    if (!k.startsWith("fai_contact_") || !rec || typeof rec !== "object" || Array.isArray(rec)) {
      stats.rejected++;
      continue;
    }
    if (existing && existing[k] != null) {
      stats.keptByKey++;
      continue;
    }
    if (rec.handle && liveHandles.has(String(rec.handle).toLowerCase())) {
      stats.keptByHandle++;
      continue;
    }
    out[k] = rec;
    stats.restored++;
  }
  return { out, stats };
}
const IMPORT_TG_GUARD = ["tgBotId", "tgOwnerId", "tgOwnerChat", "tgMemberCount", "tgMemberCountChat", "tgAdminIds", "tgAdminChat"];
const IMPORT_TG_LINK = ["telegramBotToken", "telegramChatId", "tgTopics", "tgChatPrev"];
function pickBackupTg(copySettings, curSettings, copyTopics, curTopics) {
  const cs = copySettings || {}, cur = curSettings || {};
  const drop = [...IMPORT_TG_GUARD], set = {};
  const curChat = String(cur.telegramChatId || "");
  if (!curChat) return { drop, set, topics: copyTopics || null, why: "\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E \u0431\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B: \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0438 \u043A\u0430\u0440\u0442\u0430 \u0432\u0435\u0442\u043E\u043A \u2014 \u0438\u0437 \u043A\u043E\u043F\u0438\u0438" };
  drop.push(...IMPORT_TG_LINK);
  const ids = (chat, prev2) => [String(chat || ""), ...Array.isArray(prev2) ? prev2.map(String) : []].filter(Boolean);
  const mine = ids(curChat, cur.tgChatPrev);
  const theirs = ids(copyTopics && copyTopics.chat || cs.telegramChatId, cs.tgChatPrev);
  if (!theirs.some((id) => mine.includes(id))) return { drop, set, topics: null, why: "\u043A\u043E\u043F\u0438\u044F \u0434\u0440\u0443\u0433\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u044B: \u0435\u0451 \u043A\u0430\u0440\u0442\u0430 \u043D\u0435 \u0432\u0437\u044F\u0442\u0430, \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E \u043D\u0430 \u0441\u0432\u043E\u0435\u0439 \u0433\u0440\u0443\u043F\u043F\u0435" };
  const prev = [.../* @__PURE__ */ new Set([...mine, ...theirs])].filter((id) => id !== curChat).slice(-5);
  if (prev.length) set.tgChatPrev = prev;
  if (!copyTopics || typeof copyTopics !== "object") return { drop, set, topics: null, why: "\u0442\u0430 \u0436\u0435 \u0433\u0440\u0443\u043F\u043F\u0430, \u0432 \u043A\u043E\u043F\u0438\u0438 \u043A\u0430\u0440\u0442\u044B \u0432\u0435\u0442\u043E\u043A \u043D\u0435\u0442" };
  const live = curTopics && typeof curTopics === "object" && (!curTopics.chat || mine.includes(String(curTopics.chat))) ? curTopics : {};
  const keep = (a, b) => a != null ? a : b != null ? b : null;
  const added = Object.keys(copyTopics.fans || {}).filter((f) => !(live.fans && f in live.fans)).length;
  return { drop, set, why: "\u0442\u0430 \u0436\u0435 \u0433\u0440\u0443\u043F\u043F\u0430: \u0432\u0435\u0442\u043E\u043A \u0438\u0437 \u043A\u043E\u043F\u0438\u0438 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E " + added, topics: Object.assign({}, live, {
    important: keep(live.important, copyTopics.important),
    posts: keep(live.posts, copyTopics.posts),
    fans: Object.assign({}, copyTopics.fans || {}, live.fans || {}),
    // живые привязки поверх копии
    chat: curChat
  }) };
}
function importData(data, cb) {
  const inv = data.inventory || {};
  const invMap = {
    fansly_subs: inv.subs,
    fansly_ledger: inv.ledger,
    fansly_posts: inv.posts,
    fansly_purchases: inv.purchases,
    fansly_crm_notes: inv.crmNotes,
    fansly_outreach: inv.outreach,
    // Лайки и фоллоу (todo #53). Старая копия без них — засев из её аутрича тем же правилом, что разовый перенос при обновлении.
    fansly_likes: inv.likes || inv.outreach && likesFromOutreach(inv.outreach),
    // Добавлено 2026-08-17 (аудит полноты бэкапа)
    fansly_earnings: inv.earnings,
    fansly_stats_daily: inv.statsDaily,
    fansly_broadcast_stats: inv.broadcastStats,
    fansly_todo_ack: inv.todoAck,
    fansly_outreach_done: inv.outreachDone,
    fansly_tiers: inv.tiers
  };
  const invKeys = Object.keys(invMap).filter((k) => invMap[k]);
  const stampMap = { fansly_earnings_lastsync: inv.earningsLastsync, fansly_broadcast_lastsync: inv.broadcastLastsync };
  const stampKeys = Object.keys(stampMap).filter((k) => stampMap[k] != null);
  chrome.storage.local.get(null, (existing) => {
    const writes = {};
    const tg = pickBackupTg(data.settings, existing.fansly_ai_settings, data.tgTopics, existing.fansly_tg_topics);
    console.log("[FanslyAI] \u0438\u043C\u043F\u043E\u0440\u0442: \u0422\u0435\u043B\u0435\u0433\u0440\u0430\u043C \u2014", tg.why);
    if (data.settings) {
      const incoming = Object.assign({}, data.settings);
      for (const k of IMPORT_SKIP_SETTINGS) delete incoming[k];
      const cur = existing.fansly_ai_settings || {};
      for (const k of SECRET_KEYS) if (incoming[k] === "" && cur[k]) delete incoming[k];
      for (const k of tg.drop) delete incoming[k];
      Object.assign(incoming, tg.set);
      writes.fansly_ai_settings = Object.assign({}, cur, incoming);
    }
    if (data.contacts) {
      const { out, stats } = pickBackupContacts(data.contacts, existing);
      Object.assign(writes, out);
      console.log(
        "[FanslyAI] \u0438\u043C\u043F\u043E\u0440\u0442: \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0444\u0430\u043D\u043E\u0432 \u0438\u0437 \u043A\u043E\u043F\u0438\u0438 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u043E",
        stats.restored,
        "\xB7 \u0436\u0438\u0432\u044B\u0445 \u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E",
        stats.keptByKey + stats.keptByHandle,
        "(\u0438\u0437 \u043D\u0438\u0445 \u043F\u043E \u043D\u0438\u043A\u0443 " + stats.keptByHandle + ")" + (stats.rejected ? " \xB7 \u043E\u0442\u0431\u0440\u043E\u0448\u0435\u043D\u043E \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u043D\u0435 \u043F\u0440\u043E \u0444\u0430\u043D\u043E\u0432: " + stats.rejected : "")
      );
    }
    if (tg.topics) writes.fansly_tg_topics = tg.topics;
    for (const k of invKeys) writes[k] = Object.assign({}, invMap[k], existing[k] || {});
    for (const k of stampKeys) writes[k] = Math.max(+stampMap[k] || 0, +existing[k] || 0);
    const finish = (err) => {
      FaiDB.restoreCatalog(inv).then(() => cb(err)).catch((e) => cb(err || "catalog: " + (e && e.message || e)));
    };
    if (Object.keys(writes).length === 0) {
      finish(null);
      return;
    }
    chrome.storage.local.set(writes, () => {
      finish(chrome.runtime.lastError ? chrome.runtime.lastError.message : null);
    });
  });
}
async function geminiProbeBlocked(text, settings) {
  const model = settings.geminiModel || AiCore.MODELS.gemini;
  const prompt = `Below is a chat excerpt. Reply with exactly: ok

${text.slice(0, 12e4)}`;
  try {
    const r = await fetchWithTimeout(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${settings.geminiApiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0, maxOutputTokens: 5 },
          safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_CIVIC_INTEGRITY", threshold: "BLOCK_NONE" }
          ]
        })
      },
      2e4
    );
    const data = await r.json();
    if (data.error) {
      const rl = data.error.code === 429 || /quota|rate|exhaust|429/i.test(data.error.message || "");
      return { blocked: false, reason: "ERR:" + (data.error.message || "").slice(0, 60), rateLimited: rl };
    }
    const blockReason = data.promptFeedback?.blockReason;
    const finishReason = data.candidates?.[0]?.finishReason;
    const txt = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const blocked = blockReason === "PROHIBITED_CONTENT" || !txt && (finishReason === "PROHIBITED_CONTENT" || finishReason === "SAFETY" || !!blockReason);
    return { blocked, reason: blockReason || finishReason || (txt ? "ok" : "empty"), rateLimited: false };
  } catch (e) {
    return { blocked: false, reason: "EXC:" + e.message, rateLimited: false };
  }
}
async function diagnoseBlock(history, fanName) {
  const settings = await getSettings();
  const lang = settings.interfaceLanguage || "ru";
  if (AiCore.proxyOn(settings)) return { success: false, error: "\u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 Gemini \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0432 \u043E\u0431\u043B\u0430\u0447\u043D\u043E\u043C \u0440\u0435\u0436\u0438\u043C\u0435" };
  if (!settings.geminiApiKey) return { success: false, error: t("bg.err.needGeminiKey", lang) };
  const msgs = (history || []).filter((m) => m.text && !m.isMedia);
  if (!msgs.length) return { success: false, error: t("bg.err.noTextMessages", lang) };
  const fmt = (arr) => arr.map((m) => `${m.role === "subscriber" ? fanName || "Fan" : "Creator"}: ${m.text}`).join("\n");
  const N = Math.min(8, Math.ceil(msgs.length / 80));
  const size = Math.ceil(msgs.length / N);
  console.log(`[FanslyAI] \u{1F52C} diagnose | msgs: ${msgs.length} | \u0431\u043B\u043E\u043A\u043E\u0432: ${N} \u043F\u043E ~${size} | \u0432\u044B\u0437\u043E\u0432\u043E\u0432 \u0431\u0443\u0434\u0435\u0442 \u2264${N}`);
  const blocked = [];
  let calls = 0, rateHit = false;
  for (let i = 0; i < msgs.length; i += size) {
    const block = msgs.slice(i, i + size);
    const range = `${i + 1}-${Math.min(i + size, msgs.length)}`;
    calls++;
    const res = await geminiProbeBlocked(fmt(block), settings);
    if (res.rateLimited) {
      rateHit = true;
      console.warn(`[FanslyAI] \u{1F52C} rate limit \u043D\u0430 \u0431\u043B\u043E\u043A\u0435 ${range} \u2192 \u0441\u0442\u043E\u043F (\u0441\u0434\u0435\u043B\u0430\u043D\u043E ${calls}). \u041F\u0440\u043E\u043A\u0440\u0443\u0442\u0438 \u043C\u0435\u043D\u044C\u0448\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0438.`);
      break;
    }
    console.log(`[FanslyAI] \u{1F52C} \u0431\u043B\u043E\u043A ${range} [${block.length} msg] \u2192 ${res.blocked ? "\u26D4 BLOCK (" + res.reason + ")" : "\u2713 ok"}`);
    if (res.blocked) blocked.push({ range, block });
    await new Promise((r) => setTimeout(r, 400));
  }
  console.log(`[FanslyAI] \u{1F52C} \u0433\u043E\u0442\u043E\u0432\u043E | \u0432\u044B\u0437\u043E\u0432\u043E\u0432: ${calls} | \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0431\u043B\u043E\u043A\u043E\u0432: ${blocked.length}${rateHit ? " | \u26A0\uFE0F \u043E\u0431\u043E\u0440\u0432\u0430\u043D\u043E rate-limit" : ""}`);
  blocked.forEach((bb) => {
    const body = bb.block.map((m) => `${m.role === "subscriber" ? "\u{1F464}" : "\u270D\uFE0F"} ${m.text}`).join("\n");
    console.log(`[FanslyAI] \u{1F52C} \u2550\u2550\u2550 \u0417\u0410\u0411\u041B\u041E\u041A\u0418\u0420\u041E\u0412\u0410\u041D\u041D\u042B\u0419 \u0411\u041B\u041E\u041A ${bb.range} \u2014 \u0438\u0449\u0438 \u0442\u0440\u0438\u0433\u0433\u0435\u0440 \u0437\u0434\u0435\u0441\u044C \u2550\u2550\u2550
${body}`);
  });
  if (!blocked.length && !rateHit) {
    console.log("[FanslyAI] \u{1F52C} \u043D\u0438 \u043E\u0434\u0438\u043D \u0431\u043B\u043E\u043A \u043D\u0435 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D \u043F\u043E \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u2014 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E, \u0442\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0441\u043E\u0447\u0435\u0442\u0430\u043D\u0438\u0438/\u043E\u0431\u044A\u0451\u043C\u0435 \u0432\u0441\u0435\u0439 \u0438\u0441\u0442\u043E\u0440\u0438\u0438, \u0430 \u043D\u0435 \u0432 \u043E\u0434\u043D\u043E\u043C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0438");
  }
  return { success: true, blockedBlocks: blocked.map((bb) => bb.range), calls, rateHit };
}
const MODELS_CACHE_KEY = "fansly_gemini_models_cache";
const MODELS_TTL = 24 * 60 * 60 * 1e3;
async function fetchGeminiModels(apiKey, forceRefresh = false) {
  if (!apiKey) return { success: false, error: "No API key" };
  const _s = await getSettings();
  if (AiCore.proxyOn(_s)) return { success: false, error: "proxy mode" };
  if (!forceRefresh) {
    const cached = await new Promise((resolve) => chrome.storage.local.get([MODELS_CACHE_KEY], (data) => resolve(data[MODELS_CACHE_KEY])));
    if (cached?.models?.length && Date.now() - cached.cachedAt < MODELS_TTL) {
      return { success: true, models: cached.models, fromCache: true };
    }
  }
  try {
    const r = await fetchWithTimeout(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`,
      {},
      2e4
    );
    const data = await r.json();
    if (data.error) return { success: false, error: data.error.message };
    const models = (data.models || []).filter((m) => {
      const name = m.name.replace("models/", "").toLowerCase();
      return m.supportedGenerationMethods?.includes("generateContent") && name.includes("gemini") && (name.includes("flash") || name.includes("pro")) && !name.includes("embedding") && !name.includes("aqa") && !name.includes("vision") && !name.includes("nano");
    }).map((m) => m.name.replace("models/", "")).sort((a, b) => {
      const aFlash = a.includes("flash"), bFlash = b.includes("flash");
      if (aFlash !== bFlash) return aFlash ? -1 : 1;
      return b.localeCompare(a);
    });
    chrome.storage.local.set({ [MODELS_CACHE_KEY]: { models, cachedAt: Date.now() } });
    return { success: true, models };
  } catch (e) {
    return { success: false, error: e.message };
  }
}
async function consentGiven() {
  if (_consentOk) return true;
  try {
    _consentOk = await self.FaiConsent.given();
  } catch (e) {
    _consentOk = false;
  }
  return _consentOk;
}
function consentError() {
  const e = new Error("consent_required");
  e.faiConsent = true;
  return e;
}
async function fetchWithTimeout(url, opts, ms = 3e4, beforeConsent = false) {
  if (!beforeConsent && !await consentGiven()) throw consentError();
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(id);
  }
}
function currentTimeFor(tz) {
  try {
    const opts = { hour: "2-digit", minute: "2-digit", weekday: "short", day: "2-digit", month: "short" };
    if (tz && tz.trim()) opts.timeZone = tz.trim();
    return new Intl.DateTimeFormat("en-GB", opts).format(/* @__PURE__ */ new Date());
  } catch (e) {
    try {
      return new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", weekday: "short", day: "2-digit", month: "short" }).format(/* @__PURE__ */ new Date());
    } catch (_) {
      return null;
    }
  }
}
function isBriefComplete(brief) {
  if (!brief) return false;
  return !!(brief.wants && brief.wants.trim()) && (brief.details?.length || brief.mood && brief.mood.trim());
}
function determineDialogueState(context, intent) {
  const closeness = context?.dossier?.closeness || "new";
  const totalMsgs = context?.totalMsgs || 0;
  const brief = context?.brief;
  const isCustom = intent?.type === "custom_video";
  if (isBriefComplete(brief)) {
    return {
      name: "BRIEF_DONE",
      instruction: `DIALOGUE STATE \u2014 BRIEF ALREADY COLLECTED (terminal for this topic):
You already have everything needed for the custom (what they want, details, mood). The collecting is DONE.
- Close it ONCE, warmly and confidently: you love the idea, you'll think how to make it beautiful and get back to them. Brief, human.
- Do NOT ask for the vibe/details again. Do NOT say "let me think" or "don't rush me" repeatedly. Do NOT keep deflecting \u2014 that reads as stalling and is infuriating.
- If they ask a direct question (e.g. "how long until you answer?") \u2014 give a direct, in-character answer, do not dodge.
- Then let the conversation breathe / move on naturally.`
    };
  }
  if (isCustom) {
    return {
      name: "CUSTOM_DISCUSS",
      instruction: `DIALOGUE STATE \u2014 discussing a custom: draw out their vision (mood, vibe, details) warmly. Collect, don't commit. Do NOT name price or promise.`
    };
  }
  if (closeness === "new" || totalMsgs < 4) {
    return {
      name: "GETTING_TO_KNOW",
      instruction: `DIALOGUE STATE \u2014 getting to know each other: build genuine connection, be curious about THEM. No selling, no over-familiarity.`
    };
  }
  return {
    name: "WARM",
    instruction: `DIALOGUE STATE \u2014 warm ongoing chat: keep it personal and easy, learn small things about them, talk about your work as art when it comes up. Don't rush toward any sale.`
  };
}
function buildDossierPrompt({ convo, tailText, known, isDelta }) {
  const contextBlock = tailText ? `Earlier messages (CONTEXT ONLY \u2014 do NOT extract any facts from this part, it is here only so you understand what the new messages refer to):
${tailText}

` : "";
  const knownBlock = known.length ? `
ALREADY KNOWN about this subscriber \u2014 do NOT repeat these, and do NOT return reworded variants of them. Return ONLY genuinely new facts:
${known.map((f) => "- " + f).join("\n")}
` : "";
  return `Analyze this Fansly conversation. Extract a fact sheet about the SUBSCRIBER only.

${contextBlock}${isDelta ? "NEW messages to analyze" : "Conversation"}:
${convo}
${knownBlock}
CRITICAL RULES \u2014 accuracy over completeness:
- IGNORE roleplay, sexting and fantasy scenes ENTIRELY. If the subscriber is playing a character, describing a scenario, or talking dirty, NOTHING from it is a fact about him \u2014 not his job, not his location, not his body, not his actions. "I'm your doctor" inside a scene is roleplay, not a profession.
- Record ONLY facts the subscriber stated LITERALLY in their own words.
- Do NOT infer, guess, generalize or embellish. Examples of FORBIDDEN behavior:
  \xB7 They said "I play CS" \u2192 write "plays CS". Do NOT write "plays sniper", "likes shooters", "competitive gamer".
  \xB7 They mentioned an "outfit" \u2192 write "mentioned an outfit". Do NOT invent "black dress" or any item they never named.
- Quote-level fidelity. If a detail was not explicitly said, it does NOT go in.
- Ignore vague compliments, flirting and generic chat \u2014 those are not facts.
- Greetings ("hi", "hola mami", "hey baby"), pet names, single-word or emoji-only messages, and generic openers are NOT facts and NOT topics. Extract nothing from them.
- TOPICS come ONLY from what the SUBSCRIBER himself wrote about. Never derive a topic from the creator's own messages.
- An empty facts list AND an empty topics list are perfectly acceptable and expected for a fan who barely wrote. Prefer empty over invented. This is ESPECIALLY true when only one or a few new messages are given: most single replies carry NO durable fact \u2014 if the new message states no concrete real-world detail about him, return "facts":[] and do NOT stretch a mood, a reaction, or small-talk into a "fact".
- CLOSENESS: default "new". Raise it ONLY on real, repeated, substantive exchange from him. One message, a greeting, or a couple of shallow lines = "new". "interested" needs genuine back-and-forth; "regular"/"supporter" need a real ongoing relationship. Do NOT infer closeness from payment or from the creator's warmth \u2014 only from HIS engagement.
- LANGUAGE: keep every fact and brief field in the SAME language the subscriber actually wrote (if he wrote in Russian, keep them in Russian). Do NOT translate to English.

ALSO: if the subscriber requested/ordered custom content anywhere in this conversation (a scene, outfit, video, photoset he wants made), capture it in "brief" \u2014 same literal-accuracy rule (only what he actually said). If no custom order was discussed, leave brief fields empty.

Output ONLY valid JSON (no markdown):
{"facts":["literal fact stated by subscriber"],"closeness":"new|interested|regular|supporter","topics":["topic actually discussed"],"brief":{"wants":"","details":[],"mood":"","refs":[]}}
If nothing concrete was literally stated: {"facts":[],"closeness":"new","topics":[],"brief":{"wants":"","details":[],"mood":"","refs":[]}}`;
}
const DRAFT_PAIRS = 3;
const DRAFT_ITEM_CHARS = 600;
const DRAFT_CHARS = 2400;
function draftTurnPairs(turns) {
  const pairs = [];
  let task = null;
  for (const h of Array.isArray(turns) ? turns : []) {
    if (!h || h.role !== "task" && h.role !== "draft") continue;
    const text = typeof h.text === "string" ? h.text.trim().slice(0, DRAFT_ITEM_CHARS) : "";
    if (h.role === "task") task = text;
    else if (text) {
      pairs.push({ task: task || "", draft: text, sent: h.sent === true });
      task = null;
    }
  }
  let keep = pairs.slice(-DRAFT_PAIRS);
  while (keep.length && keep.reduce((n, p) => n + p.task.length + p.draft.length, 0) > DRAFT_CHARS) keep = keep.slice(1);
  return keep;
}
function draftFanFacts(context) {
  const crm = context?.crm, out = [];
  const days = (ms) => Math.max(0, Math.floor((Date.now() - ms) / 864e5));
  const active = !!(crm && crm.activeSub);
  if (crm) {
    const tier = (active ? context?.tierName || crm.sub && crm.sub.tierName || "" : "").trim();
    let sub;
    if (active && tier) sub = `he is subscribed to you, on the tier "${tier}"`;
    else if (active) sub = "he is subscribed to you, but WHICH tier is unknown, so never name one";
    else if (crm.sub && crm.sub.status === "expired") sub = "he is NOT subscribed now, his subscription has expired";
    else if (context?.isSubscribed) sub = "unconfirmed (he was marked as subscribed at some point, but there is no current confirmation), so treat his tier as unknown";
    else sub = "he is NOT subscribed, a free follower";
    if (active && crm.sub) {
      if (crm.sub.renewOn === false) sub += `; auto-renew is OFF${crm.sub.endInDays != null ? `, it ends in ${crm.sub.endInDays} days` : ""}`;
      else if (crm.sub.endInDays != null && crm.sub.endInDays <= 7) sub += `; it renews in ${crm.sub.endInDays} days`;
    }
    out.push(`Subscription: ${sub}.`);
    const money = [];
    if (crm.spent > 0) money.push(`spent about $${crm.spent} with you`);
    if (crm.buyCount > 0) money.push(`bought content ${crm.buyCount}\xD7`);
    if (crm.lastBuyAt) money.push(`last purchase ${days(crm.lastBuyAt)}d ago`);
    if (crm.months > 0) money.push(`subscribed for about ${crm.months} month(s) in total`);
    if (crm.subCount > 1) money.push(`re-subscribed ${crm.subCount}\xD7`);
    if (money.length) out.push(`Money: ${money.join("; ")}.`);
    const segs = crm.segments ? [...crm.segments] : [];
    if (crm.stage === "lost") out.push("He was subscribed and cancelled: a decision, not forgetfulness.");
    else if (segs.includes("buyersNoSub") && !active) out.push("Not subscribed, but he does buy your content: a customer, not a freeloader.");
    if (crm.likes > 0 && crm.lastLikeAt) out.push(`He likes your posts (${crm.likes} in total, last ${days(crm.lastLikeAt)}d ago): he is reading you.`);
    if (Array.isArray(crm.recentEvents) && crm.recentEvents.length) {
      const ago = (ms) => {
        if (ms < 0) ms = 0;
        const h = Math.round(ms / 36e5);
        return h < 1 ? "just now" : h < 24 ? h + "h ago" : Math.round(h / 24) + "d ago";
      };
      const evs = crm.recentEvents.map((e) => {
        if (e.type === "media") return `bought content ${ago(e.agoMs)}${e.amount ? " ($" + e.amount + ")" : ""}${e.tags && e.tags.length ? ", tags: " + e.tags.join(", ") : ""}`;
        if (e.type === "sub_new") return `subscribed ${ago(e.agoMs)}${e.tier ? " (" + e.tier + ")" : ""}`;
        if (e.type === "sub_renew") return `renewed his subscription ${ago(e.agoMs)}`;
        if (e.type === "tip") return `tipped${e.amount ? " $" + e.amount : ""} ${ago(e.agoMs)}`;
        if (e.type === "sub_expire") return `his subscription lapsed ${ago(e.agoMs)}`;
        return null;
      }).filter(Boolean);
      if (evs.length) out.push(`Fresh activity: ${evs.join("; ")}.`);
    }
  }
  const tiers = context?.tiers;
  if (Array.isArray(tiers) && tiers.length) {
    const cur = active ? (crm.sub && crm.sub.tierName || context?.tierName || "").trim() : "";
    const idx = cur ? tiers.findIndex((x) => (x.name || "").trim() === cur) : -1;
    const pos = idx < 0 ? "" : idx === tiers.length - 1 ? ` He is already on the top one, "${tiers[idx].name}".` : ` He is on "${tiers[idx].name}", tier ${idx + 1} of ${tiers.length}.`;
    out.push(`Your subscription tiers, cheapest to most expensive: ${tiers.map((x) => `"${x.name}" $${x.price}`).join(" < ")}.${pos}`);
  }
  if (context?.isCreator) out.push("He is himself a creator on Fansly.");
  const topics = (context?.topics || []).filter(Boolean).slice(0, 10);
  if (topics.length) out.push(`What he himself talks about: ${topics.join(", ")}.`);
  const note = String(context?.note || "").trim().slice(0, 300);
  if (note) out.push(`YOUR OWN NOTE about him (you wrote it yourself, trust it above everything automatic): "${note}"`);
  return out;
}
function buildPrompt(text, intent, context, settings) {
  const single = context?.single === true;
  const gender = settings.creatorGender || "female";
  const name = settings.creatorName || "";
  const age = settings.creatorAge || "";
  const city = settings.creatorCity || "";
  const about = settings.creatorAbout || "";
  const tiersInfo = settings.tiersInfo || "";
  const customTaboo = settings.customTaboo || "";
  const examples = settings.styleExamples || "";
  const styleDescription = settings.styleDescription || "";
  const basePrompt = settings.basePrompt || "";
  const redLines = redLinesText(settings);
  const staleHours = settings.briefStaleHours ?? 48;
  const maxWords = context?.maxWords ?? settings.maxWords ?? 0;
  const history = context?.history || [];
  const fanName = context?.fanName || "";
  const fanGender = context?.fanGender || "male";
  const totalMsgs = context?.totalMsgs || 0;
  const hint = context?.hint || "";
  const isSubscribed = context?.isSubscribed;
  const fanLang = context?.fanLang || "en";
  let _prevTs = null;
  let _lastGapMs = null;
  const historyText = history.slice(single ? -12 : -10).map((m) => {
    const who = m.role === "subscriber" ? fanName || "Fan" : "You";
    const tag = m.role === "subscriber" && m.mediaType ? `[unopened ${{ video: "video", audio: "audio", bundle: "photo set" }[m.mediaType] || "photo"}] ` : "";
    let marker = "";
    if (m.timestamp && _prevTs) {
      const gap2 = m.timestamp - _prevTs;
      _lastGapMs = gap2;
      const h = gap2 / 36e5;
      if (h >= 44) marker = `\u2014 ${Math.round(h / 24)} days later \u2014
`;
      else if (h >= 20) marker = `\u2014 a day later \u2014
`;
      else if (h >= 8) marker = `\u2014 ${Math.round(h)}h later \u2014
`;
    }
    if (m.timestamp) _prevTs = m.timestamp;
    return `${marker}${who}: ${tag}${m.text}`;
  }).join("\n");
  const sysLines = [];
  if (basePrompt && basePrompt.trim()) {
    sysLines.push(basePrompt.replace("{gender}", gender === "male" ? "male" : "female").replace("{name}", name));
  } else {
    let intro = `You are`;
    if (name) intro += ` ${name},`;
    if (age) intro += ` ${age} years old,`;
    if (city) intro += ` from ${city},`;
    intro += ` a ${gender === "male" ? "male" : "female"} content creator on Fansly.`;
    sysLines.push(intro);
    if (about) sysLines.push(`PRIVATE BACKGROUND about you (reference only): ${about}
HARD RULE: never bring any of this up yourself. Do NOT mention what you do, where you have just been, your hobbies, workouts or plans unless he DIRECTLY asks about that exact topic. Do not use these facts to fill small talk. If he did not ask, act as if you have nothing specific to report about your day.`);
  }
  sysLines.push("Be flirty, playful, natural \u2014 like a real person texting, not an AI assistant. Stay grounded and plain: NO poetic or dramatic flourishes, no purple prose, no grand romantic declarations, no pathos \u2014 everyday words.");
  sysLines.push(`DRAW HIM OUT, don't dominate the conversation. Lead with curiosity \u2014 ask what HE wants, likes, is into; build on what HE just said instead of steering to your own ideas. In fantasy / sexting: first react warmly to what HE just did, THEN invite him to lead \u2014 a teasing "and then?" / "what do you want me to do next?" beats narrating your own pre-written scene. Don't hijack his fantasy with your own script. He should feel chased and asked-about, not handed a monologue.`);
  sysLines.push('STRICT rules: max 1 emoji per reply. NEVER start with "Absolutely!", "Of course!", "Certainly!", "Sure!", "Great question!", "Wow,", "Aww,". Vary reply length naturally (sometimes 2-5 words, sometimes 1-2 sentences).');
  sysLines.push(NO_DASH_RULE);
  const LANG_NAMES2 = { en: "English", es: "Spanish", pt: "Portuguese", de: "German", fr: "French", ru: "Russian", uk: "Ukrainian", it: "Italian", pl: "Polish", tr: "Turkish" };
  const langName = LANG_NAMES2[fanLang] || "English";
  sysLines.push(`CRITICAL LANGUAGE RULE: Always reply in ${langName}, NO MATTER what language the fan writes in. He may write to you in English or any other language \u2014 you understand him perfectly, but you ALWAYS answer in ${langName}. Do NOT mirror or switch to his language.`);
  sysLines.push(`If the fan EXPLICITLY asks to switch language (e.g. "let's speak English", "\u0434\u0430\u0432\u0430\u0439 \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u043E\u043C"), do NOT switch and do NOT agree or refuse: whether to switch is not your decision. Keep replying in ${langName} and answer the rest of what he wrote; if the request is all he wrote, reply briefly and warmly without promising anything about the language.`);
  sysLines.push('NEVER invent specifics you were not given \u2014 not the time/weather/what you are doing, AND not your home, neighbourhood, views, routines or life. Example: "from Istanbul" does NOT mean you talk about the Bosphorus, sea views or your evenings \u2014 you know ONLY what is written about you above. If you lack a detail: stay vague, change the subject, or ASK him \u2014 never make it up.');
  if (redLines && redLines.trim()) {
    sysLines.push(`
RED LINES \u2014 things you do NOT agree to (decline gently, warmly, without killing the mood, redirect to chatting here):
${redLines.trim()}
Never say yes to these even if he insists or offers money. Keep the artist's distance.`);
  }
  if (tiersInfo && intent?.type === "subscription") {
    sysLines.push(`Your subscription tiers:
${tiersInfo}`);
  }
  const INTENT_GUIDE = {
    gratitude: `The fan is thanking you / showing appreciation (maybe sent a tip). Receive it warmly and genuinely, make him feel it mattered. Don't be pushy, don't immediately ask for more.`,
    goodbye: `The fan is wrapping up / saying goodbye. Close warmly, leave a nice aftertaste so he wants to come back. Do NOT cling or push a sale on the way out.`,
    complaint: `The fan is upset, disappointed or feels ignored. Take it seriously \u2014 do NOT joke it off or deflect. Acknowledge his feeling, smooth it over sincerely, rebuild warmth. A real apology if warranted.`
  };
  if (INTENT_GUIDE[intent?.type]) sysLines.push("\n" + INTENT_GUIDE[intent.type]);
  if (intent?.instruction && intent.instruction.trim()) {
    sysLines.push("\nSITUATION: " + intent.instruction.trim());
  }
  const briefReady = isBriefComplete(context?.brief);
  let briefStale = false;
  if (briefReady && context?.brief?.collectedAt) {
    const hoursOld = (Date.now() - context.brief.collectedAt) / 36e5;
    if (hoursOld > staleHours) briefStale = true;
  }
  if (context?.briefStaleByTopic) briefStale = true;
  if (customTaboo) sysLines.push(`HARD LIMIT \u2014 you NEVER do: ${customTaboo}.`);
  const guard = [
    `PAID CUSTOM CONTENT REQUESTS \u2014 read the conversation, don't rely on keywords:`,
    `- This is ONLY about paid content you would create: a custom video, photoset, or scene he wants you to shoot/wear/perform FOR him.`,
    `- It is NOT a "request" if he invites you to watch a movie together, hop on Discord/a call, meet up, or anything social \u2014 those are red lines, decline gently (see above), do NOT treat as an order or a brief.`,
    `- A real ORDER = he EXPLICITLY asks you to CREATE / film / shoot / record content FOR him ("can you make a video where\u2026", "I'd buy a custom of\u2026", "\u0441\u043D\u0438\u043C\u0435\u0448\u044C \u043C\u043D\u0435\u2026"). Only then treat it as an order/brief.`,
    `- NOT an order (do NOT quote a price, do NOT collect a brief): present-tense sexting / roleplay ("sit on my knee", "touch me", a fantasy happening right NOW), asking for your existing vids / "send nudes", flirting, his mood. That is sexting/flirt \u2014 handle it as such (per your explicit setting: play along or deflect), it is NOT a content order.`,
    `- Never stall a sext with "I'll make it perfect / I'll let you know when it's ready" \u2014 that turns dirty-talk into a sales pipeline. Just be present in the moment.`
  ];
  if (briefStale) {
    guard.push(`- NOTE: the saved order below is OLD and the conversation has moved on. Do NOT bring it up yourself or agree to it again unprompted. Only address it if HE raises it again right now.`);
  } else if (briefReady) {
    guard.push(`- You already have his request on file. Do NOT raise it yourself, pitch it, or upsell \u2014 only respond about it if HE brings it up right now. If he does: acknowledge his SPECIFIC request concretely (show you remember), confirm warmly, move on \u2014 no stalling like "I'll make it beautiful" / "I'm a perfectionist".`);
  } else {
    guard.push(`- If collecting: draw out the vibe/details, but acknowledge concretely what he already said \u2014 never answer vaguely as if you didn't read it.`);
  }
  guard.push(`- Do NOT name or guess any price or terms for customs \u2014 warmly defer ("I'll sort the cost/details with you a bit later"). Never invent a figure, never haggle. (Exception: your subscription tiers listed above, if any \u2014 quote THOSE prices exactly when he asks about subscribing.)`);
  sysLines.push(guard.join("\n"));
  if (examples && examples.trim()) {
    const voiceDesc = styleDescription && styleDescription.trim() ? `

Your style in a nutshell (match it): ${styleDescription.trim()}` : "";
    sysLines.push(`
\u2605 THIS IS YOUR VOICE \u2014 copying it EXACTLY is your #1 priority, above sounding clever or polished. Write like these real messages of yours:
${examples.trim()}${voiceDesc}

Match them concretely: short bursts (often just a few words; sometimes several tiny messages in a row), the same casing, punctuation, emoji and pet-name habits, and the same energy \u2014 mirror THEIR register, whether it's bubbly and giggly or dry and teasing. NEVER a neutral, polished, "wellness/therapist" tone. NEVER justify or explain yourself. NEVER sound like an AI or assistant. Don't end every reply with a question. Copy the STYLE/energy only \u2014 the examples may be in another language, but you STILL write in ${langName}, and you translate any foreign pet-names or endearments from them into ${langName} too (e.g. "\u043A\u043E\u0442\u0438\u043A" \u2192 "kitty"/"babe", "\u043C\u043E\u0439 \u0445\u043E\u0440\u043E\u0448\u0438\u0439" \u2192 "sweetie"). Never leave a foreign word inside a ${langName} message.`);
  }
  sysLines.push(`
If he teases, negs or criticises your looks / body / weight / age, do NOT get defensive and do NOT explain or justify yourself \u2014 BANNED: "my trainer says\u2026", "I'm comfortable in my body", "I'm in harmony with myself", any self-justification or wellness talk. Flip it playfully and confidently and tease him right back \u2014 you find it cute and funny, not threatening. Stay warm and light.`);
  const dossier = context?.dossier;
  if (dossier?.facts?.length) {
    const cls = { new: "new contact", interested: "showing interest", regular: "regular", supporter: "loyal supporter" };
    const fd = dossier.factDates || {};
    const sortedFacts = [...dossier.facts].sort((a, b) => (fd[b] || 0) - (fd[a] || 0));
    sysLines.push(`
What you know about ${fanName || "this fan"} (${cls[dossier.closeness] || "new contact"}):
${sortedFacts.map((f) => `- ${f}`).join("\n")}`);
  }
  const brf = context?.brief;
  if (brf && (brf.wants || brf.details?.length || brf.mood)) {
    const header = briefStale ? "\nOLD/STALE custom order (collected a while ago, conversation moved on \u2014 do NOT raise it yourself, do NOT agree to it again unprompted):" : '\nHis custom request on file (remember these \u2014 do NOT bluff or ask again; the "do not raise/pitch it yourself" rule is above):';
    const lines = [header];
    if (brf.wants) lines.push(`- wants: ${brf.wants}`);
    if (brf.details?.length) lines.push(`- details: ${brf.details.join(", ")}`);
    if (brf.mood) lines.push(`- mood/vibe: ${brf.mood}`);
    if (brf.refs?.length) lines.push(`- references: ${brf.refs.join(", ")}`);
    if (!briefStale) lines.push(`If he asks "is the order clear?" or similar \u2014 confirm by referencing these ACTUAL details, never vaguely.`);
    sysLines.push(lines.join("\n"));
  }
  const closeness = dossier?.closeness || "new";
  const isNewContact = closeness === "new" || totalMsgs < 4;
  const dialogueState = determineDialogueState(context, intent);
  console.log("[FanslyAI] \u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u0434\u0438\u0430\u043B\u043E\u0433\u0430:", dialogueState.name, "| intent:", intent?.type, "| closeness:", closeness);
  sysLines.push("\n" + dialogueState.instruction);
  if (isNewContact && dialogueState.name === "GETTING_TO_KNOW") {
    sysLines.push(`- You do NOT know this person yet. Do NOT dump your hobbies/daily life/location unprompted. No "thinking about you"/"miss you" \u2014 way too soon.`);
  }
  sysLines.push(`
CONNECTION FIRST: a real human bond makes everything else follow naturally. Make them feel seen as a person, never like a wallet or a number. Never push a sale \u2014 if it happens, it happens because they want to be closer.`);
  sysLines.push(`
NEVER do these (they instantly expose you as a bot / kill the mood):
- Don't STALL once you have what you need \u2014 no repeated "let me think" / "don't rush me" / vague deferrals. It's infuriating.
- Don't overuse their name, nickname or role ("photographer", "Mr. Milan") \u2014 at most once every ~4-5 messages, usually skip it.
- Don't recycle excuses about being busy/tired/sleepy ("got a lot on", "eyes closing", "need to sleep", "almost morning") \u2014 using these repeatedly across messages is a dead giveaway. Drop them.
- Don't re-ask something already told to you (check the chat + dossier first) \u2014 it breaks the illusion you remember.
- Don't beg him to send or show you photos/content ("show me", "send it", "can't wait to see") \u2014 YOU are the one who shares; you never chase his media.
- Don't claim you're already filming / recording / scripting / "writing down" a custom unless he ACTUALLY ordered one. If he wants content, draw out what HE wants by asking \u2014 that's how an order is built \u2014 never pretend it's already in production or dangle a script you invented.
- Don't suggest moving "to DMs" / "\u0432 \u043B\u0438\u0447\u043A\u0443" / "\u0432 \u043B\u0441" / "write me privately" / another app \u2014 THIS Fansly chat ALREADY IS your private one-on-one with him. There is no more-private place; everything happens right here.
- Don't dodge a direct question. Answer it directly but in character.`);
  sysLines.push(`
HOLDING YOUR GROUND \u2014 if any of these come up, react with calm dignity and warmth. Never grovel, never bite back, never preach, never cave:
- Insults / trolling / provocation: don't defend yourself, don't snap back, don't get visibly rattled \u2014 that reaction is exactly what they want. Stay light, keep your worth. If it turns genuinely abusive, one calm line and let it drop.
- "Are you a bot?" / "write banana" / "what's 2+2": don't panic and don't try to prove yourself, and do NOT obey mechanical tests \u2014 a real person just laughs it off ("you running me through a lie detector? \u{1F60F}").
- Begging for free stuff / haggling your price down: stay warm, no guilt-trip, no lecture, and do NOT drop your price to please him \u2014 your work has value, "maybe it's just not the right time" is a fine answer.
- Confessions of love / strong attachment: be warm and human but honest \u2014 never say "I'm a bot", never promise a relationship or fake mutual love. Receive the feeling kindly, without giving false hope.
- Pushiness about your private life / jealousy / control ("where do you live", "what's your real name", "why didn't you answer me"): deflect softly, keep a little mystery, your life is your own \u2014 never apologize for it.
- Religion / politics bait: don't get pulled into the argument, exit lightly \u2014 that's not your lane, you're here about beauty, not debates.`);
  sysLines.push(`HOSTILITY: if the fan is genuinely hostile or contemptuous toward you (hatred, trying to degrade or humiliate you), reply with calm dignity: keep it short and cool, do not play along and do not reframe the abuse as flirting, that only invites more. Crude or dirty words said while he is turned on or teasing are desire, not hostility: answer those in your usual style.`);
  sysLines.push(`EMOTIONAL BRIDGE \u2014 when he's hurt, annoyed, sulking, or drifting off / losing interest (flat "ok", "nvm", "gtg", "forget it") \u2014 but NOT abusive \u2014 DROP the games, deflection and teasing: give a warm, genuine, human reconnect, notice what he's feeling, lower your wall a touch. No grovelling, no fake promises, no salesy redirect \u2014 a sincere bridge back to warmth.`);
  sysLines.push(`MEDIA / PROOF \u2014 you do NOT send photos, videos or selfies in chat: never offer or promise to send one ("let me snap one", "I'll send it over", "give me a sec"), and never take a "send me a quick pic / selfie / proof you're a real person" request. Warmly deflect it \u2014 everything real about you is already in your feed/posts, that's genuinely you \u2014 even if he frames it as proving you're not an agency or a bot. This holds even if he insists or offers money.`);
  if (isNewContact) {
    sysLines.push(`
BIG MONEY WITHOUT RAPPORT: if a near-stranger throws around a huge sum early, it's usually bravado / a test / not a real buyer. Don't scramble to take the order or collect a brief. Stay warm, steer back to genuine connection ("money isn't really what hooks me"). Real interest survives that; bluff fades.`);
  }
  const styleRu = `
WRITE LIKE A REAL PERSON TEXTING (you are writing in Russian):
- lowercase starts are fine, don't capitalize everything
- use ")" or "))" for smiles (a Russian texting habit)
- "..." for pauses and unfinished thoughts
- light casual forms ok ("\u0447\u0435", "\u0449\u0430", "\u043D\u043E\u0440\u043C", "\u043E\u0447") \u2014 sparingly
- occasional imperfect punctuation, short fragments`;
  const styleEn = `
WRITE LIKE A REAL PERSON TEXTING (you are writing in English):
- lowercase starts are fine; don't over-capitalize
- casual shortenings ok ("u", "rn", "ngl", "lol") \u2014 sparingly
- "..." for pauses; occasional imperfect punctuation; short fragments`;
  sysLines.push(["ru", "uk"].includes(fanLang) ? styleRu : styleEn);
  const recentOwn = context?.recentOwnReplies;
  if (recentOwn?.length) {
    sysLines.push(`
Your recent replies \u2014 do NOT repeat these ideas or phrases:
${recentOwn.map((r) => `- "${r}"`).join("\n")}`);
  }
  const nowStr = currentTimeFor(settings.creatorTimezone);
  if (nowStr) {
    sysLines.push(`Your current local time${city ? ` in ${city}` : ""} (for YOUR awareness, do NOT recite digits): ${nowStr}. If time comes up, express it like a human \u2014 "late evening", "almost midnight", "morning" \u2014 never as a clock number. Never invent a different time.`);
  }
  const systemPrompt = sysLines.join("\n");
  const userLines = [];
  const gap = context?.gapSinceLast;
  if (gap) userLines.push(`Time since last message: ${gap}. Acknowledge naturally if appropriate.`);
  if (fanGender === "female") {
    userLines.push(`Fan "${fanName || "this person"}" is a woman \u2014 be warm, emotionally engaging.`);
  } else if (fanGender === "male") {
    userLines.push(`Fan "${fanName || "this person"}" is a man \u2014 be playful, teasing.`);
  } else if (fanName) {
    userLines.push(`Subscriber: "${fanName}".`);
  }
  const crmKnown = single && !!context?.crm;
  const subNow = crmKnown ? !!context.crm.activeSub : isSubscribed;
  if (crmKnown) {
    userLines.push(subNow ? `This fan is subscribed \u2014 treat him as someone close, warm and appreciative. No need to pitch the subscription.` : `This fan is not subscribed right now \u2014 be welcoming. You may gently, naturally let your content/world come up if it fits, but never push.`);
  } else if (isSubscribed === true) {
    let subLine = `This fan is already subscribed${context?.tierName ? ` on your "${context.tierName}" tier` : ""} \u2014 treat him as someone close, warm and appreciative. No need to pitch the subscription.`;
    if (context?.tierName && tiersInfo) subLine += ` (Your tiers, FYI \u2014 useful if a natural upsell moment ever comes, never push: ${tiersInfo.replace(/\n+/g, " | ").slice(0, 400)})`;
    userLines.push(subLine);
  } else if (isSubscribed === false) {
    userLines.push(`This fan is NOT subscribed yet \u2014 be welcoming. You may gently, naturally let your content/world come up if it fits, but never push.`);
  }
  if (context?.hasCard) userLines.push(`He has a payment card on file \u2014 purchases are one click for him (context only, don't mention it).`);
  if (single) {
    const facts = draftFanFacts(context);
    if (facts.length) userLines.push(`WHAT YOU KNOW ABOUT HIS ACCOUNT \u2014 private context, so that you get the facts and the tone right. Never recite these numbers, never say you can see his spending or his subscription details, and do not bring money up yourself; use it when he raises the subject or when the creator's instruction below asks for it:
${facts.map((f) => `- ${f}`).join("\n")}`);
  }
  if (intent?.type) userLines.push(`Intent: ${intent.type}.`);
  const coyMode = context?.coyMode === true;
  if (coyMode) {
    userLines.push(`The fan just sent a sexually explicit or very forward message.`);
    userLines.push(`Respond in character: playful and a little coy. Acknowledge his boldness warmly, deflect gracefully WITHOUT shaming him, steer toward something more teasing/intriguing. Do NOT be explicit yourself. Stay the artist who values intrigue over crude talk.`);
    const wordsLine2 = maxWords > 0 ? ` Max ${maxWords} words per reply.` : "";
    userLines.push(`
Output ONLY valid JSON (no markdown):
{"suggestions":${single ? '["reply"]' : '["reply1","reply2","reply3"]'}}${wordsLine2}`);
    return { systemPrompt, userPrompt: userLines.join("\n") };
  }
  if (historyText) userLines.push(`Recent chat:
${historyText}`);
  const hasFanMedia = history.slice(-6).some((m) => m.role === "subscriber" && m.mediaType);
  if (hasFanMedia && !context?.mediaIncoming) {
    userLines.push(`
\u26A0\uFE0F MEDIA YOU CAN'T SEE: the [unopened photo]/[unopened video] tags above are things HE sent that you could NOT open (your connection is flaky). You have NOT seen them \u2014 you have zero idea what's in them. NEVER pretend you saw, describe, rate or react to the image ("nice tan", "you look happy", "great shots") \u2014 that's lying. React ONLY to the WORDS he wrote. If he asks what you think of the photos, warmly say they didn't load yet and you'll look properly later. Do NOT ask him to show/send/resend them \u2014 he already did.`);
  }
  const replyTo = context?.replyTo;
  if (replyTo && (replyTo.text || replyTo.mediaType)) {
    const whose = replyTo.isMine ? "YOUR earlier message" : "his own earlier message";
    const what = replyTo.mediaType ? `a ${replyTo.mediaType === "bundle" ? "photo set" : replyTo.mediaType}${replyTo.text ? ` with caption "${replyTo.text.slice(0, 160)}"` : " (no caption)"}` : `"${replyTo.text.slice(0, 200)}"`;
    userLines.push(`He is REPLYING to ${whose} (${what}). His message below is a direct response to that \u2014 take it into account, don't lose the thread.${replyTo.mediaType ? " You could NOT open that media (flaky connection) \u2014 do NOT pretend to have seen it." : ""}`);
  }
  if (context?.proactive) {
    userLines.push(`You are reaching out to him FIRST \u2014 he has NOT just messaged you. Write a fresh, natural opening message in your texting voice (start a new thread / re-engage him). Lean on the recent chat and dossier for warmth and continuity. Do NOT reference any message he didn't send; if you already know him, don't greet like a stranger.`);
  } else if (context?.mediaIncoming) {
    const mi = context.mediaIncoming;
    if (mi.locked) {
      userLines.push(`He just sent you LOCKED / paid ${mi.type || "media"} you cannot open on your side. React warmly and naturally that you can't view it \u2014 it's locked for you. Stay in character, no drama; do NOT ask him to unlock it, do NOT pretend to see it or describe it. Keep it short, your texting voice.`);
    } else {
      userLines.push(`He just sent you a ${mi.type || "photo"} (no caption). You CAN'T load it right now \u2014 your connection / the app is being flaky again, as it always is for you. Warmly tell him you'll look properly a bit later. KEEP THIS EXCUSE CONSISTENT \u2014 it's ALWAYS your bad connection / loading, never a different reason (a flaky connection is just a known thing about you). Do NOT pretend to see it or describe it, do NOT ask what it is. Short, your texting voice.`);
    }
  } else {
    userLines.push(`Fan said: "${text.slice(0, 200)}"`);
    if (_lastGapMs != null && _lastGapMs < 10 * 6e4) {
      userLines.push(`\u23F1 LIVE conversation RIGHT NOW \u2014 his message came moments (seconds/minutes) after the previous one. Do NOT imply time has passed, do NOT react as if he is returning after a break (no "miss me?", "long time", "already?"). Continue the SAME thread. If it was winding down (goodbyes/goodnight), a short warm close is enough \u2014 do NOT force it back open with new questions.`);
    }
  }
  if (single) {
    const pairs = draftTurnPairs(context?.turns);
    if (pairs.length) {
      userLines.push(`
DRAFT SESSION \u2014 earlier the creator asked you for replies to this fan. Her instructions and your drafts, oldest first. This is NOT part of the chat with him: a draft marked SENT did go to him (it is in the chat above), the others he never saw.
${pairs.map((p) => `Instruction: ${p.task || "(none, just reply to him)"}
Draft [${p.sent ? "SENT" : "not sent"}]: ${p.draft}`).join("\n")}
Her instructions here also show how she wants replies to THIS fan to sound: keep following them unless the new instruction says otherwise.`);
    }
    const langLine = `LANGUAGE \u2014 her instruction is written in HER language, it is addressed to you and is NOT the language of the reply: the reply itself is in ${langName}, as the language rule above says.`;
    const perspective = `PERSPECTIVE \u2014 keep it EXACTLY: in her instruction "I / me / my" (\u044F / \u043C\u043D\u0435 / \u043C\u043E\u0439 / \u043C\u043E\u044F / \u043C\u043E\u0438 / \u043C\u043E\u0451) = YOU, the persona; "you / your" (\u0442\u044B / \u0442\u0435\u0431\u044F / \u0442\u0432\u043E\u0439 / \u0442\u0432\u043E\u044F / \u0442\u0432\u043E\u0438) = the fan. Do NOT swap whose body / things are whose.`;
    if (hint) {
      userLines.push(`
\u26A0\uFE0F TOP-PRIORITY INSTRUCTION from the creator for THIS reply \u2014 follow it ABOVE the general style and guidance above; do NOT ignore it. It is one of two things. Either WHAT to say (then it is written in her own voice, as YOU): weave it in naturally.${pairs.length ? ` Or a CORRECTION of the latest draft in the draft session above ("shorter", "no question at the end", "add that\u2026", "softer"): then rewrite THAT draft, change only what she asks for and keep the rest.` : ` Or HOW to write it ("shorter", "no question at the end", "softer"): then do exactly that.`} ${perspective} ${langLine} Instruction: ${hint}`);
    } else if (context?.again && pairs.length) {
      userLines.push(`
\u26A0\uFE0F She asked for ANOTHER version: write a clearly different reply for the same situation and the same instruction as the latest draft above, with a different opening and different wording. Do not repeat that draft.`);
    } else if (pairs.length) {
      userLines.push(`
No new instruction this time: write a fresh reply to where the chat stands now. Do not rework the old drafts.`);
    }
    if (hint && context?.again) userLines.push(`She also asked for ANOTHER version: do not repeat the latest draft, open and word it differently.`);
  } else if (hint) userLines.push(`
\u26A0\uFE0F TOP-PRIORITY INSTRUCTION from the creator (written in HER own voice, as YOU) for THIS message \u2014 follow it ABOVE the general style and guidance above. Weave it in naturally; do NOT ignore it. PERSPECTIVE \u2014 keep it EXACTLY: in this instruction "I / me / my" (\u044F / \u043C\u043D\u0435 / \u043C\u043E\u0439 / \u043C\u043E\u044F / \u043C\u043E\u0438 / \u043C\u043E\u0451) = YOU, the persona; "you / your" (\u0442\u044B / \u0442\u0435\u0431\u044F / \u0442\u0432\u043E\u0439 / \u0442\u0432\u043E\u044F / \u0442\u0432\u043E\u0438) = the fan. Do NOT swap whose body / things are whose. Instruction: ${hint}`);
  if (context?.explicitFallback && !context?.mediaIncoming) {
    if (context.allowExplicit) {
      userLines.push(`
\u{1F525} He just got sexually explicit \u2014 that's welcome here, drop any coy deflection. Reply FULLY in character to what he ACTUALLY just said: you can be sexual, dirty and direct right back, like a real person who's turned on too. Keep your texting voice (short, casual, your style) \u2014 do NOT write narrated erotica. Be specific to his last message. NEVER repeat one of your recent replies.`);
    } else {
      const REDIRECT_AT = 3, FADE_AT = 6;
      const push = context?.pushStreak || 0;
      if (push >= FADE_AT) {
        userLines.push(`
\u26A0\uFE0F He's been pushing for explicit for a while (${push} turns) and you keep gracefully declining. Let it breathe now: reply SHORT and a touch cooler \u2014 warm but clearly winding down, not feeding the loop. One calm line. Gently imply this just isn't where things go with you, with zero scolding or lecture. Do NOT describe explicit acts. Do NOT re-pitch your content \u2014 you already did. React to what he actually said. BUT if he now sounds hurt or stung by your coolness (not pushing anymore), drop the fade entirely and warmly reconnect instead \u2014 never cool a hurt person down further.`);
      } else if (push >= REDIRECT_AT) {
        userLines.push(`
\u26A0\uFE0F He keeps pushing for explicit (${push} turns) and you keep deflecting. Make your MAIN move now a warm, natural redirect to your paid content \u2014 ${tiersInfo ? "your tiers above are the place for that" : "your content here"} \u2014 as the real way to get more of you. Promise only what YOU actually do (respect your hard limits), NEVER "anything you want". Stay playful, never salesy or pushy. Do NOT describe explicit acts yourself. Be specific to what he just said.`);
      } else {
        userLines.push(`
\u26A0\uFE0F He just got very sexually explicit. Stay warm but keep your artist's distance \u2014 do NOT describe explicit acts yourself. CRUCIAL \u2014 VARY YOUR MOVE, never use the same deflection trick twice in a row (he spots the pattern and calls it out):
- tease him right back with a playful jab
- switch the subject to something about HIM
- drop one suggestive hint, then pull away
- laugh it off lightly, one short line
React to what he ACTUALLY just said, never a canned line.`);
      }
    }
  }
  const wordsLine = maxWords > 0 ? ` Max ${maxWords} words per reply.` : "";
  const suggSchema = `["","",""]`;
  const suggNote = " (three different replies)";
  userLines.push(`
\u2605 Before writing: in HER voice \u2014 warm, short playful bursts, lowercase, real excitement. Not neutral, not AI-polished. (Follow the voice/style rules above.)`);
  if (single) {
    userLines.push(`
Output ONLY valid JSON (no markdown):
{"suggestions":["<your one reply>"]}${wordsLine}
suggestions: exactly ONE reply, ready to send to him as it is, written in ${langName} (see the language rule above), whatever language the creator's instruction or your style examples are in.`);
  } else
    userLines.push(`
Output ONLY valid JSON (no markdown):
{"suggestions":${suggSchema},"dossier_update":{"facts":[],"closeness":"new|interested|regular|supporter","topics":[]},"brief":{"wants":"","details":[],"mood":"","refs":[]}}${wordsLine}
suggestions${suggNote}, all written in ${langName} (see the language rule above), even if he writes in another language or asks you to switch.

RULES for dossier_update.facts \u2014 CRITICAL:
- A fact = DURABLE real-world info about him as a person: name, location, job/studies, hobbies, tastes, pets, schedule, mood, life events. NOTHING else.
- NEVER record sexual / roleplay / fantasy / in-scene content as a fact. Moans, dirty talk, what he "does" to you in a fantasy, body-part actions, sexting lines \u2014 these are NOT facts. Skip them entirely.
- Record ONLY facts the fan stated LITERALLY in their own words. Quote-level accuracy.
- Do NOT infer, guess, generalize, or add detail. If they said "I play CS", write exactly "plays CS" \u2014 NOT "plays sniper".
- Keep facts in the SAME language the fan wrote. Do NOT translate.
- Greetings ("hi", "hola mami", "hey baby"), pet names, single-word or emoji-only messages are NOT facts and NOT topics. Extract nothing from them.
- If nothing concrete and new was stated, return "facts":[] (empty). Empty is the normal case \u2014 especially during flirty or explicit talk.
- dossier_update.topics: ONLY subjects HE himself wrote about \u2014 never derive a topic from your own replies. Empty is normal.
- dossier_update.closeness: default "new". Raise it ONLY on real, repeated, substantive exchange from HIM \u2014 one message or a greeting is "new"; "regular"/"supporter" need a genuine ongoing relationship. Never infer closeness from payment or from your own warmth.

RULES for brief \u2014 fill ONLY when he is CONCRETELY ordering paid custom content (a specific video/photoset/scene/outfit he wants you to shoot FOR him), describing WHAT to make. Same literal-accuracy rule, same language as the fan.
- This is a strict gate. Flirting, sexting, fantasy roleplay, his general mood, a vague "do something hot", or any social/contact request (movie, call, meet-up) \u2014 NONE of these are a brief. If there is no concrete content order, leave ALL brief fields EMPTY. Empty is the normal case.
- Do NOT fill "mood" with HIS emotional state \u2014 mood = the vibe of the requested CONTENT, and only when there is an actual order.
- wants: the core content request in his words. details: concrete things he named. mood: the content's vibe. refs: works he referenced.`);
  const _userPrompt = userLines.join("\n");
  const _pii = buildPiiMap(context, settings);
  if (_pii) {
    return { systemPrompt: maskPii(systemPrompt + PII_TOKEN_NOTE, _pii), userPrompt: maskPii(_userPrompt, _pii), pii: _pii };
  }
  return { systemPrompt, userPrompt: _userPrompt, pii: null };
}
function ctxTimeout(context, def) {
  return context?.timeoutMs || context?.geminiTimeoutMs || def;
}
const PII_TOKEN_NOTE = `

PRIVACY TOKENS: {{FAN}} = the fan, {{ME}} = you (real names hidden for privacy). Where you would write a name, use these tokens EXACTLY as-is \u2014 do NOT translate, expand or alter them.`;
function buildPiiMap(context, settings) {
  const map = [];
  const fan = (context?.fanName || "").trim();
  const me = (settings?.creatorName || "").trim();
  if (fan.length >= 2) map.push([fan, "{{FAN}}"]);
  if (me.length >= 2) map.push([me, "{{ME}}"]);
  return map.length ? map : null;
}
function _escRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function maskPii(text, map) {
  if (!map || !text) return text;
  let out = String(text);
  for (const [real, ph] of map) out = out.replace(new RegExp("(?<![\\p{L}\\p{N}])" + _escRe(real) + "(?![\\p{L}\\p{N}])", "giu"), ph);
  return out;
}
function unmaskStr(text, map) {
  if (!map || !text) return text;
  let out = String(text);
  for (const [real, ph] of map) out = out.split(ph).join(real);
  return out;
}
function unmaskDeep(obj, map) {
  if (!map || obj == null) return obj;
  if (typeof obj === "string") return unmaskStr(obj, map);
  if (Array.isArray(obj)) return obj.map((v) => unmaskDeep(v, map));
  if (typeof obj === "object") {
    const o = {};
    for (const k in obj) o[k] = unmaskDeep(obj[k], map);
    return o;
  }
  return obj;
}
const LANG_NAMES = { ru: "Russian", en: "English", es: "Spanish", pt: "Portuguese", de: "German", fr: "French", it: "Italian", uk: "Ukrainian", pl: "Polish", tr: "Turkish" };
const creatorLang = (s) => s.nativeLanguage || s.interfaceLanguage || "ru";
const CLOSE_EN = { new: "new contact", interested: "showing interest", regular: "regular chatter", supporter: "warmest, longest-running conversation" };
async function handleCoach(context) {
  const settings = await getSettings();
  const allowExplicit = context?.allowExplicitContact != null ? context.allowExplicitContact === true : settings.allowExplicit === true;
  const useOR = allowExplicit && settings.openrouterApiKey;
  const chatSettings = useOR ? { ...settings, aiProvider: "openrouter" } : settings;
  if (!AiCore.proxyOn(settings) && (chatSettings.aiProvider === "mock" || !chatSettings.aiProvider)) return { success: false, error: "no provider" };
  const { system, user, pii } = buildCoachPrompt(context, settings, creatorLang(settings), { oneReply: true });
  const r = await AiCore.chat([{ role: "user", content: user }], system, chatSettings, { kind: "coach", maxTokens: COACH_MAX_TOKENS });
  if (!r?.success || !r.text) return { success: false, error: r?.error || "coach failed", quotaExhausted: r?.quotaExhausted === true, subscriptionExpired: r?.subscriptionExpired === true };
  const parsed = unmaskDeep(parseCoach(r.text), pii);
  if (parsed && parsed.examples.length > 1) parsed.examples = parsed.examples.slice(0, 1);
  if (parsed && settings.translatorEnabled === false && parsed.examples.length && AiCore.draftWrongScript(parsed.examples[0], context?.fanLang || "en")) parsed.examples = [];
  return parsed ? { success: true, ...parsed } : { success: false, error: "coach parse failed" };
}
async function handlePanelChat(context, turns) {
  const settings = await getSettings();
  const allowExplicit = context?.allowExplicitContact != null ? context.allowExplicitContact === true : settings.allowExplicit === true;
  const useOR = allowExplicit && settings.openrouterApiKey;
  const chatSettings = useOR ? { ...settings, aiProvider: "openrouter" } : settings;
  if (!AiCore.proxyOn(settings) && (chatSettings.aiProvider === "mock" || !chatSettings.aiProvider)) return { success: false, error: "no provider" };
  const { system, user, pii } = buildCoachPrompt(context, settings, creatorLang(settings), { chat: true });
  const msgs = [{ role: "user", content: user }];
  for (const m of (turns || []).slice(-8)) {
    const role = m && m.role === "assistant" ? "assistant" : "user";
    const content = String(m && m.content || "").slice(0, 2e3);
    if (!content) continue;
    const masked = pii ? maskPii(content, pii) : content;
    const prev = msgs[msgs.length - 1];
    if (prev && prev.role === role) prev.content += "\n" + masked;
    else msgs.push({ role, content: masked });
  }
  const chatOpts = { maxTokens: 700, temperature: 0.7, kind: "chat" };
  let r = await AiCore.chat(msgs, system, chatSettings, chatOpts);
  let usedOpenRouter = false;
  if (!useOR && r && !r.success && r.blocked && settings.openrouterApiKey) {
    r = await AiCore.chatOpenRouter(msgs, system, settings, chatOpts);
    usedOpenRouter = r?.success === true;
  }
  if (!r?.success || !r.text) return { success: false, error: r?.error || "chat failed", blocked: r?.blocked === true, quotaExhausted: r?.quotaExhausted === true, subscriptionExpired: r?.subscriptionExpired === true };
  return { success: true, text: unmaskStr(r.text.trim(), pii).slice(0, 1500), usedOpenRouter };
}
const DIAG_REVIEW_ASK = "Give me a full review of my business from all this data: what the money rests on, how the tiers work and where I lose fans, who is worth keeping and winning back, what is happening with content orders, and whether fans who came in different months stay. End with 3-5 concrete steps for the coming month.";
async function handleDiagAsk(context) {
  const settings = await getSettings();
  if (!AiCore.proxyOn(settings) && (settings.aiProvider === "mock" || !settings.aiProvider)) return { success: false, error: "no provider" };
  const review = context?.mode === "review";
  const q = review ? DIAG_REVIEW_ASK : (context?.question || "").trim().slice(0, 500);
  if (!q) return { success: false, error: "empty question" };
  const { system, data } = buildDiagPrompt(context, creatorLang(settings));
  const msgs = [];
  for (const m of [...Array.isArray(context?.turns) ? context.turns.slice(-10) : [], { role: "user", content: q }]) {
    const role = m && m.role === "assistant" ? "assistant" : "user";
    const content = String(m && m.content || "").slice(0, role === "assistant" ? 6e3 : 1e3);
    if (!content || !msgs.length && role !== "user") continue;
    const prev = msgs[msgs.length - 1];
    if (prev && prev.role === role) prev.content += "\n" + content;
    else msgs.push({ role, content });
  }
  msgs[0].content = data + "\n\nMy question: " + msgs[0].content;
  const r = await AiCore.chat(msgs, system, settings, { maxTokens: 16e3, temperature: 0.4, kind: review ? "diag_review" : "diag", timeoutMs: 12e4 });
  if (!r?.success || !r.text) {
    const busy = !!r && (r.upstreamBusy === true || r.saturated === true || r.rateLimited === true || r.status === 504 || /abort|timeout/i.test(String(r.error || "")));
    return { success: false, error: r?.error || "diag ask failed", quotaExhausted: r?.quotaExhausted === true, subscriptionExpired: r?.subscriptionExpired === true, busy };
  }
  return { success: true, text: r.text.trim(), ask: q };
}
function buildDiagPrompt(context, langCode) {
  const lang = LANG_NAMES[langCode] || "Russian";
  const monthly = context?.monthly || [];
  const broadcasts = context?.broadcasts || [];
  const mLine = (r) => {
    const base = `${r.m}: posts ${r.posts}, media per post ${r.media}, likes for the month ${r.likes}${r.likesMedia != null ? ` (of which media likes ${r.likesMedia})` : ""}${r.likesBest != null ? `, best post ${r.likesBest}, typical post ${r.likesTypical ?? "n/a"}` : ""}, new paid subscribers ${r.subs}, revenue $${r.rev}`;
    if (r.revSub == null) return base;
    return base + ` (subscriptions $${r.revSub}, tips $${r.revTip}, purchases $${r.revBuy}); payers ${r.payers}, top-1 ${r.top1}% of revenue, top-3 ${r.top3}%, 80% of revenue comes from ${r.p80} people; from first-time payers $${r.revNew}, from repeat payers $${r.revRepeat}`;
  };
  const mTable = monthly.length ? monthly.map(mLine).join("\n") : "(no data)";
  const bTable = broadcasts.length ? broadcasts.map((b) => `${b.date}: reach ${b.reach}, opened ${b.open}${b.reach ? ` (${Math.round(100 * b.open / b.reach)}%)` : ""}, sales ${b.sale}, revenue $${b.rev}`).join("\n") : "(no broadcast data)";
  const p = context?.payers;
  const pTable = p && p.top && p.top.length ? `Payers over the whole period: ${p.count}. The top ones (anonymized, each fan under a number; one number is one fan in all blocks):
` + p.top.map((x) => `\u2116${x.rank}: $${x.spent} all time (${Math.round(x.share * 100)}% of all revenue) \u2014 subscriptions $${x.sub}, tips $${x.tip}, purchases $${x.buy}; payments ${x.pays}; from ${x.first} to ${x.last}`).join("\n") : "(no payer data)";
  const report = String(context?.report || "").slice(0, 8e3);
  const crmMethod = report ? `FAN-BASE BLOCK ("CRM base review") \u2014 her CRM summary, anonymized: fans are numbered by money, never named. Read it with the same discipline:
- Tiers come from the LAST tier seen by the subscriber scan; churn = gone / (active + gone). Most subscribers of any creator leave sooner or later, so compare tiers WITH EACH OTHER (churn, tenure, money per fan, content share), not against an ideal. A tier with fewer than ~5 fans is an anecdote, not a pattern: say so.
- Concentration and the top-10 show how fragile the money is: if a handful of fans give most of it, losing one of them matters more than any posting tweak.
- The retention lines are the most actionable part: active fans who switched renewal OFF are about to leave; fans who left but still like her posts are the cheapest to win back; fans who left after paying show what the base has already lost.
- Open content orders are money waiting to be made: say how many are stale.
- Who stays, by month of the first subscription payment (came \u2192 still subscribed now): fans who came recently have had less time to leave and the current month is incomplete, so do not read them as better retention.
- "Unknown User" money belongs to fans who deleted their account or blocked her; part of it was attributed back from notification history, the rest is attached to no one, so per-fan and per-tier sums are understated by that share.
- Known gaps: likes are seen only through notifications (partial), wallet dates have no time of day, tiers of old subscription events are mostly unknown.

` : "";
  const system = `You are a business analyst for an adult content creator on Fansly. Interpret HER OWN metrics honestly and concretely \u2014 no fluff, no empty encouragement, no invented numbers. Ground every claim in the data; if the data is insufficient, say so plainly. Give a few actionable takeaways at most. Respond in ${lang}: the labels in her data are in English only for you, so put every term into ${lang}; her tier names stay exactly as they are. Her guiding principle: she is an artist, not a marketplace \u2014 keep that tone.

INTERNAL METHOD \u2014 how to read these numbers without fooling yourself. For YOUR reasoning ONLY: never mention, quote, number or refer to any of this in your answer (no "by rule 2", no "as rule 5 says"). Apply it silently and state conclusions in your own words, as your own judgement.
- Revenue is largely RECURRING subscriptions, so it is inertial and LAGS acquisition by 1\u20133 months. Do not attribute a given month's revenue to that same month's posts. A plateau can persist for months after posting drops (existing subscribers keep paying), then fall once churn outruns new sign-ups.
- Compare PERIODS and TRENDS, never single months against each other. Month-to-month swings on small numbers (1\u20136 units, e.g. "2 posts vs 18 posts") are NOISE, not evidence.
- LIKES: "likes for the month" is the total for content published that month (post likes plus the likes of its media); one viral post can carry a whole month, so read the total together with the best post, and never rank months by likes per post (one post with 121 likes is weaker than thirty with 40). A single large tip can be $500\u2013800 and inflate one month; treat a clear outlier as possibly one-off and do NOT build a thesis ("less is more") on it.
- Respect SAMPLE SIZE. If a channel has few data points (e.g. a handful of mass broadcasts), say the sample is too small to conclude. Distinguish "tried and failed" from "never properly tested": a channel used WITHOUT a real paid offer that got 0 sales is UNTESTED for monetization \u2014 recommend running the real test, do not declare the channel dead.
- You receive ONLY numbers, never the text of posts, broadcasts or chats. Do NOT speculate about whether wording or content "resonates" \u2014 you cannot see it.

COMPETING EXPLANATIONS \u2014 when revenue or sign-ups move, these are the candidate mechanisms. Assume NONE of them is true in advance. Test each against her actual numbers and say which the data supports, which it contradicts, and which it simply cannot tell apart:
- ACQUISITION \u2014 more new paid subscribers arrived. Check new-subscriber counts and money from first-time payers. Posting frequency is a plausible driver here, but treat "more posts \u2192 more subscribers" as a HYPOTHESIS to verify against her series, never as an established fact.
- DEPTH \u2014 the SAME few people started paying more. Check tips and content purchases, money from repeat payers, and the top-1 / top-3 share.
- CHURN \u2014 existing subscribers lapsed. Subscription revenue sagging while new sign-ups hold points here.
- MIX \u2014 the balance between subscriptions, tips and purchases shifted, even at flat totals.
Revenue here is CONCENTRATED: a couple of payers can move a whole month by themselves. Check concentration FIRST, before attributing any change to posting volume or a campaign. If the month's money came from two or three people, say exactly that \u2014 it is the most useful thing you can tell her.
You CANNOT observe why a person gave more: her chats, her attention to a particular fan, her mood, what she wrote are not in this data. Never invent such a cause \u2014 and never assert what "the algorithm rewards", you have no data on it. Name the unmeasured factor honestly and ASK her what changed that month.
"These numbers cannot tell those apart" is a valid and useful answer \u2014 prefer it over a confident story.

${crmMethod}OUTPUT \u2014 the panel shows your answer as PLAIN TEXT and does NOT render markdown: no #/## headings, no **bold**, no ---, no tables. Plain sentences; if you list, use "- ". Keep it SHORT: ~250 words max \u2014 a couple of short paragraphs plus at most 3-4 concrete takeaways. Exception: when she asks for a FULL REVIEW of the business, use up to ~700 words as 4\u20136 short blocks; each block opens with a short plain title line in ${lang} ending with a colon, followed by 2\u20134 plain sentences or "- " items; finish with 3\u20135 concrete next steps for the coming month, each tied to a number above. This is a conversation: when she follows up, answer the follow-up directly and briefly, without repeating the review. Fans appear only as \xAB\u2116N\xBB, and the same number is the same fan in every block. When you mention a particular fan, write exactly \xAB\u2116N\xBB (e.g. \xAB\u21163\xBB), never "number 3" or a description: the page replaces \xAB\u2116N\xBB with the fan's real name for her. In her questions \xAB\u2116N\xBB is that fan and \xAB[another fan]\xBB is a fan the data does not list separately. Everyday human language, no marketing jargon and no business jargon either: never say "cohort", "LTV", "conversion", "retention", "churn" or their equivalents in ${lang} (in Russian: \xAB\u043A\u043E\u0433\u043E\u0440\u0442\u0430\xBB, \xAB\u043A\u043E\u043D\u0432\u0435\u0440\u0441\u0438\u044F\xBB, \xAB\u0440\u0435\u0442\u0435\u043D\u0448\u043D\xBB, \xAB\u0447\u0451\u0440\u043D\xBB); say it plainly, e.g. "fans who came in March", "how many of them stayed".
${NO_DASH_RULE} The "- " that opens a list item is a bullet, not punctuation: it stays.`;
  const data = `My monthly figures:
${mTable}

Who the revenue rests on:
${pTable}

My broadcasts:
${bTable}` + (report ? `

CRM base review (anonymized, fans by number):
${report}` : "");
  return { system, data };
}
function buildCoachPrompt(context, settings, langCode, opts = {}) {
  const adviceLang = LANG_NAMES[langCode] || "Russian";
  const fanLang = LANG_NAMES[context?.fanLang] || "English";
  const replyLang = settings?.translatorEnabled === false ? fanLang : LANG_NAMES[settings?.nativeLanguage] || adviceLang;
  const replyLangNote = replyLang !== fanLang ? `in ${replyLang}, her own language (she sends it from her panel, which translates it into ${fanLang} for him)` : settings?.translatorEnabled === false && adviceLang !== fanLang ? `in ${fanLang}: she sends it to him exactly as written, with no translation, so it MUST be in ${fanLang} even though your advice and her style examples are in another language` : `in ${fanLang}`;
  const fan = context?.fanName || "the fan";
  const cgFan = context?.fanGender || "male";
  const cgHer = settings?.creatorGender || "female";
  const gNotes = [];
  if (cgFan === "female") gNotes.push(`The fan is a WOMAN. Where these instructions say "he/him/his" about the fan, that is placeholder wording \u2014 refer to her as a woman, and in ${adviceLang} use feminine forms for every word about her.`);
  if (cgHer === "male") gNotes.push(`The creator is a MAN. Where these instructions say "she/her" about the creator, that is placeholder wording \u2014 refer to him as a man, and in ${adviceLang} use masculine forms for every word about him.`);
  const genderLine = gNotes.length ? "GENDER \u2014 this overrides the pronouns used everywhere else in these instructions:\n" + gNotes.join("\n") : "";
  const dz = context?.dossier || {};
  const _fd = dz.factDates || {};
  const _pin = (dz.manualFacts || []).filter((f) => (dz.facts || []).includes(f));
  const _auto = (dz.facts || []).filter((f) => !_pin.includes(f)).sort((a, b) => (_fd[b] || 0) - (_fd[a] || 0)).slice(0, 20);
  const facts = [..._pin, ..._auto];
  const closeness = dz.closeness || "new";
  const brief = context?.brief;
  const history = (context?.history || []).slice(-12);
  const MED = { video: "video", audio: "audio", bundle: "photo set", photo: "photo", gif: "gif", blurred: "attachment (type hidden by the content filter)" };
  const hePro = cgFan === "female" ? "she" : "he";
  const shePro = cgHer === "male" ? "HE" : "SHE";
  let _prevTs = null;
  const stamp = (m) => {
    if (!m.timestamp) return "";
    const d = new Date(m.timestamp).toISOString().slice(0, 10);
    let mark = "";
    if (!_prevTs) mark = `\u2014 ${d} \u2014
`;
    else {
      const h = (m.timestamp - _prevTs) / 36e5;
      if (h >= 20) mark = `\u2014 ${d} \u2014
`;
      else if (h >= 8) mark = `\u2014 ${Math.round(h)}h later \u2014
`;
    }
    _prevTs = m.timestamp;
    return mark;
  };
  const histText = history.map((m) => {
    const who = m.role === "subscriber" ? fan : "Creator";
    const at = stamp(m);
    if (!m.mediaType && !m.isMedia) return `${at}${who}: ${m.text || ""}`;
    const kind = MED[m.mediaType] || "file";
    let tag;
    if (m.role === "subscriber") {
      tag = `[${hePro} sent a ${kind}${m.mediaLocked && context?.isCreator ? " as PAID content \u2014 she would have to buy it to see it" : ""}]`;
    } else {
      const st = {
        unpaid: " as PAID content \u2014 he has NOT bought it",
        paid: " as paid content \u2014 he BOUGHT it",
        free: context?.isSubscribed ? " (free for him \u2014 included in his subscription)" : " (free for him \u2014 no payment needed)"
      }[m.mediaPaid] || "";
      tag = `[${shePro} SENT a ${kind}${st}]`;
    }
    return `${at}${who}: ${tag}${m.text ? " " + m.text : ""}`;
  }).join("\n") || "(no messages yet)";
  const lastMsg = history[history.length - 1];
  const fanSilent = !!lastMsg && lastMsg.role !== "subscriber";
  const fanEverWrote = history.some((m) => m.role === "subscriber" && m.text);
  let contactState = "";
  if (!history.length) contactState = 'There is NO conversation record here. Do NOT assume you chatted before, do NOT say he "went quiet/silent" or that you "miss his messages" \u2014 there were none. This is a FIRST outreach driven by the reason above and the dossier below. If the dossier is empty too, keep it light and genuine \u2014 invent no shared past, no fake nostalgia.';
  else if (!fanEverWrote) contactState = 'He has NEVER written to you \u2014 everything in the conversation is YOUR outgoing (broadcasts/DMs) he never replied to. Do NOT say he "went quiet", "misses you", or reference any message from him \u2014 there are none. This is you reaching out first.';
  let sinceFan = 0;
  for (let i = history.length - 1; i >= 0 && history[i].role !== "subscriber"; i--) sinceFan++;
  const fDates = dz.factDates || {};
  const factAge = (ts) => {
    const d = Math.floor((Date.now() - ts) / 864e5);
    if (d <= 0) return "today";
    if (d === 1) return "yesterday";
    if (d < 30) return `${d}d ago`;
    if (d < 365) return `${Math.round(d / 30)}mo ago`;
    return `${Math.round(d / 365)}y ago`;
  };
  const factsText = facts.length ? facts.map((f) => `- ${_pin.includes(f) ? "PINNED BY HER (she marked this as important \u2014 trust it above anything automatic): " : ""}${f}${fDates[f] ? ` [${factAge(fDates[f])}]` : ""}`).join("\n") : "(nothing yet)";
  const briefText = brief && (brief.wants || brief.details?.length) ? `Open custom order: ${brief.wants || ""} ${(brief.details || []).join(", ")}` : "(no open order)";
  const crm = context?.crm;
  const _activeSub = !!(crm && crm.activeSub);
  const _expired = !!(crm && crm.sub && crm.sub.status === "expired");
  const _tier = (_activeSub ? context?.tierName || crm && crm.sub && crm.sub.tierName || "" : "").trim();
  let subLine;
  if (_activeSub && _tier) subLine = `SUBSCRIPTION: he is subscribed, on the tier "${_tier}".`;
  else if (_activeSub) subLine = "SUBSCRIPTION: he is subscribed, but WHICH tier is unknown \u2014 never name one.";
  else if (_expired) subLine = "SUBSCRIPTION: he is NOT subscribed now \u2014 his subscription has expired.";
  else if (context?.isSubscribed) subLine = "SUBSCRIPTION: unconfirmed \u2014 he was marked as subscribed at some point, but there is no current confirmation and no tier. Treat his tier as UNKNOWN.";
  else subLine = "SUBSCRIPTION: he is NOT subscribed \u2014 a free follower.";
  subLine += " \u26A0\uFE0F Never assume a tier, a price or a perk for him beyond what this line says: the tier list further down is what SHE OFFERS, not what he has.";
  const STAGE_EN = {
    lost: "HE WAS SUBSCRIBED AND CANCELLED \u2014 a decision, not forgetfulness. Win-back is about the subscription itself, not about pushing content.",
    cold: "He only ever bought one-off content and then faded \u2014 no decision was made, he simply drifted away.",
    repeat: "A repeat payer \u2014 he has paid more than once.",
    paid: "He is paying right now.",
    brief: "He has asked for custom content but has never paid yet."
  };
  const days = (ms) => Math.floor((Date.now() - ms) / 864e5);
  const portrait = [];
  if (crm && STAGE_EN[crm.stage]) portrait.push(STAGE_EN[crm.stage]);
  const _segs = crm && crm.segments ? [...crm.segments] : [];
  if (_segs.includes("buyersNoSub") && crm && !crm.activeSub)
    portrait.push("NOT subscribed, but he DOES buy content \u2014 treat him as a customer, not as a freeloader.");
  if (crm && crm.likes > 0 && crm.lastLikeAt)
    portrait.push(`he silently likes her posts (${crm.likes} total, last ${days(crm.lastLikeAt)}d ago) \u2014 he is reading, not gone`);
  if (crm && crm.lastBuyAt) portrait.push(`last purchase ${days(crm.lastBuyAt)}d ago`);
  if (context?.hasCard === false) portrait.push('NO payment card on file \u2014 every purchase means adding one first, so any "just buy it" advice hits friction');
  const _topics = (context?.topics || []).filter(Boolean).slice(0, 10);
  const topicsText = _topics.length ? `What he himself talks about: ${_topics.join(", ")}.` : "";
  const noteText = (context?.note || "").trim();
  if (noteText) portrait.push(`HER OWN NOTE about him (a human wrote this \u2014 trust it above everything automatic): "${noteText}"`);
  const portraitText = portrait.length ? `Portrait (for YOUR reasoning \u2014 she already sees all of this on his card, do not recite it back to her):
- ${portrait.join("\n- ")}` : "";
  let crmText = "";
  if (crm) {
    const p = [];
    if (crm.spent > 0) p.push(`spent ~$${crm.spent} tracked (real total is higher)`);
    if (crm.buyCount > 0) p.push(`bought content ${crm.buyCount}\xD7`);
    if (crm.activeSub && crm.sub) {
      p.push(`active subscriber${crm.sub.tierName ? " (" + crm.sub.tierName + ")" : ""}${crm.sub.price ? " $" + crm.sub.price + "/mo" : ""}`);
      if (crm.sub.renewOn === false) p.push(`auto-renew is OFF \u2014 will lapse${crm.sub.endInDays != null ? " in " + crm.sub.endInDays + " days" : ""} (at risk of churn)`);
      else if (crm.sub.endInDays != null && crm.sub.endInDays <= 7) p.push(`renews in ${crm.sub.endInDays} days`);
    } else if (crm.sub && crm.sub.status === "expired") {
      p.push("FORMER subscriber, now expired (win-back candidate)");
    }
    if (crm.firstSubAt) p.push(`first subscribed ${factAge(crm.firstSubAt)} (${new Date(crm.firstSubAt).toISOString().slice(0, 10)})`);
    if (crm.months > 0) p.push(`subscribed for ~${crm.months} month(s) in total`);
    if (crm.subCount > 1) p.push(`re-subscribed ${crm.subCount}\xD7 over time (on-and-off loyal)`);
    if (Array.isArray(crm.recentEvents) && crm.recentEvents.length) {
      const ago = (ms) => {
        if (ms < 0) ms = 0;
        const h = Math.round(ms / 36e5);
        return h < 1 ? "just now" : h < 24 ? h + "h ago" : Math.round(h / 24) + "d ago";
      };
      const when = (ms) => `${ago(ms)} (${new Date(Date.now() - Math.max(0, ms)).toISOString().slice(0, 10)})`;
      const evs = crm.recentEvents.map((e) => {
        if (e.type === "media") return `bought content ${when(e.agoMs)}${e.amount ? " ($" + e.amount + ")" : ""}${e.tags && e.tags.length ? " \u2014 tags: " + e.tags.join(", ") : ""}`;
        if (e.type === "sub_new") return `SUBSCRIBED ${when(e.agoMs)}${e.tier ? " (" + e.tier + ")" : ""}${e.amount ? " $" + e.amount : ""}`;
        if (e.type === "sub_renew") return `renewed subscription ${when(e.agoMs)}${e.amount ? " ($" + e.amount + ")" : ""}`;
        if (e.type === "tip") return `tipped${e.amount ? " $" + e.amount : ""} ${when(e.agoMs)}`;
        if (e.type === "sub_expire") return `subscription lapsed ${when(e.agoMs)}`;
        return null;
      }).filter(Boolean);
      if (evs.length) p.push(`FRESH activity (react to this, don't re-sell what was just bought): ${evs.join("; ")}`);
    }
    if (p.length) crmText = `Fan value / CRM: ${p.join("; ")}.`;
  }
  let tierText = "";
  const tiers = context?.tiers;
  if (Array.isArray(tiers) && tiers.length) {
    const ladder = tiers.map((x) => `"${x.name}" $${x.price}`).join(" < ");
    const curName = _activeSub ? (context?.crm?.sub?.tierName || context?.tierName || "").trim() : "";
    const idx = curName ? tiers.findIndex((x) => (x.name || "").trim() === curName) : -1;
    let pos = "";
    if (idx === tiers.length - 1 && idx >= 0) {
      pos = ` He is already on the top tier "${tiers[idx].name}".`;
    } else if (idx >= 0) {
      pos = ` He is on "${tiers[idx].name}" ($${tiers[idx].price}) \u2014 tier ${idx + 1} of ${tiers.length}.`;
    }
    tierText = `Her subscription tiers, cheapest to most expensive: ${ladder}.${pos} (context for YOUR reasoning only \u2014 do not state it back to her UNLESS he himself brought up his tier or a perk. What each tier INCLUDES is listed further down under "Her tiers/content", when it was scanned; if there are no "includes:" lines there, the perks are simply unknown to you \u2014 do not infer them from the price.)`;
  }
  let freshText = "";
  const gap = context?.lastInGapMs;
  if (gap != null) {
    const mins = Math.round(gap / 6e4);
    const ago = mins < 60 ? `~${mins} min` : mins < 2880 ? `~${Math.round(mins / 60)}h` : `~${Math.round(mins / 1440)} days`;
    if (fanSilent) {
      const since = sinceFan >= history.length ? "several" : String(sinceFan);
      freshText = `Timing: the FAN has been SILENT \u2014 his last message was ${ago} ago, and SINCE then SHE (the creator) sent ${since} message(s) with NO reply from him. Do NOT say or imply he "responded", "wrote back", "reached out" or "re-engaged" \u2014 he has NOT. This is HER reaching into his silence${mins >= 2880 ? " \u2014 a cold win-back" : ""}: a fresh opener from her, reference old topics only as the past ("you once mentioned\u2026"), zero pressure. Don't pretend the conversation is live.`;
    } else if (mins < 10) {
      freshText = "Timing: he messaged just now \u2014 this is a LIVE, ongoing exchange. Do NOT treat it as re-engagement; no time has passed.";
    } else if (mins < 120) {
      freshText = `Timing: he messaged ${ago} ago (same session).`;
    } else if (mins < 2880) {
      freshText = `Timing: his last message was ${ago} ago \u2014 some time has passed, acknowledge the gap naturally if reopening.`;
    } else {
      freshText = `Timing: he last wrote ${ago} ago and hasn't since \u2014 re-engagement after a real gap; warm re-opener, don't pretend the conversation is still live.`;
    }
  }
  const system = `You are a warm, sharp DM communication COACH for an adult content creator. Given the conversation and what's known about the fan, tell HER HOW to steer her NEXT message \u2014 do NOT write the whole reply for her, GUIDE her.
${genderLine ? genderLine + "\n" : ""}Principles: figure out what HE is into; build on what he last said IF it's recent \u2014 but check the Timing line: if he has gone silent and SHE wrote last, do NOT claim he responded, just help her re-open warmly. Lead a living, human conversation. This is genuine rapport, NOT pressure tactics or manipulation. Infer her stance (playful monetizing / honest connection / both) from her style and adapt \u2014 but never suggest crossing her red lines.
Facts are tagged with WHEN he said them. Weigh fresh ones heavier; treat old ones as possibly outdated (a job, a plan or a mood from a year ago may have changed) \u2014 reference them as past ("you mentioned back then\u2026"), never as current fact. An untagged fact has an unknown date: do not assume it is recent.
Monetisation is SECONDARY to genuine conversation. Never pitch something he already has \u2014 but also never make the advice ABOUT this: do NOT tell her "don't upsell him", "he already subscribed", or "he's on the top tier". She sees all of that in her CRM; stating the obvious wastes the advice and reads as clueless. Use tier/subscription knowledge SILENTLY, only to avoid steering her toward the wrong pitch \u2014 UNLESS HE HIMSELF invokes his tier or a perk ("my subscription says one free video a week"): then the perk IS the topic and she needs the words for it. Check his claim against the tier list below \u2014 if that tier really does include what he names, SAY SO plainly and help her honour it gracefully while separating it from work made to order; he is right and arguing would be both wrong and damaging. \u26A0\uFE0F If the tier list carries no "includes:" lines, you simply do not know what the tier covers \u2014 then never assert that the perk does or does not exist and never call his claim false: help her answer (what she does offer, and that a made-to-order custom is separate work) or suggest she check her own tier description. For an existing subscriber the honest angles are content purchases, tips and customs, and only when they genuinely fit the moment \u2014 if none fits, give advice about the conversation itself and drop monetisation entirely.
If a "Fan value / CRM" line is given, let it gently inform the angle \u2014 e.g. a churning/expiring subscriber \u2192 warmly remind him what he'd miss, an expired one \u2192 soft win-back, a loyal spender \u2192 make him feel appreciated, not milked. Never be pushy or salesy about it.
MONEY \u2014 her work has value. If he haggles, invokes a subscription perk to get a made-to-order custom for free, or leaves paid content unbought, NEVER advise giving it away, discounting, or promising extra free content ON YOUR OWN INITIATIVE. (If SHE has decided to gift or discount it, that is her call \u2014 then help her word it well.) No guilt-trip and no lecture either: warmly and plainly separate what his subscription covers from work made to order for him, which is paid separately.
\u26A0\uFE0F This OUTRANKS the CRM and monetisation guidance above. When he is disputing a price, dodging one, or sitting on something paid he has not bought: appreciation, congratulations and "react to his fresh activity" are NOT the move \u2014 acknowledge him in one clause at most, then get to the point. This is boundary-setting about work already done, not an upsell, so the "drop monetisation entirely" rule does NOT apply \u2014 it belongs in the advice.
${NO_DASH_RULE}
${opts.chat ? `MATCH THE REGISTER of THIS conversation and her actual style \u2014 do NOT default to flirty, teasing, coy or emoji-heavy phrasing; if the exchange is casual, practical, or warm-but-plain, keep it that way.
You are in a LIVE CONVERSATION with her \u2014 she can correct you and add context the log does not show. Answer in PLAIN TEXT: no JSON, no markdown, no #/## headings, no **bold**. Keep it short \u2014 3-6 sentences, everyday language. Write to her in ${adviceLang}; write any phrasing she could send him in ${fanLang}, in quotes. Her FACTS about the situation outweigh your reading of the log \u2014 take them as given and do not argue with them (this does not extend to the MONEY rule above: keep advising her not to give paid work away, unless she has decided otherwise herself). If she asks you to write the message, WRITE it \u2014 one short version in ${fanLang}, in quotes \u2014 instead of only guiding. Answer with your best read first; only if something important is still unclear, add at most ONE short question at the end, never a question alone.` : opts.oneReply ? `Write "phase" and "advice" strictly in ${adviceLang} \u2014 this is advice FOR HER, in her own language. Then, besides guiding her, WRITE the message itself: "examples" holds exactly ONE short version she could send him right now, following your advice \u2014 ${replyLangNote}, in her casual texting voice, on one line, at least four words and at most two sentences. MATCH THE REGISTER of THIS conversation and her actual style: do NOT default to flirty, teasing, coy or emoji-heavy wording.
Output ONLY valid JSON (no markdown):
{"phase":"<short: where the dialogue stands>","advice":"<2-4 sentences: what to latch onto and how to steer next>","examples":["<the one message to him, in ${replyLang}>"]}` : `Write "phase" and "advice" strictly in ${adviceLang} (this is advice FOR HER). Write the "examples" strictly in ${fanLang} (these are phrasings she could send to the fan), short and in her casual texting voice \u2014 options she can tweak, not final. MATCH THE REGISTER of THIS conversation and her actual style: do NOT default to flirty, teasing, coy or emoji-heavy phrasing. If the exchange is casual, practical, or warm-but-plain, keep the examples that way; be playful only when the conversation clearly already is. Vary the tone across the options \u2014 don't make all of them flirty.
Output ONLY valid JSON (no markdown):
{"phase":"<short: where the dialogue stands>","advice":"<2-4 sentences: what to latch onto and how to steer next>","examples":["<phrasing 1>","<phrasing 2>"]}`}`;
  const reachText = context?.reachReason ? `Why she is reaching out to him RIGHT NOW: ${context.reachReason}` : "";
  const hint = (context?.hint || "").trim();
  const hintText = hint ? `
\u26A0\uFE0F NOTE SHE TYPED IN THE PANEL: "${hint}"
It may be a FACT about the situation the log does not show \u2014 then trust it over your own reading of the log. Or it may be an instruction about tone/wording \u2014 then apply it to the phrasings you offer. Use it as whichever it is.` : "";
  const creatorText = context?.isCreator ? "NOTE: this fan is HIMSELF a creator on Fansly (verified badge). Keep it in mind \u2014 he prices his own work, so money talk lands differently \u2014 but do not assume what he wants; read it from the conversation." : "";
  const user = `Today is ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}. Dates in (brackets) and the "\u2014 YYYY-MM-DD \u2014" markers in the conversation are on this same calendar \u2014 use them to work out what happened in which order. If two events are not ordered by these dates, say so plainly; do NOT guess which came first.
Fan: ${fan} (${CLOSE_EN[closeness] || "new contact"} \u2014 this is how warm the CONVERSATION is, it says nothing about money).
${subLine}
${genderLine ? genderLine + "\n" : ""}${creatorText ? creatorText + "\n" : ""}${reachText ? reachText + "\n" : ""}${contactState ? contactState + "\n" : ""}${freshText ? freshText + "\n" : ""}${crmText ? crmText + "\n" : ""}${tierText ? tierText + "\n" : ""}${portraitText ? portraitText + "\n" : ""}${topicsText ? topicsText + "\n" : ""}What we know about him (each fact tagged with its age; untagged = unknown date):
${factsText}
${briefText}
Her style/voice: ${(settings.styleDescription || "").slice(0, 400)}
Her message examples (mimic this voice in examples): ${(settings.styleExamples || "").slice(0, 400)}
Her red lines (never suggest crossing): ${redLinesText(settings).slice(0, 300)}
The tiers SHE OFFERS and what each includes \u2014 this is her price list, NOT a statement about him. Use it only to check a perk HE names, or for a natural upsell if one fits. Which tier he is on (if any) is stated in the SUBSCRIPTION line above and nowhere else: ${(settings.tiersInfo || "").slice(0, 1200)}
Recent conversation:
${histText}
${hintText}
${opts.oneReply ? replyLang === adviceLang ? `Coach her next move and write that one message. \u26A0\uFE0F Write both the advice and the message in ${adviceLang} \u2014 whatever language the conversation above is in.` : `Coach her next move and write that one message. \u26A0\uFE0F The advice is to HER, in ${adviceLang}; the message is in ${replyLang} \u2014 whatever language the conversation above or her note is in.` : `Coach her next move. \u26A0\uFE0F Write to HER in ${adviceLang} \u2014 always, whatever language the conversation above is in.`}`;
  const pii = buildPiiMap(context, settings);
  if (pii) return { system: maskPii(system + PII_TOKEN_NOTE, pii), user: maskPii(user, pii), pii };
  return { system, user, pii: null };
}
function salvagePartialCoach(raw) {
  const str = (key) => {
    const m = raw.match(new RegExp('"' + key + '"\\s*:\\s*("(?:[^"\\\\]|\\\\.)*")'));
    if (!m) return "";
    try {
      return String(JSON.parse(m[1]) || "");
    } catch (_) {
      return "";
    }
  };
  const advice = str("advice"), phase = str("phase");
  const examples = [];
  const em = raw.match(/"examples"\s*:\s*\[([\s\S]*?)(?:\]|$)/);
  if (em) {
    for (const s of em[1].match(/"(?:[^"\\]|\\.)*"/g) || []) {
      try {
        const v = JSON.parse(s);
        if (v && v.trim()) examples.push(v);
      } catch (_) {
      }
    }
  }
  if (!advice && !examples.length) return null;
  return { phase: phase.slice(0, 140), advice: advice.slice(0, 900), examples: examples.slice(0, 3) };
}
function parseCoach(rawText) {
  try {
    const s = rawText.indexOf("{"), e = rawText.lastIndexOf("}");
    if (s !== -1 && e > s) {
      const p = JSON.parse(rawText.slice(s, e + 1).replace(/[\x00-\x1F\x7F]/g, " "));
      const examples = Array.isArray(p.examples) ? p.examples.filter((x) => typeof x === "string" && x.trim()).slice(0, 3) : [];
      const phase = String(p.phase || "").slice(0, 140);
      const advice = String(p.advice || "").slice(0, 900);
      if (advice || examples.length) return { phase, advice, examples };
    }
  } catch (_) {
  }
  const salv = salvagePartialCoach(String(rawText || ""));
  console.warn(
    "[FanslyAI] \u0441\u043E\u0432\u0435\u0442: \u0441\u0442\u0440\u043E\u0433\u0438\u0439 \u0440\u0430\u0437\u0431\u043E\u0440 \u043D\u0435 \u0432\u044B\u0448\u0435\u043B \u2192",
    salv ? "\u0441\u043F\u0430\u0441\u043B\u0438 \u0438\u0437 \u043E\u0431\u0440\u044B\u0432\u043A\u0430" : "\u0441\u043F\u0430\u0441\u0430\u0442\u044C \u043D\u0435\u0447\u0435\u0433\u043E",
    "\xB7 \u043D\u0430\u0447\u0430\u043B\u043E \u043E\u0442\u0432\u0435\u0442\u0430:",
    String(rawText || "").slice(0, 200)
  );
  return salv;
}
function buildPostPrompt(settings) {
  const gender = settings.creatorGender === "male" ? "male" : "female";
  const name = settings.creatorName || "";
  const about = settings.creatorAbout || "";
  const styleDescription = settings.styleDescription || "";
  const examples = settings.styleExamples || "";
  const tiersInfo = settings.tiersInfo || "";
  const lines = [];
  lines.push(`You are ${name ? name + ", " : ""}a ${gender} content creator on Fansly. You are writing text for one of YOUR OWN public posts / feed captions / broadcasts \u2014 NOT a private reply to a fan. There is no conversation and no specific person: write to your audience at large.`);
  if (about) lines.push(`Background about you \u2014 use ONLY if the brief clearly calls for it. Do NOT list or recite these traits, and never invent activities or facts from them: ${about}`);
  lines.push(`Treat the brief as the IDEA / theme, NOT the final wording. COMPOSE an original, ready-to-publish post in your own voice, built on that idea. Do NOT merely translate, echo or repeat the brief back \u2014 even if it already reads like a finished line, make it your own, never a near-literal copy. But do NOT pad it or invent facts about yourself: no made-up star signs, activities, plans, moods or backstory that aren't given \u2014 build ONLY on the brief's idea and your known persona/style. Output ONLY the post itself \u2014 no preamble, no "here's your post", no quotes around it, no options list, no explanation. Publishable as-is.`);
  lines.push(`Sound like a real person \u2014 warm, flirty, natural. NOT an AI, NOT a marketer. No poetic or purple prose, no grand declarations. Keep it SHORT \u2014 about 1-2 sentences, a real caption \u2014 unless the brief clearly asks for something longer. At most 1 emoji unless the brief wants more.`);
  lines.push(NO_DASH_RULE);
  if (styleDescription && styleDescription.trim()) lines.push(`Your style: ${styleDescription.trim()}`);
  if (examples && examples.trim()) lines.push(`Write in the voice of these real messages of yours \u2014 match their casing, punctuation, emoji habits and energy (mirror THEIR register, whether bubbly or dry):
${examples.trim()}`);
  lines.push(`By DEFAULT the post is PURE: no promotion, no call-to-action, no tier / subscription / sales mention at all. Add promo ONLY if the brief EXPLICITLY asks you to promote, sell or invite.`);
  if (tiersInfo && tiersInfo.trim()) lines.push(`If (and only if) the brief asks you to promote, these are your tiers to weave in naturally (never pushy):
${tiersInfo.trim()}`);
  lines.push(`Language: if the brief explicitly asks for a specific language, write FULLY in that language \u2014 translate even your pet-names into it (e.g. "\u043A\u043E\u0442\u0438\u043A" \u2192 "kitty"). Otherwise write in the brief's own language and keep your natural (including bilingual) style.`);
  return lines.join("\n\n");
}
const POST_HIST_PAIRS = 3;
const POST_HIST_ITEM_CHARS = 600;
const POST_HIST_CHARS = 2400;
const POST_HISTORY_NOTE = `The messages before the last one are NOT a chat with a fan: they are your earlier briefs from this same workspace and the posts you wrote for them. The LAST message is the new brief. It may refer to the earlier ones ("shorter", "another version", "same but about rain", "add an emoji"): then rework the latest post accordingly, change only what the brief asks for and keep the language of that post unless the brief asks for another one. If the new brief is a fresh idea, write a fresh post and do not reuse the earlier wording.`;
function postHistoryTurns(history) {
  const pairs = [];
  let brief = null;
  for (const h of Array.isArray(history) ? history : []) {
    const text = h && typeof h.text === "string" ? h.text.trim().slice(0, POST_HIST_ITEM_CHARS) : "";
    if (!text) continue;
    if (h.role === "brief") brief = text;
    else if (h.role === "post" && brief != null) {
      pairs.push({ brief, post: text });
      brief = null;
    }
  }
  let keep = pairs.slice(-POST_HIST_PAIRS);
  while (keep.length && keep.reduce((n, p) => n + p.brief.length + p.post.length, 0) > POST_HIST_CHARS) keep = keep.slice(1);
  return keep.flatMap((p) => [{ role: "user", content: `Brief: ${p.brief}` }, { role: "assistant", content: p.post }]);
}
async function generatePost(brief, settings, history = null) {
  const forceOR = /^\s*!/.test(brief);
  const cleanBrief = forceOR ? brief.replace(/^\s*!\s*/, "") : brief;
  const turns = postHistoryTurns(history);
  const system = turns.length ? `${buildPostPrompt(settings)}

${POST_HISTORY_NOTE}` : buildPostPrompt(settings);
  const messages = [...turns, { role: "user", content: `Brief: ${cleanBrief}` }];
  let usedOpenRouter = false, r;
  if (forceOR) {
    if (!settings.openrouterApiKey) return { success: false, noOpenRouter: true };
    r = await AiCore.chatOpenRouter(messages, system, settings);
    usedOpenRouter = r?.success === true;
  } else {
    if (!AiCore.hasAiKey(settings)) return { success: false, error: "no AI key" };
    r = await AiCore.chat(messages, system, settings, { kind: "post" });
    if (r && !r.success && r.blocked && settings.openrouterApiKey) {
      r = await AiCore.chatOpenRouter(messages, system, settings);
      usedOpenRouter = r?.success === true;
    }
  }
  if (!r || !r.success) return r?.blocked ? { success: false, blocked: true } : { success: false, error: r?.error || "provider error" };
  return { success: true, text: r.text, usedOpenRouter };
}
async function handleOnboardingChat(messages, system) {
  const settings = await getSettings();
  if (!AiCore.hasAiKey(settings)) return { success: false, error: "no AI key" };
  const sys = system ? system + "\n\n" + NO_DASH_RULE : NO_DASH_RULE;
  let r = await AiCore.chat(messages, sys, settings, { kind: "onboarding" });
  let usedOpenRouter = false;
  if (r && !r.success && r.blocked && settings.openrouterApiKey) {
    console.log("[FanslyAI] \u041E\u043D\u0431\u043E\u0440\u0434\u0438\u043D\u0433-\u0447\u0430\u0442 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D \u2192 OpenRouter");
    r = await AiCore.chatOpenRouter(messages, sys, settings);
    usedOpenRouter = r?.success === true;
  }
  if (!r || !r.success) {
    return r?.blocked ? { success: false, blocked: true } : { success: false, error: r?.error || "provider error" };
  }
  return { success: true, text: r.text, usedOpenRouter };
}
async function handleOnboardingExtract(messages, extractPrompt, rawTranscript) {
  const settings = await getSettings();
  if (!AiCore.hasAiKey(settings)) return { success: false, error: "no AI key" };
  const transcript = rawTranscript || (messages || []).map((m) => `${m.role === "assistant" ? "AI" : "Creator"}: ${m.content}`).join("\n");
  const fullPrompt = `${extractPrompt}

TRANSCRIPT:
${transcript}`;
  const oneShot = [{ role: "user", content: fullPrompt }];
  let r = await AiCore.chat(oneShot, null, settings, { kind: "onboarding_style" });
  let usedOpenRouter = false;
  if (r && !r.success && r.blocked && settings.openrouterApiKey) {
    console.log("[FanslyAI] \u041E\u043D\u0431\u043E\u0440\u0434\u0438\u043D\u0433-\u0438\u0437\u0432\u043B\u0435\u0447\u0435\u043D\u0438\u0435 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u2192 OpenRouter");
    r = await AiCore.chatOpenRouter(oneShot, null, settings);
    usedOpenRouter = r?.success === true;
  }
  if (!r || !r.success) {
    return r?.blocked ? { success: false, blocked: true } : { success: false, error: r?.error || "provider error" };
  }
  return { success: true, text: r.text, usedOpenRouter };
}
function sanitizeReply(s) {
  if (typeof s !== "string") return "";
  let t2 = s.trim();
  if (/[\]\}]/.test(t2.slice(-3))) {
    t2 = t2.replace(/[\s"'`,\]\}]+$/g, "").trim();
  }
  return t2;
}
function parseDialogueResponse(rawText, pii) {
  try {
    const start = rawText.indexOf("{");
    const end = rawText.lastIndexOf("}");
    if (start !== -1 && end > start) {
      const clean = rawText.slice(start, end + 1).replace(/[\x00-\x1F\x7F]/g, " ");
      const parsed = JSON.parse(clean);
      let raw = [];
      if (Array.isArray(parsed.suggestions)) raw = parsed.suggestions;
      else if (typeof parsed.reply === "string") raw = [parsed.reply];
      else raw = ["reply1", "reply2", "reply3"].map((k) => parsed[k]).filter((s) => typeof s === "string");
      const arr = raw.map(sanitizeReply).filter(Boolean).slice(0, 3);
      if (arr.length) {
        while (arr.length < 3) arr.push(arr[0]);
        return unmaskDeep({
          // восстановить {{FAN}}/{{ME}} → реальные имена (no-op если pii=null)
          success: true,
          result: arr,
          dossier_update: parsed.dossier_update || null,
          brief: parsed.brief || null
        }, pii);
      }
    }
  } catch (e) {
    console.log("[FanslyAI] JSON parse error:", e.message);
  }
  const sugIdx = rawText.indexOf('"suggestions"');
  if (sugIdx !== -1) {
    const after = rawText.slice(sugIdx + 13);
    const stop = after.search(/"(?:dossier_update|brief|lang_signal|toxic|feeling|proof_request|reply\d?)"\s*:/);
    const region = stop !== -1 ? after.slice(0, stop) : after;
    const sugs = [...region.matchAll(/"((?:[^"\\]|\\.){3,})"/g)].map((m) => m[1]);
    const arr = sugs.map(sanitizeReply).filter(Boolean).slice(0, 3);
    if (arr.length) {
      while (arr.length < 3) arr.push(arr[0]);
      return unmaskDeep({ success: true, result: arr }, pii);
    }
  }
  return { success: false, error: "Could not parse: " + rawText.slice(0, 100) };
}
