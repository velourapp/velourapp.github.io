(function() {
  "use strict";
  let q, qa, qm, selStr, waitForElement, synthClick, waitVisible, startKeepAlive, stopKeepAlive, layout;
  let subText, subCardParse, parseEarningsRow, broadcastParseCard, broadcastDate, notifParse, parseMoney;
  const DEPS = ["sel", "waitForElement", "synthClick", "waitVisible", "keepAlive", "parsers", "layout"];
  function init(d) {
    for (const k of DEPS) if (!d || d[k] == null) throw new Error("Scans.init: \u043D\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \xAB" + k + "\xBB");
    ({ q, qa, qm, selStr } = d.sel);
    waitForElement = d.waitForElement;
    synthClick = d.synthClick;
    waitVisible = d.waitVisible;
    startKeepAlive = d.keepAlive.start;
    stopKeepAlive = d.keepAlive.stop;
    layout = d.layout;
    ({ subText, subCardParse, parseEarningsRow, broadcastParseCard, broadcastDate, notifParse, parseMoney } = d.parsers);
  }
  let uiLang = "ru";
  let onPhase = null;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const phaseBegin = (info) => {
    if (onPhase) return onPhase("begin", info);
  };
  const phaseEnd = (info) => {
    if (onPhase) onPhase("end", info);
  };
  const STOP = { requested: false };
  function layoutMissError(area, key) {
    const e = new Error(area + ": Fansly, \u043F\u043E\u0445\u043E\u0436\u0435, \u043F\u0435\u0440\u0435\u0434\u0435\u043B\u0430\u043B \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u2014 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \xAB" + key + "\xBB");
    e.layoutMiss = { area, key };
    return e;
  }
  const storeHas = (key) => new Promise((r) => chrome.storage.local.get(key, (d) => {
    const v = d && d[key];
    r(!!v && typeof v === "object" && Object.keys(v).length > 0);
  }));
  async function scanPause(setStatus) {
    if (!document.hidden) return;
    setStatus(t("panel.scan.paused", uiLang));
    await waitVisible();
    setStatus(t("panel.scan.resumed", uiLang));
    await sleep(600);
  }
  const LOCK_TTL = 45e3;
  const LOCK_OWNER = Math.random().toString(36).slice(2) + Date.now().toString(36);
  function scanLock(key) {
    const read = () => new Promise((r) => chrome.storage.local.get(key, (d) => r(d[key])));
    const fresh = (l) => !!(l && l.at && Date.now() - l.at < LOCK_TTL);
    return {
      active: async () => {
        const l = await read();
        return fresh(l) && l.owner !== LOCK_OWNER;
      },
      touch: () => new Promise((r) => chrome.storage.local.set({ [key]: { at: Date.now(), owner: LOCK_OWNER } }, r)),
      clear: async () => {
        const l = await read();
        if (fresh(l) && l.owner && l.owner !== LOCK_OWNER) return;
        await new Promise((r) => chrome.storage.local.remove(key, r));
      }
    };
  }
  function pagerNext(nav) {
    return nav ? [...qa("pagerItem", nav)].find((it) => q("pagerNextIcon", it) && !qm("pagerOff", it) && !it.disabled) || null : null;
  }
  function pagerCurrent(nav) {
    const sel = nav && q("pagerSelected", nav);
    return sel ? subText(sel) : "";
  }
  function pagerOnLast(nav) {
    if (!nav) return null;
    const items = [...qa("pagerItem", nav)];
    const nums = items.map((it) => parseInt(subText(it), 10)).filter((n) => n > 0);
    const at = items.findIndex((it) => qm("pagerSelected", it)), sel = at < 0 ? NaN : parseInt(subText(items[at]), 10);
    if (!nums.length || !(sel > 0)) return null;
    return sel >= Math.max(...nums) && !items.slice(at + 1).some((it) => /^(\.\.\.|…)$/.test(subText(it)));
  }
  async function pagerTurn(page, next, last, navOf, first) {
    const cur = pagerCurrent(navOf()), before = first();
    const turned = async () => {
      for (let w = 0; w < 30; w++) {
        await sleep(200);
        if (pagerCurrent(navOf()) !== cur) return true;
        if (first() && first() !== before) return true;
      }
      return false;
    };
    next.click();
    if (await turned()) return true;
    if (last === null) return false;
    const again = pagerNext(navOf());
    if (!again) return false;
    again.click();
    if (await turned()) return true;
    throw new Error(page + ": \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u043D\u0435 \u0441\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u043F\u043E\u0441\u043B\u0435 \u0434\u0432\u0443\u0445 \u043D\u0430\u0436\u0430\u0442\u0438\u0439 \xAB\u0432\u043F\u0435\u0440\u0451\u0434\xBB");
  }
  const BROADCAST = { running: false };
  const BROADCAST_LOCK = "fansly_broadcast_lock";
  const broadcastLock = scanLock(BROADCAST_LOCK);
  function broadcastCardEls() {
    return [...qa("broadcastCard")];
  }
  async function broadcastEnsureTab(setStatus) {
    for (let attempt = 0; attempt < 2; attempt++) {
      if (broadcastCardEls().length) return true;
      const tabs = [...qa("broadcastTab")];
      const tab = tabs.find((x) => /broadcast|рассыл/i.test(subText(x)) && /stat|стат/i.test(subText(x))) || tabs.find((x) => /broadcast\s+message\s+stats/i.test(subText(x)));
      if (!tab) {
        await sleep(600);
        continue;
      }
      if (setStatus) setStatus(t("panel.broadcast.opening", uiLang));
      synthClick(tab);
      for (let w = 0; w < 25 && !broadcastCardEls().length; w++) await sleep(250);
      if (broadcastCardEls().length) return true;
    }
    return broadcastCardEls().length > 0;
  }
  function broadcastCards() {
    const out = [];
    for (const card of broadcastCardEls()) {
      const c = broadcastParseCard(card);
      if (c) out.push(c);
    }
    return out;
  }
  function broadcastMinute(at) {
    const d = new Date(at), p = (n) => String(n).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
  }
  function broadcastKey(c) {
    if (c.at) return "b:" + broadcastMinute(c.at) + "|" + (c.preview || "");
    if (c.label) return "b:" + c.label + "|" + (c.preview || "");
    return "c:" + [c.reach, c.open, c.sale].join("|");
  }
  function broadcastMerge(store) {
    const out = {};
    for (const r of Object.values(store)) {
      const at = r.label ? broadcastDate(r.label) : r.at;
      const rec = at ? Object.assign({}, r, { at }) : r;
      const k = broadcastKey(rec);
      if (!out[k] || (rec.syncedAt || 0) > (out[k].syncedAt || 0)) out[k] = rec;
    }
    return out;
  }
  async function syncBroadcast(setStatus, scheduled = false) {
    if (BROADCAST.running) return;
    if (scheduled && await broadcastLock.active()) {
      console.log("[FanslyAI] broadcast: \u0430\u043A\u0442\u0438\u0432\u0435\u043D \u0434\u0440\u0443\u0433\u043E\u0439 \u0441\u043A\u0430\u043D \u2192 \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u0446\u0438\u043A\u043B\u0430 \u043F\u043E \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044E");
      return;
    }
    BROADCAST.running = true;
    const manual = !scheduled;
    if (manual) phaseBegin({ kind: "scan", zoom: false });
    startKeepAlive();
    await broadcastLock.touch();
    try {
      const ok = await broadcastEnsureTab(setStatus);
      if (!ok) {
        if (await storeHas("fansly_broadcast_stats")) throw layoutMissError("broadcast", "broadcastCard");
        setStatus(t("panel.broadcast.noTab", uiLang));
        return;
      }
      for (let i = 0; i < 12 && !broadcastCards().length; i++) await sleep(300);
      const cards = broadcastCards();
      if (!cards.length) {
        if (await storeHas("fansly_broadcast_stats")) throw layoutMissError("broadcast", "broadcastParse");
        setStatus(t("panel.broadcast.none", uiLang));
        return;
      }
      layout.seen("broadcast");
      const saved = await new Promise((r) => chrome.storage.local.get("fansly_broadcast_stats", (d) => r(d.fansly_broadcast_stats || {})));
      for (const k of Object.keys(saved)) if (!/^b:/.test(k)) delete saved[k];
      const store = broadcastMerge(saved);
      for (const c of cards) store[broadcastKey(c)] = c;
      await new Promise((r) => chrome.storage.local.set({ fansly_broadcast_stats: store, fansly_broadcast_lastsync: { at: Date.now() } }, r));
      await broadcastLock.touch();
      setStatus(t("panel.broadcast.done", uiLang, { n: Object.keys(store).length }));
    } finally {
      BROADCAST.running = false;
      stopKeepAlive();
      phaseEnd({ zoom: false });
      await broadcastLock.clear();
    }
  }
  const EARN = { MAX_PAGES: 200, running: false };
  const EARN_LOCK = "fansly_earn_lock";
  const earnLock = scanLock(EARN_LOCK);
  function earnRows() {
    return [...qa("earnRow")];
  }
  function earnFirstOrderId() {
    const r = earnRows().find((tr) => parseEarningsRow(tr));
    const p = r && parseEarningsRow(r);
    return p ? p.orderId : "";
  }
  async function earnSettleBuyers() {
    for (let i = 0; i < 12; i++) {
      const rows = earnRows().filter((tr) => parseEarningsRow(tr));
      if (!rows.length) {
        await sleep(300);
        continue;
      }
      const unresolved = rows.filter((tr) => {
        const a = q("earnBuyerLink", tr);
        const href = a ? a.getAttribute("href") || "" : "";
        const name = subText(q("earnBuyerName", tr) || document.createElement("span"));
        return !href || href === "/" || href === "#" || /^unknown/i.test(name);
      }).length;
      if (!unresolved) return;
      await sleep(400);
    }
  }
  function earnNav() {
    return q("earnPager");
  }
  async function syncEarnings(setStatus, incremental = false, scheduled = false) {
    if (EARN.running) return;
    if (scheduled && await earnLock.active()) {
      console.log("[FanslyAI] earnings: \u0430\u043A\u0442\u0438\u0432\u0435\u043D \u0434\u0440\u0443\u0433\u043E\u0439 \u0441\u043A\u0430\u043D \u2192 \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u0446\u0438\u043A\u043B\u0430 \u043F\u043E \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044E");
      return;
    }
    EARN.running = true;
    const manual = !scheduled;
    if (manual) phaseBegin({ kind: "scan", zoom: false });
    startKeepAlive();
    await earnLock.touch();
    try {
      await waitForElement(selStr("earnRoot"), 15e3).catch(() => {
      });
      for (let i = 0; i < 20 && !earnRows().some((tr) => parseEarningsRow(tr)); i++) await sleep(300);
      if (!earnRows().some((tr) => parseEarningsRow(tr))) {
        if (await storeHas("fansly_earnings")) throw layoutMissError("earnings", q("earnRoot") ? "earnRow" : "earnRoot");
        setStatus(t("panel.earn.none", uiLang));
        return;
      }
      layout.seen("earnings");
      const store = await new Promise((r) => chrome.storage.local.get("fansly_earnings", (d) => r(d.fansly_earnings || {})));
      let dirty = false, knownStreak = 0;
      const persist = async () => {
        if (dirty) {
          dirty = false;
          await new Promise((r) => chrome.storage.local.set({ fansly_earnings: store }, r));
          await earnLock.touch();
        }
      };
      for (let page = 0; page < EARN.MAX_PAGES; page++) {
        await earnLock.touch();
        await earnSettleBuyers();
        for (const tr of earnRows()) {
          const p = parseEarningsRow(tr);
          if (!p) continue;
          const existed = !!store[p.orderId];
          if (existed && incremental) {
            knownStreak++;
            continue;
          }
          if (!existed) knownStreak = 0;
          if (existed && !p.buyer && store[p.orderId].buyer) {
            p.buyer = store[p.orderId].buyer;
            p.unknownAt = store[p.orderId].unknownAt || Date.now();
          }
          store[p.orderId] = p;
          dirty = true;
        }
        setStatus(t("panel.earn.scanning", uiLang, { n: Object.keys(store).length }));
        await persist();
        if (incremental && knownStreak >= 30) break;
        if (STOP.requested) break;
        const nav = earnNav(), next = pagerNext(nav), last = pagerOnLast(nav);
        if (!next || last === true) break;
        if (!await pagerTurn("earnings", next, last, earnNav, earnFirstOrderId)) break;
        await sleep(400 + Math.random() * 400);
      }
      await persist();
      if (STOP.requested) return { stopped: true };
      await new Promise((r) => chrome.storage.local.set({ fansly_earnings_lastsync: { at: Date.now() } }, r));
      setStatus(t("panel.earn.done", uiLang, { n: Object.keys(store).length }));
    } finally {
      EARN.running = false;
      stopKeepAlive();
      phaseEnd({ zoom: false });
      await earnLock.clear();
    }
  }
  const SUBS = { MAX_PAGES: 80, running: false };
  function subsTabs() {
    const box = q("subsSearch"), wrap = box && box.closest(selStr("subsTabsWrap"));
    return [...qa("subsTab", wrap || document)];
  }
  function subsTabCount(x) {
    const m = subText(x).match(/\((\d[\d\s.,]*)\)/);
    return m ? parseInt(m[1].replace(/\D/g, ""), 10) : -1;
  }
  async function subsStable() {
    let n = -1, same = 0;
    for (let i = 0; i < 40; i++) {
      const m = qa("subCard").length;
      same = m === n ? same + 1 : 0;
      n = m;
      if (same >= 3) return;
      await sleep(300);
    }
  }
  async function subsEnsureAll(setStatus) {
    let tabs = subsTabs();
    for (let i = 0; i < 50 && !(tabs.length && tabs.some((x) => subsTabCount(x) > 0)); i++) {
      await sleep(200);
      tabs = subsTabs();
    }
    if (!tabs.length) return null;
    const most = tabs.reduce((best, x) => subsTabCount(x) >= subsTabCount(best) ? x : best);
    const at = tabs.indexOf(tabs.find((x) => /\ball\b/i.test(subText(x))) || (subsTabCount(most) >= 0 ? most : tabs[tabs.length - 1]));
    const all = () => subsTabs()[at] || tabs[at];
    const total = subsTabCount(all()) > 0 ? subsTabCount(all()) : null;
    const picked = () => qm("subsTabOn", all());
    if (picked()) return total;
    setStatus(t("panel.subs.selectAll", uiLang));
    await subsStable();
    const n0 = qa("subCard").length, h0 = subsFirstHref();
    for (let k = 0; k < 2 && !picked(); k++) {
      all().click();
      for (let w = 0; w < 50 && !(picked() && (qa("subCard").length !== n0 || subsFirstHref() !== h0)); w++) await sleep(200);
    }
    if (!picked()) throw new Error("\u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438: \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \xAB" + subText(all()) + "\xBB \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043B\u0430\u0441\u044C \u043F\u043E\u0441\u043B\u0435 \u0434\u0432\u0443\u0445 \u043D\u0430\u0436\u0430\u0442\u0438\u0439");
    await subsStable();
    return total;
  }
  function subsUnresolved(c) {
    const a = q("subUserLink", c);
    const href = a ? a.getAttribute("href") || "" : "";
    const name = subText(q("subUserName", c) || document.createElement("span"));
    return !href || href === "/" || href === "#" || /^unknown/i.test(name);
  }
  async function subsSettleCards() {
    let prev = -1, still = 0;
    for (let i = 0; i < 30; i++) {
      const cards = [...qa("subCard")];
      const unresolved = cards.filter(subsUnresolved).length;
      if (cards.length && !unresolved) return;
      if (cards.length) {
        still = prev >= 0 && unresolved >= prev ? still + 1 : 0;
        prev = unresolved;
      }
      if (i >= 12 && still >= 3) return;
      await sleep(400);
    }
  }
  function subsHandle(c) {
    if (subsUnresolved(c)) return "";
    const a = q("subUserLink", c);
    return (a.getAttribute("href") || "").replace(/^\//, "").trim();
  }
  async function subsNewPage(seen) {
    for (let w = 0; w < 50; w++) {
      const hs = [...qa("subCard")].map(subsHandle);
      if (hs.length && (hs.some((h) => h && !seen.has(h)) || hs.every((h) => !h))) return true;
      await sleep(200);
    }
    return false;
  }
  function subsNav() {
    const navs = [...qa("subsPager")];
    const cards = [...qa("subCard")], last = cards[cards.length - 1];
    return last && navs.find((n) => last.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING) || navs[0] || null;
  }
  function subsFirstHref() {
    const c = q("subCard");
    const a = c && q("subUserLink", c);
    return a ? a.getAttribute("href") : "";
  }
  async function syncSubs(setStatus, scheduled = false) {
    if (SUBS.running) return;
    SUBS.running = true;
    const manual = !scheduled;
    if (manual) phaseBegin({ kind: "scan", zoom: false });
    startKeepAlive();
    try {
      const total = await subsEnsureAll(setStatus);
      for (let i = 0; i < 20 && !q("subCard"); i++) await sleep(300);
      if (!q("subCard")) {
        if (total > 0 || await storeHas("fansly_subs")) throw layoutMissError("subs", "subCard");
        setStatus(t("panel.subs.none", uiLang));
        return;
      }
      layout.seen("subs");
      const subs = await new Promise((r) => chrome.storage.local.get("fansly_subs", (d) => r(d.fansly_subs || {})));
      const seen = /* @__PURE__ */ new Set();
      let dirty = false, read = 0;
      const persist = async () => {
        if (dirty) {
          dirty = false;
          await new Promise((r) => chrome.storage.local.set({ fansly_subs: subs }, r));
        }
      };
      for (let page = 0; page < SUBS.MAX_PAGES; page++) {
        await subsSettleCards();
        for (const card of qa("subCard")) {
          const h = subsHandle(card);
          if (!h || !seen.has(h)) read++;
          const parsed = subCardParse(card);
          if (!parsed || seen.has(parsed.handle)) continue;
          seen.add(parsed.handle);
          subs[parsed.handle] = parsed;
          dirty = true;
        }
        setStatus(t("panel.subs.scanning", uiLang, { n: seen.size }));
        await persist();
        if (STOP.requested) break;
        const nav = subsNav(), next = pagerNext(nav), last = pagerOnLast(nav);
        if (!next || last === true) break;
        if (!await pagerTurn("subs", next, last, subsNav, subsFirstHref)) break;
        if (!await subsNewPage(seen)) throw new Error("\u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438: \u043F\u043E\u0441\u043B\u0435 \xAB\u0432\u043F\u0435\u0440\u0451\u0434\xBB \u043D\u043E\u0432\u044B\u0445 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u043D\u0435\u0442");
        await subsStable();
        await sleep(400 + Math.random() * 400);
      }
      await persist();
      if (STOP.requested) return { stopped: true };
      if (total) {
        console.log(`[FanslyAI] \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438: \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043E ${read} \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0438\u0437 ${total} \u043F\u043E \u0432\u043A\u043B\u0430\u0434\u043A\u0435 \xABAll\xBB`);
        if (total - read > Math.max(2, Math.round(total * 0.02))) throw new Error(`\u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438: \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043E ${read} \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0438\u0437 ${total} \u2014 \u0441\u043F\u0438\u0441\u043E\u043A \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D \u043D\u0435 \u0446\u0435\u043B\u0438\u043A\u043E\u043C`);
      }
      setStatus(t("panel.subs.done", uiLang, { n: seen.size }));
    } finally {
      SUBS.running = false;
      stopKeepAlive();
      phaseEnd({ zoom: false });
    }
  }
  const NOTIF = { MAX_PASSES: 1500, BOTTOM_STREAK: 8, STAGNANT_SAFETY: 40, running: false };
  function notifDayKey(at) {
    if (!at) return "";
    const d = new Date(at);
    return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate();
  }
  function notifKey(e) {
    return e.type + "|" + notifDayKey(e.at) + "|" + (e.amount || "") + "|" + (e.mediaId || "");
  }
  function ledgerKey(e) {
    return e.type === "media" && e.mediaId ? "media|" + e.mediaId : notifKey(e);
  }
  const NOTIF_FILTER_BACK = "fansly_notif_filter_back";
  const NOTIF_FILTER_STALE = 50 * 60 * 1e3;
  const notifFilterHasCheck = (it) => !!q("notifFilterCheck", it);
  const notifFilterFind = () => [...qa("notifFilterBox")].find((d) => [...qa("notifFilterItem", d)].some(notifFilterHasCheck));
  const notifFilterItems = (dd) => [...qa("notifFilterItem", dd)].filter(notifFilterHasCheck);
  const notifFilterOnList = (items) => items.map((it, i) => q("notifFilterOn", it) ? i : -1).filter((i) => i >= 0);
  const notifFilterWant = () => new Set(selStr("notifFilterWant").split(",").map((s) => parseInt(s, 10)).filter((n) => n >= 0));
  const notifFilterIs = (list, set) => list.length === set.size && list.every((i) => set.has(i));
  const filterBackGet = () => new Promise((r) => {
    try {
      chrome.storage.local.get(NOTIF_FILTER_BACK, (d) => r(d && d[NOTIF_FILTER_BACK] || null));
    } catch (e) {
      r(null);
    }
  });
  const filterBackPut = (v) => new Promise((r) => {
    try {
      if (v) chrome.storage.local.set({ [NOTIF_FILTER_BACK]: v }, () => r());
      else chrome.storage.local.remove(NOTIF_FILTER_BACK, () => r());
    } catch (e) {
      r();
    }
  });
  async function notifFilterWait() {
    let dd = notifFilterFind();
    for (let i = 0; i < 20 && !dd; i++) {
      await sleep(250);
      dd = notifFilterFind();
    }
    return dd || null;
  }
  async function notifFilterSet(items, target) {
    for (let i = 0; i < items.length; i++) {
      const on = !!q("notifFilterOn", items[i]);
      if (target.has(i) !== on) {
        items[i].click();
        await sleep(160);
      }
    }
  }
  async function notifFilterNote(items, want) {
    const prev = await filterBackGet();
    if (prev && Array.isArray(prev.on) && prev.n === items.length) return filterBackPut({ on: prev.on, n: prev.n, at: Date.now() });
    const on = notifFilterOnList(items);
    return filterBackPut(notifFilterIs(on, want) ? null : { on, n: items.length, at: Date.now() });
  }
  async function notifFilterBeat() {
    const back = await filterBackGet();
    if (back) await filterBackPut(Object.assign({}, back, { at: Date.now() }));
  }
  async function restoreNotifFilter(staleOnly = false) {
    const back = await filterBackGet();
    if (!back || !Array.isArray(back.on)) return false;
    if (staleOnly && !(Date.now() - (back.at || 0) > NOTIF_FILTER_STALE)) return false;
    const dd = await notifFilterWait();
    if (!dd) return false;
    const title = q("notifFilterTitle", dd);
    if (title) {
      title.click();
      await sleep(450);
    }
    const items = notifFilterItems(dd);
    let done = false;
    if (items.length !== back.n) {
      if (layout && layout.report) layout.report("notifhist:notifFilter", items.length);
    } else if (notifFilterIs(notifFilterOnList(items), notifFilterWant())) {
      await notifFilterSet(items, new Set(back.on));
      done = true;
    }
    if (title) {
      title.click();
      await sleep(350);
    }
    await filterBackPut(null);
    console.log("[FanslyAI] \u0444\u0438\u043B\u044C\u0442\u0440 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439: " + (done ? "\u0433\u0430\u043B\u043A\u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u044B, \u043A\u0430\u043A \u0431\u044B\u043B\u0438 \u0434\u043E \u0441\u0431\u043E\u0440\u0430 \u0438\u0441\u0442\u043E\u0440\u0438\u0438" : "\u043D\u0435 \u0442\u0440\u043E\u0433\u0430\u044E: \u0441\u0442\u043E\u044F\u0442 \u043D\u0435 \u0442\u0435 \u0433\u0430\u043B\u043A\u0438, \u0447\u0442\u043E \u0441\u0442\u0430\u0432\u0438\u043B \u0441\u0431\u043E\u0440, \u0438\u043B\u0438 \u043F\u0443\u043D\u043A\u0442\u043E\u0432 \u0441\u0442\u0430\u043B\u043E \u0434\u0440\u0443\u0433\u043E\u0435 \u0447\u0438\u0441\u043B\u043E"));
    return done;
  }
  const healNotifFilter = () => restoreNotifFilter(true);
  async function ensureNotifFilters() {
    const dd = await notifFilterWait();
    if (!dd) {
      if (q("notifRow") && layout.report) layout.report("notifhist:notifFilter", 0);
      return;
    }
    const title = q("notifFilterTitle", dd);
    if (title) {
      title.click();
      await sleep(450);
    }
    const items = notifFilterItems(dd);
    const want = notifFilterWant();
    const count = parseInt(selStr("notifFilterCount"), 10);
    console.log("[FanslyAI] \u0444\u0438\u043B\u044C\u0442\u0440 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439: \u043F\u0443\u043D\u043A\u0442\u043E\u0432 " + items.length + (count > 0 ? " (\u0436\u0434\u0451\u043C " + count + ")" : ""));
    if (!want.size || [...want].some((n) => n >= items.length) || count > 0 && items.length !== count) {
      if (title) title.click();
      if (layout.report) layout.report("notifhist:notifFilter", items.length);
      return;
    }
    await notifFilterNote(items, want);
    await notifFilterSet(items, want);
    if (title) {
      title.click();
      await sleep(350);
    }
  }
  async function notifNickSeen() {
    const seen = () => [...qa("notifRow")].some((r) => q("notifUser", r));
    for (let i = 0; i < 20 && !seen(); i++) await sleep(400);
    return seen();
  }
  function notifScroller() {
    const n0 = q("notifRow");
    let n = n0 && n0.parentElement;
    while (n && n !== document.body) {
      const oy = getComputedStyle(n).overflowY;
      if ((oy === "auto" || oy === "scroll") && n.scrollHeight > n.clientHeight + 40) return n;
      n = n.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }
  async function syncNotifHistory(setStatus) {
    if (NOTIF.running) return;
    NOTIF.running = true;
    startKeepAlive();
    phaseBegin({ kind: "scan", zoom: false });
    try {
      await waitForElement(selStr("notifRow"), 15e3).catch(() => {
      });
      await ensureNotifFilters();
      await sleep(1500);
      await waitForElement(selStr("notifRow"), 15e3).catch(() => {
      });
      if (!q("notifRow")) {
        if (await storeHas("fansly_ledger")) throw layoutMissError("notifhist", "notifRow");
        setStatus(t("panel.notif.none", uiLang));
        return;
      }
      if (!await notifNickSeen() && await storeHas("fansly_ledger")) throw layoutMissError("notifhist", "notifUser");
      layout.seen("notifhist");
      const ledger = await new Promise((r) => chrome.storage.local.get("fansly_ledger", (d) => r(d.fansly_ledger || {})));
      const keysByHandle = {};
      let count = 0;
      for (const [h, arr] of Object.entries(ledger)) {
        keysByHandle[h] = new Set((arr || []).map(ledgerKey));
        count += (arr || []).length;
      }
      let stagnant = 0, bottomStreak = 0, dirty = false;
      const scroller = notifScroller();
      const seen = /* @__PURE__ */ new Set();
      const persist = async () => {
        if (dirty) {
          dirty = false;
          await new Promise((r) => chrome.storage.local.set({ fansly_ledger: ledger }, r));
        }
      };
      for (let pass = 0; pass < NOTIF.MAX_PASSES && bottomStreak < NOTIF.BOTTOM_STREAK && stagnant < NOTIF.STAGNANT_SAFETY; pass++) {
        await scanPause(setStatus);
        const before = seen.size;
        for (const node of qa("notifRow")) {
          const e = notifParse(node);
          if (!e) continue;
          const k = ledgerKey(e);
          seen.add(e.handle + "|" + k);
          if (!keysByHandle[e.handle]) keysByHandle[e.handle] = /* @__PURE__ */ new Set();
          if (keysByHandle[e.handle].has(k)) {
            if (e.type === "media" && (e.amount || 0) > 0) {
              const ex = (ledger[e.handle] || []).find((x) => x.type === "media" && x.mediaId === e.mediaId);
              if (ex && !((ex.amount || 0) > 0)) {
                ex.amount = e.amount;
                if (e.at) ex.at = e.at;
                if (e.name) ex.name = e.name;
                dirty = true;
              }
            }
            continue;
          }
          keysByHandle[e.handle].add(k);
          if (!ledger[e.handle]) ledger[e.handle] = [];
          ledger[e.handle].push({ type: e.type, amount: e.amount, mediaId: e.mediaId, tier: e.tier, at: e.at, name: e.name });
          count++;
          dirty = true;
        }
        setStatus(t("panel.notif.scanning", uiLang, { n: count }));
        const beforeTop = scroller.scrollTop, beforeH = scroller.scrollHeight;
        const step = Math.max(scroller.clientHeight, 500);
        try {
          scroller.scrollTop = beforeTop + step;
        } catch (e) {
        }
        if (scroller.scrollTop <= beforeTop + 2) {
          const nodes = qa("notifRow");
          try {
            nodes[nodes.length - 1].scrollIntoView({ block: "end", behavior: "auto" });
          } catch (e) {
          }
        }
        await sleep(800 + Math.random() * 600);
        const moved = scroller.scrollTop > beforeTop + 2;
        const grew = scroller.scrollHeight > beforeH + 10;
        if (!moved && !grew) {
          bottomStreak++;
          try {
            scroller.scrollTop = Math.max(0, scroller.scrollTop - 1200);
          } catch (e) {
          }
          await sleep(250 + Math.random() * 250);
          try {
            scroller.scrollTop = scroller.scrollHeight;
          } catch (e) {
          }
          await sleep(900 + 700 * bottomStreak);
        } else bottomStreak = 0;
        if (seen.size === before) stagnant++;
        else stagnant = 0;
        if (pass % 12 === 11) {
          await persist();
          await notifFilterBeat();
        }
        if (STOP.requested) break;
      }
      await persist();
      if (STOP.requested) return { stopped: true };
      setStatus(t("panel.notif.done", uiLang, { n: count }));
    } finally {
      try {
        await restoreNotifFilter();
      } catch (e) {
      }
      NOTIF.running = false;
      stopKeepAlive();
      phaseEnd({ zoom: false });
    }
  }
  const POSTS = { MAX_PASSES: 1200, BOTTOM_STREAK: 6, STAGNANT_SAFETY: 40, MAX_EXPANDS: 40, running: false };
  const POSTS_LOCK = "fansly_posts_lock";
  const postsLock = scanLock(POSTS_LOCK);
  function postMediaEls(postEl) {
    return [...qa("postMedia", postEl)].filter((m) => !qm("mediaPreview", m) && !qm("postAvatar", m) && !(m.parentElement && m.parentElement.closest(selStr("postMediaNest"))));
  }
  function postMediaLikes(m) {
    const am = m.closest(selStr("postMediaBox"));
    const st = am && q("postMediaLike", am);
    if (!st) return null;
    const v = parseInt((st.textContent || "").replace(/\D+/g, ""), 10);
    return isNaN(v) ? null : v;
  }
  function postStats(el) {
    const box = [...qa("postStatsBox", el)].find((s) => !s.closest(selStr("postMediaBox")));
    const num = (key) => {
      const n = box && q(key, box);
      if (!n) return null;
      const v = parseInt((n.textContent || "").replace(/\D+/g, ""), 10);
      return isNaN(v) ? null : v;
    };
    return { likes: num("postLikes"), comments: num("postComments") };
  }
  async function postExpandBundle(postEl, budget) {
    const more = q("postBundleMore", postEl);
    if (!more) return null;
    if (budget.used >= POSTS.MAX_EXPANDS || budget.broken) return null;
    budget.used++;
    let r0 = null;
    const vh = window.innerHeight || document.documentElement.clientHeight;
    for (let i = 0; i < 8; i++) {
      try {
        more.scrollIntoView({ block: "center", behavior: "auto" });
      } catch (e) {
      }
      await sleep(250 + Math.random() * 250);
      r0 = more.getBoundingClientRect();
      if (r0.height > 0 && r0.top > 90 && r0.bottom < vh - 20) break;
      if (r0.height > 0 && r0.top > 90 && r0.top + r0.height / 2 < vh - 20) break;
    }
    await sleep(700 + Math.random() * 700);
    const ovT0 = Date.now();
    let ov = null, node = more;
    for (let i = 0; i < 60; i++) {
      if (!node || !node.isConnected) node = postEl.isConnected ? q("postBundleMore", postEl) : null;
      ov = node ? q("postBundleOverlay", node) : null;
      if (ov) break;
      await sleep(100);
    }
    const ovMs = ov ? Date.now() - ovT0 : -1;
    if (!node) return null;
    const inBundle = (g) => !g.closest(selStr("postProfileGallery"));
    const preItems = new Set([...qa("postGalleryItem")].filter(inBundle));
    r0 = node.getBoundingClientRect();
    const cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2;
    const ownUi = (el) => {
      try {
        return !!(el.closest && el.closest('[id^="fai-"]'));
      } catch (e) {
        return false;
      }
    };
    const hit = document.elementFromPoint(cx, cy);
    const targets = [ov, ownUi(hit) ? null : hit, node].filter(Boolean);
    let closeBtn = null;
    const tried = [];
    if (hit && ownUi(hit)) tried.push((hit.id || hit.tagName) + " (skip-\u043D\u0430\u0448\u0430 \u0432\u0443\u0430\u043B\u044C/\u0437\u0430\u043C\u043E\u043A)");
    let won = "";
    for (const target of targets) {
      const raw = target.tagName + "." + String(target.className).replace(/\s+/g, ".").slice(0, 40);
      if (/nav-content|app-nav/.test(raw)) {
        tried.push(raw + " (skip-\u043D\u0430\u0432\u0431\u0430\u0440)");
        continue;
      }
      tried.push(raw);
      for (const type of ["pointerover", "pointerdown", "mousedown", "pointerup", "mouseup", "click"])
        target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
      for (let i = 0; i < 12; i++) {
        await sleep(200);
        closeBtn = q("postModalClose");
        if (closeBtn) break;
      }
      if (closeBtn) {
        won = target === ov ? "\u043E\u0432\u0435\u0440\u043B\u0435\u0439" : target === node ? "\u0441\u0430\u043C\u0430 \u043F\u043B\u0438\u0442\u043A\u0430" : "\u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u043F\u043E\u0434 \u0442\u043E\u0447\u043A\u043E\u0439";
        break;
      }
    }
    if (!closeBtn) {
      const _img = node.querySelector("img.image");
      const _sig = (e) => e.tagName.toLowerCase() + (typeof e.className === "string" && e.className.trim() ? "." + e.className.trim().replace(/\s+/g, ".") : "");
      const _inner = [...node.querySelectorAll("*")].slice(0, 12).map(_sig).join(" > ");
      const _video = !!node.querySelector('video, .fa-play, [class*="video-controls"]');
      console.warn(
        "[FanslyAI] \u{1F4E3} \u0431\u0430\u043D\u0434\u043B \u043D\u0435 \u0440\u0430\u0441\u043A\u0440\u044B\u043B\u0441\u044F. rect top/bottom:",
        Math.round(r0.top) + "/" + Math.round(r0.bottom),
        "| \u043E\u043A\u043D\u043E:",
        vh + "x" + (window.innerWidth || 0),
        "| \u0442\u043E\u0447\u043A\u0430 \u043A\u043B\u0438\u043A\u0430:",
        Math.round(cx) + "," + Math.round(cy),
        "| \u043E\u0432\u0435\u0440\u043B\u0435\u0439:",
        ov ? "\u0435\u0441\u0442\u044C \u0447\u0435\u0440\u0435\u0437 " + ovMs + " \u043C\u0441" : "\u041D\u0415 \u043F\u043E\u044F\u0432\u0438\u043B\u0441\u044F \u0437\u0430 6 \u0441",
        "| \u043A\u0430\u0440\u0442\u0438\u043D\u043A\u0430:",
        _img ? _img.complete ? "\u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430" : "\u0413\u0420\u0423\u0417\u0418\u0422\u0421\u042F" : "\u043D\u0435\u0442 \u0432\u043E\u0432\u0441\u0435",
        "| \u0432\u0438\u0434\u0435\u043E:",
        _video ? "\u0434\u0430" : "\u043D\u0435\u0442",
        "| \u0437\u0430\u043C\u043E\u043A:",
        document.getElementById("fai-screen-lock") ? "\u0437\u0430\u043F\u0435\u0440\u0442" : "\u043D\u0435\u0442",
        "\n    \u0432\u043D\u0443\u0442\u0440\u0438 \u043F\u043B\u0438\u0442\u043A\u0438:",
        _inner || "(\u043F\u0443\u0441\u0442\u043E)",
        "\n   ",
        "| \u0446\u0435\u043B\u0438:",
        tried.join(" | "),
        "| \u043F\u043E\u0441\u0442:",
        (postEl.querySelector("app-post-attachment app-media[data-media-id]") || {}).getAttribute?.("data-media-id") || "?"
      );
      return null;
    }
    console.log("[FanslyAI] \u{1F4E3} \u0431\u0430\u043D\u0434\u043B \u0440\u0430\u0441\u043A\u0440\u044B\u0442:", won, "\xB7 \u043E\u0432\u0435\u0440\u043B\u0435\u0439", ov ? ovMs + " \u043C\u0441" : "\u043D\u0435 \u0434\u043E\u0436\u0434\u0430\u043B\u0438\u0441\u044C", "\xB7 \u043F\u043E\u043F\u044B\u0442\u043E\u043A", tried.length);
    await sleep(700 + Math.random() * 500);
    const items = [...qa("postGalleryItem")].filter((g) => !preItems.has(g) && inBundle(g)).map((g) => q("postGalleryMedia", g)).filter((m) => m && !qm("mediaPreview", m) && !(m.parentElement && m.parentElement.closest(selStr("postMediaNest")))).map((m) => ({ id: m.getAttribute("data-media-id"), likes: postMediaLikes(m) }));
    for (let a = 0; a < 2 && q("postModalClose"); a++) {
      synthClick(q("postModalClose"));
      for (let i = 0; i < 10 && q("postModalClose"); i++) await sleep(200);
    }
    if (q("postModalClose")) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      for (let i = 0; i < 10 && q("postModalClose"); i++) await sleep(200);
    }
    if (q("postModalClose")) {
      budget.broken = true;
      return items;
    }
    await sleep(400 + Math.random() * 400);
    return items;
  }
  function postsScroller() {
    const p0 = q("postCard");
    let n = p0 && p0.parentElement;
    while (n && n !== document.body) {
      const oy = getComputedStyle(n).overflowY;
      if ((oy === "auto" || oy === "scroll") && n.scrollHeight > n.clientHeight + 40) return n;
      n = n.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }
  async function postsEnsureWall() {
    await waitForElement(selStr("postWallBubble") + ", " + selStr("postCard"), 2e4).catch(() => {
    });
    const bubble = [...qa("postWallBubble")].find((b) => /^\s*Posts\s*$/i.test(b.textContent || ""));
    if (!bubble || qm("postWallActive", bubble)) return;
    bubble.click();
    await sleep(1500);
    await waitForElement(selStr("postCard"), 12e3).catch(() => {
    });
  }
  async function syncPosts(setStatus, incremental = false, scheduled = false) {
    if (POSTS.running) return;
    if (scheduled && await postsLock.active()) {
      console.log("[FanslyAI] posts: \u0430\u043A\u0442\u0438\u0432\u0435\u043D \u0434\u0440\u0443\u0433\u043E\u0439 \u0441\u043A\u0430\u043D \u2192 \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u0446\u0438\u043A\u043B\u0430 \u043F\u043E \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044E");
      return;
    }
    POSTS.running = true;
    const manual = !scheduled;
    if (manual) phaseBegin({ kind: "scan", zoom: true });
    startKeepAlive();
    await postsLock.touch();
    try {
      await postsEnsureWall();
      await waitForElement(selStr("postCard"), 15e3).catch(() => {
      });
      if (!q("postCard")) {
        if (await storeHas("fansly_posts")) throw layoutMissError("posts", "postCard");
        setStatus(t("panel.posts.none", uiLang));
        return;
      }
      layout.seen("posts");
      const posts = await new Promise((r) => chrome.storage.local.get("fansly_posts", (d) => r(d.fansly_posts || {})));
      const knownBefore = new Set(Object.keys(posts));
      let knownStreak = 0, incrDone = false;
      const seen = /* @__PURE__ */ new Set();
      const budget = { used: 0, broken: false };
      let stagnant = 0, bottomStreak = 0, dirty = false;
      const scroller = postsScroller();
      const persist = async () => {
        if (dirty) {
          dirty = false;
          await new Promise((r) => chrome.storage.local.set({ fansly_posts: posts }, r));
        }
      };
      for (let pass = 0; pass < POSTS.MAX_PASSES && bottomStreak < POSTS.BOTTOM_STREAK && stagnant < POSTS.STAGNANT_SAFETY && !incrDone; pass++) {
        if (manual) await scanPause(setStatus);
        await postsLock.touch();
        const before = seen.size;
        for (const el of qa("postCard")) {
          const mediaEls = postMediaEls(el);
          if (!mediaEls.length) continue;
          const ids = mediaEls.map((m) => m.getAttribute("data-media-id")).filter(Boolean);
          if (!ids.length) continue;
          const key = ids.reduce((a, b) => {
            try {
              return BigInt(b) < BigInt(a) ? b : a;
            } catch (e) {
              return a;
            }
          });
          if (seen.has(key)) continue;
          seen.add(key);
          if (incremental) {
            if (knownBefore.has(key)) {
              if (++knownStreak >= 12) {
                incrDone = true;
                break;
              }
            } else knownStreak = 0;
          }
          const st = postStats(el);
          const mediaLikes = {};
          mediaEls.forEach((m) => {
            const v = postMediaLikes(m);
            if (v != null) mediaLikes[m.getAttribute("data-media-id")] = v;
          });
          const moreSpan = q("moreOverlay", el);
          let hiddenMore = moreSpan ? parseInt((moreSpan.textContent || "").replace(/\D+/g, ""), 10) || 0 : 0;
          const prev = posts[key] || {};
          const bundleKnown = prev.hiddenMore === 0 && (prev.mediaIds || []).length >= ids.length + hiddenMore;
          if (hiddenMore > 0 && !document.hidden && !bundleKnown && !STOP.requested) {
            const extra = await postExpandBundle(el, budget);
            if (extra && extra.length) {
              for (const x of extra) {
                if (x.id && !ids.includes(x.id)) ids.push(x.id);
                if (x.likes != null) mediaLikes[x.id] = x.likes;
              }
              hiddenMore = 0;
            }
          } else if (hiddenMore > 0 && bundleKnown) {
            hiddenMore = 0;
          }
          posts[key] = {
            mediaIds: [.../* @__PURE__ */ new Set([...prev.mediaIds || [], ...ids])],
            likes: st.likes,
            comments: st.comments,
            date: subText(q("postTime", el)),
            text: subText(q("postText", el)).slice(0, 200),
            tags: [...new Set([...qa("postTag", el)].map((a) => a.getAttribute("href").replace("/explore/tag/", "")))],
            // ссылка-тег — реестр; её адрес «/explore/tag/…» — формат ссылки, не вёрстка
            mediaLikes: Object.assign({}, prev.mediaLikes || {}, mediaLikes),
            hiddenMore,
            firstSeen: prev.firstSeen || Date.now(),
            lastSeen: Date.now()
          };
          dirty = true;
          if (budget.broken) break;
        }
        if (budget.broken) break;
        setStatus(t("panel.posts.scanning", uiLang, { n: seen.size }));
        const beforeTop = scroller.scrollTop, beforeH = scroller.scrollHeight;
        const step = Math.max(Math.round(scroller.clientHeight * 0.8), 400);
        try {
          scroller.scrollTop = beforeTop + step;
        } catch (e) {
        }
        if (scroller.scrollTop <= beforeTop + 2) {
          const nodes = qa("postCard");
          try {
            nodes[nodes.length - 1].scrollIntoView({ block: "end", behavior: "auto" });
          } catch (e) {
          }
        }
        await sleep(800 + Math.random() * 600);
        const moved = scroller.scrollTop > beforeTop + 2;
        const grew = scroller.scrollHeight > beforeH + 10;
        if (!moved && !grew) {
          bottomStreak++;
          try {
            scroller.scrollTop = Math.max(0, scroller.scrollTop - 350);
          } catch (e) {
          }
          await sleep(200 + Math.random() * 200);
          try {
            scroller.scrollTop = scroller.scrollTop + 1200;
          } catch (e) {
          }
          await sleep(1e3 + 500 * bottomStreak);
        } else bottomStreak = 0;
        if (seen.size === before) stagnant++;
        else stagnant = 0;
        if (pass % 10 === 9) {
          await persist();
          await postsLock.touch();
        }
        if (STOP.requested) break;
      }
      await persist();
      if (STOP.requested) return { stopped: true };
      const added = [...seen].filter((k) => !knownBefore.has(k)).length;
      const bundlesOpen = Object.values(posts).filter((p) => ((p || {}).hiddenMore | 0) > 0).length;
      await new Promise((r) => chrome.storage.local.set({ fansly_posts_lastsync: { at: Date.now(), added, bundlesOpen } }, r));
      if (budget.broken) {
        setStatus(t("panel.posts.modalStuck", uiLang));
        return;
      }
      setStatus(t("panel.posts.done", uiLang, { n: Object.keys(posts).length }));
    } finally {
      POSTS.running = false;
      stopKeepAlive();
      phaseEnd({ zoom: manual });
      await postsLock.clear();
    }
  }
  const running = () => BROADCAST.running ? "broadcast" : EARN.running ? "earnings" : SUBS.running ? "subs" : NOTIF.running ? "notifhist" : POSTS.running ? "posts" : null;
  function setCall(o) {
    uiLang = o && o.lang || uiLang;
    if (!running()) {
      onPhase = o && o.onPhase || null;
      STOP.requested = false;
    }
  }
  function stop() {
    STOP.requested = true;
  }
  async function start(o) {
    setCall(o);
    const st = o && o.onProgress || (() => {
    });
    switch (o && o.page) {
      case "broadcast":
        return syncBroadcast(st, !!(o && o.scheduled));
      case "earnings":
        return syncEarnings(st, (o && o.mode) === "quick", !!(o && o.scheduled));
      // quick — инкремент (стоп на 30 известных подряд), full — вся история
      case "subs":
        return syncSubs(st, !!(o && o.scheduled));
      case "notifhist":
        return syncNotifHistory(st);
      // только ручной: «плановый» у него не бывает
      case "posts":
        return syncPosts(st, (o && o.mode) === "quick", !!(o && o.scheduled));
    }
    throw new Error("Scans.start: \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \xAB" + (o && o.page) + "\xBB");
  }
  const status = () => ({ running: running() });
  self.Scans = { init, start, status, stop, ledgerKey, notifNickSeen, healNotifFilter };
})();
