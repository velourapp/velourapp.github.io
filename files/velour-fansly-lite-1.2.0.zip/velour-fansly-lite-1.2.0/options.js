let uiLang = "ru";
let _loadedBgAck = false;
const BUILD_STAMP = true ? "215b065@20261028.0206" : "dev";
const PLATFORM = true ? "fansly" : "fansly";
let _aboutSettings = null;
document.addEventListener("DOMContentLoaded", () => {
  const BUILD = true ? "store" : "full";
  if (BUILD === "store") document.body.classList.add("show-advanced");
  loadSettings();
  bindEvents();
  bindAbout();
  checkBackupReminder();
  updateStorageLabel();
  showLastImport();
});
function loadSettings() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (response) => {
    if (!response?.result) return;
    const s = response.result;
    uiLang = s.interfaceLanguage || "ru";
    applyI18n(document, uiLang);
    renderAbout(s);
    setValue("interfaceLanguage", s.interfaceLanguage || "ru");
    setValue("nativeLanguage", s.nativeLanguage);
    document.getElementById("translatorEnabled").checked = s.translatorEnabled !== false;
    document.getElementById("useProxy").checked = s.useProxy === true;
    setValue("licenseKey", s.licenseKey);
    document.getElementById("bugReportEnabled").checked = s.bugReportEnabled === true;
    updateProxyVisibility();
    updateBugReportNote();
    setValue("deepLApiKey", s.deepLApiKey);
    updateVisibility();
    layoutCards(true);
  });
}
function setValue(id, val) {
  const el = document.getElementById(id);
  if (el && val !== void 0 && val !== null && val !== "") el.value = val;
}
function setTextarea(id, val) {
  const el = document.getElementById(id);
  if (el && val !== void 0 && val !== null) el.value = val;
}
const CARD_MIN_W = 320, CARD_GAP = 14;
let _cardCols = 0, _cardItems = null;
function cardColCount(width) {
  return Math.max(1, Math.floor((width + CARD_GAP) / (CARD_MIN_W + CARD_GAP)));
}
function cardColumns(heights, n) {
  const fill = (cap) => {
    const col = [];
    let c = 0, used = 0;
    for (const h of heights) {
      if (used && used + h > cap) {
        c++;
        used = 0;
      }
      col.push(c);
      used += h;
    }
    return col;
  };
  const caps = /* @__PURE__ */ new Set();
  for (let i = 0; i < heights.length; i++) for (let j = i, s = 0; j < heights.length; j++) caps.add(s += heights[j]);
  const low = Math.max(0, ...heights);
  for (const cap of [...caps].filter((c) => c >= low).sort((a, b) => a - b)) {
    const col = fill(cap);
    if (col[col.length - 1] < n) return col;
  }
  return heights.map(() => 0);
}
function cssPx(v) {
  return parseFloat(v) || 0;
}
function cardHeight(el) {
  return el.offsetHeight ? el.offsetHeight + cssPx(getComputedStyle(el).marginBottom) : 0;
}
function layoutCards(force) {
  const body = document.querySelector(".body");
  if (!body) return;
  if (!_cardItems) _cardItems = [...body.children];
  const cs = getComputedStyle(body);
  const n = cardColCount(body.clientWidth - cssPx(cs.paddingLeft) - cssPx(cs.paddingRight));
  if (!force && n === _cardCols) return;
  body.classList.add("fixed-cols");
  const old = [...body.children].filter((c) => c.classList.contains("col"));
  const cols = Array.from({ length: n }, () => {
    const c = document.createElement("div");
    c.className = "col";
    return c;
  });
  body.append(...cols);
  cols[0].append(..._cardItems);
  old.forEach((c) => c.remove());
  const at = cardColumns(_cardItems.map(cardHeight), n);
  _cardItems.forEach((el, i) => {
    if (at[i]) cols[at[i]].append(el);
  });
  _cardCols = n;
}
function aboutStampParts(stamp) {
  const m = /^([0-9a-f]{7,40})(\+?)@(\d{4})(\d{2})(\d{2})\.(\d{2})(\d{2})$/.exec(stamp || "");
  return m ? { short: m[1].slice(0, 7) + m[2], date: `${m[5]}.${m[4]}.${m[3]}` } : null;
}
function aboutBrowser() {
  const brands = navigator.userAgentData && navigator.userAgentData.brands || [];
  const b = brands.find((x) => /Google Chrome|Microsoft Edge|Brave|Opera|Yandex|Chromium/.test(x.brand));
  const m = /Chrome\/(\d+)/.exec(navigator.userAgent || "");
  const browser = b ? `${b.brand} ${b.version}` : m ? `Chrome ${m[1]}` : "Chrome ?";
  const os = navigator.userAgentData && navigator.userAgentData.platform || navigator.platform || "";
  return os ? `${browser} \xB7 ${os}` : browser;
}
function aboutTier(q) {
  const tier = String(q && q.tier || "").trim();
  return tier ? tier.charAt(0).toUpperCase() + tier.slice(1) : "";
}
async function renderAbout(s) {
  _aboutSettings = s || {};
  const mf = chrome.runtime.getManifest();
  const fromStore = !!mf.update_url;
  const build = true ? "store" : "full";
  const parts = aboutStampParts(BUILD_STAMP);
  const stampText = parts ? t("options.about.stamp", uiLang, { stamp: parts.short, date: parts.date }) : t("options.about.stamp.dev", uiLang);
  const formText = t(fromStore ? "options.about.build.store" : "options.about.build.self", uiLang);
  const set = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };
  set("about-name", mf.name || "Velour");
  set("about-ver", `${t("options.about.version", uiLang, { version: mf.version })} \xB7 ${stampText} \xB7 ${formText}`);
  set("about-data", t(build === "store" ? "options.about.data.store" : "options.about.data", uiLang));
  set("about-footer", t("options.about.footer", uiLang, { year: (/* @__PURE__ */ new Date()).getFullYear(), platform: (
    /*@of-start@*/
    PLATFORM === "onlyfans" ? "OnlyFans" : (
      /*@of-end@*/
      "Fansly"
    )
  ) }));
  const store = document.getElementById("about-store");
  if (store) {
    store.style.display = fromStore ? "" : "none";
    if (fromStore) store.href = "https://chromewebstore.google.com/detail/" + chrome.runtime.id;
  }
  const cloudOn = !!s && s.useProxy === true && !!String(s.licenseKey || "").trim();
  const q = cloudOn ? await new Promise((r) => chrome.storage.local.get("fansly_ai_quota", (d) => r(d.fansly_ai_quota || null))) : null;
  const tier = aboutTier(q);
  const cloudText = cloudOn ? t("options.about.cloud.on", uiLang) + (tier ? t("options.about.cloud.tier", uiLang, { tier }) : "") : t("options.about.cloud.off", uiLang);
  set("about-cloud", cloudText);
  const info = await new Promise((r) => chrome.runtime.sendMessage({ type: "ABOUT_INFO" }, (x) => r(x || null)));
  const deviceId = info && info.deviceId || "\u2014";
  set("about-device", deviceId);
  set("about-report", [
    `${mf.name} ${mf.version} \xB7 ${BUILD_STAMP} \xB7 ${formText}`,
    `${aboutBrowser()} \xB7 ${t("options.label.interfaceLanguage", uiLang)}: ${uiLang}`,
    `${t("options.about.row.install", uiLang)}: ${deviceId} \xB7 ${t("options.about.row.cloud", uiLang)}: ${cloudText}`
    // подпись как в строке выше: в немецком «Cloud» с большой
  ].join("\n"));
  if (location.hash === "#about" && !renderAbout._scrolled) {
    renderAbout._scrolled = true;
    setTimeout(() => {
      const el = document.getElementById("about");
      if (el) el.scrollIntoView({ block: "start" });
    }, 80);
  }
}
function bindAbout() {
  const status = (key) => {
    const st = document.getElementById("about-status");
    if (!st) return;
    const text = t(key, uiLang);
    st.textContent = text;
    setTimeout(() => {
      if (st.textContent === text) st.textContent = "";
    }, 2500);
  };
  const copy = (text, okKey) => navigator.clipboard.writeText(text).then(() => status(okKey), () => status("options.about.copyFail"));
  document.getElementById("aboutCopyBtn")?.addEventListener("click", () => copy(document.getElementById("about-report")?.textContent || "", "options.about.copied"));
  document.getElementById("aboutCopyIdBtn")?.addEventListener("click", () => copy(document.getElementById("about-device")?.textContent || "", "options.about.idCopied"));
}
function bindEvents() {
  document.getElementById("saveBtn").addEventListener("click", saveSettings);
  window.addEventListener("resize", () => layoutCards());
  document.getElementById("interfaceLanguage").addEventListener("change", (e) => {
    uiLang = e.target.value || "ru";
    applyI18n(document, uiLang);
    layoutCards(true);
    chrome.storage.local.get("fansly_last_export", (d) => updateLastExportLabel(d.fansly_last_export || 0));
    if (_aboutSettings) renderAbout(_aboutSettings);
  });
  document.getElementById("exportBtn").addEventListener("click", exportData);
  document.getElementById("importBtn").addEventListener("click", () => {
    document.getElementById("importFileInput").click();
  });
  document.getElementById("importFileInput").addEventListener("change", (e) => {
    const f = e.target.files[0];
    e.target.value = "";
    if (f) importData(f).catch((err) => {
      console.error("[FanslyAI] \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435:", err);
      showStatus(t("options.status.restoreAborted", uiLang, { err: err && err.message || err }), "#f44336");
    });
  });
  document.getElementById("wipeFansBtn")?.addEventListener("click", () => wipeData("WIPE_FAN_DATA", "options.privacy.confirmFans"));
  document.getElementById("wipeAllBtn")?.addEventListener("click", () => wipeData("WIPE_ALL", "options.privacy.confirmAll"));
  document.getElementById("resetDefaultsBtn")?.addEventListener("click", () => {
    const b = document.getElementById("reset-box");
    b.style.display = b.style.display === "none" ? "" : "none";
  });
  document.getElementById("resetCancelBtn")?.addEventListener("click", () => {
    document.getElementById("reset-box").style.display = "none";
  });
  document.getElementById("resetBackupBtn")?.addEventListener("click", () => exportData());
  document.getElementById("resetConfirmBtn")?.addEventListener("click", () => {
    const st = document.getElementById("reset-status");
    if (st) st.textContent = "\u23F3";
    chrome.runtime.sendMessage({ type: "RESET_SETTINGS" }, (r) => {
      if (st) st.textContent = r && r.success ? t("options.reset.done", uiLang) : "\u274C";
      if (r && r.success) setTimeout(() => location.reload(), 900);
    });
  });
  document.getElementById("useProxy").addEventListener("change", updateProxyVisibility);
  document.getElementById("bugReportEnabled").addEventListener("change", updateBugReportNote);
  document.getElementById("licenseKeyEye")?.addEventListener("click", () => {
    const inp = document.getElementById("licenseKey"), btn = document.getElementById("licenseKeyEye");
    const show = inp.type === "password";
    inp.type = show ? "text" : "password";
    btn.textContent = t(show ? "setup.btn.keyHide" : "setup.btn.keyShow", uiLang);
    btn.title = t(show ? "setup.btn.keyHide.title" : "setup.btn.keyShow.title", uiLang);
  });
  document.getElementById("licenseKeyCopy")?.addEventListener("click", async () => {
    const btn = document.getElementById("licenseKeyCopy"), key = (document.getElementById("licenseKey").value || "").trim();
    let ok = false;
    if (key) {
      try {
        await navigator.clipboard.writeText(key);
        ok = true;
      } catch (e) {
      }
    }
    btn.textContent = t(ok ? "options.key.copied" : key ? "options.key.copyFail" : "options.key.none", uiLang);
    setTimeout(() => {
      btn.textContent = t("options.btn.keyCopy", uiLang);
    }, 1200);
  });
  document.getElementById("licenseBuyLink")?.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.sendMessage({ type: "OPEN_PRICING" });
  });
  document.getElementById("dismissBackupBtn")?.addEventListener("click", () => {
    chrome.storage.local.set({ fansly_no_backup_reminder: true });
    document.getElementById("backup-warning").style.display = "none";
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.fansly_ai_settings) {
      const next = ch.fansly_ai_settings.newValue?.interfaceLanguage || "ru";
      if (next !== uiLang) {
        uiLang = next;
        applyI18n(document, uiLang);
        layoutCards(true);
        chrome.storage.local.get("fansly_last_export", (d) => updateLastExportLabel(d.fansly_last_export || 0));
      }
    }
  });
}
function updateVisibility() {
  const proxyOn = document.getElementById("useProxy")?.checked;
  document.getElementById("deepl-key-row").style.display = proxyOn ? "none" : "block";
}
function updateBugReportNote() {
  const on = document.getElementById("bugReportEnabled")?.checked;
  const note = document.getElementById("bugreport-note");
  if (note) note.style.display = on ? "block" : "none";
}
function updateProxyVisibility() {
  const on = document.getElementById("useProxy").checked;
  const pf = document.getElementById("proxy-fields");
  if (pf) pf.style.display = on ? "block" : "none";
  [
    "gemini-key-row",
    "gemini-model-row",
    "groq-key-row",
    "groq-model-row",
    "openrouter-row",
    "openrouter-model-row",
    "claude-key-row",
    "claude-model-row",
    "provider-order-row",
    "ai-provider-row",
    /*@cws-cut-start@*/
    "ollama-row",
    "ollama-model-row"
    /*@cws-cut-end@*/
  ].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.style.display = on ? "none" : "";
  });
  updateVisibility();
}
function saveSettings() {
  const settings = {
    // Настройки (translateProvider больше не пишем — селект убран, дефолт 'deepl' + ключи решают сами)
    interfaceLanguage: document.getElementById("interfaceLanguage").value,
    nativeLanguage: document.getElementById("nativeLanguage").value,
    translatorEnabled: document.getElementById("translatorEnabled").checked,
    useProxy: document.getElementById("useProxy").checked,
    licenseKey: document.getElementById("licenseKey").value.trim(),
    // proxyBaseUrl намеренно НЕ пишется (поле удалено из UI): сохранённое значение переживает Save как есть
    bugReportEnabled: document.getElementById("bugReportEnabled").checked,
    deepLApiKey: document.getElementById("deepLApiKey").value.trim()
  };
  chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings }, (response) => {
    if (response?.success) {
      showStatus(t("options.status.saved", uiLang), "#4caf50");
    } else {
      showStatus(t("options.status.saveError", uiLang), "#f44336");
    }
  });
}
async function readCatalogForBackup(withThumbs) {
  try {
    await FaiDB.ensureMigrated();
    return {
      catalog: await FaiDB.metaGetAll(),
      thumbHashes: await FaiDB.hashGetAll(),
      thumbs: withThumbs ? await FaiDB.thumbGetAll() : null,
      // Кадры видео идут ПО ТОЙ ЖЕ галке, что и превью (Alex 2026-08-19). В отличие от превью пересканом
      // они не восстанавливаются: пересъёмка — час работы, а последующая разметка — часы. Терять их при
      // переезде на другой компьютер нельзя.
      frames: withThumbs ? await FaiDB.frameGetAll() : null
    };
  } catch (e) {
    console.warn("[FanslyAI] \u043A\u043E\u043F\u0438\u044F: \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043D\u0435 \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043B\u0441\u044F \u2014", e && e.message);
    return null;
  }
}
function wipeData(type, confirmKey) {
  if (!window.confirm(t(confirmKey, uiLang))) return;
  const st = document.getElementById("wipe-status");
  if (st) st.textContent = "\u23F3";
  chrome.runtime.sendMessage({ type }, (r) => {
    const why = r && r.error === "idb_blocked" ? t("options.privacy.err.idbBlocked", uiLang) : r && r.error ? " (" + r.error + ")" : "";
    if (st) st.textContent = r && r.success ? t("options.privacy.done", uiLang) : "\u274C" + why;
    if (r && r.success) setTimeout(() => location.reload(), 900);
  });
}
const SECRET_FIELDS = [
  "licenseKey",
  "claudeApiKey",
  "deepLApiKey",
  "geminiApiKey",
  "groqApiKey",
  "openrouterApiKey",
  "telegramBotToken"
];
function exportData() {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (settingsResp) => {
    chrome.runtime.sendMessage({ type: "GET_ALL_CONTACTS" }, (contactsResp) => {
      const INV_KEYS = [
        "fansly_tg_topics",
        "fansly_subs",
        "fansly_ledger",
        "fansly_posts",
        "fansly_purchases",
        "fansly_crm_notes",
        "fansly_outreach",
        "fansly_likes",
        "fansly_earnings",
        "fansly_earnings_lastsync",
        "fansly_stats_daily",
        "fansly_broadcast_stats",
        "fansly_broadcast_lastsync",
        "fansly_todo_ack",
        "fansly_outreach_done",
        "fansly_tiers"
      ];
      chrome.storage.local.get(INV_KEYS, async (extra) => {
        const withThumbs = document.getElementById("exportWithThumbs")?.checked === true;
        const cat = await readCatalogForBackup(withThumbs);
        if (!cat) {
          showStatus(t("options.export.errCatalog", uiLang), "#f44336");
          return;
        }
        const thumbs = cat.thumbs, frames = cat.frames;
        const withKeys = document.getElementById("exportWithKeys")?.checked === true;
        const settings = Object.assign({}, settingsResp?.result || {});
        if (!withKeys) for (const k of SECRET_FIELDS) delete settings[k];
        if (!settingsResp?.result || !contactsResp || contactsResp.result == null) {
          showStatus(t("options.export.errData", uiLang), "#f44336");
          return;
        }
        const data = {
          version: "0.5",
          exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
          secretsIncluded: withKeys,
          // чтобы при восстановлении было понятно, надо ли вводить ключи руками
          settings,
          contacts: contactsResp.result,
          tgTopics: extra.fansly_tg_topics || null,
          inventory: {
            // Inventory/CRM — переживает переустановку (chrome.storage.local стирается при удалении)
            catalog: cat.catalog || null,
            // из IndexedDB
            subs: extra.fansly_subs || null,
            ledger: extra.fansly_ledger || null,
            posts: extra.fansly_posts || null,
            purchases: extra.fansly_purchases || null,
            crmNotes: extra.fansly_crm_notes || null,
            likes: extra.fansly_likes || null,
            // лайки и фоллоу фанов (todo #53); пара — fansly_likes в background.importData
            outreach: extra.fansly_outreach || null,
            // Добавлено 2026-08-17 (аудит полноты). Пары в background.importData обязательны.
            earnings: extra.fansly_earnings || null,
            earningsLastsync: extra.fansly_earnings_lastsync || null,
            statsDaily: extra.fansly_stats_daily || null,
            broadcastStats: extra.fansly_broadcast_stats || null,
            broadcastLastsync: extra.fansly_broadcast_lastsync || null,
            todoAck: extra.fansly_todo_ack || null,
            outreachDone: extra.fansly_outreach_done || null,
            tiers: extra.fansly_tiers || null,
            thumbHashes: cat.thumbHashes || null,
            // из IndexedDB
            thumbs,
            // превью из IndexedDB — только по галке (null = каталог восстановится без картинок, до перескана vault)
            frames
            // кадры видео — та же галка; пересканом НЕ восстановимы (только пересъёмкой и повторной разметкой)
          }
        };
        let blob = new Blob([JSON.stringify(data)], { type: "application/json" });
        let ext = "json";
        if (typeof CompressionStream === "function") {
          try {
            blob = await new Response(blob.stream().pipeThrough(new CompressionStream("gzip"))).blob();
            ext = "json.gz";
          } catch (e) {
          }
        }
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `velour-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.${ext}`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 12e4);
        const now = Date.now();
        chrome.storage.local.set({ fansly_last_export: now });
        updateLastExportLabel(now);
        const mb = (blob.size / 1048576).toFixed(1);
        showStatus(t("options.status.exported", uiLang) + ` (${mb} \u041C\u0411${withThumbs ? ", \u0441 \u043F\u0440\u0435\u0432\u044C\u044E" : ""})`, "#4caf50");
      });
    });
  });
}
async function readBackupFile(file) {
  const buf = await file.arrayBuffer();
  const u8 = new Uint8Array(buf, 0, Math.min(2, buf.byteLength));
  if (u8[0] === 31 && u8[1] === 139) {
    if (typeof DecompressionStream !== "function") throw new Error("\u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u043D\u0435 \u0443\u043C\u0435\u0435\u0442 \u0440\u0430\u0441\u043F\u0430\u043A\u043E\u0432\u044B\u0432\u0430\u0442\u044C .gz");
    return await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream("gzip"))).text();
  }
  return new TextDecoder().decode(buf);
}
async function importData(file) {
  let data;
  const mb = (n) => (n / 1048576).toFixed(1) + " \u041C\u0411";
  try {
    console.log("[FanslyAI] \u043A\u043E\u043F\u0438\u044F:", file.name, mb(file.size));
    showStatus("\u23F3 \u0427\u0438\u0442\u0430\u044E \u0444\u0430\u0439\u043B\u2026", "#8a8aa5");
    const t0 = Date.now();
    const text = await readBackupFile(file);
    console.log("[FanslyAI] \u0440\u0430\u0441\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E", mb(text.length), "\u0437\u0430", ((Date.now() - t0) / 1e3).toFixed(1), "\u0441");
    showStatus("\u23F3 \u0420\u0430\u0437\u0431\u0438\u0440\u0430\u044E \u043A\u043E\u043F\u0438\u044E\u2026", "#8a8aa5");
    data = JSON.parse(text);
  } catch (e) {
    console.error("[FanslyAI] \u043A\u043E\u043F\u0438\u044F \u043D\u0435 \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043B\u0430\u0441\u044C:", e);
    showStatus(t("options.status.parseError", uiLang) + " \u2014 " + (e && e.message || e), "#f44336");
    return;
  }
  if (!data.settings) {
    showStatus(t("options.status.badFile", uiLang), "#f44336");
    return;
  }
  const inv = data.inventory || {};
  const heavy = { catalog: inv.catalog, thumbHashes: inv.thumbHashes, thumbs: inv.thumbs, frames: inv.frames };
  const hasHeavy = !!(heavy.catalog || heavy.thumbHashes || heavy.thumbs || heavy.frames);
  const slim = Object.assign({}, data, { inventory: Object.assign({}, inv, { catalog: null, thumbHashes: null, thumbs: null, frames: null }) });
  const cnt = (o) => o && typeof o === "object" ? Object.keys(o).length : 0;
  console.log(
    "[FanslyAI] \u0432 \u043A\u043E\u043F\u0438\u0438: \u043A\u0430\u0442\u0430\u043B\u043E\u0433",
    cnt(inv.catalog),
    "\xB7 \u043F\u0440\u0435\u0432\u044C\u044E",
    cnt(inv.thumbs),
    "\xB7 \u0445\u0435\u0448\u0438",
    cnt(inv.thumbHashes),
    "\xB7 \u043A\u0430\u0434\u0440\u044B \u0432\u0438\u0434\u0435\u043E",
    cnt(inv.frames),
    "\xB7 \u0434\u043E\u0441\u044C\u0435",
    cnt(data.contacts),
    "\xB7 \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438",
    cnt(inv.subs),
    "\xB7 \u043A\u043E\u0448\u0435\u043B\u0451\u043A",
    cnt(inv.earnings),
    "\xB7 \u043F\u043E\u0441\u0442\u044B",
    cnt(inv.posts)
  );
  const trace = [];
  const step = (name, extra) => {
    trace.push(Object.assign({ at: Date.now(), name }, extra || {}));
    try {
      chrome.storage.local.set({ fansly_last_import: trace.slice(-40) });
    } catch (e) {
    }
    console.log("[FanslyAI] \u0438\u043C\u043F\u043E\u0440\u0442 \u2192", name, extra || "");
  };
  const doImport = async () => {
    showStatus(t("options.status.transferring", uiLang), "#8a8aa5");
    step("storage:start");
    let response;
    try {
      response = await new Promise((resolve) => chrome.runtime.sendMessage(
        { type: "IMPORT_DATA", data: slim },
        (r) => resolve(chrome.runtime.lastError ? { success: false, error: chrome.runtime.lastError.message } : r)
      ));
    } catch (e) {
      step("storage:throw", { err: String(e && e.message || e) });
      showStatus(t("options.status.importError", uiLang) + " \u2014 " + (e && e.message || e), "#f44336");
      return;
    }
    if (!response?.success) {
      step("storage:fail", { err: String(response?.error || "") });
      showStatus(t("options.status.importError", uiLang) + (response?.error ? " \u2014 " + response.error : ""), "#f44336");
      return;
    }
    step("storage:ok");
    loadSettings();
    updateStorageLabel();
    if (!hasHeavy) {
      showStatus(t("options.status.imported", uiLang), "#4caf50");
      step("done");
    } else {
      const NAME = {
        start: t("options.import.progress.start", uiLang),
        catalog: t("options.import.progress.catalog", uiLang),
        hashes: t("options.import.progress.hashes", uiLang),
        thumbs: t("options.import.progress.thumbs", uiLang),
        frames: t("options.import.progress.frames", uiLang),
        done: t("options.import.progress.done", uiLang)
      };
      let lastStage = "";
      try {
        await FaiDB.restoreCatalog(heavy, ({ stage, done, total }) => {
          showStatus("\u23F3 " + (NAME[stage] || stage) + (total ? " " + done + "/" + total : "") + "\u2026", "#8a8aa5");
          if (stage !== lastStage) {
            lastStage = stage;
            step("catalog:" + stage, total ? { total } : null);
          }
        });
      } catch (e) {
        console.error("[FanslyAI] \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043D\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B\u0441\u044F:", e);
        step("catalog:fail", { stage: lastStage, err: String(e && e.message || e) });
        showStatus(t("options.status.catalogPartial", uiLang, { err: e && e.message || e }), "#ffa726");
        return;
      }
      const n = await FaiDB.metaCount().catch(() => null);
      const th = await FaiDB.thumbCount().catch(() => null);
      const fr = await FaiDB.frameCount().catch(() => null);
      step("done", { media: n, thumbs: th, frames: fr });
      showStatus(t("options.status.imported", uiLang) + t("options.status.imported.catalogInfo", uiLang, { n: n ?? "?", th: th ?? "?" }), "#4caf50");
    }
    if (data.secretsIncluded === false) {
      setTimeout(() => showStatus(t("options.import.noKeys", uiLang), "#ffa726"), 3200);
    } else if (!inv.thumbs) {
      setTimeout(() => showStatus(t("options.import.noThumbs", uiLang), "#8a8aa5"), 3200);
    }
  };
  const hasContacts = Object.keys(data.contacts || {}).length > 0;
  if (hasContacts) {
    const ok = confirm(t("options.confirm.importContacts", uiLang, { n: Object.keys(data.contacts).length }));
    if (!ok) {
      showStatus(t("options.status.restoreCancelled", uiLang), "#8a8aa5");
      return;
    }
  }
  doImport();
}
function showLastImport() {
  chrome.storage.local.get("fansly_last_import", (d) => {
    const tr = d.fansly_last_import;
    if (!Array.isArray(tr) || !tr.length) return;
    const last = tr[tr.length - 1];
    const el = document.getElementById("wipe-status") || document.getElementById("status");
    if (last.name === "done" || !el) return;
    const STAGE = {
      "storage:start": t("options.import.stage.storageStart", uiLang),
      "storage:fail": t("options.import.stage.storageFail", uiLang),
      "storage:throw": t("options.import.stage.storageThrow", uiLang),
      "catalog:start": t("options.import.stage.catalogStart", uiLang),
      "catalog:catalog": t("options.import.stage.catalogWrite", uiLang),
      "catalog:hashes": t("options.import.stage.catalogHashes", uiLang),
      "catalog:thumbs": t("options.import.stage.catalogThumbs", uiLang),
      "catalog:fail": t("options.import.stage.catalogFail", uiLang)
    };
    const when = new Date(last.at).toLocaleString(uiLang, { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    el.textContent = t("options.import.lastBroken", uiLang, { when, stage: STAGE[last.name] || last.name, err: last.err ? ": " + last.err : "" });
    el.style.color = "#ffa726";
  });
}
function checkBackupReminder() {
  chrome.storage.local.get(["fansly_last_export", "fansly_no_backup_reminder"], (data) => {
    if (data.fansly_no_backup_reminder) return;
    const lastExport = data.fansly_last_export || 0;
    updateLastExportLabel(lastExport);
    const daysSince = (Date.now() - lastExport) / (1e3 * 60 * 60 * 24);
    if (daysSince > 7 || lastExport === 0) {
      document.getElementById("backup-warning").style.display = "block";
    }
  });
}
const DATE_LOCALES = { ru: "ru", en: "en-US", es: "es-ES", de: "de-DE", fr: "fr-FR" };
function updateStorageLabel() {
  const el = document.getElementById("storage-label");
  if (!el || !chrome.storage.local.getBytesInUse) return;
  chrome.storage.local.getBytesInUse(null, (bytes) => {
    const quota = chrome.storage.local.QUOTA_BYTES || 10485760;
    const pct = Math.round(bytes / quota * 100);
    const mb = (bytes / 1048576).toFixed(1);
    el.textContent = t("options.storage.label", uiLang, { mb, total: Math.round(quota / 1048576), pct });
    el.style.color = pct >= 80 ? "#ff7043" : pct >= 60 ? "#ffa726" : "#6f6f8a";
  });
}
function updateLastExportLabel(ts) {
  const el = document.getElementById("last-export-label");
  if (!el) return;
  if (!ts) {
    el.textContent = t("options.export.never", uiLang);
    return;
  }
  const loc = DATE_LOCALES[uiLang] || "ru";
  const d = new Date(ts);
  el.textContent = t("options.export.last", uiLang, { date: d.toLocaleDateString(loc), time: d.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit" }) });
}
function showStatus(msg, color = "#888") {
  const el = document.getElementById("status");
  el.textContent = msg;
  el.style.color = color;
  setTimeout(() => {
    el.textContent = "";
  }, 3e3);
}
