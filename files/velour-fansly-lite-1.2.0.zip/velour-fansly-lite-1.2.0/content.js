console.log("[FanslyAI] *** CONTENT SCRIPT LOADED v0.3 ***");
(function() {
  "use strict";
  const BUILD = true ? "store" : "full";
  const _bugCrumbs = [];
  function bugCrumb(code) {
    if (code) {
      _bugCrumbs.push(code);
      if (_bugCrumbs.length > 8) _bugCrumbs.shift();
    }
  }
  function bugStackFrames(err) {
    const out = { name: err && err.name || "Error" };
    const stack = err && err.stack || "";
    const re = /(?:chrome-extension:\/\/[a-z]+\/)?([\w.-]+\.js):(\d+):(\d+)/g;
    const frames = [];
    let m;
    while ((m = re.exec(stack)) && frames.length < 2) frames.push(`${m[1]}:${m[2]}:${m[3]}`);
    if (frames[0]) out.frame = frames[0];
    if (frames[1]) out.frame2 = frames[1];
    return out;
  }
  function reportBug(code, fields, k) {
    try {
      sendSafe({ type: "REPORT_BUG", code, fields: fields || {}, bc: _bugCrumbs.slice(), k });
    } catch (e) {
    }
  }
  window.addEventListener("unhandledrejection", (e) => {
    const m = (e.reason && (e.reason.message || e.reason)) + "";
    if (/context invalidated/i.test(m)) {
      e.preventDefault();
      return;
    }
    if (e.reason && e.reason._faiReported) {
      e.preventDefault();
      return;
    }
    reportBug("exception", { src: "content", ...bugStackFrames(e.reason) });
  });
  window.addEventListener("error", (e) => {
    if (/context invalidated/i.test(e.message || "")) {
      e.preventDefault();
      return;
    }
    const f = e.filename ? { frame: `${e.filename.split("/").pop()}:${e.lineno}:${e.colno}` } : {};
    reportBug("exception", { src: "content", ...bugStackFrames(e.error), ...f });
  });
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type !== "PULT_STATE") return;
    sendResponse({ pult: !!state._pultActive });
  });
  const PLATFORM = true ? "fansly" : "fansly";
  const FANSLY = {
    key: "fansly",
    SEL: {
      messageContent: ".message-content-list",
      messageText: ".message-text",
      textarea: "textarea.message-input",
      contactHeader: ".message-content-header-contact",
      headerWrap: ".message-content-header",
      quote: ".message-reply, .message-quote",
      media: ".message-attachment, .image-placeholder-wrapper",
      displayName: ".display-name",
      contactList: ".message-list.noselect",
      contactLink: '.message-list.noselect a[href*="messages"]',
      search: ".search-input-container input",
      listUnread: '[class~="badge"], [class*="badge-container"]',
      messageTime: ".message-time",
      // время последнего сообщения в строке списка (now/2m/8h/Jul 20, 15:22)
      rowPreview: ".font-size-xs.dark-blue-1.eclipse",
      // превью строки списка = ПОЛНЫЙ текст последнего сообщения (eclipse — только CSS-обрезка); у медиа без текста пусто
      rowPaid: ".fa-badge-dollar",
      // платное вложение в непрочитанном
      rowMedia: ".fa-image, .fa-images, .fa-video, .fa-photo-video, .fa-file-image, .fa-paperclip, .fa-microphone, .fa-camera",
      // признак вложения в строке (best-effort: ⏳ живой замер на фото с подписью)
      navEnvelope: '[data-menu-item="message"] .notification-badge',
      navNotif: '[routerlink="/notifications"] .notification-badge',
      sendBtn: 'button[class*="send"], .send-btn',
      messageNode: "app-group-message.message",
      // один узел сообщения (для observer/скролл-догрузки)
      messageTimestamp: ".timestamp",
      // разделитель даты в ленте — соседний div ВНЕ узла сообщения (пункт 4, 20.10: в реестр)
      usernameLink: ".username-wrapper",
      // ссылка на ник фана в шапке чата (href «/ник») — якорь имени, когда шапка показывает «Unknown User»
      // ── Корневые якоря сканеров (Fansly, full-only использование; ТОЛЬКО через q()/qa()/selStr()) ──
      // Значение — массив кандидатов (fallback-цепочка): первый живой побеждает. Ломкие места редизайна
      // площадки (app-*-компоненты); удалённый оверрайд (selectors.json) чинит их без перевыпуска.
      subCard: ["app-creator-dashboard-subscription"],
      earnRoot: ["app-creator-wallet-transaction-history", "app-wallet-transaction-history"],
      // кошелёк после редизайна 19.10; прежняя таблица — запасом
      earnRow: ["app-creator-wallet-transaction-history .tx-row", "app-wallet-transaction-history table tbody tr, app-wallet-transaction-history table tr"],
      broadcastCard: ["app-broadcast-message-history-item"],
      // Вкладка и внутренности карточки рассылки (6а, 23.10: из кода в реестр — редизайн чинится selectors.json, без релиза).
      // Метрика — по ИКОНКЕ внутри блока метрики (язык-независимо): охват, открытия, продажи; число — текст рядом с иконкой.
      broadcastTab: [".tab-nav-items .tab-nav-item, .tab-nav-item"],
      // ОДНОЙ строкой: нужны все вкладки разом (какая из них «Broadcast Message Stats» — по тексту)
      broadcastStat: [".stat-item"],
      // блок метрики
      broadcastReach: ["i.fa-telegram"],
      // иконка охвата (сколько получили)
      broadcastOpen: ["i.fa-eye"],
      // иконка открытий
      broadcastSale: ["i.fa-tally"],
      // иконка продаж
      broadcastTooltip: [".tooltiptext"],
      // подсказка: вырезаем, иначе число тонет в её тексте
      broadcastAmount: [".stat-item-dollar app-balance-display"],
      // сумма продаж — сам элемент суммы
      broadcastAmountBox: [".stat-item-dollar"],
      // блок суммы — запасной путь, подсказка вырезается
      broadcastTime: [".timestamp"],
      // «Sunday, Jul 26, 2026 at 18:38»
      broadcastText: [".message-content"],
      // превью текста рассылки
      postCard: ["app-post.feed-item", "app-post"],
      // Внутренности поста, бандл «+N», стена профиля и тарифы (6б, 23.10: из кода в реестр — редизайн чинится selectors.json,
      // без релиза). Признаки (postAvatar, postWallActive) проверяются на самом элементе (qm), остальное — поиск внутри.
      postMedia: ["app-post-attachment app-media[data-media-id]"],
      // медиа-вложения поста (не аватар, не превью)
      postMediaNest: ["app-media"],
      // тег медиа: медиа внутри другого медиа — служебное превью, не считаем
      postAvatar: [".avatar"],
      // аватар автора — не медиа поста
      postMediaBox: ["app-account-media"],
      // обёртка медиа со своими счётчиками
      postMediaLike: [".stats-overlay .feed-item-stat.likes"],
      // лайки отдельного медиа (в его обёртке)
      postStatsBox: [".feed-item-stats"],
      // блок счётчиков поста (не тот, что в обёртке медиа)
      postLikes: [".feed-item-stat.likes"],
      // лайки поста — в блоке счётчиков
      postComments: [".feed-item-stat.comments"],
      // комментарии поста — в блоке счётчиков
      postBundleMore: [".more-media-available"],
      // плитка «ещё N медиа» (бандл)
      postBundleOverlay: [".image-overlay"],
      // её оверлей — по нему кликаем
      postGalleryItem: [".media-gallery-item"],
      // плитка галереи в окне бандла
      postGalleryMedia: ["app-media[data-media-id]"],
      // медиа в плитке галереи
      postProfileGallery: [".profile-media-gallery"],
      // профильная карусель в том же окне — её плитки не наши
      postModalClose: [".modal-close-button"],
      // крестик окна: есть он — окно открыто
      postWallBubble: [".bubble"],
      // пузыри стен профиля («Posts», «Live», …)
      postWallActive: [".active"],
      // признак открытой стены
      postTime: [".feed-item-timestamp"],
      // дата поста
      postText: [".feed-item-description"],
      // текст поста
      postTag: ['a[href^="/explore/tag/"]'],
      // ссылки-теги поста
      tierBox: [".subscription-plans"],
      // блок тарифа на профиле
      tierName: [".subscription-tier-title"],
      // название тарифа
      tierPlan: [".subscription-plan[style]"],
      // плашка тарифа — цвет из background в style
      tierPrice: [".subscription-price app-balance-display"],
      // цена тарифа
      notifRow: [".notifications-list .notification", ".notification"],
      vaultTile: [".vault-content app-media[data-media-id]"],
      // Картинка для тумбы/блюр-метрик ВНУТРИ тайла. У видео их ДВЕ (Alex 2026-08-15): `.preview.overflow-hidden`
      // → `img.image.cover` (обрезанная, размытая) и `.preview` → `img.image.contain` (чёткий постер). Первый
      // кандидат цепочки = contain: q() отдаёт первый живой, у фото contain нет → падаем на обычный img.image.
      vaultThumbImg: ["img.image.contain", "img.image"],
      vaultReady: [".vault-album, .quick-menu .bubble, .vault-content app-media[data-media-id]"],
      // Съёмка кадров из видео. ⚠️ Кликать МОЖНО только по кнопке плеера: клик по `.image-overlay`
      // или по самой картинке открывает модалку просмотра и ломает ленту (проверено живьём 2026-08-19).
      vaultPlayBtn: [".video-controls .play-button"],
      vaultVideoEl: ["app-video-element-wrapper video", "video"],
      // Всё остальное хранилища (6в, 23.10: из кода в реестр — редизайн чинится selectors.json, без релиза). Признаки
      // (vaultCoverMedia, vaultAvatar, vaultItemActive) проверяются на самом элементе (qm), остальное — поиск внутри.
      // Альбомы на Overview (их же читает vault-counts.js: реестр ему передаёт сбор хранилища).
      vaultAlbum: [".vault-album"],
      // плитка альбома
      vaultAlbumName: [".vault-album-footer .semi-bold"],
      // имя альбома — единственный ключ папки
      vaultAlbumCount: [".vault-album-footer .dark-blue-1"],
      // счётчик медиа альбома («3,141»)
      vaultAlbumMedia: [".vault-album-media"],
      // обложка альбома — по ней кликаем, чтобы войти
      // Навигация папок: меню пузырей и выпадающий «More» с остальными папками.
      vaultMenu: [".quick-menu"],
      // меню пузырей (у Fansly есть и чужие — наше узнаём по All/Overview/Posts)
      vaultBubble: [".bubble"],
      // пузырь папки (любой глубины в меню)
      vaultBubbleTop: [":scope > .bubble"],
      // прямой пузырь меню — относительно меню (More вложен глубже и сюда не попадает)
      vaultBubbleActive: [".bubble.active"],
      // пузырь открытой папки
      vaultMore: [".transparent-dropdown"],
      // выпадающий «More» в меню
      vaultMoreToggle: [":scope > .bubble"],
      // кнопка «More» — собственный пузырь выпадающего (относительно него)
      vaultMoreItem: [".dropdown-list .dropdown-item"],
      // пункт «More» — папка (в DOM и закрытым)
      vaultItemActive: [".active"],
      // признак открытой папки на пункте «More»
      vaultFolderName: [".eclipse"],
      // имя папки в пункте — по нему кликаем (не по ✏️/✖: ✖ удаляет папку!)
      // Плитка медиа: длительность, имя и дата файла, признаки аудио и видео, служебные превью.
      vaultPlayTime: [".play-time"],
      // длительность видео «0:07»
      vaultProgress: [".progressed-time"],
      // прогресс внутри длительности — вырезаем
      vaultFileName: [".image-filename"],
      // имя файла в ячейке грида
      vaultFileDate: [".image-date"],
      // дата файла в ячейке грида
      vaultAudioMark: [".contains-audio, audio.audio, .audio-wrapper"],
      // ОДНОЙ строкой: любой из признаков аудио
      vaultVideoMark: ["app-video-element-wrapper, video, .play-time"],
      // ОДНОЙ строкой: любой из признаков видео (запас, когда имени нет)
      vaultMediaNest: ["app-media"],
      // тег медиа: медиа внутри другого медиа — служебное превью
      vaultCoverMedia: [".album-cover-media"],
      // обложка альбома — не медиа сетки
      vaultAvatar: [".avatar"],
      // аватар — не медиа сетки
      vaultPreviewPoster: ["app-media.preview"],
      // превью-постер: кнопка плеера в нём — не та
      vaultModalClose: [".modal-close-button"],
      // крестик окна просмотра (клик открыл его — закрыть)
      vaultScroller: [".vault-wrapper"],
      // прокрутка хранилища (запас, если по плитке не нашлась)
      vaultSearchIcon: ["i.fa-search"],
      // лупа в пузыре поиска
      vaultSearchInput: ['.material-input input[type="text"]'],
      // поле «Search Album»
      // Пикер «Из хранилища» (чат, окно загрузки медиа; 24.10): альбомы в окне — те же vaultAlbum / vaultAlbumName / vaultAlbumMedia.
      vaultPickerModal: ["app-media-vault-picker-modal.active-modal"],
      // окно выбора медиа из хранилища
      vaultPickerSearch: [".vault-search .bubble"],
      // лупа поиска файла в окне (внутри папки)
      vaultPickerInput: [".material-input input"],
      // поле поиска файла в окне
      vaultPickMenuItem: [".dropdown-item"],
      // пункт меню, по клику на который проверяем «это хранилище?»
      vaultPickIcon: [".fa-photo-film"],
      // значок «Из хранилища» (меню вложений чата, «добавить ещё»)
      vaultPickUploadIcon: [".fa-upload"],
      // значок загрузки — у «From Vault» блока превью он же
      vaultPickUploadNew: ['[data-menu-item="upload-new"]'],
      // признак соседа «Загрузить новое»: у пункта хранилища его нет
      // Тайл статы в шапке (Лайки / Бесплатные / Платные подписчики → дневной срез + график «Динамики»).
      // Деградирует МОЛЧА (график просто перестаёт пополняться) → корень и внутренности в реестре с оверрайдом.
      creatorStat: [".creator-stats .creator-stat"],
      creatorStatTitle: [".creator-stat-title"],
      creatorStatValue: [".creator-stat-value"],
      // Типы нотификаций — СТРУКТУРНО по тегу компонента (текст локализуется Fansly и ломается молча:
      // «Приобрели ваш медиа-контент» уже не матчился /Purchased your Media/). Теги сняты с живой ленты
      // (Alex 2026-08-13; чаевые и набор — дампы 2026-09-26, #132). Ключи-ПРЕДИКАТЫ (qm). Текстовые регэкспы остаются
      // фолбэком в notifParse — только английским: в русском интерфейсе без тега терялись все чаевые и наборы.
      notifMediaOrder: ["app-account-media-order-notification", "app-account-media-bundle-order-notification"],
      // одиночная покупка и набор: текст у них один
      notifSubPay: ["app-subscription-history-renew-notification"],
      // ОБЩИЙ тег покупки И продления подписки — new/renew различаем по тексту
      notifSubExpire: ["app-subscription-expire-notification"],
      notifTipRow: ["app-tip-received-notification"],
      notifTime: [".notification-timestamp"],
      // штамп времени строки («47m» / «Aug 12»)
      // Внутренности строки уведомления (пункт 5, 20.10: из кода в реестр — редизайн строки чинится без перевыпуска).
      // Без ника строка пропускается целиком; сумма — деньги в ledger; медиа — какое купили или лайкнули.
      notifUser: ["a.username-wrapper[href]"],
      // ссылка на ник фана (href «/ник»)
      notifAmount: ["app-balance-display"],
      // сумма в строке (чаевые, покупка, подписка)
      notifMedia: ["app-media[data-media-id]"],
      // медиа в строке; у видео первым — само медиа, следом превью
      // Лайк / подписка-фоллоу — по имени тега («…like…» / «…follow…», так в коде). Эти ключи по умолчанию пусты и только
      // ДОБАВЛЯЮТ признак: переименовал Fansly тег без этих слов — дописываем его сюда удалённо.
      notifLikeRow: [],
      notifFollowRow: [],
      // Фильтр типов на странице истории уведомлений (глубокий скан). Пункты без иконок, текст локализован — выбираем по
      // НОМЕРУ (одинаков во всех языках): notifFilterWant — какие включить (чаевые, покупки медиа, платные подписчики,
      // истёкшие), notifFilterCount — сколько пунктов ждём: галки ставятся лишь при ровно таком списке (см. scans.js).
      // 12 — живая проверка Алекса 20.10: Fansly Alerts · Likes · Post Replies · Post Quotes · Tips · Followers · Media Purchases ·
      // Subscribers · Expired Subscriptions · Promotions · Locked Text Purchases · Stream Ticket Purchases (три последних Fansly
      // дописал в конец, 4/6/7/8 не сдвинулись). Вставит пункт в середину — галки не тронем, нам отчёт.
      // ⚠️ Две последние записи — числа строкой, не селекторы: у реестра одна схема, и так их тоже чинит selectors.json.
      notifFilterBox: ["[appxddropdown].dropdown, .dropdown"],
      // ОДНОЙ строкой: нужны все дропдауны разом (какой из них фильтр — по пунктам с галкой), а не первый непустой кандидат
      notifFilterItem: [".dropdown-item"],
      notifFilterCheck: [".checkbox"],
      notifFilterOn: [".checkbox.selected"],
      notifFilterTitle: [".dropdown-title"],
      notifFilterWant: ["4", "6", "7", "8"],
      notifFilterCount: ["12"],
      // Разбор строки кошелька: от этих зависит, ЧТО и ПО КАКОЙ цене мы засчитали за проданное.
      // Деградируют молча (ноль ошибок в консоли, просто неверные цифры) → держим в реестре с оверрайдом.
      earnMedia: ["app-media[data-media-id]"],
      // медиа-плитка внутри строки заказа
      moreOverlay: [".more-media-available-overlay span"],
      // «+N» скрытых в пакете (кошелёк и посты)
      // Всё остальное в строке кошелька и общий пагинатор (7а, 24.10: из кода в реестр — редизайн чинится selectors.json, без релиза).
      // Новая вёрстка кошелька (19.10): строка — div.tx-row без ячеек. Признак строки (earnTxRow) проверяется на ней самой (qm).
      earnTxRow: [".tx-row"],
      // строка новой вёрстки → разбор по блокам, а не по ячейкам
      earnTxBuyer: [".tx-main app-account-username, .tx-main a.username-wrapper[href]"],
      // покупатель есть — продажа (у выплаты его нет)
      earnTxOut: [".tx-thumb.out"],
      // исходящая (деньги ушли) — не продажа
      earnTxSign: [".tx-sign"],
      // знак суммы («−» — деньги ушли)
      earnTxId: [".tx-id"],
      // номер заказа «#966…»
      earnTxAmount: [".tx-amount app-balance-display"],
      // сумма продажи
      earnTxStatus: [".fansly-status-pill"],
      // плашка статуса: возврат, отклонено
      earnTxBuyerLink: [".tx-main a.username-wrapper[href]", '.tx-main app-account-username a[href^="/"]'],
      // ссылка покупателя → хэндл
      earnTxDate: [".tx-meta > span:not(.tx-id):not(.fansly-status-pill)"],
      // дата «Oct 12, 2026, 15:11»
      // Прежняя таблица кошелька (до 19.10) — запасной разбор.
      earnCell: [":scope > td"],
      // ячейки строки (относительно строки)
      earnCellBuyer: ["app-account-username, a.username-wrapper[href]"],
      // ячейка с покупателем
      earnCellBuyerLink: ["a.username-wrapper[href]", 'a[href^="/"]'],
      // ссылка покупателя в ячейке (запас — любая ссылка на профиль)
      earnAmount: ["app-balance-display"],
      // сумма в строке таблицы
      // Ожидание ников покупателей: ник дорисовывается лениво — сначала «Unknown user» без ссылки, потом хэндл.
      earnBuyerLink: ["a.username-wrapper[href]"],
      // ссылка на профиль покупателя в строке
      earnBuyerName: [".display-name"],
      // имя покупателя («Unknown…» — ещё не дорисован)
      // Пагинатор Fansly — общий для доходов и подписчиков. Прежняя разметка (app-xd-pagination): .nav-item, выбранный .selected,
      // погашенный .disabled; новая кошелька (app-cursor-pager): .pager-btn, номер .pager-num.active, пропуск .pager-gap, погашенная — disabled.
      pagerItem: [".nav-item, .pager-btn, .pager-gap"],
      // ОДНОЙ строкой: кнопки, номера и пропуски — в порядке документа
      pagerNextIcon: ["i.fa-chevron-right"],
      // стрелка «вперёд» внутри кнопки
      pagerSelected: [".nav-item.selected, .pager-num.active"],
      // выбранный номер (и признак на самом элементе)
      pagerOff: [".disabled"],
      // погашенная кнопка прежней разметки (у новой — свойство disabled)
      earnPager: ["app-creator-wallet-transaction-history app-cursor-pager, app-wallet-transaction-history app-xd-pagination, app-wallet-transaction-history .table-nav"],
      // пагинатор ИСТОРИИ, не выплат
      subsPager: ["app-xd-pagination, .table-nav"],
      // пагинаторы страницы подписчиков (свой — первый после списка карточек)
      // Подписчики (7б, 25.10): вкладки, фан в карточке и карточка новой вёрстки (с 14.10). Карточка — subCard; прежняя вёрстка
      // карточки (строки с иконками, до 14.10) — запасная ветка разбора, в реестр не вынесена. Признаки (subsTabOn, subPriceRow,
      // subStatusOk) проверяются на самом элементе (qm).
      subsSearch: [".subscriber-search"],
      // поиск подписчика — рядом с ним СВОЯ полоса вкладок
      subsTabsWrap: [".tab-nav-wrapper"],
      // блок вкладок вокруг поиска (closest)
      subsTab: [".tab-nav-items .tab-nav-item"],
      // вкладка «Активно / Истёк / Все (N)»
      subsTabOn: [".selected"],
      // признак выбранной вкладки
      subUserLink: ["a.username-wrapper[href]", 'a[href^="/"]'],
      // ссылка на профиль фана в карточке (запас — любая ссылка на профиль)
      subUserName: [".display-name"],
      // имя фана («Unknown…» — ещё не дорисован или удалён)
      subStarIcon: [".user-icon"],
      // значки у ника (галочка верификации и звезда тира)
      subStar: [".icon-stack .fa-star"],
      // звезда тира внутри значка — значок со звездой и есть тир (цвет — в style)
      subStarOverlay: [".overlay"],
      // значок поверх звезды (продление / пауза) — подтверждение статуса
      subDetails: ["dl.subscription-details"],
      // детали подписки новой вёрстки: dt — название, dd — значение
      subTier: [".subscriber-tier"],
      // название тира в шапке карточки
      subDetailValue: ["dd"],
      // значение строки деталей
      subPriceRow: [".subscriber-price"],
      // признак строки цены среди деталей
      subDateBox: [".subscriber-date"],
      // блок даты продления / окончания
      subDateValue: [".subscriber-date-value"],
      // сама дата в блоке
      subStatus: [".fansly-status-pill"],
      // плашка статуса подписки
      subStatusOk: [".ok"],
      // признак действующей подписки на плашке
      subPrice: ["app-balance-display"],
      // цена подписки
      // ⚠️ ПРЕДИКАТ (qm/matches), не поиск. Служебный превью-вариант закрытого видео: рядом с настоящим медиа
      // Fansly рисует его же превью — это не покупка, не файл каталога и не вложение поста. Один ключ на все
      // четыре места (кошелёк, vault, посты, бандл). Замерено на живом DOM: 71 плитка, 16 превью — класс всегда
      // самостоятельный токен `preview`, иногда с довеском (`preview overflow-hidden`), поэтому именно `.preview`,
      // а не равенство класса. Подстроку (`[class*="preview" i]`) намеренно НЕ берём: она поймала бы и будущий
      // `preview-enabled` у настоящего медиа, а потерять реальный файл хуже, чем посчитать лишний. Переименование
      // класса площадкой чинится добавлением кандидата в selectors.json — без перевыпуска.
      mediaPreview: [".preview"],
      // Оплачено ли СВОЁ платное медиа. Лочка тут ни при чём — она только прикрывает контент от посторонних
      // (Alex 2026-08-21), а ценника в СВОЁМ узле нет вовсе: «Unlock for $X» видит фан, а не криейтер, поэтому
      // detectMediaLocked на своих сообщениях всегда false. Настоящий признак — значок «$» в стеке покупателей:
      // с модификатором dark-blue-1 = ещё не куплено, без него = куплено, а если значка нет совсем — медиа
      // доступно фану бесплатно (входит в подписку). Оба ключа чинятся через selectors.json без перевыпуска.
      paidBadge: [".purchased-icon"],
      // значок «$» в стеке покупателей
      paidUnbought: [".purchased-icon.dark-blue-1, .purchased-avatar.not-purchased"],
      // маркер «ещё не куплено»: висит то на значке, то на аватаре
      // Пейвол — СТРУКТУРНО: платное Fansly оборачивает в .locked-image и рисует .locked-icon/.locked-text
      // («Unlock Video» у чужого, «Show Video» у своего). Фильтр чувствительного контента — это ДРУГОЙ узел
      // (.blur-overlay + «View Content / Disable Filter»), .locked-* там нет вовсе (unlocked_content.txt).
      // Признак язык-независимый, в отличие от прежней ловли по тексту/ценнику.
      lockedGate: [".locked-image", ".locked-icon", ".locked-text-container"],
      // Тарифы на /posts: карточка тарифа кликабельна → открывается модалка подписчика с условиями.
      // ⚠️ purchaseBtn здесь ТОЛЬКО чтобы обходить его стороной — кликать по нему нельзя никогда.
      subPlanCard: [".subscription-plans .subscription-plan"],
      subModal: [".active-modal .modal-content", ".modal.v2 .modal-content"],
      subBenefits: [".subscription-benefits"],
      subModalClose: [".active-modal i.fa-xmark.pointer", ".modal.v2 i.fa-xmark.pointer"],
      subModalTier: [".tier-title-header .bold"]
    },
    // Своё исходящее сообщение (входящее — без my-message). Медиа: класс my-message иногда навешивается
    // ПОЗЖЕ рендера вложения (гонка при live-отправке) → узел ловился как чужой (слева, как фан) и ломал
    // коучинг. Страховка — структурный признак «моё медиа»: .purchased-content (стек «кто купил», есть
    // ТОЛЬКО на своём медиа). ⚠️ .unlocked-content для этого больше НЕ годится — теперь она есть и у медиа
    // ФАНА (урезанное меню Toggle Preview/Add to Collection) → метила входящее фана своим. Дампы 2026-08.
    isOwn(node) {
      if (node.classList.contains("my-message")) return true;
      const own = node.querySelector(".purchased-content");
      return !!own && !own.closest(".message-reply");
    },
    // числовой id контакта: из URL и из href строки списка (стабильнее имени)
    contactId() {
      return (location.href.match(/\/messages\/(\d+)/) || [])[1] || null;
    },
    contactIdFromHref(h) {
      return ((h || "").match(/\/messages\/(\d+)/) || [])[1] || null;
    },
    // раздел сообщений (гейт загрузки панели/ретрая/ре-инита при SPA-навигации)
    isMessagesPage(url = location.href) {
      return /messaging|messages/.test(url);
    },
    // добавленный узел = сообщение (для MutationObserver-фильтра живых входящих/исходящих)
    isMessageNode(node) {
      return node.tagName === "APP-GROUP-MESSAGE" || qm("messageNode", node);
    },
    // + реестр (пункт 4): переопределённый узел сообщения тоже узнаётся
    // href строки списка + навигабельный клик-элемент (на Fansly el = сам <a>, так что оба — тождество)
    hrefOf(el) {
      return el.getAttribute("href");
    },
    clickTarget(el) {
      return el;
    },
    // Открыть строку списка чатов БЕЗ «активности». Слушатель активности Fansly висит на document в фазе всплытия
    // (click/keydown/touch*): обычный el.click() всплывает до него → через 90–120 с POST /status → криейтер числится
    // «онлайн», пока пульт открывает чаты (замер Алекса 2026-09-06, только в режиме Online). RouterLink слушает на
    // самой <a>, поэтому клик без всплытия чат открывает, а до document не доходит (три клика за 5,5 мин — ноль
    // /status). Диспатч обязан идти на саму <a>: у внутреннего узла RouterLink нет.
    openRow(el) {
      const a = el && el.matches && el.matches("a[href]") ? el : el?.closest?.("a[href]") || el?.querySelector?.("a[href]") || el;
      if (!a) return;
      a.dispatchEvent(new MouseEvent("click", { bubbles: false, cancelable: true, composed: true, view: window }));
    },
    profileUrl(handle) {
      return handle ? "https://fansly.com/" + encodeURIComponent(handle) : null;
    },
    // Время сообщения: в самом узле даты нет — `.timestamp` лежит соседним div ВНЕ app-group-message.
    // Идём вверх от узла, на каждом уровне ищем прямого ребёнка `.timestamp` (не внутри сообщения) → parseFanslyTs.
    // null — если не нашли (сгруппированные сообщения без своей метки → carry-forward выше по стеку).
    timeOf(node) {
      let el = node;
      for (let i = 0; i < 4 && el; i++) {
        el = el.parentElement;
        if (!el) break;
        for (const c of el.children) {
          if (c.nodeType === 1 && qm("messageTimestamp", c) && !c.closest(selStr("messageNode"))) {
            const t2 = parseFanslyTs(c.textContent);
            if (t2) return t2;
          }
        }
      }
      return null;
    }
  };
  const ONLYFANS = {
    key: "onlyfans",
    SEL: {
      messageContent: ".b-chat__messages-wrapper",
      // контейнер истории
      messageText: ".b-chat__message__text-holder",
      textarea: '.b-text-editor[contenteditable="true"], .tiptap.ProseMirror[contenteditable="true"]',
      contactHeader: ".b-chat__header__wrapper",
      headerWrap: ".b-chat__header__wrapper",
      quote: ".b-chat__replied-message",
      // цитата (reply) — подтверждено на живом OF-DOM
      media: ".b-chat__message__media-wrapper, .b-purchase__list",
      displayName: ".g-user-name",
      contactList: ".b-chats__list",
      /* TODO(sonnet): подтвердить контейнер скролла */
      contactLink: ".b-chats__item",
      // строка списка (внутри: chatLink)
      chatLink: 'a[href^="/my/chats/chat/"]',
      // ссылка чата внутри строки
      search: ".b-chat__search-form .b-search-form__input",
      // поле поиска чатов (подтв. на живом DOM)
      listUnread: ".m-unread",
      // OF: непрочит = класс на .b-chats__item
      navEnvelope: 'a[data-name="Chats"] .l-header__menu__item__count',
      navNotif: 'a[data-name="Notifications"] .l-header__menu__item__count',
      sendBtn: 'button[at-attr="send_btn"]',
      messageNode: '.b-chat__message[at-attr="chat_message"]'
      // один узел сообщения
    },
    isOwn(node) {
      return node.classList.contains("m-from-me");
    },
    contactId() {
      return (location.pathname.match(/\/my\/chats\/chat\/(\d+)/) || [])[1] || null;
    },
    contactIdFromHref(h) {
      return ((h || "").match(/chat\/(\d+)/) || [])[1] || null;
    },
    isMessagesPage(url = location.href) {
      return /\/my\/chats/.test(url);
    },
    isMessageNode(node) {
      return !!node.matches && node.matches(ONLYFANS.SEL.messageNode);
    },
    // href лежит на внутренней ссылке <a>, а НЕ на контейнере .b-chats__item; клик — по навигабельной ссылке
    hrefOf(el) {
      return (el.querySelector(ONLYFANS.SEL.chatLink) || el).getAttribute("href");
    },
    clickTarget(el) {
      return el.querySelector(ONLYFANS.SEL.chatLink) || el.querySelector(".b-chats__item__link") || el;
    },
    openRow(el) {
      el.click();
    },
    // на OF ровно как раньше (обычный клик по переданному элементу): без своей живой проверки не меняем
    profileUrl(handle) {
      return handle ? "https://onlyfans.com/" + encodeURIComponent(handle) : null;
    },
    timeOf(node) {
      return null;
    },
    // TODO(OF-порт): извлечение времени сообщения из OF-DOM не портировано
    // ── Whole-function OF-варианты (стубы — заполняет Sonnet) ──
    // Контракт = поведение одноимённой FANSLY-функции, но по OF-DOM. Пока возвращают безопасные
    // пустышки: OF-сборка не падает, просто пусто, до заливки.
    findUnreadContacts() {
      const out = [];
      document.querySelectorAll(ONLYFANS.SEL.contactLink + ONLYFANS.SEL.listUnread).forEach((el) => {
        const link = el.querySelector(ONLYFANS.SEL.chatLink);
        const href = link ? link.getAttribute("href") : "";
        const id = this.contactIdFromHref(href);
        const nameEl = el.querySelector(ONLYFANS.SEL.displayName);
        const name = nameEl ? cleanContactName(nameEl.innerText) : "(?)";
        out.push({ el: ONLYFANS.clickTarget(el), id, name, count: 1 });
      });
      return out;
    },
    detectContact() {
      state.currentContactId = this.contactId();
      const header = document.querySelector(ONLYFANS.SEL.contactHeader);
      if (header) {
        const nameEl = header.querySelector(ONLYFANS.SEL.displayName);
        state.currentContact = cleanContactName(nameEl ? nameEl.innerText : header.innerText);
      }
    },
    loadHistory() {
      state.chatHistory = [];
      state._histFor = state.currentContactId;
      state.processedNodes = /* @__PURE__ */ new WeakSet();
      state._mirrorLiveCount = 0;
      state._mirrorLiveAt = 0;
      const historyEl = document.getElementById("fai-chat-history");
      if (historyEl) historyEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.loading">${t("panel.history.loading", state.uiLang)}</div>`;
      document.querySelectorAll(ONLYFANS.SEL.messageNode).forEach((node) => {
        const role = this.isOwn(node) ? "model" : "subscriber";
        const text = getMessageText(node);
        const hasMedia = node.querySelector(ONLYFANS.SEL.media);
        if (!text && !hasMedia) return;
        state.processedNodes.add(node);
        const entry = {
          role,
          text: text || "",
          isMedia: !!hasMedia && !text,
          mediaType: null,
          mediaLocked: false,
          timestamp: this.timeOf(node) || Date.now(),
          // OF timeOf пока стаб(null)→now; заполнит OF-порт — подхватится
          ts: null,
          reply: null
        };
        state.chatHistory.push(entry);
        const msgEl = appendMessageToHistory(entry);
        if (text && msgEl) translateMsgForDisplay(text, msgEl, role === "model" ? outGenders() : inGenders());
      });
      const lastSub = [...state.chatHistory].reverse().find((m) => m.role === "subscriber" && !m.isMedia && m.text);
      state.lastIncomingText = lastSub ? lastSub.text : null;
      updateStats();
      scrollHistoryToBottom();
    },
    applyFanStatus() {
      return;
    },
    // ── Отправка ──
    // Ввод в ProseMirror недоступен из isolated world → делаем через main-world мост (of-bridge.js):
    // postMessage 'setText' → мост зовёт el.editor…insertContent → отвечает 'setText:done'. Затем клик
    // send (DOM-действие доступно из isolated) и ждём своё .m-from-me (OF шлёт с задержкой ~5с).
    _bridgeSetText(text) {
      return new Promise((resolve) => {
        const onMsg = (e) => {
          if (e.source === window && e.data && e.data.source === "fai-of-bridge" && e.data.action === "setText:done") {
            window.removeEventListener("message", onMsg);
            resolve(e.data);
          }
        };
        window.addEventListener("message", onMsg);
        window.postMessage({ source: "fai-of", action: "setText", text: String(text || "") }, "*");
        setTimeout(() => {
          window.removeEventListener("message", onMsg);
          resolve({ ok: false, err: "timeout" });
        }, 3e3);
      });
    },
    // Возвращает тот же статус-контракт, что humanTypeAndSend: 'sent' | 'unconfirmed' | 'no-field'
    // (вызывающий по нему решает, писать ли в ТГ «✅ отправлено»).
    async setAndSend(text) {
      state.suppressUntil = Date.now() + 2500;
      const r = await ONLYFANS._bridgeSetText(text);
      if (!r.ok) {
        setStatus(t("panel.status.noInputField", state.uiLang));
        console.warn("[FanslyAI] OF: \u0432\u0432\u043E\u0434 \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F:", r.err);
        return "no-field";
      }
      const btn = document.querySelector(ONLYFANS.SEL.sendBtn);
      if (!btn || btn.disabled) {
        setStatus(t("panel.status.noInputField", state.uiLang));
        return "no-field";
      }
      const own = () => document.querySelectorAll(".b-chat__message.m-from-me").length;
      const before = own();
      btn.click();
      const appeared = await new Promise((res) => {
        let n = 0;
        const iv = setInterval(() => {
          if (own() > before) {
            clearInterval(iv);
            res(true);
          } else if (++n > 24) {
            clearInterval(iv);
            res(false);
          }
        }, 500);
      });
      if (!appeared) console.warn("[FanslyAI] OF: \u0441\u0432\u043E\u0451 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B\u043E\u0441\u044C \u0437\u0430 12\u0441 (\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E, \u0432\u0441\u0451 \u0436\u0435 \u0443\u0448\u043B\u043E)");
      setStatus(t("panel.status.sent", state.uiLang));
      setTimeout(() => setStatus(""), 2e3);
      return appeared ? "sent" : "unconfirmed";
    }
  };
  const PLAT = (
    /*@of-start@*/
    PLATFORM === "onlyfans" ? ONLYFANS : (
      /*@of-end@*/
      FANSLY
    )
  );
  const { hashString, parseFanslyTs, bodyMediaEl, bodyMediaId, detectMediaType, detectMediaLocked, detectPaidState, cleanContactName } = Parsers;
  Parsers.init({ sel: { q, qa, qm, selStr }, plat: PLAT });
  const { keyOfCurrent, contactDataIsCurrent, defaultContact, loadContact, saveContact, pinnedOf, isPinned, applyScanMarks, keepPinnedOnly } = ContactStore;
  const CONFIG = {
    SELECTORS: PLAT.SEL,
    // источник истины — адаптер (ключи messageContent/messageText/textarea/contactHeader сохранены)
    POS_KEY: "fansly_ai_panel_pos",
    CONTACT_DELAY: 800,
    MAX_TRANSLATE: 3
  };
  let _initialized = false;
  const state = {
    currentContact: null,
    // display name (для UI)
    currentContactId: null,
    // числовой ID из URL — стабильный ключ хранилища
    fanGender: "male",
    contactData: null,
    lastIncomingText: null,
    chatHistory: [],
    observer: null,
    active: false,
    processedNodes: /* @__PURE__ */ new WeakSet(),
    translateQueue: [],
    translateRunning: 0,
    contactTimer: null,
    suppressUntil: 0,
    uiLang: "ru",
    // язык UI расширения (interfaceLanguage) — НЕ путать с nativeLang ниже
    nativeLang: "ru",
    maxWords: 0,
    customIntents: [],
    // пользовательские интенты из настроек
    briefShowOriginal: false,
    // бриф: false = перевод на язык настроек, true = оригинал
    briefCollapsed: true,
    // бриф свёрнут по умолчанию (не забивает обзор)
    typingNow: false,
    // идёт человекоподобная печать (защита от обрезков)
    lastIncomingReply: null,
    // {text, author, isMine} — цитата последнего входящего (#2)
    forceProvider: "auto",
    // ручной override провайдера генерации: auto (каскад) | openrouter | gemini | groq | claude
    _incomingDebounce: null,
    // дебаунс генерации на входящее (защита от лавины)
    activatedAt: 0,
    // момент активации
    historyScrolling: false,
    // true пока пользователь скроллит историю вверх
    _scrollTimer: null,
    transCache: /* @__PURE__ */ new Map(),
    // text → перевод (в памяти сессии): без мигания и повторных запросов
    tiers: [],
    // тарифы {name, price, color}, снятые со страницы /posts (fansly_tiers) — замена ручного маппинга
    selOverrides: null
    // удалённый оверрайд селекторов (fansly_sel_overrides[PLATFORM]) — приоритет над PLAT.SEL
  };
  ContactStore.init({ state, hashString, send: sendSafe, renderDossier });
  function waitForElement(selector, timeout = 3e4) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      const obs = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) {
          obs.disconnect();
          resolve(found);
        }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => {
        obs.disconnect();
        reject(new Error(`Timeout: ${selector}`));
      }, timeout);
    });
  }
  function selList(key) {
    const ov = state.selOverrides && state.selOverrides[key];
    const v = ov != null ? ov : PLAT.SEL[key];
    return Array.isArray(v) ? v.filter(Boolean) : v ? [v] : [];
  }
  function selStr(key) {
    return selList(key).join(", ");
  }
  function selJoin(...keys) {
    return keys.map(selStr).filter(Boolean).join(", ");
  }
  function q(key, root) {
    for (const s of selList(key)) {
      try {
        const el = (root || document).querySelector(s);
        if (el) return el;
      } catch (e) {
      }
    }
    return null;
  }
  function qa(key, root) {
    for (const s of selList(key)) {
      try {
        const els = (root || document).querySelectorAll(s);
        if (els.length) return els;
      } catch (e) {
      }
    }
    return document.querySelectorAll("[data-fai-never]");
  }
  function qm(key, el) {
    if (!el) return false;
    for (const s of selList(key)) {
      try {
        if (el.matches(s)) return true;
      } catch (e) {
      }
    }
    return false;
  }
  function sanitizeSelOverrides(raw) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    const out = {};
    let n = 0;
    for (const key of Object.keys(raw)) {
      if (!Object.prototype.hasOwnProperty.call(PLAT.SEL, key)) continue;
      const list = (Array.isArray(raw[key]) ? raw[key] : [raw[key]]).filter((s) => typeof s === "string" && s.trim() && s.length <= 200).slice(0, 8);
      if (!list.length) continue;
      out[key] = list;
      n++;
    }
    return n ? out : null;
  }
  function loadSelOverrides() {
    try {
      chrome.storage.local.get("fansly_sel_overrides", (d) => {
        const o = d && d.fansly_sel_overrides;
        state.selOverrides = sanitizeSelOverrides(o && o[PLATFORM]);
      });
    } catch (e) {
    }
  }
  loadSelOverrides();
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "local" && ch.fansly_sel_overrides) loadSelOverrides();
    });
  } catch (e) {
  }
  function timeStr(ts) {
    const d = new Date(ts), now = /* @__PURE__ */ new Date();
    const lang = state.uiLang || "ru";
    const time = d.toLocaleTimeString(lang, { hour: "2-digit", minute: "2-digit" });
    if (d.toDateString() === now.toDateString()) return time;
    const opts = { day: "2-digit", month: "short" };
    if (d.getFullYear() !== now.getFullYear()) opts.year = "numeric";
    return `${d.toLocaleDateString(lang, opts)}, ${time}`;
  }
  function getMessageText(node) {
    const allTexts = qa("messageText", node);
    for (const el of allTexts) {
      if (!el.closest(selStr("quote"))) {
        return el.innerText?.trim() || "";
      }
    }
    return "";
  }
  function extractContactIdFromUrl() {
    return PLAT.contactId();
  }
  const FANSLY_SYSTEM_PATHS = /* @__PURE__ */ new Set([
    "messages",
    "home",
    "explore",
    "search",
    "notifications",
    "settings",
    "live",
    "lists",
    "wallet",
    "help",
    "account",
    "post",
    "posts",
    "media",
    "suggestions",
    "subscriptions",
    "collections",
    "following",
    "followers",
    "chat",
    "feed",
    "timeline"
  ]);
  function extractProfileHandle() {
    const candidates = [];
    const header = q("contactHeader")?.closest("*");
    const scopes = [
      q("headerWrap"),
      q("contactHeader")?.parentElement,
      header
    ].filter(Boolean);
    for (const scope of scopes) {
      scope.querySelectorAll('a[href^="/"]').forEach((a) => {
        const href = a.getAttribute("href") || "";
        const seg = href.replace(/^\/+/, "").split(/[/?#]/)[0].toLowerCase();
        if (seg && !FANSLY_SYSTEM_PATHS.has(seg) && /^[a-z0-9_.]+$/.test(seg)) {
          candidates.push(seg);
        }
      });
    }
    const handle = candidates[0] || null;
    console.log("[FanslyAI] Profile handle candidates:", candidates, "\u2192 picked:", handle);
    return handle;
  }
  function chatNameFrom(scope) {
    const nameEl = scope ? q("displayName", scope) : null;
    let name = cleanContactName(nameEl ? nameEl.textContent : scope && scope.innerText || "");
    const unresolved = /^unknown/i.test(name);
    if (/…|\.\.\./.test(name) || unresolved) {
      const handle = (q("usernameLink", scope)?.getAttribute("href") || "").replace(/^\//, "").trim();
      if (handle) name = handle;
    }
    return { name: name || null, unresolved };
  }
  function healthyName(n) {
    return !!n && !/^unknown/i.test(n) && !/…|\.\.\./.test(n);
  }
  function headerIdentity(id) {
    if (PLATFORM === "onlyfans") return { handle: extractProfileHandle(), name: null, trusted: true };
    const linkHandle = (a) => (a && a.getAttribute("href") || "").replace(/^\/+/, "").split(/[/?#]/)[0].trim().toLowerCase() || null;
    let row = null;
    if (id) {
      for (const a of qa("contactLink")) if (PLAT.contactIdFromHref(a.getAttribute("href")) === String(id)) {
        row = a;
        break;
      }
    }
    const rowHandle = row ? linkHandle(q("usernameLink", row)) : null;
    const rowName = row ? chatNameFrom(row).name : null;
    const heads = document.querySelectorAll(selStr("contactHeader"));
    const head = heads.length === 1 ? heads[0] : null;
    const headHandle = head ? linkHandle(q("usernameLink", head)) : null;
    const headName = head ? chatNameFrom(head).name : null;
    if (rowHandle) {
      const agree = headHandle === rowHandle;
      if (heads.length && !agree) console.log("[FanslyAI] \u0448\u0430\u043F\u043A\u0430 \u0447\u0430\u0442\u0430 \u043D\u0435 \u043E\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430 (" + (headHandle || heads.length + " \u0448\u0430\u043F\u043A\u0438") + " \u2260 " + rowHandle + ") \u2014 \u043D\u0438\u043A \u0438 \u0438\u043C\u044F \u0431\u0435\u0440\u0443 \u0438\u0437 \u0441\u0442\u0440\u043E\u043A\u0438 \u0441\u043F\u0438\u0441\u043A\u0430 (#180)");
      return { handle: rowHandle, name: agree && headName ? headName : rowName, trusted: true };
    }
    if (head && headHandle && (!rowName || headName === rowName)) return { handle: headHandle, name: headName, trusted: true };
    if (heads.length > 1) console.log("[FanslyAI] \u0432 DOM " + heads.length + " \u0448\u0430\u043F\u043A\u0438 \u0447\u0430\u0442\u0430, \u0441\u0442\u0440\u043E\u043A\u0438 \u0441 id " + id + " \u043D\u0435\u0442 \u2014 \u043D\u0438\u043A \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u044E (#180)");
    return { handle: null, name: null, trusted: false };
  }
  function getRecentOwnReplies(n = 3) {
    return state.chatHistory.filter((m) => m.role === "model" && !m.isMedia && m.text).slice(-n).map((m) => m.text);
  }
  function computeGap(lastTs) {
    if (!lastTs) return null;
    const hours = (Date.now() - lastTs) / 36e5;
    if (hours < 5) return null;
    const isNewDay = new Date(lastTs).toDateString() !== (/* @__PURE__ */ new Date()).toDateString();
    return `${Math.round(hours)}h${isNewDay ? ", new day" : ""}`;
  }
  const PINNED_MAX = 15;
  function togglePin(fact) {
    const d = state.contactData?.dossier;
    if (!d || !fact) return;
    if (!d.manualFacts) d.manualFacts = [];
    const i = d.manualFacts.indexOf(fact);
    if (i >= 0) d.manualFacts.splice(i, 1);
    else {
      if (d.manualFacts.length >= PINNED_MAX) {
        setStatus(t("panel.dossier.pin.limit", state.uiLang, { n: PINNED_MAX }));
        setTimeout(() => setStatus(""), 5e3);
        return;
      }
      d.manualFacts.push(fact);
    }
    saveContact(state.currentContact, { dossier: d });
    renderDossier();
  }
  function deleteFact(idx) {
    if (!state.contactData?.dossier) return;
    const d = state.contactData.dossier;
    const removed = d.facts[idx];
    d.facts.splice(idx, 1);
    if (removed) {
      if (d.factDates) delete d.factDates[removed];
      if (d.manualFacts) d.manualFacts = d.manualFacts.filter((f) => f !== removed);
    }
    saveContact(state.currentContact, { dossier: d });
    renderDossier();
  }
  function relTime(ts) {
    if (!ts) return "";
    const diff = Date.now() - ts;
    if (diff < 0) return "";
    const day = 864e5;
    if (diff < day) return t("common.relTime.today", state.uiLang);
    const days = Math.floor(diff / day);
    if (days < 7) return t("common.relTime.days", state.uiLang, { n: days });
    if (days < 30) return t("common.relTime.weeks", state.uiLang, { n: Math.floor(days / 7) });
    if (days < 365) return t("common.relTime.months", state.uiLang, { n: Math.floor(days / 30) });
    return t("common.relTime.years", state.uiLang, { n: Math.floor(days / 365) });
  }
  function updateGenderBtn() {
    const b = document.getElementById("fai-fan-gender");
    if (!b) return;
    const female = (state.fanGender || "male") === "female";
    b.textContent = female ? "\u{1F469}" : "\u{1F468}";
    b.title = t("panel.btn.fanGender.state", state.uiLang, {
      gender: t(female ? "common.gender.female" : "common.gender.male", state.uiLang)
    });
  }
  function factsCountText(n) {
    if (state.uiLang === "ru" && typeof CRM !== "undefined" && CRM.plural) return CRM.plural(n, ["\u0444\u0430\u043A\u0442", "\u0444\u0430\u043A\u0442\u0430", "\u0444\u0430\u043A\u0442\u043E\u0432"]);
    return t("panel.dossier.factsCount", state.uiLang, { n });
  }
  function crmCurrent() {
    const h = state.contactData && state.contactData.handle;
    return h && state._crmHandle === h ? state._crm || null : null;
  }
  function aboutSummaryText() {
    const parts = [];
    const s = crmCurrent();
    const money = (n) => (+(+n).toFixed(2)).toString();
    if (s && s.spent > 0) parts.push("$" + money(s.spent));
    if (s && s.buyCount > 0) parts.push(t("crm.card.buys", state.uiLang, { n: s.buyCount }));
    if (s && s.activeSub && s.daysLeft != null) parts.push(t("crm.card.renews", state.uiLang, { n: s.daysLeft }));
    else if (s && s.expired) parts.push(t("crm.card.expired", state.uiLang));
    const b = state.contactData?.brief;
    if (b && b.collectedAt && (b.wants || b.details?.length)) {
      const days = Math.max(0, Math.floor((Date.now() - b.collectedAt) / 864e5));
      parts.push(t("panel.about.brief", state.uiLang, { n: days }));
    }
    const facts = state.contactData?.dossier?.facts?.length || 0;
    if (facts) parts.push(factsCountText(facts));
    return parts.join(" \xB7 ");
  }
  function updateAboutSummary() {
    const el = document.getElementById("fai-about-sum");
    if (!el) return;
    const txt = aboutSummaryText();
    el.textContent = txt;
    const head = document.getElementById("fai-about-head");
    if (head) head.title = txt ? "" : t("panel.about.empty", state.uiLang);
    applyAboutOpen();
  }
  function aboutIsOpen() {
    return !!(state._panelUi && state._panelUi.aboutOpen);
  }
  function applyAboutOpen() {
    const body = document.getElementById("fai-about-body");
    const caret = document.getElementById("fai-about-caret");
    if (body) body.style.display = aboutIsOpen() ? "block" : "none";
    if (caret) caret.textContent = aboutIsOpen() ? "\u25BE" : "\u25B8";
  }
  function aboutToggle() {
    const nv = !aboutIsOpen();
    state._panelUi = Object.assign({}, state._panelUi, { aboutOpen: nv });
    applyAboutOpen();
  }
  function renderDossier() {
    const d = state.contactData?.dossier;
    const badgeEl = document.getElementById("fai-closeness-badge");
    const countEl = document.getElementById("fai-facts-count");
    const listEl = document.getElementById("fai-facts-list");
    if (!badgeEl) return;
    const closenessMap = {
      new: { icon: "\u{1F331}", key: "common.closeness.new" },
      interested: { icon: "\u{1F4AC}", key: "common.closeness.interested" },
      regular: { icon: "\u{1F525}", key: "common.closeness.regular" },
      supporter: { icon: "\u{1F48E}", key: "common.closeness.supporter" }
    };
    const cl = closenessMap[d?.closeness] || closenessMap.new;
    badgeEl.textContent = cl.icon;
    badgeEl.title = t(cl.key, state.uiLang);
    const facts = d?.facts || [];
    if (countEl) countEl.textContent = facts.length ? factsCountText(facts.length) : "";
    updateAboutSummary();
    if (listEl) {
      listEl.innerHTML = "";
      const fd = d.factDates || {};
      const ordered = facts.map((fact, idx) => ({ fact, idx, ts: fd[fact] || 0, pin: isPinned(d, fact) })).sort((a, b) => b.pin - a.pin || b.ts - a.ts);
      ordered.forEach(({ fact, idx, pin }) => {
        const item = document.createElement("div");
        item.className = "fai-fact-item" + (pin ? " fai-fact-pinned" : "");
        const pinBtn = document.createElement("button");
        pinBtn.className = "fai-fact-pin" + (pin ? " on" : "");
        pinBtn.textContent = "\u{1F4CC}";
        pinBtn.title = t(pin ? "panel.dossier.unpin.title" : "panel.dossier.pin.title", state.uiLang);
        pinBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          togglePin(fact);
        });
        const del = document.createElement("button");
        del.className = "fai-fact-delete";
        del.textContent = "\xD7";
        del.title = t("common.btn.delete", state.uiLang);
        del.addEventListener("click", (e) => {
          e.stopPropagation();
          deleteFact(idx);
        });
        const txt = document.createElement("span");
        txt.className = "fai-fact-text";
        txt.textContent = fact;
        txt.title = fact;
        const fg = inGenders();
        const cf = state.transCache.get(tcKey(fact, fg)) ?? state.transCache.get(tcKey(fact, null));
        if (cf != null) txt.textContent = cf;
        else enqueueTranslate(fact, state.nativeLang, (res, meta) => {
          if (res) {
            state.transCache.set(tcKey(fact, meta?.genderSafe !== false ? fg : null), res);
            txt.textContent = res;
          }
        }, fg);
        item.appendChild(pinBtn);
        item.appendChild(del);
        item.appendChild(txt);
        const ts = fd[fact];
        if (ts) {
          const age = document.createElement("span");
          age.className = "fai-fact-age";
          age.textContent = relTime(ts);
          age.title = new Date(ts).toLocaleString();
          age.style.cssText = "font-size:10px;color:#888;margin-left:6px;white-space:nowrap;flex-shrink:0";
          item.appendChild(age);
        }
        listEl.appendChild(item);
      });
    }
  }
  function enqueueTranslate(text, targetLang, onResult, g = null, ctx = null, fanLang = null) {
    if (!/[\p{L}\p{N}]/u.test(text || "")) {
      onResult(null, { genderSafe: true, retryAfterMs: 0 });
      return;
    }
    state.translateQueue.push({ text, targetLang, onResult, g, ctx, fanLang });
    if (!state._trFlushTimer) state._trFlushTimer = setTimeout(() => {
      state._trFlushTimer = null;
      processTranslateQueue();
    }, 60);
  }
  const _transPending = /* @__PURE__ */ new Map();
  function outGenders() {
    return { genderHint: state.creatorGender || "female", toGender: state.fanGender || "male" };
  }
  function inGenders() {
    return { genderHint: state.fanGender || "male", toGender: state.creatorGender || "female" };
  }
  function tcKey(text, g) {
    return `${g?.genderHint || ""}|${g?.toGender || ""}|${text}`;
  }
  const TR_CTX_MAX = 3, TR_CTX_LINE = 200, TR_CTX_CHARS = 600;
  function trContextLines(prev, role) {
    const lines = prev.filter((e) => e.text && !e.isMedia && e.text.trim()).slice(-TR_CTX_MAX).map((e) => ({ who: e.role === role ? "speaker" : "addressee", t: e.text.trim().slice(0, TR_CTX_LINE) }));
    while (lines.length && lines.reduce((n, l) => n + l.t.length, 0) > TR_CTX_CHARS) lines.shift();
    return lines.length ? lines : null;
  }
  function trContextFor(entry) {
    if (state.translateContext === false || !entry) return null;
    const idx = state.chatHistory.lastIndexOf(entry);
    return idx < 0 ? null : trContextLines(state.chatHistory.slice(0, idx), entry.role);
  }
  function trContextOut(chatId = null) {
    if (state.translateContext === false) return null;
    if (chatId && state.currentContactId !== chatId) return null;
    ensureHistoryForCurrent();
    return trContextLines(state.chatHistory || [], "model");
  }
  function trEntryOf(text, isOwn) {
    const role = isOwn ? "model" : "subscriber";
    for (let i = state.chatHistory.length - 1; i >= 0; i--) {
      const e = state.chatHistory[i];
      if (e.role === role && e.text === text) return e;
    }
    return null;
  }
  const TR_CTX_NOCACHE = 20;
  const _trCtxShort = /* @__PURE__ */ new Set();
  let _trCtxChat = "";
  function trChatNow() {
    return String(state.currentContactId || state.currentContact || "");
  }
  function trCtxShort(text, ctx) {
    return !!ctx && String(text).trim().length < TR_CTX_NOCACHE;
  }
  function trCtxChatSync() {
    const chat = trChatNow();
    if (chat === _trCtxChat) return;
    for (const k of _trCtxShort) state.transCache.delete(k);
    _trCtxShort.clear();
    _trCtxChat = chat;
  }
  function translateForOwner(text, g = null, ctx = null) {
    if (!text) return Promise.resolve(null);
    if (state.translatorEnabled === false) return Promise.resolve(null);
    trCtxChatSync();
    const short = trCtxShort(text, ctx), chat = trChatNow();
    const ck = tcKey(text, g);
    const ckPlain = tcKey(text, null);
    const pk = short ? ck + "ctx" : ck;
    const cached = state.transCache.get(ck);
    if (cached != null && (!short || _trCtxShort.has(ck))) return Promise.resolve(cached);
    const plain = state.transCache.get(ckPlain);
    if (plain != null && Date.now() < (state._genderlessUntil || 0)) return Promise.resolve(plain);
    if (_transPending.has(pk)) return _transPending.get(pk);
    const fanLang = contactDataIsCurrent() && state.contactData ? state.contactData.lang || "en" : null;
    const p = new Promise((resolve) => {
      enqueueTranslate(text, state.nativeLang, (result, meta) => {
        if (result) {
          const key = meta?.genderSafe !== false ? ck : ckPlain;
          if (!short) {
            state.transCache.set(key, result);
            _trCtxShort.delete(key);
          } else if (trChatNow() === chat) {
            state.transCache.set(key, result);
            _trCtxShort.add(key);
          }
          if (meta?.genderSafe === false) state._genderlessUntil = Date.now() + (meta?.retryAfterMs || 6e4);
        }
        _transPending.delete(pk);
        resolve(result || (plain != null ? plain : null));
      }, g, ctx, fanLang);
    });
    _transPending.set(pk, p);
    return p;
  }
  function translateMsgForDisplay(text, msgEl, g = null, ctx = null) {
    if (!text || !msgEl) return;
    const div = msgEl.querySelector(".fai-msg-text");
    if (!div) return;
    div.dataset.orig = text;
    const mark = div.dataset.mediaMark ? div.dataset.mediaMark + " " : "";
    trCtxChatSync();
    const ck = tcKey(text, g);
    const cached = state.transCache.get(ck);
    if (cached != null && (!trCtxShort(text, ctx) || _trCtxShort.has(ck))) {
      div.textContent = mark + cached;
      return;
    }
    translateForOwner(text, g, ctx).then((r) => {
      if (r) div.textContent = mark + r;
    });
  }
  function retranslateHistory() {
    document.querySelectorAll("#fansly-ai-panel .fai-msg-text[data-orig]").forEach((div) => {
      const mark = div.dataset.mediaMark ? div.dataset.mediaMark + " " : "";
      const g = div.closest(".fai-msg")?.classList.contains("model") ? outGenders() : inGenders();
      translateForOwner(div.dataset.orig, g).then((r) => {
        if (r) div.textContent = mark + r;
      });
    });
  }
  const TR_BATCH_MAX = 12, TR_BATCH_CHARS = 6e3;
  function processTranslateQueue() {
    while (state.translateRunning < CONFIG.MAX_TRANSLATE && state.translateQueue.length > 0) {
      const head = state.translateQueue.find((it) => it.ctx) || state.translateQueue[0];
      const sameGroup = (it) => !!it.ctx === !!head.ctx && it.targetLang === head.targetLang && (it.g?.genderHint || "") === (head.g?.genderHint || "") && (it.g?.toGender || "") === (head.g?.toGender || "") && (it.fanLang || "") === (head.fanLang || "");
      const group = [];
      let chars = 0;
      for (let i = 0; i < state.translateQueue.length && group.length < TR_BATCH_MAX; ) {
        const it = state.translateQueue[i];
        if (!sameGroup(it) || group.length && chars + it.text.length > TR_BATCH_CHARS) {
          i++;
          continue;
        }
        chars += it.text.length;
        group.push(state.translateQueue.splice(i, 1)[0]);
      }
      if (!group.length) break;
      state.translateRunning++;
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        state.translateRunning--;
        processTranslateQueue();
      };
      const deliver = (item, one) => {
        try {
          item.onResult(one?.result ?? null, { genderSafe: one?.genderSafe !== false, retryAfterMs: one?.retryAfterMs || 0 });
        } catch (e) {
        }
      };
      const ask = (texts, cheapOnly) => sendSafe({
        type: "TRANSLATE_BATCH",
        texts,
        cheapOnly,
        targetLang: head.targetLang,
        genderHint: head.g?.genderHint || null,
        toGender: head.g?.toGender || null,
        ...head.ctx ? { ctx: head.ctx } : {},
        // в ОБОИХ заходах: с контекстом фон и дешёвый заход мимо постоянного кеша ведёт сам
        ...head.fanLang ? { fanLang: head.fanLang } : {}
      }).then((r) => r?.success && Array.isArray(r.results) ? r.results : null).catch(() => null);
      ask(group.map((x) => x.text), true).then((cheap) => {
        const rest = [];
        group.forEach((item, i) => {
          const one = cheap ? cheap[i] : null;
          if (one) deliver(item, one);
          else rest.push(item);
        });
        if (!rest.length) {
          finish();
          return;
        }
        return ask(rest.map((x) => x.text), false).then((out) => {
          rest.forEach((item, k) => deliver(item, out ? out[k] : null));
          finish();
        });
      }).catch(() => finish());
    }
  }
  function _tabId() {
    return state._tabId || (state._tabId = Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
  }
  let _hbPrevLabel = null;
  function faiHeartbeat() {
    if (!isExtensionAlive()) return;
    let label = "", navType = "";
    try {
      const row = q("contactLink");
      label = ((row && q("messageTime", row))?.textContent || "").trim();
    } catch (e) {
    }
    try {
      navType = performance.getEntriesByType("navigation")[0]?.type || "";
    } catch (e) {
    }
    const labelMoved = _hbPrevLabel != null && label !== _hbPrevLabel;
    _hbPrevLabel = label;
    const entry = {
      ts: Date.now(),
      carousel: !!carousel.running,
      poll: !!state._tgPollTimer,
      vis: document.visibilityState,
      focus: document.hasFocus(),
      ka: typeof _keepAliveCtx !== "undefined" && _keepAliveCtx ? _keepAliveCtx.state : "off",
      url: location.pathname,
      stepAgo: carousel._lastStepAt ? Math.round((Date.now() - carousel._lastStepAt) / 6e4) : null,
      navBusy: !!carousel.navBusy,
      label,
      labelMoved,
      wasDisc: document.wasDiscarded === true,
      navType,
      tab: _tabId()
    };
    hbTelemetry(entry);
    chrome.storage.local.get("fansly_ai_health", (d) => {
      const log = d.fansly_ai_health || [];
      log.push(entry);
      if (log.length > 200) log.splice(0, log.length - 200);
      chrome.storage.local.set({ fansly_ai_health: log });
    });
  }
  let _hbLastAt = 0, _hbStallSent = false, _hbDiscSent = false, _hbNoRedraw = 0;
  const HB_GAP_MS = 15 * 6e4;
  const HB_STALL_MS = 15 * 6e4;
  function hbTelemetry(e) {
    const now = e.ts, role = e.carousel ? "pult" : "tab";
    if (_hbLastAt && now - _hbLastAt > HB_GAP_MS) reportBug("pult_health", { code: "gap", ageMs: now - _hbLastAt, name: e.ka, src: role }, "note");
    _hbLastAt = now;
    _hbNoRedraw = e.labelMoved ? 0 : _hbNoRedraw + 1;
    const stallMs = e.carousel && carousel._lastStepAt ? now - carousel._lastStepAt : 0;
    if (stallMs > HB_STALL_MS) {
      if (!_hbStallSent) {
        _hbStallSent = true;
        reportBug("pult_health", { code: "stall", ageMs: stallMs, n: _hbNoRedraw }, "bug");
      }
    } else _hbStallSent = false;
    if (e.wasDisc && !_hbDiscSent && (e.carousel || state._carouselWanted)) {
      _hbDiscSent = true;
      reportBug("pult_health", { code: "discard", src: role }, "bug");
    }
  }
  window.__faiHealth = function() {
    chrome.storage.local.get("fansly_ai_health", (d) => {
      const log = d.fansly_ai_health || [];
      const prevBy = {}, short = (t2) => (t2 || "\u2014").slice(-4);
      const rows = log.map((e) => {
        const k = e.tab || "\u2014";
        const gap = prevBy[k] ? Math.round((e.ts - prevBy[k]) / 6e4) : 0;
        prevBy[k] = e.ts;
        return { \u0432\u0440\u0435\u043C\u044F: new Date(e.ts).toLocaleString(), \u043E\u043A\u043D\u043E: short(e.tab), \u043F\u0430\u0443\u0437\u0430_\u043C\u0438\u043D: gap, \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C: e.carousel, \u043E\u043F\u0440\u043E\u0441: e.poll, \u0432\u043A\u043B\u0430\u0434\u043A\u0430: e.vis, \u0444\u043E\u043A\u0443\u0441: e.focus, keepalive: e.ka, \u0448\u0430\u0433_\u043C\u0438\u043D: e.stepAgo, \u043C\u044C\u044E\u0442\u0435\u043A\u0441: e.navBusy, \u043C\u0435\u0442\u043A\u0430: e.label, \u043C\u0435\u0442\u043A\u0430_\u0448\u043B\u0430: e.labelMoved, \u0432\u044B\u0433\u0440\u0443\u0436\u0430\u043B\u0438: e.wasDisc, \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0430: e.navType };
      });
      console.table(rows);
      const tabs = [...new Set(log.map((e) => e.tab || "\u2014"))];
      const gaps = rows.filter((r) => r.\u043F\u0430\u0443\u0437\u0430_\u043C\u0438\u043D > 7);
      console.log(`[FanslyAI] \u0432\u043A\u043B\u0430\u0434\u043E\u043A \u0432 \u043A\u043E\u043B\u044C\u0446\u0435: ${tabs.length} (${tabs.map(short).join(", ")}) \u2014 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0435\u0440\u0435\u043C\u0435\u0448\u0430\u043D\u044B, \u043F\u0430\u0443\u0437\u044B \u0441\u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F \u043F\u043E \u0441\u0432\u043E\u0435\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435`);
      console.warn(gaps.length ? `[FanslyAI] \u0440\u0430\u0437\u0440\u044B\u0432\u043E\u0432 >7\u043C\u0438\u043D: ${gaps.length} (\u0437\u0430\u043C\u043E\u0440\u043E\u0437\u043A\u0438)` : "[FanslyAI] \u0440\u0430\u0437\u0440\u044B\u0432\u043E\u0432 \u043D\u0435\u0442 \u2014 \u043F\u0438\u043D\u0433 \u0440\u043E\u0432\u043D\u044B\u0439", gaps);
    });
  };
  window.__faiReport = function() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["fansly_ai_health", "fansly_bugbuf", "fansly_ai_settings"], (d) => {
        const log = d.fansly_ai_health || [], buf = d.fansly_bugbuf || [], st = d.fansly_ai_settings || {};
        if (!log.length) {
          console.log("[FanslyAI] \u0441\u0432\u043E\u0434\u043A\u0430: \u043A\u043E\u043B\u044C\u0446\u043E \u043F\u0438\u043D\u0433\u043E\u0432 \u043F\u0443\u0441\u0442\u043E\u0435");
          resolve("");
          return;
        }
        const fmt = (ts) => new Date(ts).toLocaleString();
        const by = {};
        log.forEach((e) => {
          const k = e.tab || "\u2014";
          (by[k] = by[k] || []).push(e);
        });
        const L = [
          "Velour \xB7 \u0441\u0432\u043E\u0434\u043A\u0430 \u0436\u0438\u0432\u0443\u0447\u0435\u0441\u0442\u0438",
          "\u043F\u0435\u0440\u0438\u043E\u0434: " + fmt(log[0].ts) + " \u2014 " + fmt(log[log.length - 1].ts) + " (\u0437\u0430\u043F\u0438\u0441\u0435\u0439 " + log.length + ", \u0432\u043A\u043B\u0430\u0434\u043E\u043A " + Object.keys(by).length + ")"
        ];
        for (const [tab, arr] of Object.entries(by)) {
          let gaps = 0, maxGap = 0, gapAt = 0;
          for (let i = 1; i < arr.length; i++) {
            const g = arr[i].ts - arr[i - 1].ts;
            if (g > 7 * 6e4) {
              gaps++;
              if (g > maxGap) {
                maxGap = g;
                gapAt = arr[i].ts;
              }
            }
          }
          const ka = arr.reduce((a, e) => {
            const k = e.ka || "?";
            a[k] = (a[k] || 0) + 1;
            return a;
          }, {});
          const steps = arr.filter((e) => e.carousel && e.stepAgo != null);
          const busy = arr.filter((e) => e.navBusy).length, moved = arr.filter((e) => e.labelMoved).length;
          const reloads = arr.filter((e) => e.navType === "reload").length, disc = arr.filter((e) => e.wasDisc).length;
          L.push("\u0432\u043A\u043B\u0430\u0434\u043A\u0430 " + tab.slice(-4) + (arr.some((e) => e.carousel) ? " (\u043F\u0443\u043B\u044C\u0442)" : "") + ": \u043F\u0438\u043D\u0433\u043E\u0432 " + arr.length + ", \u043F\u0440\u043E\u0432\u0430\u043B\u043E\u0432>7\u043C\u0438\u043D " + gaps + (maxGap ? " (\u043C\u0430\u043A\u0441 " + Math.round(maxGap / 6e4) + " \u043C\u0438\u043D, " + fmt(gapAt) + ")" : ""));
          L.push("   keepalive: " + Object.entries(ka).map(([k, v]) => k + "\xD7" + v).join(", ") + " | reload " + reloads + " | \u0432\u044B\u0433\u0440\u0443\u0436\u0430\u043B\u0438 " + disc);
          if (steps.length) L.push("   \u0448\u0430\u0433 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u0438: \u043C\u0430\u043A\u0441 " + steps.reduce((m, e) => Math.max(m, e.stepAgo), 0) + " \u043C\u0438\u043D, \u043F\u0438\u043D\u0433\u043E\u0432 \u0441\u043E \u0441\u0442\u043E\u044F\u0449\u0438\u043C \u0448\u0430\u0433\u043E\u043C " + steps.filter((e) => e.stepAgo > 5).length + " \u0438\u0437 " + steps.length);
          L.push("   \u043C\u044C\u044E\u0442\u0435\u043A\u0441 \u0437\u0430\u043D\u044F\u0442: " + busy + " | \u0441\u0442\u0440\u043E\u043A\u0443 \u043F\u0435\u0440\u0435\u0440\u0438\u0441\u043E\u0432\u044B\u0432\u0430\u043B\u0438: " + Math.round(moved / arr.length * 100) + "% \u043F\u0438\u043D\u0433\u043E\u0432");
        }
        const codes = buf.reduce((a, e) => {
          const k = e.c + (e.code ? "/" + e.code : "");
          a[k] = (a[k] || 0) + (e.n || 1);
          return a;
        }, {});
        L.push("\u0431\u0430\u0433\u0440\u0435\u043F\u043E\u0440\u0442\u044B \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u0438: " + (Object.keys(codes).length ? Object.entries(codes).map(([k, v]) => k + "\xD7" + v).join(", ") : "\u043F\u0443\u0441\u0442\u043E") + " (\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 " + (st.bugReportEnabled === true ? "\u0432\u043A\u043B\u044E\u0447\u0435\u043D\u0430" : "\u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D\u0430") + ")");
        const text = L.join("\n");
        console.log(text);
        resolve(text);
      });
    });
  };
  let _healthWatchTimer = null, _healthWatchUntil = 0, _healthWatchLast = 0;
  const HEALTH_WATCH_MS = 15e3;
  window.__faiHealthWatch = function(min) {
    if (min == null) {
      chrome.storage.local.get("fansly_ai_health_watch", (d) => {
        const log = d.fansly_ai_health_watch || [];
        console.table(log.map((e) => ({ \u0432\u0440\u0435\u043C\u044F: new Date(e.ts).toLocaleTimeString(), \u0444\u0430\u043A\u0442_\u0441: Math.round(e.actual / 1e3), \u0434\u0440\u0435\u0439\u0444_\u0441: Math.round(e.drift / 1e3), \u0432\u043A\u043B\u0430\u0434\u043A\u0430: e.vis, \u0444\u043E\u043A\u0443\u0441: e.focus, keepalive: e.ka })));
        const frozen = log.filter((e) => e.drift > 5e3);
        console.warn(frozen.length ? `[FanslyAI] \u0442\u0438\u043A\u043E\u0432 \u0441 \u0434\u0440\u0435\u0439\u0444\u043E\u043C >5\u0441: ${frozen.length} \u0438\u0437 ${log.length} \u2014 \u0442\u0430\u0439\u043C\u0435\u0440\u044B \u0442\u0440\u043E\u0442\u0442\u043B\u0438\u043B\u0438\u0441\u044C/\u0437\u0430\u043C\u0438\u0440\u0430\u043B\u0438` : `[FanslyAI] \u0434\u0440\u0435\u0439\u0444 \u0440\u043E\u0432\u043D\u044B\u0439 (${log.length} \u0442\u0438\u043A\u043E\u0432) \u2014 \u0442\u0430\u0439\u043C\u0435\u0440\u044B \u043D\u0435 \u0442\u0440\u043E\u0442\u0442\u043B\u0438\u043B\u0438\u0441\u044C`);
      });
      return;
    }
    clearInterval(_healthWatchTimer);
    _healthWatchUntil = Date.now() + min * 6e4;
    _healthWatchLast = Date.now();
    chrome.storage.local.set({ fansly_ai_health_watch: [] });
    console.log(`[FanslyAI] \u{1FA7A} \u0437\u0430\u043C\u0435\u0440 \u043D\u0430 ${min} \u043C\u0438\u043D \u043F\u043E\u0448\u0451\u043B. \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u0443\u0439 \u044D\u043A\u0440\u0430\u043D / \u0441\u0432\u0435\u0440\u043D\u0438 / \u043E\u0442\u043A\u043B\u044E\u0447\u0438 RDP, \u043F\u043E\u0442\u043E\u043C \u0432\u0435\u0440\u043D\u0438\u0441\u044C \u0438 \u0432\u044B\u0437\u043E\u0432\u0438 __faiHealthWatch()`);
    _healthWatchTimer = setInterval(() => {
      const now = Date.now();
      const actual = now - _healthWatchLast;
      _healthWatchLast = now;
      const entry = { ts: now, actual, drift: actual - HEALTH_WATCH_MS, vis: document.visibilityState, focus: document.hasFocus(), ka: typeof _keepAliveCtx !== "undefined" && _keepAliveCtx ? _keepAliveCtx.state : "off" };
      chrome.storage.local.get("fansly_ai_health_watch", (d) => {
        const log = d.fansly_ai_health_watch || [];
        log.push(entry);
        if (log.length > 600) log.splice(0, log.length - 600);
        chrome.storage.local.set({ fansly_ai_health_watch: log });
      });
      if (now >= _healthWatchUntil) {
        clearInterval(_healthWatchTimer);
        _healthWatchTimer = null;
        console.log("[FanslyAI] \u{1FA7A} \u0437\u0430\u043C\u0435\u0440 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D \u2014 __faiHealthWatch() \u043F\u043E\u043A\u0430\u0436\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
      }
    }, HEALTH_WATCH_MS);
  };
  function processMessageNode(node) {
    if (state.processedNodes.has(node)) return;
    state.processedNodes.add(node);
    const isOwn = PLAT.isOwn(node);
    const role = isOwn ? "model" : "subscriber";
    const hasMedia = bodyMediaEl(node);
    const text = getMessageText(node);
    if (!text && !hasMedia) return;
    const freshTs = PLAT.timeOf(node);
    if (freshTs) state._lastDomTs = freshTs;
    const timestampReliable = freshTs != null;
    const timestamp = freshTs != null ? freshTs : state._lastDomTs || Date.now();
    const isScrollLoaded = state.historyScrolling || timestampReliable && timestamp < state.activatedAt;
    if (isScrollLoaded) return;
    const entry = {
      role,
      text: text || "",
      isMedia: !!hasMedia && !text,
      mediaType: hasMedia ? detectMediaType(node) : null,
      mediaLocked: hasMedia ? detectMediaLocked(node) : false,
      mediaPaid: hasMedia ? detectPaidState(node) : null,
      // своё платное: выкуплено/нет/бесплатно (см. detectPaidState)
      timestamp,
      ts: Date.now()
      // живое сообщение приходит сейчас → реальная дата = now (для метки разрыва)
    };
    state.chatHistory.push(entry);
    updateStats();
    const msgEl = appendMessageToHistory(entry);
    if (role === "subscriber" && text && state.active) {
      translateMsgForDisplay(text, msgEl, inGenders(), trContextFor(entry));
    } else if (role === "subscriber" && entry.isMedia && state.active) {
    } else if (role === "model" && text) {
      translateMsgForDisplay(text, msgEl, outGenders());
    }
  }
  function ensureHistoryForCurrent() {
    if (state._histFor === state.currentContactId) return;
    loadExistingMessages();
  }
  function loadExistingMessages() {
    state._histFor = state.currentContactId;
    if (PLATFORM === "onlyfans") return ONLYFANS.loadHistory();
    state.translateQueue = [];
    _transPending.clear();
    state.chatHistory = [];
    state.processedNodes = /* @__PURE__ */ new WeakSet();
    state._mirrorLiveCount = 0;
    state._mirrorLiveAt = 0;
    const historyEl = document.getElementById("fai-chat-history");
    if (historyEl) historyEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.loading">${t("panel.history.loading", state.uiLang)}</div>`;
    let curTs = null;
    const sel = selJoin("messageNode", "messageTimestamp");
    if (sel) document.querySelectorAll(sel).forEach((node) => {
      if (qm("messageTimestamp", node)) {
        if (!node.closest(selStr("messageNode"))) {
          const t2 = parseFanslyTs(node.textContent);
          if (t2) curTs = t2;
        }
        return;
      }
      if (state.processedNodes.has(node)) return;
      state.processedNodes.add(node);
      const isOwn = PLAT.isOwn(node);
      const role = isOwn ? "model" : "subscriber";
      const hasMedia = bodyMediaEl(node);
      const text = getMessageText(node);
      if (!text && !hasMedia) return;
      const entry = {
        role,
        text: text || "",
        isMedia: !!hasMedia && !text,
        mediaType: hasMedia ? detectMediaType(node) : null,
        mediaLocked: hasMedia ? detectMediaLocked(node) : false,
        // за пейволом? → для метки в ТГ
        mediaPaid: hasMedia ? detectPaidState(node) : null,
        // своё платное: выкуплено/нет/бесплатно (см. detectPaidState)
        timestamp: PLAT.timeOf(node) || curTs || Date.now(),
        // реальное время сообщения (панель рисует его); timeOf per-узел обходит off-by-one carry-forward
        ts: curTs
        // реальная дата сообщения → метка разрыва в промпте (NB: при возобновлении после паузы)
        // #2
      };
      state.chatHistory.push(entry);
      const msgEl = appendMessageToHistory(entry);
      if (text && msgEl) translateMsgForDisplay(text, msgEl, role === "model" ? outGenders() : inGenders());
    });
    updateStats();
    scrollHistoryToBottom();
    console.log(`[FanslyAI] Loaded ${state.chatHistory.length} messages`);
  }
  function ensureDomObserver() {
    if (PLATFORM === "onlyfans") return;
    if (!isExtensionAlive() || !PLAT.isMessagesPage()) return;
    const cur = q("messageContent");
    if (!cur) return;
    const t2 = state._obsTarget;
    if (state.observer && t2 && t2.isConnected && t2 === cur) return;
    console.log("[FanslyAI] \u{1FA9E} observer \u043C\u0451\u0440\u0442\u0432/\u043D\u0430 \u0447\u0443\u0436\u043E\u0439 \u043B\u0435\u043D\u0442\u0435 \u2192 \u043F\u0435\u0440\u0435\u0432\u0435\u0448\u0438\u0432\u0430\u044E | obs=" + !!state.observer + " connected=" + (t2 ? t2.isConnected : "\u2014") + " same=" + (t2 === cur) + " \u043B\u0435\u043D\u0442 \u0432 DOM=" + qa("messageContent").length);
    startDomObserver(cur);
  }
  function startDomObserver(container) {
    if (state.observer) state.observer.disconnect();
    state._obsTarget = container;
    if (!state._obsWatchTimer) state._obsWatchTimer = setInterval(ensureDomObserver, 25e3);
    if (PLATFORM === "onlyfans") {
      state.observer = new MutationObserver(() => {
        clearTimeout(state._ofSyncTimer);
        state._ofSyncTimer = setTimeout(() => ONLYFANS.loadHistory(), 500);
      });
      state.observer.observe(container, { childList: true, subtree: true });
      return;
    }
    state.observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (PLAT.isMessageNode(node)) processMessageNode(node);
          qa("messageNode", node).forEach((n) => processMessageNode(n));
        });
      });
    });
    state.observer.observe(container, { childList: true, subtree: true });
    if (container._faiScrollBound) return;
    container._faiScrollBound = true;
    container.addEventListener("scroll", () => {
      if (container.scrollTop < 400) {
        state.historyScrolling = true;
        clearTimeout(state._scrollTimer);
        state._scrollTimer = setTimeout(() => {
          state.historyScrolling = false;
          renderWindowFromDom();
        }, 1200);
      }
    }, { passive: true });
  }
  function renderWindowFromDom() {
    const historyEl = document.getElementById("fai-chat-history");
    if (!historyEl) return;
    historyEl.innerHTML = "";
    qa("messageNode").forEach((node) => {
      const isOwn = PLAT.isOwn(node);
      const role = isOwn ? "model" : "subscriber";
      const hasMedia = bodyMediaEl(node);
      const text = getMessageText(node);
      if (!text && !hasMedia) return;
      const entry = {
        role,
        text: text || "",
        isMedia: !!hasMedia && !text,
        mediaType: hasMedia ? detectMediaType(node) : null,
        timestamp: PLAT.timeOf(node) || Date.now()
        // реальное время сообщения (панель рисует его), не время перерисовки
      };
      const msgEl = appendMessageToHistory(entry);
      if (text && msgEl) translateMsgForDisplay(text, msgEl, role === "model" ? outGenders() : inGenders());
    });
  }
  function detectContact() {
    if (PLATFORM === "onlyfans") return ONLYFANS.detectContact();
    state.currentContactId = extractContactIdFromUrl();
    if (state.contactData && state._dataFor && state.currentContactId && state._dataFor !== "fai_contact_" + state.currentContactId) {
      console.log("[FanslyAI] contactData \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u0447\u0430\u0442\u0443 (" + state._dataFor + ") \u2192 \u0441\u0431\u0440\u043E\u0441 \u0434\u043E \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u043D\u043E\u0432\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438");
      state.contactData = null;
      state._dataFor = null;
    }
    const header = q("contactHeader");
    if (header) {
      const { name, unresolved } = chatNameFrom(header);
      state.currentContact = name;
      state._nameUnresolved = unresolved;
    }
  }
  async function resolveNamePoll() {
    if (PLATFORM !== "fansly") return;
    const id0 = state.currentContactId;
    const header = q("contactHeader");
    if (!header) return;
    const readName = () => {
      const el = q("displayName", header);
      return cleanContactName(el ? el.textContent : "");
    };
    let resolved = null;
    for (let i = 0; i < 12; i++) {
      const nm = readName();
      if (nm && !/^unknown/i.test(nm) && !/…|\.\.\./.test(nm)) {
        resolved = nm;
        break;
      }
      if (!state._nameUnresolved) return;
      await sleep(500);
    }
    if (state.currentContactId !== id0) return;
    if (!state.contactData) return;
    if (resolved) {
      state.currentContact = resolved;
      state._nameUnresolved = false;
      const upd = { name: resolved, nameResolved: true };
      if (state.contactData.unknownConfirmed || state.contactData.unknownSeen) {
        upd.unknownConfirmed = false;
        upd.unknownSeen = 0;
      }
      Object.assign(state.contactData, upd);
      saveContact(state.currentContact, upd);
      updatePanelContact();
    } else if (state._nameUnresolved) {
      const seen = (state.contactData.unknownSeen || 0) + 1;
      const upd = { unknownSeen: seen, unknownLast: Date.now() };
      if (seen >= 2) upd.unknownConfirmed = true;
      Object.assign(state.contactData, upd);
      saveContact(state.currentContact, upd);
    }
  }
  function onContactChange() {
    if (state.contactTimer) clearTimeout(state.contactTimer);
    state.contactTimer = setTimeout(() => {
      detectContact();
      clearTimeout(state._dossierDeltaTimer);
      state.historyScrolling = false;
      clearTimeout(state._scrollTimer);
      if (carousel.running) return;
      if (state.observer) {
        state.observer.disconnect();
        state.observer = null;
      }
      const panel = document.getElementById("fansly-ai-panel");
      const panelVisible = panel && panel.style.display !== "none";
      if (panelVisible) {
        activateForContact();
      } else {
        state.active = false;
        state.contactData = null;
        state._crm = null;
        state._crmHandle = null;
        if (panel) {
          updatePanelContact();
          const title = document.querySelector(".fai-title");
          if (title) title.textContent = "\u{1F916}";
          const historyEl = document.getElementById("fai-chat-history");
          if (historyEl) historyEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.clickToActivate">${t("panel.history.clickToActivate", state.uiLang)}</div>`;
          state.chatHistory = [];
          state._histFor = null;
          state.translateQueue = [];
          updateStats();
        }
      }
    }, CONFIG.CONTACT_DELAY);
  }
  function normColor(c) {
    if (!c) return "";
    c = c.trim().toLowerCase();
    const hex = c.match(/^#([0-9a-f]{6})$/i);
    if (hex) {
      const n = parseInt(hex[1], 16);
      return `rgb(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255})`;
    }
    return c.replace(/\s+/g, " ").replace(/,(?=\S)/g, ", ");
  }
  function subTitleKey(isSub) {
    if (BUILD === "full") return isSub ? "panel.sub.title.autoOn" : "panel.sub.title.autoOff";
    return isSub ? "panel.sub.title.on" : "panel.sub.title.off";
  }
  function tierNameByColor(color) {
    if (!color || !state.tiers?.length) return null;
    const want = normColor(color);
    const hit = state.tiers.find((t2) => t2.color && normColor(t2.color) === want);
    return hit ? hit.name : null;
  }
  function applyFanStatusFromHeader() {
    if (PLATFORM === "onlyfans") return ONLYFANS.applyFanStatus();
    const head = q("contactHeader");
    if (!head || !state.contactData || !state.currentContact) return;
    const star = head.querySelector("i.fa-star");
    const tierColor = star ? star.closest(".user-icon")?.style?.color || null : null;
    const upd = {};
    if (star) {
      if (!state.contactData.isSubscribed) upd.isSubscribed = true;
      const tn = tierNameByColor(tierColor);
      if (tierColor && tierColor !== state.contactData.tierColor) upd.tierColor = tierColor;
      if (tn && tn !== state.contactData.tierName) upd.tierName = tn;
    }
    const _headerReady = !!(q("displayName", head)?.textContent || "").trim();
    const _cardIcon = !!head.querySelector("i.fa-credit-card");
    if (_cardIcon && !state.contactData.hasCard) upd.hasCard = true;
    else if (!_cardIcon && _headerReady && state.contactData.hasCard) upd.hasCard = false;
    if (head.querySelector("i.fa-arrow-rotate-right") && !state.contactData.autoRenew) upd.autoRenew = true;
    if (head.querySelector("i.fa-badge") && !state.contactData.isCreator) upd.isCreator = true;
    if (Object.keys(upd).length) {
      Object.assign(state.contactData, upd);
      saveContact(state.currentContact, upd);
      console.log("[FanslyAI] \u0421\u0442\u0430\u0442\u0443\u0441\u044B \u0438\u0437 \u0448\u0430\u043F\u043A\u0438:", JSON.stringify(upd));
    }
    const subBtn = document.getElementById("fai-subscribed");
    if (subBtn && state.contactData.isSubscribed) {
      subBtn.textContent = "\u2B50";
      subBtn.title = t(subTitleKey(true), state.uiLang);
    }
    const tierEl = document.getElementById("fai-tier");
    if (tierEl) {
      const tn = state.contactData.tierName;
      tierEl.textContent = tn ? tn.slice(0, 12) : "";
      tierEl.title = tn ? t("panel.tier.title", state.uiLang, { tier: tn }) + (state.contactData.hasCard ? t("panel.tier.cardSuffix", state.uiLang) : "") : "";
    }
  }
  const ensureConsent = () => {
    try {
      FaiConsent.ask();
    } catch (e) {
    }
  };
  function activateForContact(nameHint = null, idHint = null) {
    state.active = true;
    ensureConsent();
    if (idHint) state.currentContactId = idHint;
    detectContact();
    if (!state.currentContact && nameHint) {
      state.currentContact = nameHint;
    }
    state.contactData = null;
    state._dataFor = null;
    state.chatHistory = [];
    state._histFor = null;
    const _histEl = document.getElementById("fai-chat-history");
    if (_histEl) _histEl.innerHTML = `<div class="fai-empty-history" data-i18n="panel.history.loading">${t("panel.history.loading", state.uiLang)}</div>`;
    clearTimeout(state._dossierDeltaTimer);
    state.activatedAt = Date.now();
    state.suppressUntil = Date.now() + 4500;
    const ident = headerIdentity(state.currentContactId);
    const handle = ident.handle;
    if (ident.trusted && ident.name) state.currentContact = ident.name;
    else if (!ident.trusted && nameHint) state.currentContact = nameHint;
    if (!ident.trusted) console.log("[FanslyAI] \u043D\u0438\u043A \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D id \u2014 \u0432 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u043D\u0435 \u043F\u0438\u0448\u0443 (#180)");
    createPanel();
    updatePanelContact();
    clearSendFailed();
    const _idAtLoad = state.currentContactId;
    loadContact(state.currentContact, handle).then((contact) => {
      if (state.currentContactId !== _idAtLoad) {
        console.log("[FanslyAI] \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \u0441\u043C\u0435\u043D\u0438\u043B\u0441\u044F, \u043F\u043E\u043A\u0430 \u0433\u0440\u0443\u0437\u0438\u043B\u0430\u0441\u044C \u0437\u0430\u043F\u0438\u0441\u044C \u2014 \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u044E");
        return;
      }
      if (contact.note && contact.note.trim()) {
        if (!contact.dossier) {
          contact.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
        }
        const note = contact.note.trim();
        if (!contact.dossier.manualFacts) contact.dossier.manualFacts = [];
        if (!contact.dossier.facts.includes(note)) {
          contact.dossier.facts.unshift(note);
          if (contact.dossier.manualFacts.length < PINNED_MAX && !contact.dossier.manualFacts.includes(note)) contact.dossier.manualFacts.push(note);
          contact.note = "";
          saveContact(state.currentContact, { note: "", dossier: contact.dossier });
        }
      }
      const updates = {};
      if (handle && contact.handle !== handle) {
        updates.handle = handle;
      }
      const newName = state.currentContact;
      if (state._nameUnresolved || !ident.trusted || !healthyName(newName)) {
      } else if (contact.name && !healthyName(contact.name) && contact.name !== newName) {
        updates.name = newName;
        if (Array.isArray(contact.nameHistory) && contact.nameHistory.some((h) => !healthyName(h))) updates.nameHistory = contact.nameHistory.filter(healthyName);
        console.log(`[FanslyAI] \u0438\u043C\u044F \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u043E\u0447\u0438\u043D\u0435\u043D\u043E: "${contact.name}" \u2192 "${newName}" (\u043E\u0431\u0440\u0435\u0437\u043A\u0430/Unknown, \u043D\u0435 \u0441\u043C\u0435\u043D\u0430 \u043D\u0438\u043A\u0430)`);
      } else if (newName && contact.name && contact.name !== newName) {
        const history = contact.nameHistory || [];
        if (!history.includes(contact.name)) history.push(contact.name);
        updates.nameHistory = history;
        updates.name = newName;
        const handleStr = handle ? ` (@${handle})` : "";
        setStatus(t("panel.status.nickChanged", state.uiLang, { old: contact.name, new: newName, handle: handleStr }));
        console.log(`[FanslyAI] Nick changed: "${contact.name}" \u2192 "${newName}"${handleStr}`);
      } else if (newName && !contact.name) {
        updates.name = newName;
      }
      if (Object.keys(updates).length) {
        Object.assign(contact, updates);
        saveContact(state.currentContact, updates);
      }
      state.fanGender = contact.gender || "male";
      state.contactData = contact;
      state._dataFor = keyOfCurrent();
      updateGenderBtn();
      const subBtn = document.getElementById("fai-subscribed");
      if (subBtn) subBtn.textContent = contact.isSubscribed ? "\u2B50" : "\u2606";
      if (subBtn) subBtn.title = t(subTitleKey(contact.isSubscribed), state.uiLang);
      const langBtn = document.getElementById("fai-fan-lang");
      if (langBtn) langBtn.textContent = (contact.lang || "en").toUpperCase();
      updatePanelContact();
      renderDossier();
      resolveNamePoll();
      setTimeout(applyFanStatusFromHeader, 2500);
    });
    sendSafe({ type: "GET_SETTINGS" }).then((r) => {
      if (r?.result) {
        state.nativeLang = r.result.nativeLanguage || "ru";
      }
    });
    const title = document.querySelector(".fai-title");
    if (title) title.textContent = "\u{1F916}\u25CF";
    const _attachFeed = (ms) => waitForElement(selStr("messageContent"), ms).then((container) => {
      startDomObserver(container);
      setTimeout(() => loadExistingMessages(), 1500);
    });
    _attachFeed(8e3).catch(() => _attachFeed(15e3)).catch(() => {
      console.warn("[FanslyAI] \u043B\u0435\u043D\u0442\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043D\u0435 \u043F\u043E\u044F\u0432\u0438\u043B\u0430\u0441\u044C \u2014 \u0438\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0443\u0441\u0442\u0430 (\u0447\u0443\u0436\u0430\u044F \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0430 \u0432 \u0418\u0418 \u043D\u0435 \u0443\u0439\u0434\u0451\u0442)");
      state.chatHistory = [];
      state._histFor = state.currentContactId;
    });
  }
  function watchContactChanges() {
    let lastUrl = location.href;
    new MutationObserver(() => {
      if (location.href === lastUrl) return;
      lastUrl = location.href;
      onContactChange();
    }).observe(document, { subtree: true, childList: true });
  }
  function injectActivationButtons() {
    const contacts = qa("contactLink");
    contacts.forEach((contactEl) => {
      if (contactEl.querySelector(".fai-activate-btn")) return;
      const nameEl = q("displayName", contactEl);
      if (!nameEl) return;
      const btn = document.createElement("span");
      btn.className = "fai-activate-btn";
      btn.textContent = "\u{1F7E3}";
      btn.title = t("panel.activate.title", state.uiLang);
      btn.style.cssText = "pointer-events: auto !important; cursor: pointer !important;";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        state._panelShown = true;
        persistSetting("panelHidden", false);
        const panel = document.getElementById("fansly-ai-panel");
        if (panel) {
          panel.style.display = "";
          panel.classList.remove("collapsed");
          const colBtn = document.getElementById("fai-collapse-btn");
          if (colBtn) colBtn.textContent = "\u25B2";
        }
        let nameFromBtn = chatNameFrom(contactEl).name;
        if (PLATFORM === "onlyfans") nameFromBtn = cleanContactName(nameEl.innerText) || null;
        const idFromHref = PLAT.contactIdFromHref(contactEl.getAttribute("href"));
        contactEl.click();
        setTimeout(() => activateForContact(nameFromBtn, idFromHref), CONFIG.CONTACT_DELAY + 200);
      });
      nameEl.parentNode.insertBefore(btn, nameEl.nextSibling);
    });
  }
  function watchContactList() {
    const tryAttach = () => {
      const listEl = q("contactList");
      if (!listEl) {
        setTimeout(tryAttach, 1e3);
        return;
      }
      injectActivationButtons();
      new MutationObserver(() => injectActivationButtons()).observe(listEl, { childList: true, subtree: true });
    };
    tryAttach();
  }
  try {
    window.__faiScan = scanUnread2;
  } catch (e) {
  }
  window.__faiDossierAudit = function(opts) {
    opts = opts || {};
    chrome.storage.local.get(null, (all) => {
      const contacts = [];
      for (const k in all) {
        if (!k.startsWith("fai_contact_")) continue;
        const c = all[k];
        if (!c || !c.dossier || !Array.isArray(c.dossier.facts) || !c.dossier.facts.length) continue;
        contacts.push({ key: k, data: c, name: c.name || c.handle || k, handle: c.handle || "", facts: c.dossier.facts });
      }
      const norm = (f) => String(f).trim().replace(/\s+/g, " ").toLowerCase();
      const byFact = /* @__PURE__ */ new Map();
      for (const c of contacts) for (const f of c.facts) {
        const n = norm(f);
        if (!n) continue;
        if (!byFact.has(n)) byFact.set(n, []);
        if (!byFact.get(n).includes(c)) byFact.get(n).push(c);
      }
      const shared = [], pairCount = /* @__PURE__ */ new Map();
      for (const [f, cs] of byFact) {
        if (cs.length < 2) continue;
        shared.push({ "\u0444\u0430\u043A\u0442": f.slice(0, 80), "\u0443 \u043A\u043E\u0433\u043E": cs.map((c) => c.name).join(" | ") });
        for (let i = 0; i < cs.length; i++) for (let j = i + 1; j < cs.length; j++) {
          const pk = [cs[i].name, cs[j].name].sort().join(" \u21C4 ");
          pairCount.set(pk, (pairCount.get(pk) || 0) + 1);
        }
      }
      console.log("[FanslyAI] \u{1F9EC} \u0430\u0443\u0434\u0438\u0442 \u0434\u043E\u0441\u044C\u0435: \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043E\u0432 \u0441 \u0444\u0430\u043A\u0442\u0430\u043C\u0438 " + contacts.length + ", \u043E\u0431\u0449\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0432 " + shared.length);
      if (shared.length) {
        console.table(shared);
        console.table([...pairCount.entries()].sort((a, b) => b[1] - a[1]).map(([p, n]) => ({ "\u043F\u0430\u0440\u0430": p, "\u043E\u0431\u0449\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0432": n })));
        console.log('[FanslyAI] \u{1F9EC} \u0441\u0435\u0440\u0438\u044F \u043E\u0431\u0449\u0438\u0445 \u0444\u0430\u043A\u0442\u043E\u0432 \u0443 \u043F\u0430\u0440\u044B = \u043F\u043E\u0447\u0442\u0438 \u043D\u0430\u0432\u0435\u0440\u043D\u044F\u043A\u0430 \u0437\u0430\u0440\u0430\u0436\u0435\u043D\u0438\u0435. \u0427\u0438\u0441\u0442\u043A\u0430: __faiDossierAudit({ removeSharedFrom: "\u0438\u043C\u044F \u0438\u043B\u0438 handle" })');
      } else {
        console.log("[FanslyAI] \u{1F9EC} \u0434\u043E\u0441\u043B\u043E\u0432\u043D\u044B\u0445 \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u0439 \u0444\u0430\u043A\u0442\u043E\u0432 \u043C\u0435\u0436\u0434\u0443 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430\u043C\u0438 \u043D\u0435\u0442");
      }
      if (opts.removeSharedFrom) {
        const q2 = String(opts.removeSharedFrom).trim().toLowerCase();
        const target = contacts.find((c) => c.name.toLowerCase() === q2 || c.handle.toLowerCase() === q2);
        if (!target) {
          console.warn("[FanslyAI] \u{1F9EC} \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \xAB" + opts.removeSharedFrom + "\xBB \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D (\u0438\u0449\u0443 \u043F\u043E \u0442\u043E\u0447\u043D\u043E\u043C\u0443 \u0438\u043C\u0435\u043D\u0438 \u0438\u043B\u0438 handle)");
          return;
        }
        const foreign = /* @__PURE__ */ new Set();
        for (const [f, cs] of byFact) if (cs.length > 1 && cs.includes(target)) foreign.add(f);
        const keep = [], removed = [];
        for (const f of target.facts) (foreign.has(norm(f)) ? removed : keep).push(f);
        if (!removed.length) {
          console.log("[FanslyAI] \u{1F9EC} \u0443 \xAB" + target.name + "\xBB \u043D\u0435\u0442 \u0444\u0430\u043A\u0442\u043E\u0432, \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0449\u0438\u0445 \u0441 \u0447\u0443\u0436\u0438\u043C\u0438 \u2014 \u0443\u0434\u0430\u043B\u044F\u0442\u044C \u043D\u0435\u0447\u0435\u0433\u043E");
          return;
        }
        target.data.dossier.facts = keep;
        if (target.data.dossier.factDates) for (const f of removed) delete target.data.dossier.factDates[f];
        if (target.data.dossier.manualFacts) target.data.dossier.manualFacts = target.data.dossier.manualFacts.filter((f) => !removed.includes(f));
        chrome.storage.local.set({ [target.key]: target.data }, () => {
          console.log("[FanslyAI] \u{1F9EC} \u0443 \xAB" + target.name + "\xBB \u0443\u0434\u0430\u043B\u0435\u043D\u043E \u0444\u0430\u043A\u0442\u043E\u0432: " + removed.length + " (\u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C " + keep.length + ")");
          removed.forEach((f) => console.log("   \u2212 " + f));
        });
      }
    });
  };
  window.__faiDiagnose = function() {
    const b = document.getElementById("fai-diagnose-btn");
    if (!b) {
      console.warn("[FanslyAI] \u{1F52C} \u043A\u043D\u043E\u043F\u043A\u0430 \u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0438 \u0435\u0441\u0442\u044C \u0442\u043E\u043B\u044C\u043A\u043E \u0432 full-\u0441\u0431\u043E\u0440\u043A\u0435");
      return;
    }
    console.log("[FanslyAI] \u{1F52C} \u0431\u0438\u0441\u0435\u043A\u0442 \u0446\u0435\u043D\u0437\u0443\u0440\u044B Gemini \u043F\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u043C\u0443 \u0447\u0430\u0442\u0443 \u2014 \u043D\u0443\u0436\u0435\u043D \u0441\u0432\u043E\u0439 Gemini-\u043A\u043B\u044E\u0447 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043D\u0438\u0436\u0435 \u0438 \u0432 \u0441\u0442\u0430\u0442\u0443\u0441\u0435 \u043F\u0430\u043D\u0435\u043B\u0438");
    b.click();
  };
  window.__faiPanelRev = function() {
    const panel = document.getElementById("fansly-ai-panel");
    const onScreen = panel ? panel.dataset.faiRev || "(\u043D\u0435\u0442 \u043C\u0435\u0442\u043A\u0438 \u2014 \u043F\u0430\u043D\u0435\u043B\u044C \u043E\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0431\u043E\u0440\u043A\u0438)" : "(\u043F\u0430\u043D\u0435\u043B\u0438 \u043D\u0435\u0442 \u0432 DOM)";
    console.log("[FanslyAI] \u0440\u0435\u0432\u0438\u0437\u0438\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0438 \u043F\u0430\u043D\u0435\u043B\u0438: \u0432 \u043A\u043E\u0434\u0435 " + PANEL_REV + " | \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 " + onScreen);
    if (panel && panel.dataset.faiRev !== PANEL_REV) console.warn("[FanslyAI] \u26A0\uFE0F \u0440\u0430\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u2014 \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5), \u0438\u043D\u0430\u0447\u0435 \u043F\u0440\u0430\u0432\u043E\u043A \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0438 \u043D\u0435 \u0443\u0432\u0438\u0434\u0438\u0448\u044C");
    else if (panel) console.log("[FanslyAI] \u2705 \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430");
  };
  window.__faiHelp = function() {
    const fns = [
      ["__faiHelp()", "\u044D\u0442\u0430 \u0441\u043F\u0440\u0430\u0432\u043A\u0430"],
      ["__faiPanelRev()", "\u0440\u0435\u0432\u0438\u0437\u0438\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0438 \u043F\u0430\u043D\u0435\u043B\u0438: \u0432 \u043A\u043E\u0434\u0435 vs \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 (\u0440\u0430\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435 = \u043D\u0443\u0436\u0435\u043D F5, \u043F\u0440\u0430\u0432\u043A\u0438 \u043D\u0435 \u0432\u0438\u0434\u043D\u044B)"]
    ];
    fns.push(
      ["__faiSel()", "\u0440\u0435\u0435\u0441\u0442\u0440 DOM-\u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440\u043E\u0432: \u043A\u0430\u043A\u0438\u0435 \u043A\u043B\u044E\u0447\u0438 \u043D\u0430\u0448\u043B\u0438\u0441\u044C \u043D\u0430 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 (\u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \u0440\u0435\u0434\u0438\u0437\u0430\u0439\u043D\u0430 Fansly)"],
      ["__faiHealth()", "\u0445\u0430\u0440\u0442\u0431\u0438\u0442 \u0432\u043A\u043B\u0430\u0434\u043A\u0438: \u0440\u0430\u0437\u0440\u044B\u0432\u044B = \u0437\u0430\u043C\u043E\u0440\u043E\u0437\u043A\u0438/\u0443\u0441\u044B\u043F\u043B\u0435\u043D\u0438\u0435 (\u0434\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \xAB\u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0432\u0441\u0442\u0430\u043B\u0430\xBB)"],
      ["__faiHealthWatch(\u043C\u0438\u043D)", "\u0438\u043D\u0442\u0435\u043D\u0441\u0438\u0432\u043D\u044B\u0439 \u0437\u0430\u043C\u0435\u0440 \u0442\u0438\u043A\u043E\u0432 ~15\u0441: drift/\u0432\u0438\u0434\u0438\u043C\u043E\u0441\u0442\u044C/\u0444\u043E\u043A\u0443\u0441/keep-alive (\u043B\u043E\u043A \u044D\u043A\u0440\u0430\u043D\u0430, RDP)"],
      ["__faiMirrorLog(n)", '\u0436\u0443\u0440\u043D\u0430\u043B \u0440\u0435\u0448\u0435\u043D\u0438\u0439 \u0437\u0435\u0440\u043A\u0430\u043B\u0430 (\u043F\u0435\u0440\u0435\u0436\u0438\u0432\u0430\u0435\u0442 F5): \u043F\u0443\u0442\u044C \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0431\u043B\u043E\u043A\u0430, \u0441\u0442\u0440\u043E\u043A\u0438 \u0434\u043E \u0438 \u043F\u043E\u0441\u043B\u0435 \u0434\u0435\u0434\u0443\u043F\u0430, \u0447\u044C\u0438, \u0441 \u043F\u043E\u043C\u0435\u0442\u043A\u043E\u0439 \xAB\u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E\xBB (#158); ("clear") \u2014 \u043E\u0447\u0438\u0441\u0442\u0438\u0442\u044C'],
      ["__faiReport()", "\u0442\u043E \u0436\u0435 \u043A\u043E\u043B\u044C\u0446\u043E \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u043C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u0441\u044B\u043B\u043A\u0438: \u043F\u0440\u043E\u0432\u0430\u043B\u044B, \u0441\u0442\u043E\u044F\u0449\u0438\u0439 \u0448\u0430\u0433, \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438, \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u0431\u0430\u0433\u0440\u0435\u043F\u043E\u0440\u0442\u043E\u0432"],
      ["__faiScan()", "\u0434\u0430\u043C\u043F \u0438\u043D\u0434\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043D\u0435\u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u043E \u0441\u0442\u0440\u043E\u043A\u0430\u043C \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u0438\u0430\u043B\u043E\u0433\u043E\u0432 (\u043A\u043E\u0433\u0434\u0430 \u0431\u0435\u0439\u0434\u0436\u0438 \xAB\u043D\u0435 \u0432\u0438\u0434\u044F\u0442\u0441\u044F\xBB)"],
      ["__faiDiagnose()", "\u0431\u0438\u0441\u0435\u043A\u0442 \u0446\u0435\u043D\u0437\u0443\u0440\u044B GEMINI \u043F\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u043C\u0443 \u0447\u0430\u0442\u0443 (\u043D\u0443\u0436\u0435\u043D \u0441\u0432\u043E\u0439 Gemini-\u043A\u043B\u044E\u0447; \u0434\u0440\u0443\u0433\u0438\u043C \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430\u043C \u0442\u0435\u0441\u0442 \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C)"],
      ["__faiDossierAudit()", "\u043F\u043E\u0438\u0441\u043A \u0437\u0430\u0440\u0430\u0436\u0435\u043D\u0438\u044F \u0434\u043E\u0441\u044C\u0435: \u0434\u043E\u0441\u043B\u043E\u0432\u043D\u043E \u043E\u0431\u0449\u0438\u0435 \u0444\u0430\u043A\u0442\u044B \u0443 \u0440\u0430\u0437\u043D\u044B\u0445 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043E\u0432 + \u043F\u0430\u0440\u044B"],
      ['__faiDossierAudit({removeSharedFrom:"\u043D\u0438\u043A"})', "\u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0443 \u0423\u041A\u0410\u0417\u0410\u041D\u041D\u041E\u0413\u041E \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430 \u0444\u0430\u043A\u0442\u044B, \u0434\u043E\u0441\u043B\u043E\u0432\u043D\u043E \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0443 \u0434\u0440\u0443\u0433\u0438\u0445"],
      ["__faiDumpHistory()", "\u0432\u044B\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u0447\u0430\u0442\u0430 \u0432 JSON \u0440\u043E\u0432\u043D\u043E \u0432 \u0442\u043E\u043C \u0432\u0438\u0434\u0435, \u0432 \u043A\u0430\u043A\u043E\u043C \u043E\u043D\u0430 \u0443\u0445\u043E\u0434\u0438\u0442 \u0432 \u0430\u043D\u0430\u043B\u0438\u0437 \u0434\u043E\u0441\u044C\u0435 (\u0434\u043B\u044F \u0441\u0442\u0435\u043D\u0434\u0430)"],
      ["__faiVaultFailNext()", "\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043E \u0441\u0431\u043E\u0435: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0437\u0430\u043F\u0443\u0441\u043A \u0441\u043A\u0430\u043D\u0430 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430 \u0443\u043F\u0430\u0434\u0451\u0442 \u043E\u0434\u0438\u043D \u0440\u0430\u0437 (\u0432 \u043B\u044E\u0431\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435)"],
      ["__faiTrFailNext()", "\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0431\u043E\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0433\u043E (\u043A\u043D\u043E\u043F\u043A\u0430 \u2191 \u043F\u0430\u043D\u0435\u043B\u0438 \u0438\u043B\u0438 \u043E\u0442\u0432\u0435\u0442 \u0438\u0437 \u0422\u0413) \u043D\u0435 \u0443\u0434\u0430\u0441\u0442\u0441\u044F \u043E\u0434\u0438\u043D \u0440\u0430\u0437"]
    );
    const rows = fns.filter(([sig]) => {
      const name = sig.split("(")[0];
      return typeof window[name] === "function";
    }).map(([sig, desc]) => ({ "\u0444\u0443\u043D\u043A\u0446\u0438\u044F": sig, "\u0447\u0442\u043E \u0434\u0435\u043B\u0430\u0435\u0442": desc }));
    console.log("[FanslyAI] \u043A\u043E\u043D\u0441\u043E\u043B\u044C\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 (DevTools \u2192 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \xABVelour for Fansly\xBB):");
    console.table(rows);
  };
  function scanUnread2() {
    const rows = [];
    qa("contactLink").forEach((el) => {
      const nameEl = q("displayName", el);
      const name = nameEl ? chatNameFrom(el).name : "(?)";
      const markers = [];
      el.querySelectorAll("*").forEach((node) => {
        const c = node.className?.toString?.() || "";
        if (/badge|count|unread|unseen|notif|dot|indicator|new|pill/i.test(c)) {
          markers.push(`${c.trim().slice(0, 40)}="${(node.innerText || "").trim().slice(0, 10)}"`);
        }
      });
      const fw = nameEl ? getComputedStyle(nameEl).fontWeight : "";
      const aria = el.getAttribute("aria-label") || "";
      const ownCls = (el.className + " " + (el.parentElement?.className || "")).trim().slice(0, 100);
      rows.push({ name, fontWeight: fw, aria: aria.slice(0, 40), markers: markers.join(" | ") || "\u2205", ownCls });
    });
    console.log("[FanslyAI] \u2500\u2500 \u0420\u0410\u0417\u0412\u0415\u0414\u041A\u0410 2.0 (" + rows.length + ") \u2500\u2500");
    console.table(rows);
    rows.forEach((r) => console.log(`  ${r.name}: fw=${r.fontWeight} | markers: ${r.markers}`));
    return rows;
  }
  const carousel = {
    running: false,
    processed: 0,
    settings: null,
    nextTimer: null,
    countdownTimer: null,
    lastHandledText: {},
    // id -> текст последнего обработанного входящего (защита от дубля)
    triedThisRound: /* @__PURE__ */ new Set(),
    // id, попробованные в текущем проходе (сброс при прогрессе/idle)
    excludedIds: /* @__PURE__ */ new Set(),
    // id контактов, исключённых из автоответа (личные диалоги)
    pushStreak: {},
    // id -> серия ходов подряд, где фан продавливал explicit (лестница увода/затухания, Блок 9)
    idleSec: 45,
    // интервал проверки в режиме ожидания
    navBusy: false,
    // мьютекс навигации: шаг карусели ИЛИ доставка ручного ответа из ТГ
    _lastStepAt: 0,
    // когда шаг карусели последний раз дошёл до работы (не просто был вызван) — для heartbeat
    _navTag: "",
    // кто держит мьютекс навигации (для лога сторожа)
    _navAt: 0,
    // когда захвачен
    _navTouch: 0,
    // когда владелец последний раз отчитался о работе (navTouch)
    _navGen: 0,
    // поколение захвата: снятый сторожем владелец своим release уже не сбивает чужой
    navGuardTimer: null,
    // сторож залипшего мьютекса
    relayQueue: [],
    // очередь ручных ответов из ТГ {fan,text,id} — доставляются по одному
    staleTimer: null,
    // сторож рассинхрона списка (конверт>0, а в списке непрочитанных нет → reload)
    staleSince: 0,
    // ts, когда рассинхрон впервые замечен (0 = нет)
    mirrorSince: 0,
    // отсечка «зеркалить активность от»: сдвигается на ts ручного включения пульта
    msgTs: {},
    // id чата -> ts последней УЧТЁННОЙ активности (водяной знак для детекта по message-time)
    _catchupNotified: false,
    // шапка «догоняю N диалогов» уже отправлена в текущем всплеске накопа
    rowSnap: {},
    // id -> последний снимок строки списка {preview,badge,paid,ts,name} (зеркало из превью, только память)
    rowMirrored: {},
    // id -> {badge, text}: бейдж и превью строки на момент последней доставки в ТГ без визита (строка / живое зеркало)
    lastRowPreview: {},
    // id -> превью строки на момент, когда её уже обработали (зеркало из строки, визит, живое зеркало): дрейф метки времени не показатель
    _rowObs: null,
    // MutationObserver списка чатов (лидер-вкладка, пока карусель работает)
    _rowObsTarget: null,
    _rowObsTimer: null,
    rowPending: /* @__PURE__ */ new Map(),
    // id|ключ -> ts: строка летит в ТГ из превью (очередь карусели и скан ленты её ждут)
    _rowGen: 0,
    // поколение наблюдателя: стоп/перевес обесценивает висящие отправки
    _rowRepeat: {},
    // id -> таймер проверки повтора того же текста (бейдж вырос, превью прежнее)
    _rowGrewAt: {},
    // id -> когда впервые увидели рост бейджа без смены текста (приход сообщения для дедупа)
    _rowSeenBadge: {},
    // id -> наибольший бейдж, увиденный при прежнем тексте (снимок в это время заморожен)
    rowResync: {},
    // id -> {badge, at}: бейдж упал до 0 при прежнем тексте снаружи (телефон/другое окно) → счётчик может вернуться по шагам
    _visitId: null,
    // чей чат мы сами сейчас открываем (визит/ответ из ТГ): его сброс бейджа — наш, не внешний
    _visitAt: 0
  };
  const extAlive = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  };
  function persistSetting(key, val) {
    if (!extAlive()) return;
    try {
      chrome.storage.local.get("fansly_ai_settings", (d) => {
        const s = d.fansly_ai_settings || {};
        s[key] = val;
        chrome.storage.local.set({ fansly_ai_settings: s });
      });
    } catch (e) {
    }
  }
  function persistSettings(obj) {
    if (!extAlive()) return;
    try {
      chrome.storage.local.get("fansly_ai_settings", (d) => {
        const s = d.fansly_ai_settings || {};
        Object.assign(s, obj);
        chrome.storage.local.set({ fansly_ai_settings: s });
      });
    } catch (e) {
    }
  }
  const aiWorks = (s) => !!(s.useProxy === true && s.licenseKey || s.geminiApiKey || s.groqApiKey || s.openrouterApiKey || s.claudeApiKey);
  const goodTranslate = (s) => !!(s.useProxy === true && s.licenseKey || s.deepLApiKey);
  const SUB_PAUSE_KEY = "fansly_sub_expired";
  const SUB_RENEW_KEY = "fansly_sub_renew";
  function subKeyFp(k) {
    let h = 5381;
    const s = String(k || "");
    for (let i = 0; i < s.length; i++) h = (h << 5) + h + s.charCodeAt(i) | 0;
    return (h >>> 0).toString(16);
  }
  let _subHintTimer = 0, _subPauseUntil = 0;
  function refreshSetupHintNow() {
    sendSafe({ type: "GET_SETTINGS" }).then((r) => {
      if (r?.result) refreshSetupHint(r.result);
    });
  }
  function refreshSetupHint(s) {
    const box = document.getElementById("fai-setup-hint");
    if (!box) return;
    const txt = document.getElementById("fai-setup-hint-text");
    const btn = document.getElementById("fai-setup-hint-btn");
    if (s.privacyDeclinedAt && !s.privacyConsentAt) {
      txt.textContent = t("panel.consent.declined", state.uiLang);
      btn.textContent = t("panel.consent.again", state.uiLang);
      box.style.display = "flex";
      btn.dataset.faiAction = "consent";
      wireHintBtn(btn);
      return;
    }
    const ai = BUILD === "store" ? true : aiWorks(s);
    const tr = goodTranslate(s);
    if (ai && tr) {
      const viaProxy = s.useProxy === true && !!s.licenseKey;
      chrome.storage.local.get([SUB_PAUSE_KEY, SUB_RENEW_KEY], (d0) => {
        const p = d0 && d0[SUB_PAUSE_KEY];
        clearTimeout(_subHintTimer);
        if (viaProxy && p && p.fp === subKeyFp(s.licenseKey) && Date.now() < p.until) {
          const renewed = d0[SUB_RENEW_KEY]?.until === p.until;
          const copied = renewed && d0[SUB_RENEW_KEY].copied === true;
          txt.textContent = t(copied ? "panel.sub.renewed.copied" : renewed ? "panel.sub.renewed" : BUILD === "store" ? "panel.sub.expired.store" : "panel.sub.expired", state.uiLang);
          btn.textContent = t(renewed ? "panel.sub.btn.options" : "panel.sub.btn", state.uiLang);
          box.style.display = "flex";
          btn.dataset.faiAction = renewed ? "options" : "pricing";
          _subPauseUntil = p.until;
          wireHintBtn(btn);
          _subHintTimer = setTimeout(refreshSetupHintNow, p.until - Date.now() + 1e3);
          return;
        }
        if (BUILD === "store") box.style.display = "none";
      });
      return;
    }
    chrome.storage.local.get("fansly_trial_state", (d) => {
      const ts = d && d.fansly_trial_state;
      if (ts && ts.closed) {
        const tg = ts.closed === "tg";
        txt.textContent = t(tg ? "panel.trial.closed.tg" : "panel.trial.closed.code", state.uiLang);
        btn.textContent = t(tg ? "panel.trial.btn.tg" : "panel.trial.btn.where", state.uiLang);
        box.style.display = "flex";
        btn.dataset.faiAction = "trial";
        wireHintBtn(btn);
        showCodeRow(!tg);
        return;
      }
      showCodeRow(false);
      const key = !ai && !tr ? "panel.setup.both" : !ai ? "panel.setup.ai" : "panel.setup.translate";
      txt.textContent = t(key, state.uiLang);
      btn.textContent = t("panel.setup.btn", state.uiLang);
      box.style.display = "flex";
      btn.dataset.faiAction = "options";
      wireHintBtn(btn);
    });
  }
  function showCodeRow(show) {
    const row = document.getElementById("fai-code-row");
    if (!row) return;
    row.style.display = show ? "flex" : "none";
    if (!show || row.dataset.faiWired) return;
    row.dataset.faiWired = "1";
    const inp = document.getElementById("fai-code-input");
    const btn = document.getElementById("fai-code-btn");
    inp.placeholder = t("panel.trial.code.hint", state.uiLang);
    btn.textContent = t("panel.trial.code.btn", state.uiLang);
    const send = () => {
      const code = (inp.value || "").trim().slice(0, 32);
      if (!code) return;
      btn.disabled = true;
      const say = (key) => {
        const t2 = document.getElementById("fai-setup-hint-text");
        if (t2) t2.textContent = t(key, state.uiLang);
      };
      say("panel.trial.code.sending");
      sendSafe({ type: "REDEEM_TRIAL_CODE", code }).then((r) => {
        btn.disabled = false;
        if (r && r.ok) {
          inp.value = "";
          showCodeRow(false);
          say("panel.trial.code.ok");
          return;
        }
        const map = {
          trial_code_unknown: "panel.trial.code.bad",
          trial_code_used: "panel.trial.code.used",
          trial_code_expired: "panel.trial.code.expired",
          trial_code_paused: "panel.trial.code.paused"
        };
        say(map[r && r.code] || "panel.trial.code.fail");
      }).catch(() => {
        btn.disabled = false;
        say("panel.trial.code.fail");
      });
    };
    btn.addEventListener("click", send);
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") send();
    });
  }
  async function copyLicenseKey() {
    const key = String((await getSettingsAsync().catch(() => null) || {}).licenseKey || "").trim();
    if (!key) return false;
    try {
      await navigator.clipboard.writeText(key);
      return true;
    } catch (e) {
      return false;
    }
  }
  function wireHintBtn(btn) {
    if (btn.dataset.faiWired) return;
    btn.dataset.faiWired = "1";
    btn.addEventListener("click", () => {
      if (btn.dataset.faiAction === "trial") {
        sendSafe({ type: "OPEN_TRIAL_PATH" });
        return;
      }
      if (btn.dataset.faiAction === "pricing") {
        copyLicenseKey().then((copied) => {
          sendSafe({ type: "OPEN_PRICING" });
          try {
            chrome.storage.local.set({ [SUB_RENEW_KEY]: { until: _subPauseUntil, copied } });
          } catch (e) {
          }
        });
        return;
      }
      if (btn.dataset.faiAction === "consent") {
        sendSafe({ type: "SAVE_SETTINGS", settings: { masterEnabled: true, privacyDeclinedAt: 0 } });
        try {
          FaiConsent.ask();
        } catch (e) {
        }
        return;
      }
      sendSafe({ type: "OPEN_OPTIONS" });
    });
  }
  function applyOwnerSettings(s) {
    if (!s) return;
    refreshSetupHint(s);
    const _prevUiLang = state.uiLang;
    const _prevNativeLang = state.nativeLang;
    state.uiLang = s.interfaceLanguage || "ru";
    if (typeof FaiLock !== "undefined") FaiLock.init({ lang: state.uiLang, skipWhen: () => !!state._pultActive });
    state.nativeLang = s.nativeLanguage || "ru";
    state.creatorGender = s.creatorGender || "female";
    state.collectDossier = s.collectDossier !== false;
    const _prevMasterOn = state._masterInit ? state.masterEnabled !== false : null;
    state._masterInit = true;
    state.masterEnabled = s.masterEnabled !== false;
    state.translatorEnabled = s.translatorEnabled !== false;
    state.translateContext = s.translateContext !== false;
    state.notificationsEnabled = s.notificationsEnabled === true;
    const _master = state.masterEnabled;
    const _pnl = document.getElementById("fansly-ai-panel");
    const _show = _master && s.panelHidden !== true;
    if (_pnl) _pnl.style.display = _show && !state._pultActive ? "" : "none";
    if (_show && _initialized && state._panelShown === false && extractContactIdFromUrl()) activateForContact();
    if (_show && state._panelShown === false) state._outreachClosed = false;
    state._panelShown = _show;
    if (_initialized) {
    }
    if (_prevUiLang !== state.uiLang) refreshPanelI18n();
    if (_prevNativeLang !== state.nativeLang) {
      clearTimeout(state._retransTimer);
      state._retransTimer = setTimeout(() => {
        state.transCache.clear();
        retranslateHistory();
      }, 3e3);
    }
    let _consentNow = false;
    try {
      _consentNow = !!(s.privacyConsentAt && (s.privacyConsentRev | 0) >= (FaiConsent.REV | 0));
    } catch (e) {
    }
    if (state._consentWas === false && _consentNow) retranslateHistory();
    state._consentWas = _consentNow;
  }
  function refreshPanelI18n() {
    const panel = document.getElementById("fansly-ai-panel");
    updatePanelContact();
    if (state.contactData) {
      renderDossier();
    }
    if (panel && typeof applyI18n === "function") applyI18n(panel, state.uiLang);
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const randInt = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
  async function getSettingsAsync() {
    const r = await sendSafe({ type: "GET_SETTINGS" });
    return r?.result || {};
  }
  function escapeHtmlC(s) {
    return String(s || "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
  }
  function setNightStatus(msg) {
    const el = document.getElementById("fai-night-status");
    if (el) el.textContent = msg;
    const pel = document.getElementById("fai-pult-status");
    if (pel) pel.textContent = msg;
  }
  function isExtensionAlive() {
    try {
      return !!chrome.runtime?.id;
    } catch (e) {
      return false;
    }
  }
  let _ctxDeadShown = false;
  function notifyContextDead() {
    if (_ctxDeadShown) return;
    _ctxDeadShown = true;
    try {
      const inPult = !!document.getElementById("fai-pult-dim");
      const k = inPult && typeof PULT_BOX_SCALE !== "undefined" ? PULT_BOX_SCALE : 1;
      const px = (n) => Math.round(n * k) + "px";
      const b = document.createElement("div");
      b.id = "fai-ctx-dead";
      b.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#e91e8c;color:#fff;font-weight:700;font-size:" + px(16) + ";line-height:1.35;font-family:-apple-system,system-ui,sans-serif;padding:" + px(14) + " " + px(18) + ";text-align:center;cursor:pointer;box-shadow:0 4px 18px rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;gap:" + px(14) + ";flex-wrap:wrap";
      const txt = document.createElement("span");
      txt.textContent = t("panel.ctxDead.banner", state.uiLang);
      const btn = document.createElement("span");
      btn.textContent = t("panel.ctxDead.btn", state.uiLang);
      btn.style.cssText = "background:#fff;color:#c2185b;border-radius:" + px(9) + ";padding:" + px(7) + " " + px(16) + ";font-weight:800;white-space:nowrap";
      b.append(txt, btn);
      b.addEventListener("click", () => location.reload());
      document.body.appendChild(b);
    } catch (e) {
    }
  }
  window.addEventListener("error", (e) => {
    if (/context invalidated/i.test(e?.message || "")) notifyContextDead();
  });
  function mediaMarkText(type) {
    if (!type) return "";
    const k = { photo: "common.media.photo", video: "common.media.video", audio: "common.media.audio", gif: "common.media.gif", blurred: "common.media.blurred", bundle: "common.media.bundle", media: "common.media.attachment" }[type] || "common.media.attachment";
    return "[" + t(k, state.uiLang) + "]";
  }
  function replyQuoteStr(reply) {
    if (!reply) return "";
    const label = t(reply.isMine ? "common.reply.toYours" : "common.reply.toHis", state.uiLang);
    const mark = reply.mediaType ? mediaMarkText(reply.mediaType) + " " : "";
    const txt = (reply.text || "").replace(/\s+/g, " ").trim();
    const short = txt.length > 50 ? txt.slice(0, 50) + "\u2026" : txt;
    return `${label}: ${(mark + short).trim()}`;
  }
  function replyGenders(reply) {
    return reply.isMine ? outGenders() : inGenders();
  }
  function replyCached(reply) {
    if (!reply || !reply.text || state.translatorEnabled === false) return reply;
    trCtxChatSync();
    const tr = state.transCache.get(tcKey(reply.text, replyGenders(reply)));
    return tr != null ? { ...reply, text: tr } : reply;
  }
  async function replyTranslated(reply) {
    if (!reply || !reply.text) return reply;
    const tr = await translateForOwner(reply.text, replyGenders(reply));
    return tr ? { ...reply, text: tr } : reply;
  }
  function appendMessageToHistory(entry) {
    const history = document.getElementById("fai-chat-history");
    if (!history) return null;
    const empty = history.querySelector(".fai-empty-history");
    if (empty) empty.remove();
    const msg = document.createElement("div");
    const mediaMark = mediaMarkText(entry.mediaType);
    const replyNow = entry.reply ? replyCached(entry.reply) : null;
    const replyHtml = replyNow ? `<div class="fai-msg-reply">\u21A9 ${escapeHtmlC(replyQuoteStr(replyNow))}</div>` : "";
    if (entry.isMedia) {
      msg.className = `fai-msg media ${entry.role}`;
      msg.innerHTML = `${replyHtml}
        <div class="fai-msg-name">${entry.role === "subscriber" ? escapeHtmlC(state.currentContact) || t("common.subFallback", state.uiLang) : t("common.you", state.uiLang)}</div>
        <div class="fai-msg-text">${mediaMark || "\u{1F4CE}"}</div>`;
    } else {
      msg.className = `fai-msg ${entry.role}`;
      const name = entry.role === "subscriber" ? escapeHtmlC(state.currentContact) || t("common.subFallback", state.uiLang) : t("common.you", state.uiLang);
      const markAttr = mediaMark ? ` data-media-mark="${mediaMark}"` : "";
      const textHtml = mediaMark ? `${mediaMark} ${escapeHtmlC(entry.text)}` : escapeHtmlC(entry.text);
      msg.innerHTML = `${replyHtml}
        <div class="fai-msg-name">${name} \xB7 ${timeStr(entry.timestamp)}</div>
        <div class="fai-msg-text"${markAttr}>${textHtml}</div>`;
    }
    history.appendChild(msg);
    if (entry.reply && entry.reply.text && replyNow === entry.reply) {
      replyTranslated(entry.reply).then((r) => {
        const el = msg.querySelector(".fai-msg-reply");
        if (el && r !== entry.reply) el.textContent = "\u21A9 " + replyQuoteStr(r);
      }).catch(() => {
      });
    }
    scrollHistoryToBottom();
    return msg;
  }
  function scrollHistoryToBottom() {
    const h = document.getElementById("fai-chat-history");
    if (h) h.scrollTop = h.scrollHeight;
  }
  const PANEL_REV = "2026-10-16.1";
  function createPanel() {
    const existing = document.getElementById("fansly-ai-panel");
    if (existing) {
      if (existing.dataset.faiRev === PANEL_REV) return;
      existing.remove();
    }
    const panel = document.createElement("div");
    panel.id = "fansly-ai-panel";
    panel.dataset.faiRev = PANEL_REV;
    panel.innerHTML = `
      <!-- \u0428\u0430\u043F\u043A\u0430: \u0421\u041B\u0415\u0412\u0410 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u0444\u0430\u043D\u0435 (\u043D\u0438\u043A, \u043F\u043E\u043B, \u043F\u043B\u0430\u0442\u043D\u044B\u0439, \u044F\u0437\u044B\u043A), \u0421\u041F\u0420\u0410\u0412\u0410 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043D\u0430\u0434 \u043F\u0430\u043D\u0435\u043B\u044C\u044E.
           \u0420\u0430\u043D\u044C\u0448\u0435 \u0438\u043D\u0434\u0438\u043A\u0430\u0442\u043E\u0440\u044B \u0438 \u043A\u043D\u043E\u043F\u043A\u0438 \u0448\u043B\u0438 \u043E\u0434\u043D\u0438\u043C \u0440\u044F\u0434\u043E\u043C \u2014 \xAB\u0440\u044F\u0434 \u0437\u0430\u0433\u0430\u0434\u043E\u0447\u043D\u044B\u0445 \u0438\u043A\u043E\u043D\u043E\u043A\xBB (\u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15).
           \u0420\u043E\u0431\u043E\u0442 \u{1F916} \u0443\u0431\u0440\u0430\u043D \u0441\u043E\u0432\u0441\u0435\u043C: \u0430\u0441\u0441\u043E\u0446\u0438\u0430\u0446\u0438\u044F \u0441 \u0431\u043E\u0442\u043E\u043C \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0440\u0435\u0447\u0438\u0442 \u043F\u043E\u0437\u0438\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430. -->
      <div class="fai-header" id="fai-header">
        <span class="fai-contact" id="fai-contact-name" data-i18n="panel.contact.selectChat">\u0412\u044B\u0431\u0435\u0440\u0438 \u0447\u0430\u0442</span>
        <span class="fai-header-info" id="fai-header-info">
          <!-- \u26A0\uFE0F \u0431\u0435\u0437 data-i18n-title: \u0442\u0443\u043B\u0442\u0438\u043F \u0434\u0438\u043D\u0430\u043C\u0438\u0447\u0435\u0441\u043A\u0438\u0439 (\u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u043E\u043B + \u0447\u0442\u043E \u0441\u0434\u0435\u043B\u0430\u0435\u0442 \u043A\u043B\u0438\u043A), \u0435\u0433\u043E \u0441\u0442\u0430\u0432\u0438\u0442
               updateGenderBtn \u2014 applyI18n \u0438\u043D\u0430\u0447\u0435 \u0437\u0430\u0442\u0438\u0440\u0430\u043B \u0431\u044B \u0435\u0433\u043E \u0441\u0442\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439 -->
          <button class="fai-header-btn" id="fai-fan-gender" title="\u041F\u043E\u043B \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0430">\u{1F468}</button>
          <button class="fai-header-btn fai-status-star" id="fai-subscribed" data-i18n-title="panel.btn.subscribed.title" title="\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438">\u2606</button>
          <span id="fai-tier" style="font-size:9px;color:#9ad;max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span>
          <button class="fai-header-btn fai-lang-btn" id="fai-fan-lang" data-i18n-title="panel.btn.fanLang.title" title="\u042F\u0437\u044B\u043A \u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0430">EN</button>
        </span>
        <span class="fai-stats-badge" id="fai-stats">0</span>
        <div class="fai-header-actions">
          
          <button class="fai-header-btn" id="fai-collapse-btn" data-i18n-title="panel.btn.collapse.title" title="\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C">\u25B2</button>
          <button class="fai-header-btn" id="fai-close-btn" data-i18n-title="panel.btn.close.title" title="\u0417\u0430\u043A\u0440\u044B\u0442\u044C">\xD7</button>
        </div>
      </div>
      <!-- \u041F\u043E\u043A\u0430 \u043A\u043B\u044E\u0447 \u043D\u0435 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D, \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0434\u0451\u0442 \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u043C Google, \u0430 \u0418\u0418 \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0432\u043E\u0432\u0441\u0435 \u2014 \u0438 \u0447\u0435\u043B\u043E\u0432\u0435\u043A \u043E\u0431
           \u044D\u0442\u043E\u043C \u041D\u0415 \u0417\u041D\u0410\u0415\u0422: \u043E\u043D \u0432\u0438\u0434\u0438\u0442 \u043F\u0440\u043E\u0441\u0442\u043E \xAB\u0442\u0430\u043A \u0441\u0435\u0431\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\xBB \u0438 \u0434\u0435\u043B\u0430\u0435\u0442 \u0432\u044B\u0432\u043E\u0434 \u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0435 (\u0436\u0438\u0432\u043E\u0439 \u0441\u043B\u0443\u0447\u0430\u0439 \u0441
           \u0442\u0435\u0441\u0442\u0435\u0440\u043E\u043C, Alex 2026-08-19). \u041F\u043E\u044D\u0442\u043E\u043C\u0443 \u043F\u043B\u0430\u0448\u043A\u0430, \u0430 \u043D\u0435 \u0442\u0435\u043A\u0441\u0442: \u0440\u0430\u0441\u0447\u0451\u0442 \u043D\u0430 \u0442\u043E, \u0447\u0442\u043E \u0447\u0438\u0442\u0430\u0442\u044C \u043D\u0435 \u0431\u0443\u0434\u0443\u0442, \u0430
           \u043A\u043D\u043E\u043F\u043A\u0443 \u0443\u0432\u0438\u0434\u044F\u0442. \u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0435\u0451 \u043D\u0435\u043B\u044C\u0437\u044F \u043D\u0430\u043C\u0435\u0440\u0435\u043D\u043D\u043E \u2014 \u043E\u043D\u0430 \u0438 \u0442\u0430\u043A \u0438\u0441\u0447\u0435\u0437\u0430\u0435\u0442, \u043A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043A\u043B\u044E\u0447 \u043F\u043E\u044F\u0432\u0438\u043B\u0441\u044F, \u0430
           \u043A\u0440\u0435\u0441\u0442\u0438\u043A \u043E\u0437\u043D\u0430\u0447\u0430\u043B \u0431\u044B \u0440\u043E\u0432\u043D\u043E \u0442\u043E\u0442 \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0439, \u043E\u0442 \u043A\u043E\u0442\u043E\u0440\u043E\u0433\u043E \u043B\u0435\u0447\u0438\u043C\u0441\u044F: \u0437\u0430\u043A\u0440\u044B\u043B \u043D\u0435 \u0433\u043B\u044F\u0434\u044F \u0438 \u0441\u043F\u0438\u0441\u0430\u043B \u043D\u0430 \u043F\u0440\u043E\u0434\u0443\u043A\u0442.
           Build-neutral: \u0432 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A\u0435 (store) \u043E\u043D\u0430 \u0433\u043E\u0432\u043E\u0440\u0438\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u2014 \u043E\u0431\u0435\u0449\u0430\u0442\u044C \u0442\u0430\u043C \u0418\u0418 \u043D\u0435\u0447\u0435\u0441\u0442\u043D\u043E. -->
      <div class="fai-setup-hint" id="fai-setup-hint" style="display:none">
        <span id="fai-setup-hint-text"></span>
        <button id="fai-setup-hint-btn" type="button"></button>
      </div>
      <!-- \u0412\u0432\u043E\u0434 \u043A\u043E\u0434\u0430 \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u044F. \u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u0422\u041E\u041B\u042C\u041A\u041E \u043A\u043E\u0433\u0434\u0430 \u0441\u0435\u0440\u0432\u0435\u0440 \u0437\u0430\u043A\u0440\u044B\u043B \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0432\u044B\u0434\u0430\u0447\u0443 \u0438 \u043D\u0430\u0437\u0432\u0430\u043B
           \u043F\u0443\u0442\u044C \xAB\u043A\u043E\u0434\xBB: \u0434\u043E \u044D\u0442\u043E\u0433\u043E \u043C\u043E\u043C\u0435\u043D\u0442\u0430 \u043F\u043E\u043B\u044F \u043D\u0435\u0442 \u0432\u043E\u0432\u0441\u0435, \u0447\u0442\u043E\u0431\u044B \u043D\u0435 \u0441\u043F\u0440\u0430\u0448\u0438\u0432\u0430\u0442\u044C \u0442\u043E, \u0447\u0435\u0433\u043E \u0443 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 \u043D\u0435\u0442 \u0438 \u043D\u0435
           \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C. \u041A\u043E\u0434 \u0432\u0432\u043E\u0434\u0438\u0442\u0441\u044F \u0417\u0414\u0415\u0421\u042C, \u0430 \u043D\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435: \u043F\u0443\u0442\u044C \xAB\u043F\u043B\u0430\u0448\u043A\u0430 \u2192 \u0441\u0430\u0439\u0442 \u2192 \u043A\u043B\u044E\u0447 \u2192 \u0432\u0441\u0442\u0430\u0432\u044C \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438\xBB
           \u044D\u0442\u043E \u0442\u0440\u0438 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0430 \u0438 \u043A\u043E\u043F\u0438\u043F\u0430\u0441\u0442\u0430 \u0434\u043B\u044F \u0442\u043E\u0433\u043E, \u043A\u0442\u043E \u0435\u0449\u0451 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0437\u0430\u043F\u043B\u0430\u0442\u0438\u043B (Alex 2026-09-02). -->
      <div class="fai-setup-hint" id="fai-code-row" style="display:none">
        <input id="fai-code-input" type="text" autocomplete="off" spellcheck="false">
        <button id="fai-code-btn" type="button"></button>
      </div>
      
      <!-- \u0421\u041F\u0420\u0410\u0412\u041A\u0410 \u041E \u0424\u0410\u041D\u0415: \u0434\u043E\u0441\u044C\u0435 + CRM-\u043F\u043E\u0440\u0442\u0440\u0435\u0442 + \u0431\u0440\u0438\u0444 \u043F\u043E\u0434 \u043E\u0434\u043D\u043E\u0439 \u0441\u0432\u0451\u0440\u0442\u043A\u043E\u0439 \u0441 \u043E\u0434\u043D\u043E\u0441\u0442\u0440\u043E\u0447\u043D\u044B\u043C \u0441\u0430\u043C\u043C\u0430\u0440\u0438.
           \u0420\u0430\u043D\u044C\u0448\u0435 \u044D\u0442\u043E \u0431\u044B\u043B\u0438 \u0442\u0440\u0438 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0435 \u0441\u0435\u043A\u0446\u0438\u0438 \u0441 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0430\u043C\u0438 \u0442\u043E\u0433\u043E \u0436\u0435 \u0432\u0435\u0441\u0430, \u0447\u0442\u043E \u0438 \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u0437\u043E\u043D\u0430, \u0438 \u043F\u044F\u0442\u044C
           \u0431\u043B\u043E\u043A\u043E\u0432 \u043A\u043E\u043D\u043A\u0443\u0440\u0438\u0440\u043E\u0432\u0430\u043B\u0438 \u0437\u0430 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u0435 (\u0434\u0438\u0437\u0430\u0439\u043D-\u0440\u0435\u0432\u044C\u044E 2026-08-15). \u0420\u0430\u0431\u043E\u0447\u0430\u044F \u0437\u043E\u043D\u0430 \u2014 \u043B\u0435\u043D\u0442\u0430, \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B,
           \u043F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 \u2014 \u0442\u0435\u043F\u0435\u0440\u044C \u043D\u0438\u0447\u0435\u043C \u043D\u0435 \u043F\u0435\u0440\u0435\u043A\u0440\u044B\u0432\u0430\u0435\u0442\u0441\u044F. \u0420\u0430\u0437\u043C\u0435\u0442\u043A\u0430 \u0432\u043D\u0443\u0442\u0440\u0438 \u041D\u0415 \u043C\u0435\u043D\u044F\u043B\u0430\u0441\u044C: id \u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0438 \u0446\u0435\u043B\u044B. -->
      <div class="fai-about" id="fai-about">
        <div class="fai-about-head" id="fai-about-head">
          <span class="fai-about-title" data-i18n="panel.about.title">\u0421\u043F\u0440\u0430\u0432\u043A\u0430 \u043E \u0444\u0430\u043D\u0435</span>
          <span class="fai-about-sum" id="fai-about-sum"></span>
          <span class="fai-about-caret" id="fai-about-caret">\u25B8</span>
        </div>
        <div class="fai-about-body" id="fai-about-body" style="display:none">
      <div class="fai-dossier" id="fai-dossier">
        <div class="fai-dossier-header" id="fai-dossier-toggle">
          <span id="fai-closeness-badge" class="fai-closeness" title="new">\u{1F331}</span>
          <span class="fai-dossier-label" data-i18n="panel.dossier.label">\u0434\u043E\u0441\u044C\u0435</span>
          <span id="fai-facts-count" class="fai-facts-count"></span>
          
          <button class="fai-dossier-btn" id="fai-dossier-btn">\u25BE</button>
        </div>
        <div class="fai-dossier-body" id="fai-dossier-body" style="display:none">
          <div id="fai-facts-list" class="fai-facts-list"></div>
          <div class="fai-dossier-add">
            <input type="text" id="fai-fact-input" data-i18n-ph="panel.fact.add.ph" placeholder="\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0444\u0430\u043A\u0442...">
            <button id="fai-fact-add-btn" class="fai-fact-add-btn">+</button>
          </div>
        </div>
      </div>
      
      
        </div><!-- /fai-about-body -->
      </div><!-- /fai-about -->
      <div class="fai-body" id="fai-body">
        <div class="fai-chat-history" id="fai-chat-history">
          <div class="fai-empty-history" data-i18n="panel.history.empty">\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0438 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u0437\u0434\u0435\u0441\u044C</div>
        </div>
        
        <!-- \xAB\u{1F4AC}\xBB \u0440\u044F\u0434\u043E\u043C \u0441 \u043F\u043E\u043B\u0435\u043C \u043E\u0442\u0432\u0435\u0442\u0430, \u0430 \u043D\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u043F\u043E\u043B\u043E\u0441\u043E\u0439 (Alex 2026-08-22): \u0446\u0435\u043B\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u043F\u043E\u0434 \u043E\u0434\u043D\u0443 \u043A\u043D\u043E\u043F\u043A\u0443
             \u0441\u044A\u0435\u0434\u0430\u043B\u0430 \u0432\u044B\u0441\u043E\u0442\u0443 \u043F\u0430\u043D\u0435\u043B\u0438. \u0417\u0434\u0435\u0441\u044C \u0436\u0435 \u0438 \u0441\u043C\u044B\u0441\u043B\u043E\u0432\u0430\u044F \u043F\u0430\u0440\u0430: \u0441\u043B\u0435\u0432\u0430 \u043F\u0438\u0448\u0435\u0448\u044C \u0444\u0430\u043D\u0443, \u0441\u043F\u0440\u0430\u0432\u0430 \u2014 \u043E\u0431\u0441\u0443\u0436\u0434\u0430\u0435\u0448\u044C \u0441 \u0418\u0418. -->
        <div class="fai-input-area">
          <textarea id="fai-custom-input" data-i18n-ph="panel.custom.ph" placeholder="\u0421\u0432\u043E\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442..."></textarea>
          <button class="fai-send-btn" id="fai-coach-toggle" data-i18n-title="panel.coach.toggle.title" title="\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C/\u0440\u0430\u0437\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u043E\u0431\u0441\u0443\u0436\u0434\u0435\u043D\u0438\u0435" style="display:none;background:#2a2540;color:#c9b8ff;border:1px solid #3a3560">\u25BE</button>
          <button class="fai-send-btn" id="fai-coach-btn" data-i18n-title="panel.coach.title" title="\u041E\u0431\u0441\u0443\u0434\u0438\u0442\u044C \u044D\u0442\u043E\u0442 \u0434\u0438\u0430\u043B\u043E\u0433 \u0441 \u0418\u0418" style="background:#2a2540;color:#c9b8ff;border:1px solid #3a3560">\u{1F4AC}</button>
          <button class="fai-send-btn" id="fai-send-btn">\u2191</button>
        </div>
        <div class="fai-status" id="fai-status"></div>
      </div>
    `;
    if (typeof applyI18n === "function") applyI18n(panel, state.uiLang || "ru");
    chrome.storage.local.get([CONFIG.POS_KEY], (result) => applyPanelGeometry(panel, result[CONFIG.POS_KEY]));
    new ResizeObserver(() => {
      if (!isExtensionAlive()) {
        notifyContextDead();
        return;
      }
      savePanelGeometry(panel);
    }).observe(panel);
    document.body.appendChild(panel);
    bindPanelEvents(panel);
    if (state._panelShown === false || state._pultActive) panel.style.display = "none";
    makeDraggable(panel);
    if (typeof refreshUpdateBanner === "function") refreshUpdateBanner();
    if (typeof refreshTgAlertBanner === "function") refreshTgAlertBanner();
    if (typeof refreshPultOff === "function") refreshPultOff();
    if (typeof refreshLayoutBanner === "function") refreshLayoutBanner();
    console.log("[FanslyAI] Panel created v0.3 \u2713");
  }
  function bindPanelEvents(panel) {
    const LANGS = ["EN", "ES", "PT", "DE", "FR", "IT", "PL", "TR", "RU", "UK"];
    document.getElementById("fai-dossier-toggle").addEventListener("click", (e) => {
      if (e.target.closest("#fai-fact-input, #fai-fact-add-btn")) return;
      const body = document.getElementById("fai-dossier-body");
      const btn = document.getElementById("fai-dossier-btn");
      const open = body.style.display !== "none";
      body.style.display = open ? "none" : "block";
      btn.textContent = open ? "\u25BE" : "\u25B4";
    });
    const addFact = () => {
      const input = document.getElementById("fai-fact-input");
      const fact = input.value.trim();
      if (!fact || !state.contactData) return;
      if (!state.contactData.dossier) {
        state.contactData.dossier = { facts: [], closeness: "new", topics: [], lastMessageAt: null };
      }
      const dd = state.contactData.dossier;
      if (!dd.factDates) dd.factDates = {};
      if (!dd.manualFacts) dd.manualFacts = [];
      if (!dd.facts.includes(fact)) {
        if (dd.manualFacts.length >= PINNED_MAX) {
          setStatus(t("panel.dossier.pin.limit", state.uiLang, { n: PINNED_MAX }));
          setTimeout(() => setStatus(""), 5e3);
          return;
        }
        dd.facts.push(fact);
        dd.factDates[fact] = Date.now();
        if (!dd.manualFacts.includes(fact)) dd.manualFacts.push(fact);
        saveContact(state.currentContact, { dossier: dd });
        renderDossier();
      }
      input.value = "";
    };
    document.getElementById("fai-fact-add-btn").addEventListener("click", addFact);
    document.getElementById("fai-fact-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addFact();
      }
    });
    document.getElementById("fai-fan-gender").addEventListener("click", () => {
      state.fanGender = state.fanGender === "male" ? "female" : "male";
      updateGenderBtn();
      if (state.contactData) state.contactData.gender = state.fanGender;
      if (state.currentContact) saveContact(state.currentContact, { gender: state.fanGender });
      setStatus(t("panel.status.fanGender", state.uiLang, { gender: t(state.fanGender === "male" ? "common.gender.male" : "common.gender.female", state.uiLang) }));
      setTimeout(() => setStatus(""), 1500);
    });
    if (BUILD === "full") {
      const _sb0 = document.getElementById("fai-subscribed");
      if (_sb0) {
        _sb0.style.cursor = "default";
        _sb0.title = t(subTitleKey(!!state.contactData?.isSubscribed), state.uiLang);
      }
    }
    document.getElementById("fai-subscribed").addEventListener("click", () => {
      if (BUILD === "full") return;
      const current = state.contactData?.isSubscribed || false;
      const next = !current;
      if (state.contactData) state.contactData.isSubscribed = next;
      const btn = document.getElementById("fai-subscribed");
      btn.textContent = next ? "\u2B50" : "\u2606";
      btn.title = t(next ? "panel.sub.title.on" : "panel.sub.title.off", state.uiLang);
      if (state.currentContact) saveContact(state.currentContact, { isSubscribed: next });
      setStatus(t(next ? "panel.status.subscribedOn" : "panel.status.subscribedOff", state.uiLang));
      setTimeout(() => setStatus(""), 1500);
    });
    document.getElementById("fai-fan-lang").addEventListener("click", () => {
      const currentLang = (state.contactData?.lang || "en").toUpperCase();
      const idx = LANGS.indexOf(currentLang);
      const next = LANGS[(idx + 1) % LANGS.length];
      const nextLower = next.toLowerCase();
      if (state.contactData) state.contactData.lang = nextLower;
      document.getElementById("fai-fan-lang").textContent = next;
      if (state.currentContact) saveContact(state.currentContact, { lang: nextLower });
      setStatus(t("panel.status.fanLang", state.uiLang, { lang: next }));
      setTimeout(() => setStatus(""), 1500);
    });
    document.getElementById("fai-about-head")?.addEventListener("click", aboutToggle);
    applyAboutOpen();
    document.getElementById("fai-collapse-btn").addEventListener("click", () => {
      const collapsed = panel.classList.toggle("collapsed");
      document.getElementById("fai-collapse-btn").textContent = collapsed ? "\u25BC" : "\u25B2";
    });
    document.getElementById("fai-close-btn").addEventListener("click", () => {
      panel.style.display = "none";
      persistSetting("panelHidden", true);
    });
    document.getElementById("fai-send-btn").addEventListener("click", () => {
      const input = document.getElementById("fai-custom-input");
      const text = input.value.trim();
      if (text) {
        panelSend(text);
        input.value = "";
      }
    });
    document.getElementById("fai-custom-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        document.getElementById("fai-send-btn").click();
      }
    });
  }
  const PANEL_MARGIN = 12;
  function panelWidthCap() {
    return Math.max(Math.round(window.innerWidth * 0.48), 480);
  }
  function panelDefaultGeometry() {
    const width = Math.max(320, Math.min(760, panelWidthCap(), window.innerWidth - PANEL_MARGIN * 2));
    const height = Math.max(320, window.innerHeight - PANEL_MARGIN * 2);
    return {
      width: width + "px",
      height: height + "px",
      left: Math.max(0, window.innerWidth - width - PANEL_MARGIN) + "px",
      top: PANEL_MARGIN + "px"
    };
  }
  function clampPanelIntoView(panel) {
    if (!panel || panel.style.display === "none") return;
    const collapsed = panel.classList.contains("collapsed");
    const w = Math.min(panel.offsetWidth, panelWidthCap(), Math.max(280, window.innerWidth - PANEL_MARGIN));
    if (w !== panel.offsetWidth) panel.style.width = w + "px";
    if (!collapsed) {
      const h = Math.min(panel.offsetHeight, Math.max(200, window.innerHeight - PANEL_MARGIN));
      if (h !== panel.offsetHeight) panel.style.height = h + "px";
    }
    const l = parseInt(panel.style.left), tp = parseInt(panel.style.top);
    panel.style.left = Math.max(0, Math.min(isNaN(l) ? 0 : l, window.innerWidth - w)) + "px";
    panel.style.top = Math.max(0, Math.min(isNaN(tp) ? 0 : tp, Math.max(0, window.innerHeight - 60))) + "px";
  }
  function applyPanelGeometry(panel, saved) {
    const g = saved && saved.left && saved.top ? saved : panelDefaultGeometry();
    panel.style.right = "auto";
    panel.style.bottom = "auto";
    panel.style.left = g.left;
    panel.style.top = g.top;
    if (g.width) panel.style.width = g.width;
    if (g.height && !panel.classList.contains("collapsed")) panel.style.height = g.height;
    clampPanelIntoView(panel);
  }
  let _geomSaveTimer = null;
  function savePanelGeometry(panel) {
    if (!isExtensionAlive()) return;
    clearTimeout(_geomSaveTimer);
    _geomSaveTimer = setTimeout(() => {
      if (!isExtensionAlive()) return;
      chrome.storage.local.get([CONFIG.POS_KEY], (d) => {
        const next = { ...d[CONFIG.POS_KEY] || {}, left: panel.style.left, top: panel.style.top };
        if (!panel.classList.contains("collapsed")) {
          next.width = panel.offsetWidth + "px";
          next.height = panel.offsetHeight + "px";
        }
        chrome.storage.local.set({ [CONFIG.POS_KEY]: next });
      });
    }, 250);
  }
  function makeDraggable(panel) {
    let dragging = false, ox, oy;
    const header = panel.querySelector("#fai-header");
    header.addEventListener("mousedown", (e) => {
      if (e.target.closest("button, input, select, label, a")) return;
      if (e.target.closest("#fai-contact-name span[title]")) return;
      dragging = true;
      panel.classList.add("dragging");
      const rect = panel.getBoundingClientRect();
      ox = e.clientX - rect.left;
      oy = e.clientY - rect.top;
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const maxX = Math.max(0, window.innerWidth - panel.offsetWidth);
      const maxY = Math.max(0, window.innerHeight - panel.offsetHeight);
      panel.style.left = Math.max(0, Math.min(e.clientX - ox, maxX)) + "px";
      panel.style.top = Math.max(0, Math.min(e.clientY - oy, maxY)) + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    });
    document.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      panel.classList.remove("dragging");
      savePanelGeometry(panel);
    });
    window.addEventListener("resize", () => {
      clampPanelIntoView(panel);
      savePanelGeometry(panel);
    });
  }
  function updatePanelContact() {
    const el = document.getElementById("fai-contact-name");
    if (!el) return;
    const name = state.currentContact || t("panel.contact.selectChat", state.uiLang);
    const handle = state.contactData?.handle;
    el.onclick = null;
    el.style.cursor = "";
    el.title = "";
    if (handle) {
      el.textContent = "";
      const link = document.createElement("span");
      link.style.cssText = "cursor:pointer";
      link.title = t("panel.contact.openCrm", state.uiLang);
      link.appendChild(document.createTextNode(name + " "));
      const hn = document.createElement("span");
      hn.className = "fai-handle";
      hn.textContent = "@" + handle;
      link.appendChild(hn);
      link.onclick = () => sendSafe({ type: "CRM_OPEN", handle });
      el.appendChild(link);
    } else {
      el.textContent = name;
    }
  }
  function updateStats() {
    const el = document.getElementById("fai-stats");
    if (el) el.textContent = state.chatHistory.length;
  }
  function setStatus(msg) {
    const el = document.getElementById("fai-status");
    if (el) el.textContent = msg;
  }
  function sendSafe(msg) {
    if (!isExtensionAlive()) return Promise.resolve(null);
    try {
      return chrome.runtime.sendMessage(msg).catch(() => null);
    } catch (e) {
      return Promise.resolve(null);
    }
  }
  async function translateOutgoing(text, fanLang, chatId = null) {
    if (await new Promise((r2) => {
      try {
        chrome.storage.local.get("fansly_dbg_trfail", (d) => r2(!!(d && d.fansly_dbg_trfail)));
      } catch (e) {
        r2(false);
      }
    })) {
      try {
        chrome.storage.local.remove("fansly_dbg_trfail");
      } catch (e) {
      }
      console.warn("[FanslyAI] \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430: \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0433\u043E \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F (__faiTrFailNext)");
      return null;
    }
    const ctx = trContextOut(chatId);
    const r = await sendSafe({ type: "TRANSLATE", text, targetLang: fanLang, ...outGenders(), ...ctx ? { ctx } : {} });
    return r && r.success && typeof r.result === "string" && r.result.trim() ? r.result : null;
  }
  window.__faiTrFailNext = function() {
    chrome.storage.local.set({ fansly_dbg_trfail: Date.now() });
    return "\u0432\u0437\u0432\u0435\u0434\u0435\u043D\u043E: \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0433\u043E \u043D\u0435 \u0443\u0434\u0430\u0441\u0442\u0441\u044F \u043E\u0434\u0438\u043D \u0440\u0430\u0437 (\u043A\u043D\u043E\u043F\u043A\u0430 \u2191 \u043F\u0430\u043D\u0435\u043B\u0438 \u0438\u043B\u0438 \u043E\u0442\u0432\u0435\u0442 \u0438\u0437 \u0422\u0413, \u0432 \u043B\u044E\u0431\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435)";
  };
  function setNativeValue(el, value) {
    el.value = value;
  }
  async function humanTypeAndSend(text, msPerWord = 700, opts = {}) {
    if (!isExtensionAlive()) return "aborted";
    if (PLATFORM === "onlyfans") return ONLYFANS.setAndSend(text);
    if (state.typingNow) {
      console.log("[FanslyAI] \u043F\u0435\u0447\u0430\u0442\u044C \u0443\u0436\u0435 \u0438\u0434\u0451\u0442, \u043F\u0440\u043E\u043F\u0443\u0441\u043A");
      return "busy";
    }
    state.typingNow = true;
    try {
      return await _humanType(text, msPerWord, opts);
    } finally {
      state.typingNow = false;
    }
  }
  const PANEL_SEND_FAIL = { "translate-failed": "panel.status.translateFailed", "busy": "panel.status.sendBusy", "no-field": "panel.status.sendNoField", "wrong-chat": "panel.status.sendWrongChat" };
  async function panelSend(text) {
    clearSendFailed();
    const expectId = state.currentContactId || null;
    const status = await humanTypeAndSend(text, carousel.settings?.nightMsPerWord || 700, { manual: true, expectId });
    const key = PANEL_SEND_FAIL[status];
    if (key || status === "aborted") {
      const input = document.getElementById("fai-custom-input");
      if (input && !input.value.trim()) input.value = text;
    }
    if (key) setStatus(t(key, state.uiLang));
    else if (status === "aborted" && !isExtensionAlive()) notifyContextDead();
    return status;
  }
  function clearSendFailed() {
    const el = document.getElementById("fai-status");
    if (el && Object.values(PANEL_SEND_FAIL).some((k) => el.textContent === t(k, state.uiLang))) setStatus("");
  }
  function countOwnMessages() {
    try {
      return [...qa("messageNode")].filter((n) => PLAT.isOwn(n)).length;
    } catch (e) {
      return -1;
    }
  }
  async function waitSendConfirmed(ownBefore, textarea, expectId) {
    let clearedAt = -1;
    for (let i = 0; i < 20; i++) {
      await sleep(250);
      if (expectId && state.currentContactId !== expectId) return false;
      if (ownBefore >= 0 && countOwnMessages() > ownBefore) return true;
      if (!textarea.value && clearedAt < 0) clearedAt = i;
      if (clearedAt >= 0 && i - clearedAt >= 8) return true;
    }
    return clearedAt >= 0;
  }
  async function _humanType(text, msPerWord = 700, opts = {}) {
    if (!isExtensionAlive()) return "aborted";
    const wrongChat = () => !!(opts.expectId && (state.currentContactId !== opts.expectId || extractContactIdFromUrl() !== opts.expectId));
    const aborted = () => (opts.manual ? !isExtensionAlive() : !carousel.running) || wrongChat();
    const bail = (why) => {
      try {
        const el = q("textarea");
        if (el && el.value && text.startsWith(el.value)) {
          setNativeValue(el, "");
          el.dispatchEvent(new InputEvent("input", { bubbles: true }));
        }
      } catch (e) {
      }
      return why;
    };
    const fanLang = state.contactData?.lang || "en";
    if (!opts.skipTranslate && fanLang && fanLang !== state.nativeLang) {
      const tr = await translateOutgoing(text, fanLang, opts.expectId || null);
      if (tr == null) return "translate-failed";
      text = tr;
    }
    if (wrongChat()) return "wrong-chat";
    const textarea = q("textarea");
    if (!textarea) {
      return "no-field";
    }
    const words = text.split(/(\s+)/);
    const cap = 25e3;
    const perWord = Math.min(msPerWord, Math.floor(cap / Math.max(1, text.split(/\s+/).length)));
    textarea.focus();
    setNativeValue(textarea, "");
    textarea.dispatchEvent(new InputEvent("input", { bubbles: true }));
    if (document.hidden && (typeof _keepAliveCtx === "undefined" || _keepAliveCtx?.state !== "running")) {
      await new Promise((res) => setTimeout(res, Math.min(perWord * 3, 6e3)));
      if (aborted()) return bail(wrongChat() ? "wrong-chat" : "aborted");
      setNativeValue(textarea, text);
      textarea.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
    } else {
      let cur = "";
      for (let i = 0; i < words.length; i++) {
        if (aborted()) return bail(wrongChat() ? "wrong-chat" : "aborted");
        cur += words[i];
        setNativeValue(textarea, cur);
        textarea.dispatchEvent(new InputEvent("input", { bubbles: true, data: words[i] }));
        if (words[i].trim()) {
          await new Promise((res) => setTimeout(res, perWord + Math.random() * perWord * 0.4));
        }
      }
    }
    state.suppressUntil = Date.now() + 2500;
    await new Promise((res) => setTimeout(res, 300 + Math.random() * 250));
    if (wrongChat()) return bail("wrong-chat");
    const ownBefore = countOwnMessages();
    textarea.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      bubbles: true,
      cancelable: true
    }));
    await sleep(150);
    if (textarea.value.length > 0) {
      if (wrongChat()) return bail("wrong-chat");
      const btn = q("sendBtn");
      if (btn) btn.click();
    }
    return await waitSendConfirmed(ownBefore, textarea, opts.expectId) ? "sent" : "unconfirmed";
  }
  async function init() {
    if (!isExtensionAlive()) {
      notifyContextDead();
      return;
    }
    console.log("[FanslyAI] init()");
    try {
      sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
      });
      if (!state._settingsListener) {
        state._settingsListener = true;
        chrome.storage.onChanged.addListener((ch, area) => {
          if (area !== "local") return;
          if (ch.fansly_ai_settings) {
            sendSafe({ type: "GET_SETTINGS" }).then((r) => {
              if (r?.result) applyOwnerSettings(r.result);
            });
          }
          if (ch[SUB_PAUSE_KEY] || ch[SUB_RENEW_KEY]) refreshSetupHintNow();
        });
      }
      if (!state._heartbeatTimer) {
        faiHeartbeat();
        state._heartbeatTimer = setInterval(faiHeartbeat, 5 * 60 * 1e3);
      }
      createPanel();
      sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
        if (state.masterEnabled !== false && !extractContactIdFromUrl()) {
          waitForElement(selStr("contactLink"), 8e3).then((first) => {
            if (first) PLAT.openRow(first);
          }).catch(() => {
          });
        }
      });
      await waitForElement(selStr("textarea"), 3e4);
      await new Promise((r) => setTimeout(r, 800));
      detectContact();
      watchContactChanges();
      watchContactList();
      if (extractContactIdFromUrl()) activateForContact();
      _initialized = true;
      console.log("[FanslyAI] \u2713 Ready v0.3");
      sendSafe({ type: "GET_SETTINGS" }).then((r) => {
        if (r?.result) applyOwnerSettings(r.result);
      });
    } catch (err) {
      if (!isExtensionAlive()) {
        notifyContextDead();
        return;
      }
      if ((err.message || "").startsWith("Timeout")) {
        console.log("[FanslyAI] init: \u0436\u0434\u0443 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u0447\u0430\u0442\u0430\u2026");
      } else console.error("[FanslyAI] Init error:", err.message);
      if (PLAT.isMessagesPage()) setTimeout(init, 5e3);
    }
  }
  let _lastUrl = location.href;
  let _initPending = false;
  function syncPanelsToRoute() {
  }
  function onUrlChange(newUrl) {
    if (!isExtensionAlive()) {
      notifyContextDead();
      return;
    }
    syncPanelsToRoute();
    if (_initPending) return;
    const isMessaging = PLAT.isMessagesPage(newUrl);
    if (!isMessaging) {
      _initialized = false;
      return;
    }
    if (_initialized) return;
    _initPending = true;
    _initialized = false;
    if (state.observer) {
      state.observer.disconnect();
      state.observer = null;
    }
    state.active = false;
    setTimeout(() => {
      _initPending = false;
      init();
    }, 1500);
  }
  setInterval(() => {
    const cur = location.href;
    if (cur !== _lastUrl) {
      _lastUrl = cur;
      onUrlChange(cur);
    }
  }, 300);
  if (PLAT.isMessagesPage()) {
    init();
  }
})();
